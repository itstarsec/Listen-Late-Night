#!/usr/bin/env node
import {readFile,writeFile} from 'node:fs/promises';import assert from 'node:assert/strict';
const arg=process.argv[2];if(!arg)throw Error('Usage: node tools/verify-live.mjs https://NEW_SITE_ORIGIN [report.json]');
const url=new URL(arg);if(url.origin!==arg||url.protocol!=='https:')throw Error('Pass an exact HTTPS origin without a trailing slash.');
if(['listen-night.holyleesin.chatgpt.site','listen-night.exactlamp6.chatgpt.site','nh4c.pages.dev'].includes(url.hostname))throw Error('This verifier is for the new independent Site, not the original.');
const snapshot=JSON.parse(await readFile(new URL('../data/runtime-snapshot.json',import.meta.url),'utf8'));
const catalogue=JSON.parse(await readFile(new URL('../data/catalogue.json',import.meta.url),'utf8')).collections;
const get=async p=>{const r=await fetch(arg+p,{signal:AbortSignal.timeout(30000),redirect:'manual'});assert.equal(r.status,200,p);return r.json();};
const cs=(await get('/api/collections')).collections;assert.equal(cs.length,catalogue.length);
for(const p of catalogue){const c=cs.find(x=>x.slug===p.slug);assert.ok(c,p.slug);for(const k of ['name','count','category'])assert.deepEqual(c[k],p[k],p.slug+' '+k);}
let cursor=0;
await Promise.all(Array.from({length:3},async()=>{while(cursor<snapshot.tables.sessions.length){const old=snapshot.tables.sessions[cursor++],a=(await get('/api/sessions/'+encodeURIComponent(old.slug))).session;assert.equal(a.name,old.name);assert.equal(a.version,old.version);assert.deepEqual(a.tracks.map(({videoId,addedAt})=>({videoId,addedAt})),JSON.parse(old.tracks),old.slug);}}));
const all=(await get('/api/library')).session;assert.equal(all.sourceCount,73);assert.equal(all.totalEntries,2476);assert.equal(all.tracks.length,2305);assert.equal(new Set(all.tracks.map(t=>t.videoId)).size,all.tracks.length);
const first=(await get('/api/sessions/bim')).session;assert.equal(first.tracks.length,25);assert.deepEqual((await get('/api/sessions/bim')).session,first);
const lite=await fetch(arg+'/lite?s=bim',{signal:AbortSignal.timeout(20000),redirect:'manual'});assert.equal(lite.status,200);assert.match(await lite.text(),/listen-lite\.js/);
const result={verifiedAt:new Date().toISOString(),origin:arg,sessions:75,publicPlaylists:73,publicEntries:2476,publicUniqueVideos:2305,bimTracks:25,sessionNamesVersionsOrderAndAddedAtMatched:true,repeatedReadStable:true,liteRoute:200,scope:'HTTP data/readback only; browser playback and admin sign-in require separate QA.'};
if(process.argv[3])await writeFile(process.argv[3],JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
