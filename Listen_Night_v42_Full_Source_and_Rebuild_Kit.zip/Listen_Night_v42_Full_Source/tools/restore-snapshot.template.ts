// Used only by a new, independent clone. No schema changes and no HTTP writer.
import snapshot from '../data/runtime-snapshot.json';

export const SNAPSHOT_MARKER = '__RESTORE_MARKER__';
const guardMarker = SNAPSHOT_MARKER + ':transaction';
const columns = {
 video_blocks:['video_id','reason','source','evidence','confirmed_at'],
 sessions:['slug','name','owner_id','tracks','version','last_request','created_at','updated_at'],
 metadata:['video_id','title','channel','thumbnail','status','expires_at'],
 playlist_imports:['owner_id','request_id','slug','fingerprint','report','created_at'],
 video_checks:['video_id','checked_at','next_check_at','outcome','reason','source','failures','first_failed_at','reported_at'],
 video_removals:['id','video_id','slug','playlist_name','position','track','removed_at'],
 maintenance_runs:['id','started_at','finished_at','summary'],
 maintenance_daily:['day','checked'],
 seeds:['key'],
} as const;
type Table = keyof typeof columns;
const tables = Object.keys(columns) as Table[];
const pending = new WeakMap<D1Database, Promise<void>>();

async function restore(db:D1Database) {
 if(await db.prepare('SELECT key FROM seeds WHERE key=?').bind(SNAPSHOT_MARKER).first()) return;
 // D1 batch is atomic. A competing completed restore is a no-op. An existing
 // database without this receipt fails the NOT NULL constraint before writes.
 const occupied = tables.map(t=>`EXISTS (SELECT 1 FROM "${t}" LIMIT 1)`).join(' OR ');
 const statements:D1PreparedStatement[] = [db.prepare(`INSERT INTO seeds (key) SELECT CASE WHEN ${occupied} THEN NULL ELSE ? END WHERE NOT EXISTS (SELECT 1 FROM seeds WHERE key=?)`).bind(guardMarker,SNAPSHOT_MARKER)];
 const data = snapshot.tables as unknown as Record<Table,Record<string,unknown>[]>;
 for(const table of tables) {
  const fields=columns[table],rows=data[table];
  if(!Array.isArray(rows)) throw Error('Missing snapshot table');
  for(let i=0;i<rows.length;i+=200) {
   const names=fields.map(c=>`"${c}"`).join(',');
   const values=fields.map(c=>`json_extract(value,'$.${c}')`).join(',');
   statements.push(db.prepare(`INSERT INTO "${table}" (${names}) SELECT ${values} FROM json_each(?) WHERE NOT EXISTS (SELECT 1 FROM seeds WHERE key=?)`).bind(JSON.stringify(rows.slice(i,i+200)),SNAPSHOT_MARKER));
  }
 }
 statements.push(db.prepare('INSERT OR IGNORE INTO seeds (key) VALUES (?)').bind(SNAPSHOT_MARKER));
 statements.push(db.prepare('DELETE FROM seeds WHERE key=?').bind(guardMarker));
 await db.batch(statements);
 if(!await db.prepare('SELECT key FROM seeds WHERE key=?').bind(SNAPSHOT_MARKER).first()) throw Error('Snapshot receipt was not saved');
}

export function ensureSnapshotRestored(db:D1Database):Promise<void> {
 let operation=pending.get(db);
 if(!operation) {
  operation=restore(db).catch(error=>{pending.delete(db);throw error;});
  pending.set(db,operation);
 }
 return operation;
}
