#!/usr/bin/env python3
import hashlib,json,pathlib,sys
root=pathlib.Path(__file__).resolve().parent.parent
manifest=json.loads((root/'INTEGRITY.json').read_text())
bad=[]
for rel,expected in manifest['files'].items():
 p=root/rel
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:bad.append(rel)
if bad:raise SystemExit('Checksum mismatch: '+', '.join(bad))
print(json.dumps({'verifiedFiles':len(manifest['files']),'sourceFiles':len(manifest['sourceFiles']),'sourceVersion':42,'sourceCommit':manifest['sourceCommit']}))
