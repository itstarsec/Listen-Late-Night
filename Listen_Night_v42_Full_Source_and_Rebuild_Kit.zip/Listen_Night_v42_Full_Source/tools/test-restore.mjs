#!/usr/bin/env node
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
const target=path.resolve(process.argv[2]||'');
if(!process.argv[2])throw Error('Usage: node tools/test-restore.mjs /absolute/prepared-site');
process.chdir(target);
const require=createRequire(path.join(target,'package.json')),ts=require('typescript');
const snapshot=JSON.parse(await readFile('data/runtime-snapshot.json','utf8'));
const catalogue=JSON.parse(await readFile(new URL('../data/catalogue.json',import.meta.url),'utf8')).collections;
const input=await readFile('lib/restore-snapshot.ts','utf8');
const compiled=ts.transpileModule(input,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,resolveJsonModule:true}}).outputText
 .replace("'../data/runtime-snapshot.json'",JSON.stringify(pathToFileURL(path.join(target,'data/runtime-snapshot.json')).href)+' with {type:"json"}');
await mkdir('.sites-runtime/tests',{recursive:true});
await writeFile('.sites-runtime/tests/restore-snapshot.mjs',compiled);
const {ensureSnapshotRestored,SNAPSHOT_MARKER}=await import(pathToFileURL(path.join(target,'.sites-runtime/tests/restore-snapshot.mjs')));
const {D1}=await import(pathToFileURL(path.join(target,'tests/test-db.mjs')));
const {handleApi}=await import(pathToFileURL(path.join(target,'.sites-runtime/tests/api.mjs')));
const {createPasswordHash}=await import(pathToFileURL(path.join(target,'.sites-runtime/tests/auth.mjs')));
const db=new D1();
await Promise.all([ensureSnapshotRestored(db),ensureSnapshotRestored(db)]);
for(const [table,rows] of Object.entries(snapshot.tables)){
 const actual=db.raw.prepare(`SELECT * FROM "${table}"`).all();
 assert.equal(actual.length,rows.length+(table==='seeds'?1:0),table);
 const filtered=actual.filter(r=>table!=='seeds'||r.key!==SNAPSHOT_MARKER).map(r=>({...r}));
 const sort=xs=>xs.map(r=>JSON.stringify(Object.fromEntries(Object.entries(r).sort()))).sort();
 assert.deepEqual(sort(filtered),sort(rows),table+' all fields');
}
assert.equal(db.raw.prepare('SELECT count(*) n FROM auth_sessions').get().n,0);
const env={DB:db,AUTH_USERNAME:'exportfixture',AUTH_PASSWORD_HASH:await createPasswordHash('fixture-pass-for-export'),AUTH_ADDITIONAL_ADMINS:JSON.stringify([{username:'exportfixture2',passwordHash:await createPasswordHash('second-fixture-pass')}])};
const api=async(p,method='GET',data,extra={})=>{
 const r=await handleApi(new Request('https://restore.test/api'+p,{method,headers:{Origin:'https://restore.test','Content-Type':'application/json',...extra},...(data===undefined?{}:{body:JSON.stringify(data)})}),env);
 return {status:r.status,body:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};
};
const collections=await api('/collections');assert.equal(collections.status,200);assert.equal(collections.body.collections.length,73);
for(const p of catalogue){const c=collections.body.collections.find(c=>c.slug===p.slug);assert.equal(c.name,p.name);assert.equal(c.count,p.count);assert.equal(c.category,p.category);}
const all=(await api('/library')).body.session;assert.equal(all.sourceCount,73);assert.equal(all.totalEntries,2476);assert.equal(all.tracks.length,2305);
for(const old of snapshot.tables.sessions){const r=await api('/sessions/'+old.slug);assert.equal(r.status,200);const s=r.body.session;assert.equal(s.version,old.version);assert.equal(s.name,old.name);assert.deepEqual(s.tracks.map(({videoId,addedAt})=>({videoId,addedAt})),JSON.parse(old.tracks));}
const original=(await api('/sessions/bim')).body.session;assert.equal(original.tracks.length,25);
for(const [username,password]of [['exportfixture','fixture-pass-for-export'],['exportfixture2','second-fixture-pass']]){
 const signed=await api('/auth/login','POST',{username,password});assert.equal(signed.status,200);assert.ok(signed.cookie);
 const auth={cookie:signed.cookie};const admin=await api('/admin/playlists','GET',undefined,auth);assert.equal(admin.status,200);assert.equal(admin.body.playlists.length,75);
 const slug='export-qa-'+(username.endsWith('2')?'two':'one');const created=await api('/sessions','POST',{slug,name:'Export QA'},auth);assert.equal(created.status,201);
 let s=created.body.session;
 const added=await api('/sessions/'+slug+'/tracks','POST',{text:'w8r5zDA4awM\ninvalid line\nhttps://youtu.be/w8r5zDA4awM\nTSTexport01'},{...auth,'If-Match':String(s.version),'X-Request-ID':'export-fixture-add-'+username});assert.equal(added.status,200);assert.deepEqual(added.body.report,{added:2,duplicates:1,invalid:1,invalidLines:[2]});
 s=added.body.session;assert.equal((await api('/sessions/'+slug)).body.session.tracks.length,2);
 assert.equal((await api('/sessions/'+slug,'DELETE',undefined,{...auth,'If-Match':String(s.version),'X-Request-ID':'export-fixture-delete-'+username})).status,200);
 assert.equal((await api('/auth/logout','POST',{},auth)).status,200);
}
await ensureSnapshotRestored(db);assert.deepEqual((await api('/sessions/bim')).body.session,original);
const occupied=new D1(),record=snapshot.tables.sessions[0];
occupied.raw.prepare('INSERT INTO sessions (slug,name,owner_id,tracks,version,created_at,updated_at) VALUES (?,?,?,?,?,?,?)').run(record.slug,record.name,record.owner_id,record.tracks,record.version,record.created_at,record.updated_at);
await assert.rejects(ensureSnapshotRestored(occupied));assert.equal(occupied.raw.prepare('SELECT count(*) n FROM sessions').get().n,1);assert.equal(occupied.raw.prepare('SELECT count(*) n FROM metadata').get().n,0);
const broken=new D1(),batch=broken.batch.bind(broken);let fail=true;
broken.batch=async statements=>{if(fail){fail=false;const receipt=statements.find(s=>s.sql==='INSERT OR IGNORE INTO seeds (key) VALUES (?)');receipt.run=async()=>{throw Error('Fixture receipt failure');};}return batch(statements);};
await assert.rejects(ensureSnapshotRestored(broken));assert.equal(broken.raw.prepare('SELECT count(*) n FROM sessions').get().n,0);assert.equal(broken.raw.prepare('SELECT count(*) n FROM seeds').get().n,0);
await ensureSnapshotRestored(broken);assert.equal(broken.raw.prepare('SELECT count(*) n FROM sessions').get().n,75);
console.log(JSON.stringify({restoredSessions:75,publicPlaylists:73,allSessionFieldsMatched:true,publicEntries:2476,publicUniqueVideos:2305,adminAccountsTested:2,bulkImportPersistence:true,idempotency:true,nonemptyDatabaseRefused:true,failedTransactionRolledBackAndRetried:true,originalPlaylistsPreserved:true}));
