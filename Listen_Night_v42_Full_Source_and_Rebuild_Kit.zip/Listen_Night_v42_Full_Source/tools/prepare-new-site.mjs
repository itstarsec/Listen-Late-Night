#!/usr/bin/env node
import {readFile,writeFile,mkdir,readdir,cp} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const kit=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const [destination,...flags]=process.argv.slice(2);
if(!destination||flags.some(f=>f!=='--seed-only')) throw Error('Usage: node tools/prepare-new-site.mjs /absolute/empty/new-site [--seed-only]');
if(!path.isAbsolute(destination)) throw Error('Destination must be absolute.');
const target=path.resolve(destination);
if(target===kit||target.startsWith(kit+path.sep)) throw Error('Choose a destination outside the export kit.');
try { if((await readdir(target)).length) throw Error('Destination must be empty; existing projects are never overwritten.'); }
catch(e) { if(e.code!=='ENOENT') throw e; }
await mkdir(target,{recursive:true});
const integrity=JSON.parse(await readFile(path.join(kit,'INTEGRITY.json'),'utf8'));
for(const [name,expected] of Object.entries(integrity.sourceFiles)) {
 const contents=await readFile(path.join(kit,'source',name));
 if(createHash('sha256').update(contents).digest('hex')!==expected) throw Error('Source checksum mismatch: '+name);
}
for(const name of await readdir(path.join(kit,'source'))) {
 await cp(path.join(kit,'source',name),path.join(target,name),{recursive:true,errorOnExist:true,force:false});
}
const manifestPath=path.join(target,'.openai/hosting.json');
const manifest=JSON.parse(await readFile(manifestPath,'utf8'));
delete manifest.project_id;
await writeFile(manifestPath,JSON.stringify(manifest,null,2)+'\n');
let restoreMarker=null;
if(!flags.includes('--seed-only')) {
 const data=await readFile(path.join(kit,'data/runtime-snapshot.json'));
 const digest=createHash('sha256').update(data).digest('hex');
 if(digest!==integrity.files['data/runtime-snapshot.json']) throw Error('Snapshot checksum mismatch.');
 restoreMarker='listen-snapshot:v42:'+digest;
 await mkdir(path.join(target,'data'),{recursive:true});
 await writeFile(path.join(target,'data/runtime-snapshot.json'),data);
 const template=await readFile(path.join(kit,'tools/restore-snapshot.template.ts'),'utf8');
 await writeFile(path.join(target,'lib/restore-snapshot.ts'),template.replace('__RESTORE_MARKER__',restoreMarker));
 const route=`import { env } from 'cloudflare:workers';
import { handleApi, type Runtime } from '@/lib/api';
import { ensureSnapshotRestored } from '@/lib/restore-snapshot';
export const dynamic = 'force-dynamic';
const handler=async(request:Request)=>{
 const runtime=env as unknown as Runtime;
 try{await ensureSnapshotRestored(runtime.DB);}
 catch{return Response.json({error:'Không thể phục hồi dữ liệu. Bản sao này cần database mới, trống; không ghi đè database đang có dữ liệu.'},{status:503,headers:{'Cache-Control':'no-store'}});}
 return handleApi(request,runtime);
};
export {handler as GET,handler as POST,handler as PATCH,handler as DELETE};
`;
 await writeFile(path.join(target,'app/api/[...path]/route.ts'),route);
}
const info={preparedAt:new Date().toISOString(),mode:restoreMarker?'restore-live-snapshot':'seed-only',sourceVersion:42,sourceCommit:integrity.sourceCommit,projectIdRemoved:true,restoreMarker,notes:'Register a new Site and DB. Set new secrets and ADMIN_ORIGIN. GET /api/collections before connecting maintenance. Never point this clone at the old database.'};
await writeFile(path.join(target,'RESTORE_INFO.json'),JSON.stringify(info,null,2)+'\n');
console.log(JSON.stringify({checkout:target,...info}));
