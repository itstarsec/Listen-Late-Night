# Phục hồi và triển khai Site mới

## 1. Kiểm tra gói

Chạy từ thư mục chứa file này:

```bash
python3 tools/verify-bundle.py
node tools/prepare-new-site.mjs /workspace/sites/listen-night-rebuilt
```

Đích phải mới/trống và ở ngoài thư mục gói. Không có tuỳ chọn ép ghi đè. `source/.openai/hosting.json` vẫn chứa ID cũ để source nguyên bản kiểm chứng được; công cụ chuẩn bị **bỏ ID đó** ở bản sao. Không deploy trực tiếp `source/` với ID cũ.

Nếu chỉ muốn bộ nhạc seed trong source, không muốn dữ liệu đang lưu, thêm `--seed-only`. Chế độ này không phục hồi các session riêng hay các chỉnh sửa runtime. Mặc định nên giữ snapshot.

## 2. Dùng Sites hiện hành

Đọc skill Sites có trong phiên mới, tạo một Site mới và D1 mới, lưu ID thật trả về vào manifest của checkout mới. Khai báo `d1: "DB"`, `r2: null`, `capabilities: ["mcp"]`; giữ tích hợp `sites()` và bốn migration schema gốc.

Không copy `.git`, `node_modules`, `.sites-runtime`, `.wrangler`, `.env` thật hay token. Các thư mục này không nằm trong gói. Gói có lockfile và source build cần thiết. Dùng Node 24 (tối thiểu 22.13) và pnpm 11.25.0/installer của Sites; giữ frozen lockfile, không nâng dependency tự động. Nếu làm local Windows, WSL/Linux phù hợp cho các shell helper; runtime portable có `run-framework.mjs` cho build/dev.

Trong môi trường Sites đã có dependencies, kiểm tra:

```bash
node tests/run.mjs
node node_modules/typescript/bin/tsc --noEmit
node /absolute/path/to/export-kit/tools/test-restore.mjs /workspace/sites/listen-night-rebuilt
```

`test-restore.mjs` yêu cầu các module kiểm thử được `tests/run.mjs` sinh trước đó. Nó chỉ dùng database SQLite in-memory và tài khoản fixture, không kết nối website gốc. Các test ứng dụng gốc vẫn dùng schema trống; snapshot nằm ngoài migration nên không làm hỏng fixture.

Build/package/push/save/deploy bằng helper hiện hành của Sites. Có thể build portable bằng `node scripts/run-framework.mjs build`; artefact chỉ là đầu ra build, không thay thế source.

## 3. Phục hồi dữ liệu một lần

`prepare-new-site.mjs` mặc định chỉ thay manifest/route API ở checkout mới và thêm hai file phục hồi. Toàn bộ CSS, UI, mô hình 3D, player, parser, auth và business API giữ nguyên byte từ source.

Sau khi schema đã được áp dụng, gọi `GET /api/collections` tại Site mới. API wrapper sẽ:

1. Kiểm tra receipt SHA-256 của snapshot trong `seeds`.
2. Nếu đã có receipt: tiếp tục API bình thường, không ghi đè dữ liệu.
3. Nếu chưa có receipt: từ chối nếu bất cứ bảng nghiệp vụ nào đã có dữ liệu.
4. Nếu database trống: dùng một D1 batch nguyên tử để nhập 9 bảng bằng JSON parameter đã bind, ghi receipt và xoá guard tạm.
5. Nếu lưu lỗi: rollback cả batch, trả 503 và cho retry; không có restore HTTP endpoint hay quyền ghi mới.

Các lần gọi đồng thời trong isolate dùng cùng promise; batch trên D1 và receipt bảo vệ giữa các isolate. Không tạo/đổi schema trong request. Không đưa hàng nghìn dòng seed vào migration.

Receipt thêm đúng **một dòng** so với 78 seed markers gốc; 75 session và các trường dữ liệu khác giữ nguyên. Phiên đăng nhập, giới hạn login/IP và khoá tác vụ đang chạy không được phục hồi. Việc mở một request đầu tiên để phục hồi là cần thiết trước khi kết nối MCP hoặc chạy lịch bảo trì.

Nếu nhận 503 vì database đã có dữ liệu, không xoá dữ liệu để ép chạy. Chọn D1 mới/trống cho bản sao, hoặc xử lý merge có chủ đích bằng writer được cấp quyền. Công cụ này dành cho dựng bản sao độc lập.

## 4. Cấu hình đăng nhập

`config/runtime.example.json` là danh sách khoá mẫu, **không được gửi nguyên placeholder vào runtime**.

- `AUTH_USERNAME`: ví dụ `thanhlm`.
- `AUTH_PASSWORD_HASH`: tạo mới bằng `node scripts/hash-password.mjs`, nhập mật khẩu qua stdin ẩn; PBKDF2-SHA256 100.000 vòng, salt ngẫu nhiên.
- `AUTH_ADDITIONAL_ADMINS`: JSON array với `tuantn` và salted hash riêng. Tất cả tài khoản cấu hình cùng quản trị không gian playlist; không có trang tạo tài khoản/RBAC cấp thấp trong v42.
- Đánh dấu các giá trị tài khoản/hash là secret. Không ghi password/hash thật trong prompt, git, ZIP, source hoặc log.
- `ADMIN_ORIGIN`: origin HTTPS thật của Site mới, không slash cuối. Đặt trước khi thử đăng nhập. Không copy hostname Site cũ.
- `APP_ALLOWED_ORIGINS`: để trống nếu không có proxy; nếu có thì dùng origin HTTPS chính xác, không wildcard/path.

Mở `/bim` bằng tab riêng tại origin mới để cookie first-party được lưu. Không bật đăng nhập ChatGPT cho trang quản trị ứng dụng. Cookie Secure/HttpOnly vẫn cần HTTPS. `/bim` và `/?s=bim` là hai chức năng độc lập.

## 5. MCP và lịch bảo trì

Thiết lập secret `MAINTENANCE_OWNER_EMAIL` cho chủ Site mới, `MAINTENANCE_DAILY_LIMIT=360`; `YOUTUBE_API_KEY` tuỳ chọn. Kết nối plugin MCP được Site mới provision bằng OAuth/quyền thực. Không giả header, không dùng token bypass thay writer.

Tạo lại lịch từ `config/video-maintenance-schedule.json` chỉ sau khi Site mới đã phục hồi và writer được xác minh. Lịch dự kiến 03:30 hằng ngày theo Asia/Bangkok. Đây là thời gian giả định ít người dùng, không phải kết luận từ analytics. Lịch cloud và kết nối không được tự clone chỉ bằng ZIP.

Không dùng ID automation/project của Site cũ cho Site mới. Không sửa hoặc xoá lịch đang hoạt động của bản gốc. Nếu MCP/quyền chưa có thì giữ app nghe/quản trị hoạt động và báo phần bảo trì chưa được cấp quyền; không lách auth.

## 6. Xác minh sau publish

```bash
node /absolute/path/to/export-kit/tools/verify-live.mjs https://NEW_SITE_ORIGIN
```

Công cụ từ chối Site gốc, chỉ GET API và kiểm tra snapshot tại Site mới. Sau khi có thay đổi quản trị thật, so sánh với snapshot sẽ không còn là tiêu chí đúng; dùng nó cho nghiệm thu lần đầu.

Kiểm tra bằng browser các luồng trong `FEATURES_AND_ACCEPTANCE.md`, cả `/lite`, quản trị và nghe. Kiểm tra trên thiết bị vật lý khi có, đặc biệt iOS 12.5.8. Không gọi preview metadata/iframe hoặc mock API là đã nghe đủ toàn bài. Quyền nhúng, giới hạn vùng, quảng cáo, autoplay và phát nền thuộc YouTube/trình duyệt.
