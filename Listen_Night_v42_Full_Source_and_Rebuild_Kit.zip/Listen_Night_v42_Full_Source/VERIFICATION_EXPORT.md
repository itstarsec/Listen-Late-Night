# Kết quả kiểm tra gói xuất · 01/11/2026

## Đã thực hiện

- Xác nhận Sites v42 trỏ commit `ed82cca0f6055c8de85adb401048bbffd0f89537`, trùng HEAD checkout sạch.
- Xuất **209 file tracked** bằng Git archive. Đối chiếu SHA-256 với bản source trong gói; không chọn file bằng glob dễ bỏ sót vendor/build/compat.
- Đọc đủ 9 bảng nghiệp vụ bằng quyền owner/read-only của Sites: sessions75, seeds78, metadata2355, playlist_imports2, video_checks367, video_blocks0, video_removals0, maintenance_runs21, maintenance_daily2.
- 20 mảng tracks bị giới hạn độ dài trong projection được đọc đầy đủ lại qua session API. Cả 75 session khớp version, tên, updatedAt tại lúc đối chiếu; mảng tracks parse được đầy đủ và không trùng ID trong session. Không coi projection bị cắt là backup đầy đủ.
- Tạo checkout mới từ công cụ đóng gói; bỏ project ID cũ. Tất cả file UI/CSS/3D/auth/business API giữ nguyên; chỉ manifest và wrapper API route thay, thêm module/data phục hồi và RESTORE_INFO.
- **163/163** test ứng dụng gốc đạt trong checkout đã chuẩn bị. TypeScript `--noEmit` đạt.
- Kiểm tra phục hồi bằng SQLite/D1 adapter: mọi trường của 9 bảng khớp snapshot, ngoại trừ thêm một receipt vào seeds theo thiết kế; 75 session đọc qua API đúng tên/version/thứ tự/addedAt; catalogue73; public2.476 vị trí/2.305 video.
- Hai tài khoản **fixture** đăng nhập, xem admin75, tạo playlist, nhập URL trùng/lỗi, đọc lại dữ liệu, xoá playlist fixture và logout thành công. Không sử dụng hoặc xuất credential production.
- Restore lặp/concurrent trong một isolate không nhân đôi; database không trống bị từ chối. Lỗi tại bước ghi receipt rollback toàn batch, retry thành công. Sửa đổi sau phục hồi không bị reset.
- Build Vinext portable từ checkout đã chuẩn bị hoàn tất, gồm wrapper phục hồi và snapshot JSON. Các chunk lớn cảnh báo như kiến trúc gốc, không có lỗi build.
- Công cụ từ chối ghi đè checkout đang có nội dung. Website gốc vẫn ở commit v42, không sửa source/database, không publish lại, không thay secret/audience/lịch.
- ZIP được kiểm tra CRC và checksum toàn bộ file trước bàn giao.

## Giới hạn của lần kiểm tra này

- Checkout QA dùng dependencies đã cài trong môi trường hiện tại, không thử một lượt tải package hoàn toàn mới từ registry. Gói có package.json và frozen lockfile để cài lại; không chứa node_modules hoặc binary runtime.
- Không tạo/deploy Site mới trong yêu cầu xuất file này. D1 phục hồi được kiểm tra bằng SQLite adapter và build Worker, chưa phải xác nhận transaction đó chạy trên D1 production của một Site mới.
- Không tạo lại kết nối MCP hoặc automation của Site mới; gói chứa template và hướng dẫn cấp quyền/tạo lịch. Lịch gốc không thay đổi.
- Không chạy browser/device QA mới vì không sửa giao diện website. Gói có nguyên các tests, assets và tài liệu kiểm tra lịch sử. Đây không phải chứng nhận phát âm thanh, WebGL FPS hoặc Safari/iPad/Android vật lý.
- Snapshot được đọc nhiều trang và có đối chiếu session, không phải bản chụp transaction toàn database tại cùng một thời điểm.
- Không xuất auth_sessions, giới hạn login/IP, khoá bảo trì tạm, mật khẩu/hash thật, secrets, OAuth token, cookie hoặc localStorage. Chúng được thiết lập mới; chức năng đăng nhập được giữ nguyên source.
- YouTube, registry package và nền tảng hosting là dịch vụ bên ngoài. Không bảo đảm bỏ quảng cáo, phát nền/khóa màn hình, mọi vùng/quyền nhúng hay hạ tầng tương lai không thay đổi.

Source/UI nội bộ được giữ nguyên theo checksum, dữ liệu snapshot có đủ để phục hồi. Cần hoàn tất cấu hình runtime, quyền và nghiệm thu trên Site đích như hướng dẫn trước khi gọi bản sao là vận hành hoàn chỉnh.
