import type {Metadata} from 'next';
import {env} from 'cloudflare:workers';
import AdminEntry from '../admin-entry';

export const metadata:Metadata={title:'Listen · Quản lý playlist',robots:{index:false,follow:false}};
export const dynamic='force-dynamic';
export default function AdminPage(){
 const value=(env as unknown as {ADMIN_ORIGIN?:string}).ADMIN_ORIGIN;
 let canonicalOriginBase64:string|undefined;
 try{if(value){const origin=new URL(value.trim());if(origin.protocol==='https:'&&!origin.username&&!origin.password&&origin.origin===value.trim())canonicalOriginBase64=btoa(origin.origin);}}catch{}
 // Serialize without a literal URL so reverse proxies that rewrite hostnames in
 // HTML cannot silently rewrite the configured administration destination.
 return <AdminEntry canonicalOriginBase64={canonicalOriginBase64}/>;
}
