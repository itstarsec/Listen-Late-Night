import type { Metadata, Viewport } from 'next';
import './globals.css';
import {COMPATIBILITY_BOOTSTRAP} from '@/lib/browser-support';
export const metadata: Metadata = { title:'Listen — Không gian nghe nhạc', description:'Bàn đĩa 3D, những playlist dành cho đêm muộn và âm nhạc YouTube trong một không gian riêng.',icons:{icon:'/favicon.svg'} };
export const viewport:Viewport={width:'device-width',initialScale:1,viewportFit:'cover',themeColor:'#121314'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="vi"><head><script dangerouslySetInnerHTML={{__html:COMPATIBILITY_BOOTSTRAP}}/></head><body>{children}</body></html>;}
