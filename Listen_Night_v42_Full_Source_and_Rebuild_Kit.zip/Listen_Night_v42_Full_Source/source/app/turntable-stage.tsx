'use client';
import {useEffect,useRef} from 'react';
import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {createTurntableModel,type ConsoleAction} from '@/lib/turntable-model';
import {initialMotion,stepMotion,motionSettled,type TurntableSignal} from '@/lib/turntable-motion';
export type StageProps={
  signal:TurntableSignal;title:string;channel:string;autoRotate:boolean;interactive:boolean;resetKey:number;
  onAction:(action:ConsoleAction)=>void;onFailure:(reason:string)=>void;
};
export default function TurntableStage(props:StageProps){
  const mount=useRef<HTMLDivElement>(null),latest=useRef(props),wake=useRef<()=>void>(()=>{});latest.current=props;
  useEffect(()=>{wake.current();},[props.signal,props.autoRotate,props.interactive,props.resetKey,props.title,props.channel]);
  useEffect(()=>{
    const root=mount.current;if(!root)return;
    let renderer:THREE.WebGLRenderer|undefined,controls:OrbitControls|undefined,model:ReturnType<typeof createTurntableModel>|undefined;
    let frame=0,disposed=false,inView=true,previousTime=0,lastRender=0,motion=initialMotion(),lastLabel='',lastReset=latest.current.resetKey,orbitTail=0;
    let down:{x:number;y:number;id:number}|null=null,hovered:THREE.Mesh|null=null,pressed:THREE.Mesh|null=null;
    const lowPower=(navigator as Navigator&{deviceMemory?:number}).deviceMemory!<4||matchMedia('(max-width: 700px)').matches;
    const coarse=matchMedia('(pointer: coarse)').matches;const touchFirst=()=>coarse||matchMedia('(max-width: 900px)').matches;
    const textures:THREE.Texture[]=[];
    const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-4.5,4.5,3.0,-3.0,.1,100);
    const startPosition=new THREE.Vector3(7.6,7.7,9.1),target=new THREE.Vector3(0,.30,0);camera.position.copy(startPosition);camera.lookAt(target);
    const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
    let resizeObserver:ResizeObserver|undefined,observer:IntersectionObserver|undefined;
    const cleanups:(()=>void)[]=[];
    function listen(target:EventTarget,type:string,fn:EventListener,options?:AddEventListenerOptions){target.addEventListener(type,fn,options);cleanups.push(()=>target.removeEventListener(type,fn,options));}
    const cleanup=()=>{if(disposed)return;disposed=true;cancelAnimationFrame(frame);wake.current=()=>{};resizeObserver?.disconnect();observer?.disconnect();for(const off of cleanups)off();controls?.dispose();model?.dispose();for(const texture of textures)texture.dispose();scene.clear();renderer?.dispose();renderer?.domElement.remove();};
    function fail(){cleanup();latest.current.onFailure('WebGL không khả dụng. Chế độ nhẹ vẫn giữ đầy đủ điều khiển nhạc.');}
    try{
      renderer=new THREE.WebGLRenderer({antialias:!lowPower,alpha:true,powerPreference:'low-power'});
      renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,lowPower?1.2:1.5));renderer.outputColorSpace=THREE.SRGBColorSpace;
      renderer.setClearColor(0x000000,0);renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;
      const canvas=renderer.domElement;canvas.setAttribute('aria-hidden','true');root.appendChild(canvas);
      const labelCanvas=document.createElement('canvas');labelCanvas.width=labelCanvas.height=512;const context=labelCanvas.getContext('2d');
      const labelTexture=new THREE.CanvasTexture(labelCanvas);labelTexture.colorSpace=THREE.SRGBColorSpace;textures.push(labelTexture);
      model=createTurntableModel({lowPower,labelTexture});scene.add(model.group);
      scene.add(new THREE.HemisphereLight('#f1eadd','#141719',2.0));
      const key=new THREE.DirectionalLight('#eee8df',3.6);key.position.set(-3,8,5);scene.add(key);
      const edge=new THREE.DirectionalLight('#9cb0bc',1.2);edge.position.set(5,4,-4);scene.add(edge);
      // A small radial opacity texture supplies contact depth without shadow maps or bloom.
      const shadowCanvas=document.createElement('canvas');shadowCanvas.width=shadowCanvas.height=128;const sc=shadowCanvas.getContext('2d');
      if(sc){const gradient=sc.createRadialGradient(64,64,8,64,64,64);gradient.addColorStop(0,'rgba(0,0,0,.64)');gradient.addColorStop(.65,'rgba(0,0,0,.30)');gradient.addColorStop(1,'rgba(0,0,0,0)');sc.fillStyle=gradient;sc.fillRect(0,0,128,128);}
      const shadowTexture=new THREE.CanvasTexture(shadowCanvas);textures.push(shadowTexture);
      const shadowGeo=new THREE.PlaneGeometry(8.6,6.4),shadowMat=new THREE.MeshBasicMaterial({map:shadowTexture,transparent:true,depthWrite:false,opacity:.70});
      const shadow=new THREE.Mesh(shadowGeo,shadowMat);shadow.rotation.x=-Math.PI/2;shadow.position.y=-.052;scene.add(shadow);cleanups.push(()=>{shadowGeo.dispose();shadowMat.dispose();});
      controls=new OrbitControls(camera,canvas);controls.target.copy(target);controls.enableZoom=false;controls.enablePan=false;controls.enableDamping=true;controls.dampingFactor=.075;
      controls.minPolarAngle=Math.PI*.19;controls.maxPolarAngle=Math.PI*.38;controls.minAzimuthAngle=-.18;controls.maxAzimuthAngle=1.28;controls.autoRotateSpeed=.30;controls.update();controls.saveState();
      controls.addEventListener('change',()=>{orbitTail=18;request();});
      controls.addEventListener('start',()=>{orbitTail=25;request();});
      const resize=()=>{if(!renderer||disposed)return;const {width,height}=root.getBoundingClientRect();if(width<1||height<1)return;const aspect=width/height;const halfWidth=aspect<1.2?3.9:4.1;const halfHeight=halfWidth/aspect;camera.left=-halfWidth;camera.right=halfWidth;camera.top=halfHeight;camera.bottom=-halfHeight;camera.updateProjectionMatrix();renderer.setSize(width,height,false);request();};
      resizeObserver=new ResizeObserver(resize);resizeObserver.observe(root);resize();
      const hit=(e:PointerEvent)=>{const r=canvas.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);raycaster.setFromCamera(pointer,camera);return raycaster.intersectObjects(model!.actionTargets,false)[0]?.object as THREE.Mesh|undefined;};
      const pointerDown=(event:Event)=>{const e=event as PointerEvent;if(e.button!==0||touchFirst()&&!latest.current.interactive)return;down={x:e.clientX,y:e.clientY,id:e.pointerId};pressed=hit(e)||null;if(pressed)pressed.position.y=Number(pressed.userData.baseY)-.018;request();};
      const pointerUp=(event:Event)=>{const e=event as PointerEvent;const start=down;down=null;if(pressed)pressed.position.y=Number(pressed.userData.baseY);pressed=null;request();if(!start||start.id!==e.pointerId||Math.hypot(e.clientX-start.x,e.clientY-start.y)>6)return;const object=hit(e);if(object?.userData.action)latest.current.onAction(object.userData.action as ConsoleAction);};
      const pointerMove=(event:Event)=>{if(touchFirst()&&!latest.current.interactive)return;const object=hit(event as PointerEvent)||null;if(object===hovered)return;if(hovered)(hovered.material as THREE.MeshStandardMaterial).emissive.setHex(0);hovered=object;if(hovered)(hovered.material as THREE.MeshStandardMaterial).emissive.set('#3d2814');canvas.style.cursor=hovered?'pointer':'grab';request();};
      const cancelPointer=()=>{down=null;if(pressed)pressed.position.y=Number(pressed.userData.baseY);pressed=null;if(hovered)(hovered.material as THREE.MeshStandardMaterial).emissive.setHex(0);hovered=null;request();};
      listen(canvas,'pointerdown',pointerDown);listen(window,'pointerup',pointerUp);listen(canvas,'pointermove',pointerMove);listen(canvas,'pointerleave',cancelPointer);listen(canvas,'pointercancel',cancelPointer);
      listen(canvas,'webglcontextlost',event=>{event.preventDefault();fail();});
      listen(document,'visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;previousTime=0;}else request();});
      observer=new IntersectionObserver(entries=>{inView=entries[0]?.isIntersecting??true;if(!inView){cancelAnimationFrame(frame);frame=0;previousTime=0;}else request();},{rootMargin:'40px'});observer.observe(root);
      function updateLabel(title:string,channel:string){if(!context)return;context.fillStyle='#d98f4a';context.fillRect(0,0,512,512);context.strokeStyle='rgba(46,27,11,.4)';context.lineWidth=2;for(const radius of [204,211,228]){context.beginPath();context.arc(256,256,radius,0,Math.PI*2);context.stroke();}context.fillStyle='#34271a';context.textAlign='center';context.font='600 25px sans-serif';context.fillText('LISTEN / SELECTED',256,136);context.font='500 23px sans-serif';const short=title.length>27?title.slice(0,26)+'…':title;context.fillText(short,256,341,370);context.font='18px sans-serif';context.fillText(channel.slice(0,32),256,375,350);context.font='18px monospace';context.fillText('33⅓   ·   LN—01',256,190);labelTexture.needsUpdate=true;}
      function render(now:number){
        frame=0;if(disposed||!inView||document.hidden||!renderer||!model||!controls)return;
        const p=latest.current,limit=lowPower?1000/30:1000/45;
        if(now-lastRender<limit){frame=requestAnimationFrame(render);return;}
        const dt=previousTime?Math.min((now-previousTime)/1000,.08):1/45;previousTime=now;lastRender=now;
        controls.enabled=!touchFirst()||p.interactive;canvas.style.touchAction=touchFirst()&&!p.interactive?'pan-y':'none';
        controls.autoRotate=p.autoRotate&&!p.signal.reducedMotion&&(!touchFirst()||p.interactive);
        if(lastReset!==p.resetKey){lastReset=p.resetKey;controls.reset();camera.position.copy(startPosition);controls.target.copy(target);controls.update();orbitTail=20;}
        motion=stepMotion(motion,p.signal,dt,now/1000);model.disc.rotation.y=-motion.rotation;model.arm.rotation.y=motion.armAngle;model.arm.position.y=.28+motion.armLift;
        model.ledMaterial.emissiveIntensity=motion.light*1.6;model.stylusMaterial.emissiveIntensity=motion.light*.8;model.stylusLight.intensity=lowPower?0:motion.light*.18;
        const label=`${p.signal.videoId}:${p.title}:${p.channel}`;if(lastLabel!==label){lastLabel=label;updateLabel(p.title,p.channel);}
        controls.update();renderer.render(scene,camera);
        orbitTail=Math.max(0,orbitTail-1);
        if(!frame&&((p.signal.playerState===1&&!p.signal.reducedMotion)||(p.signal.playerState===3&&!p.signal.reducedMotion)||!motionSettled(motion,p.signal)||controls.autoRotate||orbitTail>0))frame=requestAnimationFrame(render);
      }
      function request(){if(!disposed&&inView&&!document.hidden&&!frame)frame=requestAnimationFrame(render);}
      wake.current=request;request();
    }catch{fail();}
    return cleanup;
  },[]);
  return <div className="webgl-stage" ref={mount}/>;
}
