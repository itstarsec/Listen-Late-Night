import ListenApp from './listen-app';
export default function Page(){return <ListenApp/>;}
