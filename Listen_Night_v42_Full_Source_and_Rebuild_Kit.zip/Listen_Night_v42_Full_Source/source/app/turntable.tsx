'use client';
import {useEffect,useRef,useState,type ComponentType} from 'react';
import {Box,Hand,RotateCcw,Orbit,LoaderCircle} from 'lucide-react';
import type {ConsoleAction} from '@/lib/turntable-model';
import type {TurntableSignal} from '@/lib/turntable-motion';
import type {StageProps} from './turntable-stage';

/** Also used while the lazy 3D chunk loads and when a WebGL context is lost. */
export function TurntableFallback({playing,title,progress=0,duration=0}:{playing:boolean;title:string;progress?:number;duration?:number}){
 const fraction=duration?Math.min(1,Math.max(0,progress/duration)):0;
 const armTube='M581 123 L555 244 C553 253 548 255 541 260 L523 273';
 return <svg className={`turntable-fallback ${playing?'is-playing':''}`} viewBox="0 0 800 470" role="img" aria-label={`Bàn đĩa ở chế độ nhẹ. ${title}`}>
  <defs><radialGradient id="console-shadow"><stop stopColor="#000" stopOpacity=".65"/><stop offset="1" stopColor="#000" stopOpacity="0"/></radialGradient><linearGradient id="deck-side" x2="0" y2="1"><stop stopColor="#252829"/><stop offset="1" stopColor="#191b1c"/></linearGradient><linearGradient id="tonearm-metal" x1="0%" y1="0%" x2="100%" y2="0%"><stop stopColor="#7b857d"/><stop offset=".45" stopColor="#b9c1b8"/><stop offset="1" stopColor="#8e9a8f"/></linearGradient></defs>
  <ellipse cx="380" cy="352" rx="327" ry="88" fill="url(#console-shadow)"/>
  <g stroke="#555957" strokeWidth="1" strokeLinejoin="round">
   <path d="m127 290 35 8-4 30-16 4-17-8zM499 392l35-6-2 25-17 10-18-8zM651 208l26 8-3 28-19 5z" fill="#111314"/>
   <path d="m74 258 433 109 199-184v35L507 407 74 293z" fill="url(#deck-side)"/>
   <path d="m74 258 433 109v40L74 293z" fill="#252728"/>
   <path d="m74 258 195-180 437 105-199 184z" fill="#2a2c2d"/>
   <path d="m88 281 414 105M517 389l178-166" stroke="#383c3b"/>
   <path d="m119 254 389 96" stroke="#3d4141"/>
  </g>
  <g transform="translate(321 217) rotate(14) scale(1 .55)">
   <circle r="158" cy="9" fill="#6a6d6b" stroke="#a3a6a0"/><circle r="154" cy="4" fill="#191c1d"/>
   <g className="fallback-record"><circle r="148" fill="#101213" stroke="#777c79" strokeWidth=".6"/>{Array.from({length:21},(_,i)=><circle key={i} r={62+i*3.9} fill="none" stroke="#7f8580" opacity={i%3===0?'.22':'.1'} strokeWidth=".7"/>)}<circle r="56" fill="#c98b4c" stroke="#eaad70" strokeWidth="1"/><circle r="50" fill="none" stroke="#4d3825" strokeWidth=".6"/><path d="M-44-2H44" stroke="#342a20" opacity=".4"/><text y="-21" textAnchor="middle" fill="#34291d" fontSize="8" fontFamily="monospace" letterSpacing="1">LISTEN / SELECTED</text><text y="27" textAnchor="middle" fill="#34291d" fontSize="7" fontFamily="monospace">33⅓ · LN—01</text><circle cx="22" cy="-9" r="3" fill="#efc089"/></g>
   <circle r="8" fill="#141719"/><circle r="3" fill="#b4b8b1" stroke="#eee"/>
  </g>
  <g stroke="#858d88" strokeWidth="1.3" strokeLinejoin="round"><ellipse cx="571" cy="194" rx="26" ry="15" fill="#151819"/><path d="M552 194v-25l18-12 20 9v28l-19 12z" fill="#515958"/><ellipse cx="571" cy="167" rx="19" ry="11" fill="#363c3b"/>
   <g transform={`rotate(${playing?25+fraction*13:0} 571 168)`} strokeLinecap="round" strokeLinejoin="round">
    {/* One continuous curve reaches inside both end fittings; all parts move together. */}
    <path d={armTube} transform="translate(1 2)" fill="none" stroke="#171d1a" strokeWidth="9"/>
    <path d={armTube} fill="none" stroke="url(#tonearm-metal)" strokeWidth="7"/>
    <path d={armTube} transform="translate(-1 -.4)" fill="none" stroke="#d5dbd0" strokeWidth="1" opacity=".5"/>
    <path d="M570 147 L583 151 V155 L570 151 Z" fill="#303831"/>
    <path d="M578 115 L591 119 L583 151 L570 147 Z" fill="#4b554d"/>
    <path d="M580 118 L588 120" fill="none" stroke="#b2bbae" strokeWidth=".8"/>
    <path d="m527 258-22 18 14 11 26-19z" fill="#444d49"/>
    <path d="M505 276 L519 287 V291 L505 280 Z" fill="#2b3530"/>
    <path d="M505 278 L518 288 L514 301 L501 291 Z" fill="#121716"/>
    <path d="M509 295 L507 301" fill="none" stroke="#a6b0a1" strokeWidth="1.6"/>
    <circle cx="507" cy="301" r="2" fill={playing?'#ff9d3c':'#8c653f'} className="fallback-stylus"/>
   </g>
  </g>
  <g transform="matrix(.94 .24 -.73 .66 147 266)"><rect width="48" height="35" rx="2" fill="#372d23" stroke="#c28b52"/><path d="m20 10 11 7-11 7z" fill="#ffb265"/><circle cx="65" cy="18" r="3" fill={playing?'#ff9d3c':'#6a5441'}/><rect x="320" width="34" height="30" fill="#343938" stroke="#6b7470"/><rect x="365" width="34" height="30" fill="#343938" stroke="#6b7470"/><path d="m342 9-9 6 9 6M377 9l9 6-9 6" fill="none" stroke="#a5afa7" strokeWidth="2"/></g>
  <g fill="#91978e" fontSize="9" fontFamily="monospace" letterSpacing="2"><text x="254" y="112" transform="rotate(14 254 112)">LISTEN / LN—01</text><text x="584" y="257" transform="rotate(-43 584 257)">DIRECT DRIVE</text></g>
 </svg>;
}
export default function Turntable({signal,title,channel,onAction,lightMode,onLightMode,loadReady=true}:{signal:Omit<TurntableSignal,'reducedMotion'>;title:string;channel:string;onAction:(action:ConsoleAction)=>void;lightMode:boolean;onLightMode:(value:boolean)=>void;loadReady?:boolean}){
 const [Stage,setStage]=useState<ComponentType<StageProps>|null>(null),[failed,setFailed]=useState(''),[autoRotate,setAutoRotate]=useState(false),[interactive,setInteractive]=useState(false),[resetKey,setResetKey]=useState(0),[reducedMotion,setReducedMotion]=useState(false),[loading,setLoading]=useState(false);
 const root=useRef<HTMLDivElement>(null);
 useEffect(()=>{const media=matchMedia('(prefers-reduced-motion: reduce)'),change=()=>setReducedMotion(media.matches);change();media.addEventListener('change',change);return()=>media.removeEventListener('change',change);},[]);
 useEffect(()=>{
  if(!loadReady||lightMode||Stage||failed)return;let active=true,idle:number|undefined;
  const start=()=>{if(!active)return;setLoading(true);import('./turntable-stage').then(module=>{if(active)setStage(()=>module.default);}).catch(()=>{if(active)setFailed('Chưa tải được cảnh 3D. Bạn vẫn có thể nghe ở chế độ nhẹ.');}).finally(()=>{if(active)setLoading(false);});};
  const observer=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){observer.disconnect();if('requestIdleCallback'in window)idle=window.requestIdleCallback(start,{timeout:1200});else start();}},{rootMargin:'100px'});if(root.current)observer.observe(root.current);
  return()=>{active=false;observer.disconnect();if(idle!==undefined)window.cancelIdleCallback(idle);};
 },[lightMode,Stage,failed,loadReady]);
 const has3d=!!Stage&&!failed&&!lightMode;
 return <section className={`turntable ${interactive?'interaction-on':''} ${has3d?'has-webgl':''}`} aria-label="Bàn đĩa tương tác" ref={root}>
  <div className="console-spec"><span><span className={`status-dot ${signal.playerState===1?'on':signal.playerState===3?'buffering':''}`}/>{signal.playerState===1?'RUNNING':signal.playerState===3?'BUFFERING':signal.playerState===2?'PAUSED':'STANDBY'}</span><span>LN—01 <b>/</b> DIRECT DRIVE</span></div>
  <div className="turntable-viewport">{has3d&&Stage?<Stage signal={{...signal,reducedMotion}} title={title} channel={channel} autoRotate={autoRotate} interactive={interactive} resetKey={resetKey} onAction={onAction} onFailure={setFailed}/>:<TurntableFallback playing={signal.playerState===1&&!reducedMotion} title={title} progress={signal.progress} duration={signal.duration}/>}</div>
  <div className="scene-controls"><span className="scene-hint">{loading?<><LoaderCircle size={12} className="spin"/>Đang dựng không gian…</>:has3d?<><Box size={13}/><span className="desktop-hint">Kéo để xoay · Bấm nút trên máy để điều khiển</span><span className="mobile-hint">{interactive?'Kéo để xoay bàn đĩa':'Bật tương tác để xoay bàn đĩa'}</span></>:<><Box size={13}/>{failed?'WebGL không khả dụng':'Chế độ nhẹ · SVG'}</>}</span><div>{has3d?<><button type="button" className={`scene-button mobile-interaction ${interactive?'selected':''}`} aria-pressed={interactive} onClick={()=>setInteractive(!interactive)}><Hand size={14}/>{interactive?'Xong':'Tương tác 3D'}</button><button type="button" className="scene-button" onClick={()=>setResetKey(x=>x+1)} title="Góc nhìn mặc định" aria-label="Góc nhìn mặc định"><RotateCcw size={15}/></button><button type="button" className={`scene-button ${autoRotate?'selected':''}`} aria-pressed={autoRotate} onClick={()=>setAutoRotate(!autoRotate)} disabled={reducedMotion} title={reducedMotion?'Tự xoay tắt theo tùy chọn giảm chuyển động':'Tự xoay chậm'} aria-label="Tự xoay chậm"><Orbit size={15}/></button></>:failed?<button className="scene-button" onClick={()=>{setFailed('');setStage(null);onLightMode(false);}}>Thử lại 3D</button>:null}</div></div>
  {failed&&<p className="fallback-note" role="status">{failed}</p>}
 </section>;
}
