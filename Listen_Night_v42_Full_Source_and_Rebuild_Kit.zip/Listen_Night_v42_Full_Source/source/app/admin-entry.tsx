'use client';
import {useEffect,useRef,useState,type FormEvent} from 'react';
import {ArrowLeft,Disc3,LoaderCircle,LogIn,RefreshCw} from 'lucide-react';
import AdminDashboard from './admin-dashboard';

async function authRequest(path:string,init:RequestInit={},signal?:AbortSignal){
 let response:Response;
 try{response=await fetch(`/api${path}`,{...init,credentials:'same-origin',cache:'no-store',headers:init.body?{'Content-Type':'application/json'}:undefined,signal});}
 catch(error){if((error as Error).name==='AbortError')throw error;throw new Error('Chưa kết nối được với máy chủ. Vui lòng thử lại.');}
 const payload=await response.json().catch(()=>null);
 const data=payload&&typeof payload==='object'&&!Array.isArray(payload)?payload as Record<string,unknown>:null;
 if(!response.ok)throw new Error(typeof data?.error==='string'?data.error:'Chưa đăng nhập được. Vui lòng thử lại.');
 if(!data||typeof data.signedIn!=='boolean')throw new Error('Chưa xác nhận được trạng thái đăng nhập. Vui lòng thử lại.');
 return {signedIn:data.signedIn};
}

export default function AdminEntry({canonicalOriginBase64}:{canonicalOriginBase64?:string}={}){
 const [phase,setPhase]=useState<'checking'|'redirecting'|'signedOut'|'signedIn'|'error'>('checking');
 const [username,setUsername]=useState(''),[password,setPassword]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const [destination,setDestination]=useState('');
 const request=useRef<AbortController|null>(null),mounted=useRef(false),locked=useRef(false);
 const checkAccess=async()=>{
  request.current?.abort();const controller=new AbortController();request.current=controller;setPhase('checking');setError('');
  try{const data=await authRequest('/me',{},controller.signal);if(mounted.current&&request.current===controller&&!controller.signal.aborted)setPhase(data.signedIn?'signedIn':'signedOut');}
  catch(error){if(mounted.current&&request.current===controller&&(error as Error).name!=='AbortError'){setError((error as Error).message);setPhase('error');}}
 };
 useEffect(()=>{
  mounted.current=true;
  let canonical:URL|null=null;
  try{if(canonicalOriginBase64){const value=atob(canonicalOriginBase64),url=new URL(value);if(url.protocol==='https:'&&!url.username&&!url.password&&url.origin===value)canonical=url;}}catch{}
  const current=new URL(window.location.href),framed=window.self!==window.top;
  if(canonical&&(current.origin!==canonical.origin||framed)){
   const next=new URL('/bim',canonical.origin),slug=current.searchParams.get('s');
   if(slug&&/^[a-z0-9][a-z0-9-]{1,46}[a-z0-9]$/.test(slug))next.searchParams.set('s',slug);
   else if(['tracks','import'].includes(current.searchParams.get('view')||'')){next.searchParams.set('view',current.searchParams.get('view')!);const to=current.searchParams.get('to');if(current.searchParams.get('view')==='import'&&to&&/^[a-z0-9][a-z0-9-]{1,46}[a-z0-9]$/.test(to))next.searchParams.set('to',to);}
   setDestination(next.href);setPhase('redirecting');
   if(!framed){try{window.location.replace(next.href);}catch{setError('Bấm Mở trang quản trị để tiếp tục.');}}
  }else void checkAccess();
  return()=>{mounted.current=false;request.current?.abort();};
 },[canonicalOriginBase64]);
 const login=async(e:FormEvent)=>{
  e.preventDefault();if(locked.current||!username.trim()||!password)return;locked.current=true;setBusy(true);setError('');
  request.current?.abort();const controller=new AbortController();request.current=controller;
  try{
   const data=await authRequest('/auth/login',{method:'POST',body:JSON.stringify({username:username.trim(),password})},controller.signal);
   if(!data.signedIn)throw new Error('Chưa xác nhận được trạng thái đăng nhập. Vui lòng thử lại.');
   const verified=await authRequest(`/me?verify=${crypto.randomUUID()}`,{},controller.signal);
   if(!verified.signedIn)throw new Error('Trình duyệt chưa giữ được phiên đăng nhập. Hãy cho phép cookie cho trang này rồi thử lại.');
   if(mounted.current&&request.current===controller&&!controller.signal.aborted){setPassword('');setPhase('signedIn');}
  }
  catch(error){if(mounted.current&&request.current===controller&&(error as Error).name!=='AbortError')setError((error as Error).message);}
  finally{locked.current=false;if(mounted.current){setPassword('');setBusy(false);}}
 };
 if(phase==='signedIn')return <AdminDashboard onSignedOut={reason=>{setPassword('');setError(reason||'');setPhase('signedOut');}}/>;
 return <main className="admin-access"><section className="admin-card" aria-labelledby="admin-title">
  <a className="admin-brand" href="/" aria-label="Listen · Về phòng nghe"><Disc3 size={27}/><span>listen<span className="brand-period">.</span></span></a>
  <p className="eyebrow">THƯ VIỆN CỦA BẠN</p><h1 id="admin-title">Quản lý playlist</h1><p className="admin-description">Đăng nhập để chăm chút những giai điệu của bạn.</p>
  {phase==='redirecting'?<div className="admin-redirect"><p role="status">Đang mở trang quản trị trực tiếp để giữ phiên đăng nhập.</p>{error&&<p className="form-error" role="alert">{error}</p>}<a className="button primary" href={destination} target="_blank" rel="noopener noreferrer">Mở trang quản trị</a></div>:phase==='checking'?<p className="admin-checking" role="status"><LoaderCircle size={18} className="spin"/>Đang kiểm tra phiên đăng nhập…</p>:phase==='error'?<div className="admin-retry"><p className="form-error" role="alert">{error}</p><button className="button" onClick={()=>void checkAccess()}><RefreshCw size={16}/>Thử lại</button></div>:<form onSubmit={login} aria-label="Đăng nhập quản lý playlist" aria-busy={busy}>
   <label htmlFor="admin-username">Tên đăng nhập</label><input id="admin-username" name="username" type="text" autoComplete="username" autoCapitalize="none" spellCheck={false} maxLength={64} value={username} onChange={e=>setUsername(e.target.value)} disabled={busy} autoFocus required/>
   <label htmlFor="admin-password">Mật khẩu</label><input id="admin-password" name="password" type="password" autoComplete="current-password" maxLength={128} value={password} onChange={e=>setPassword(e.target.value)} disabled={busy} required/>
   {error&&<p className="form-error" role="alert">{error}</p>}
   <button className="button primary" type="submit" disabled={busy||!username.trim()||!password}>{busy?<LoaderCircle size={18} className="spin"/>:<LogIn size={18}/>}Đăng nhập</button>
  </form>}
  <a className="admin-back" href="/"><ArrowLeft size={15}/>Về phòng nghe</a>
 </section><span className="admin-caption mono">LISTEN · A SPACE FOR YOUR SOUND</span></main>;
}
