'use client';
import {useCallback,useEffect,useRef,useState,useMemo,memo,type ReactNode} from 'react';
import {Headphones,Plus,ArrowUpRight,Link2,Check,Pencil,Trash2,Search,Play,Pause,SkipBack,SkipForward,Shuffle,Repeat,Repeat1,Download,ArrowUp,ArrowDown,GripVertical,ChevronDown,ChevronRight,Music2,ListMusic,LogOut,LoaderCircle,X,RefreshCw,AlertCircle,ShieldCheck,PanelLeft,PanelRightClose,PanelRightOpen,Disc3,Box,Layers,Gamepad2,Motorbike,Dumbbell,Sparkles,Bot} from 'lucide-react';
import {type Session,type Track,type CollectionSummary,ALL_SONGS_SLUG,entryViewSlug,viewApiPath,parseBatch,slugValue,nextId,replacementAfterDelete} from '@/lib/domain';
import Turntable from './turntable';
import {reconcileQueue} from '@/lib/playback-queue';
import {loadYouTube,PLAYER_ERROR,type YouTubePlayer} from '@/lib/youtube';
const API='/api';
const readLocal=(key:string,fallback:any=null)=>{try{return JSON.parse(localStorage.getItem(key)||'null')??fallback;}catch{return fallback;}};
const writeLocal=(key:string,value:unknown)=>{try{localStorage.setItem(key,JSON.stringify(value));}catch{}};
const time=(n:number)=>`${Math.floor((n||0)/60)}:${String(Math.floor((n||0)%60)).padStart(2,'0')}`;
type Message={text:string;error?:boolean};
type ResponseData={session:Session;report?:{added:number;duplicates:number;invalid:number;invalidLines:number[];blocked?:number};error?:string};
type Me={signedIn:boolean;name?:string|null;sessions:{slug:string;name:string}[]};
async function api<T=ResponseData>(path:string,init:RequestInit={}):Promise<T>{
 let response:Response;
 try{response=await fetch(`${API}${path}`,{...init,credentials:'same-origin',headers:{...(init.body?{'Content-Type':'application/json'}:{}),...init.headers},cache:'no-store'});}catch(e){if((e as Error).name==='AbortError')throw e;throw new Error('Mất kết nối mạng. Chưa xác nhận được thay đổi đã lưu; hãy tải lại playlist trước khi thử lại.');}
 const data=await response.json().catch(()=>({error:'Máy chủ trả về dữ liệu không hợp lệ.'})) as T & {error?:string};
 if(!data||typeof data!=='object')throw new Error('Máy chủ trả về dữ liệu không hợp lệ.');
 if(!response.ok){const e=new Error(data.error||'Thao tác chưa thành công.') as Error&{status:number};e.status=response.status;throw e;}return data;
}
function IconButton({label,children,className='',...props}:React.ButtonHTMLAttributes<HTMLButtonElement>&{label:string;children:ReactNode}){return <button type="button" title={label} aria-label={label} className={`icon-button ${className}`} {...props}>{children}</button>;}
function Equalizer({active=false}:{active?:boolean}){return <span className={`equalizer ${active?'active':''}`} aria-hidden="true"><i/><i/><i/><i/></span>;}
const PlayerSurface=memo(function PlayerSurface({onReady,onState,onError,onBlocked,attempt,onLoadError}:{onReady:(p:YouTubePlayer)=>void;onState:(s:number)=>void;onError:(s:number)=>void;onBlocked:()=>void;attempt:number;onLoadError:(m:string)=>void}){
 const root=useRef<HTMLDivElement>(null),callbacks=useRef({onReady,onState,onError,onBlocked,onLoadError});callbacks.current={onReady,onState,onError,onBlocked,onLoadError};
 useEffect(()=>{let disposed=false,player:YouTubePlayer|undefined;
  loadYouTube().then(YT=>{if(disposed||!root.current)return;const node=document.createElement('div');root.current.replaceChildren(node);
   player=new YT.Player(node,{width:'100%',height:'100%',playerVars:{autoplay:0,controls:1,playsinline:1,rel:0,origin:window.location.origin},events:{
    onReady:(e:{target:YouTubePlayer})=>{if(disposed)return;const iframe=e.target.getIframe();iframe.title='Trình phát video YouTube';iframe.setAttribute('allow','accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share');iframe.setAttribute('referrerpolicy','strict-origin-when-cross-origin');callbacks.current.onReady(e.target);},
    onStateChange:(e:{data:number})=>!disposed&&callbacks.current.onState(e.data),onError:(e:{data:number})=>!disposed&&callbacks.current.onError(e.data),onAutoplayBlocked:()=>!disposed&&callbacks.current.onBlocked(),
   }});
  }).catch(e=>!disposed&&callbacks.current.onLoadError(e.message));
  return ()=>{disposed=true;player?.destroy();};
 },[attempt]);
 return <div className="player-mount" ref={root}/>;
});
function Modal({title,children,onClose}:{title:string;children:ReactNode;onClose:()=>void}){
 const ref=useRef<HTMLDialogElement>(null);
 useEffect(()=>{const dialog=ref.current;dialog?.showModal();return()=>dialog?.close();},[]);
 return <dialog ref={ref} className="modal" aria-labelledby="modal-title" onCancel={e=>{e.preventDefault();onClose();}} onClick={e=>{if(e.target===ref.current)onClose();}}><div className="modal-head"><h2 id="modal-title">{title}</h2><IconButton label="Đóng" onClick={onClose}><X size={20}/></IconButton></div>{children}</dialog>;
}
export default function ListenApp({onSignedOut}:{onSignedOut?:()=>void}={}){
 const [queue,setQueue]=useState<Session|null>(null),[libraryOpen,setLibraryOpen]=useState(false),[queueOpen,setQueueOpen]=useState(false),[lightMode,setLightMode]=useState(false);
 const queueRef=useRef<Session|null>(null),queueSequence=useRef(0),searchRef=useRef<HTMLInputElement>(null);
 const requestedSlug=useRef<string|null>(null),retryEntry=useRef<()=>Promise<void>>(async()=>{});
 const [collections,setCollections]=useState<CollectionSummary[]>([]),[collectionsError,setCollectionsError]=useState('');
 const [libraryFilter,setLibraryFilter]=useState<'all'|'viet'|'ai'|'tryhard'|'gaming'|'ride'|'active'|'dopamine'>('all');
 const [session,setSession]=useState<Session|null>(null),[loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[message,setMessage]=useState<Message|null>(null),[error,setError]=useState('');
 const [user,setUser]=useState<Me>({signedIn:false,sessions:[]});
 const [dialog,setDialog]=useState<'create'|'open'|'rename'|'delete'|'share'|'add'|null>(null),[slugInput,setSlugInput]=useState(''),[nameInput,setNameInput]=useState(''),[dialogError,setDialogError]=useState('');
 const [addText,setAddText]=useState(''),[query,setQuery]=useState(''),[currentId,setCurrentId]=useState<string|null>(null);
 const [playerState,setPlayerState]=useState(-1),[ready,setReady]=useState(false),[blocked,setBlocked]=useState(false),[playerError,setPlayerError]=useState(''),[apiError,setApiError]=useState(''),[playerAttempt,setPlayerAttempt]=useState(0);
 const [shuffle,setShuffle]=useState(false),[repeat,setRepeat]=useState<'off'|'one'|'all'>('off'),[progress,setProgress]=useState(0),[duration,setDuration]=useState(0),[metaLoading,setMetaLoading]=useState(false),[copied,setCopied]=useState(false),[dragged,setDragged]=useState<string|null>(null),[online,setOnline]=useState(true);
 const sessionRef=useRef<Session|null>(null),currentRef=useRef<string|null>(null),player=useRef<YouTubePlayer|null>(null),readyRef=useRef(false),pending=useRef<{id:string;play:boolean;start:number}|null>(null),sequence=useRef(0),busyRef=useRef(false),played=useRef(new Set<string>()),failed=useRef(new Set<string>()),failCount=useRef(0),intent=useRef(false),skipTimer=useRef<ReturnType<typeof setTimeout>|null>(null),blockTimer=useRef<ReturnType<typeof setTimeout>|null>(null),endGuard=useRef(''),settings=useRef({shuffle,repeat}),loadRef=useRef<(slug:string)=>Promise<void>>(async()=>{});
 settings.current={shuffle,repeat};
 const notify=useCallback((text:string,error=false)=>setMessage({text,error}),[]);
 const clearTimers=()=>{if(skipTimer.current)clearTimeout(skipTimer.current);if(blockTimer.current)clearTimeout(blockTimer.current);};
 const setSnapshot=(s:Session)=>{sessionRef.current=s;setSession(s);setCollections(items=>items.map(c=>c.slug===s.slug?{...c,name:s.name,count:s.tracks.length,cover:s.tracks[0]?.thumbnail??null,canEdit:s.canEdit}:c));};
 const remember=()=>{const s=queueRef.current;if(!s||!currentRef.current)return;const p=player.current;writeLocal(`listen:position:${s.slug}`,{id:currentRef.current,time:p&&readyRef.current?Math.max(0,p.getCurrentTime()||0):0});};
 const apply=useCallback(()=>{const p=player.current,item=pending.current;if(!p||!readyRef.current||!item)return;pending.current=null;
  try{const options={videoId:item.id,startSeconds:item.start};if(item.play)p.loadVideoById(options);else p.cueVideoById(options);
   if(item.play){if(blockTimer.current)clearTimeout(blockTimer.current);blockTimer.current=setTimeout(()=>{if(intent.current&&player.current?.getPlayerState()!==1&&player.current?.getPlayerState()!==3)setBlocked(true);},2200);}
  }catch{setPlayerError('Trình phát chưa sẵn sàng. Hãy thử lại.');}
 },[]);
 const select=useCallback((id:string|null,play=false,start=0,userAction=false)=>{
  const previous=currentRef.current;clearTimers();if(userAction){failed.current.clear();played.current.clear();failCount.current=0;}if(id)played.current.add(id);currentRef.current=id;setCurrentId(id);setPlayerError('');setBlocked(false);setProgress(start);setDuration(0);if(userAction||id!==previous)endGuard.current='';intent.current=play;setPlayerState(-1);
  if(!id){pending.current=null;player.current?.stopVideo();setPlayerState(-1);return;}
  pending.current={id,play,start};apply();
 },[apply]);
 const putQueue=(s:Session)=>{queueRef.current=s;setQueue(s);};
 const reconcilePlayback=(s:Session)=>{const previous=queueRef.current;if(!previous){putQueue(s);return;}const next=reconcileQueue(previous,s,currentRef.current);putQueue(next.queue);if(next.reload)select(next.currentId,player.current?.getPlayerState()===1||player.current?.getPlayerState()===3);};
 const refreshAggregateQueue=async()=>{const token=++queueSequence.current;try{const d=await api('/library');if(queueSequence.current===token&&queueRef.current?.slug===ALL_SONGS_SLUG)reconcilePlayback(d.session);}catch{notify('Chưa đồng bộ được hàng phát. Bài đang nghe vẫn tiếp tục; mở lại Tất cả bài hát để thử lại.',true);}};
 const hydrate=useCallback(async(slug:string,tracks:Track[],token:number,force=false)=>{
  const ids=tracks.filter(t=>force||t.metadataStatus!=='ready').map(t=>t.videoId);if(!ids.length)return;setMetaLoading(true);
  try{for(let i=0;i<ids.length;i+=6){if(sequence.current!==token)return;const d=await api<{tracks:Track[]}>(`${viewApiPath(slug)}/metadata?ids=${ids.slice(i,i+6).join(',')}`);
    if(sequence.current!==token||sessionRef.current?.slug!==slug)return;const map=new Map<string,Track>(d.tracks.map((t:Track)=>[t.videoId,t]));const s=sessionRef.current;setSnapshot({...s,tracks:s.tracks.map(t=>map.has(t.videoId)?{...t,...map.get(t.videoId),addedAt:t.addedAt,sourcePlaylists:t.sourcePlaylists}:t)});const q=queueRef.current;if(q)putQueue({...q,tracks:q.tracks.map(t=>map.has(t.videoId)?{...t,...map.get(t.videoId),addedAt:t.addedAt,sourcePlaylists:t.sourcePlaylists}:t)});
   }}catch{if(sequence.current===token)notify('Chưa lấy được một số thông tin từ YouTube. Playlist vẫn đã lưu; có thể thử tải thông tin lại.',true);}finally{if(sequence.current===token)setMetaLoading(false);}
 },[notify]);
 const loadSession=useCallback(async(slug:string)=>{
  const token=++sequence.current;requestedSlug.current=slug;setLoading(true);setError('');setMetaLoading(false);
  try{if(slug!==ALL_SONGS_SLUG)slugValue(slug);const d=await api(viewApiPath(slug));if(token!==sequence.current)return;
   snapshotSession(d.session);
   writeLocal('listen:last',slug);const url=new URL(window.location.href);if(slug===ALL_SONGS_SLUG){url.searchParams.delete('s');url.searchParams.set('view','all');}else{url.searchParams.set('s',slug);url.searchParams.delete('view');}history.replaceState(null,'',url);setQuery('');
   void hydrate(slug,d.session.tracks,token);
  }catch(e){if(token===sequence.current)setError((e as Error).message);}finally{if(token===sequence.current)setLoading(false);}
  function snapshotSession(s:Session){
   setSnapshot(s);
   if(!queueRef.current){putQueue(s);const saved=readLocal(`listen:position:${s.slug}`),id=s.tracks.some(t=>t.videoId===saved?.id)?saved.id:s.tracks[0]?.videoId??null;select(id,false,Math.max(0,Number(saved?.time)||0));}
   else if(queueRef.current.slug===s.slug)reconcilePlayback(s);
  }
 },[hydrate,select]);
 loadRef.current=loadSession;
 useEffect(()=>{
  let disposed=false,catalogController:AbortController|undefined;
  const openEntry=async()=>{
   const token=++sequence.current,search=new URL(window.location.href).search;
   const slug=entryViewSlug(search,matchMedia('(max-width: 900px)').matches);
   catalogController?.abort();const controller=new AbortController();catalogController=controller;
   setCollectionsError('');
   if(slug)void loadRef.current(slug);
   else{requestedSlug.current=null;setLoading(true);setError('');}
   try{
    const d=await api<{collections:CollectionSummary[]}>('/collections',{signal:controller.signal});
    if(disposed||controller.signal.aborted)return;setCollections(d.collections);
    // A late catalogue response must never override a playlist the listener opened.
    if(!slug&&token===sequence.current){
     const selected=entryViewSlug(search,true,d.collections);
     if(selected)void loadRef.current(selected);
     else{setError('Chưa có playlist có bài hát để nghe. Vui lòng thử lại sau.');setLoading(false);}
    }
   }catch(e){
    if(disposed||controller.signal.aborted)return;
    setCollectionsError('Chưa tải được bộ sưu tập. Chạm để thử lại.');
    if(!slug&&token===sequence.current){setError('Chưa tải được playlist gợi ý. Kiểm tra kết nối và thử lại.');setLoading(false);}
   }
  };
  retryEntry.current=openEntry;
  const prefs=readLocal('listen:prefs',{});setQueueOpen(matchMedia('(min-width: 1200px)').matches);setLightMode(!!readLocal('listen:light-mode',false));setShuffle(!!prefs.shuffle);setRepeat(['off','one','all'].includes(prefs.repeat)?prefs.repeat:'off');
  void openEntry();
  api<Me>('/me').then(setUser).catch(()=>{});
  const network=()=>setOnline(navigator.onLine);network();window.addEventListener('online',network);window.addEventListener('offline',network);
  const pop=()=>void openEntry();window.addEventListener('popstate',pop);
  const persist=()=>{remember();};window.addEventListener('pagehide',persist);document.addEventListener('visibilitychange',persist);
  const timer=setInterval(()=>{const p=player.current;if(!readyRef.current||!p)return;if(document.visibilityState==='visible'){setProgress(p.getCurrentTime()||0);setDuration(p.getDuration()||0);}if(p.getPlayerState()===1)remember();},1000);
  return()=>{disposed=true;catalogController?.abort();sequence.current++;clearInterval(timer);clearTimers();window.removeEventListener('online',network);window.removeEventListener('offline',network);window.removeEventListener('popstate',pop);window.removeEventListener('pagehide',persist);document.removeEventListener('visibilitychange',persist);};
 },[]);
 useEffect(()=>{writeLocal('listen:prefs',{shuffle,repeat});},[shuffle,repeat]);
 useEffect(()=>{if(message){const timer=setTimeout(()=>setMessage(null),10000);return()=>clearTimeout(timer);}},[message]);
 const move=(direction=1,automatic=false)=>{
  const s=queueRef.current;if(!s?.tracks.length)return;if(!automatic){failed.current.clear();failCount.current=0;}
  if(automatic&&settings.current.shuffle&&settings.current.repeat==='all'&&s.tracks.every(t=>played.current.has(t.videoId)||failed.current.has(t.videoId)))played.current.clear();
  const id=nextId(s.tracks.map(t=>t.videoId),currentRef.current,{direction,automatic,...settings.current,failed:failed.current,played:played.current});
  if(id)select(id,true,0,!automatic);else{intent.current=false;notify(automatic?'Bạn đã nghe hết playlist. Chọn một bài để nghe tiếp.':'Không còn bài có thể phát.');}
 };
 const onState=(state:number)=>{
  const actual=player.current?.getVideoData()?.video_id;if(actual&&actual!==currentRef.current)return;
  setPlayerState(state);
  if(state===1){endGuard.current='';setBlocked(false);setPlayerError('');intent.current=true;failCount.current=0;const data=player.current?.getVideoData();
   if(data?.video_id===currentRef.current&&data.title){const update=(s:Session)=>({...s,tracks:s.tracks.map(t=>t.videoId===data.video_id?{...t,title:data.title!,channel:data.author||t.channel,metadataStatus:'ready'}:t)});if(queueRef.current)putQueue(update(queueRef.current));if(sessionRef.current?.tracks.some(t=>t.videoId===data.video_id))setSnapshot(update(sessionRef.current));}
  }
  if(state===2){intent.current=false;remember();}
  if(state===0&&intent.current&&currentRef.current&&endGuard.current!==currentRef.current){endGuard.current=currentRef.current;remember();move(1,true);}
 };
 const onPlayerError=(code:number)=>{
  const id=currentRef.current;if(!id)return;
  if([100,101,150].includes(code)&&!failed.current.has(id))void api('/video-reports',{method:'POST',body:JSON.stringify({videoId:id,code})}).catch(()=>{});
  failed.current.add(id);failCount.current++;
  const message=PLAYER_ERROR[code]||'YouTube chưa phát được video này. Hãy thử lại hoặc chuyển bài.';setPlayerError(message);setPlayerState(-1);setBlocked(false);
  const s=queueRef.current;if(!s||!intent.current)return;
  if(code===153||failCount.current>=Math.min(3,s.tracks.length)){intent.current=false;notify('Đã dừng tự chuyển sau các lỗi phát. Bạn có thể chọn bài khác hoặc mở trên YouTube.',true);return;}
  if(skipTimer.current)clearTimeout(skipTimer.current);skipTimer.current=setTimeout(()=>{const id=nextId(s.tracks.map(t=>t.videoId),currentRef.current,{repeat:'all',failed:failed.current});if(id)select(id,true);else intent.current=false;},1800);
 };
 const togglePlay=()=>{const p=player.current;if(!readyRef.current||!p||!currentRef.current)return;failed.current.clear();failCount.current=0;clearTimers();
  if(p.getPlayerState()===1){intent.current=false;p.pauseVideo();}else{intent.current=true;setPlayerError('');setBlocked(false);p.playVideo();blockTimer.current=setTimeout(()=>{if(intent.current&&p.getPlayerState()!==1&&p.getPlayerState()!==3)setBlocked(true);},2200);}
 };
 const mutate=async(path:string,method:string,body?:unknown)=>{
  const s=sessionRef.current;if(!s||busyRef.current)return null;busyRef.current=true;setBusy(true);
  try{const d:ResponseData=await api(`/sessions/${s.slug}${path}`,{method,body:body===undefined?undefined:JSON.stringify(body),headers:{'If-Match':String(s.version),'X-Request-ID':crypto.randomUUID()}});
   if(d.session){if(sessionRef.current?.slug===s.slug)setSnapshot(d.session);if(queueRef.current?.slug===s.slug)reconcilePlayback(d.session);else if(queueRef.current?.kind==='all')void refreshAggregateQueue();}return d;
  }catch(e){if((e as any).status===409&&sessionRef.current?.slug===s.slug)await loadRef.current(s.slug);throw e;}finally{busyRef.current=false;setBusy(false);}
 };
 const addTracks=async()=>{try{const existing=sessionRef.current?.tracks.map(x=>x.videoId)||[];parseBatch(addText,existing);const d=await mutate('/tracks','POST',{text:addText});if(!d)return;setAddText('');const r=d.report!;notify(`Đã thêm ${r.added} bài · ${r.duplicates} trùng · ${r.invalid} dòng không hợp lệ${r.blocked?` · ${r.blocked} video đã chặn`:""}${r.invalidLines.length?` (dòng ${r.invalidLines.join(', ')})`:''}.`);void hydrate(d.session.slug,d.session.tracks,sequence.current);}catch(e){notify((e as Error).message,true);}};
 const remove=async(id:string)=>{try{if(await mutate('/tracks','DELETE',{videoId:id}))notify('Đã xóa bài khỏi playlist.');}catch(e){notify((e as Error).message,true);}};
 const reorder=async(id:string,target:string)=>{const s=sessionRef.current;if(!s||id===target||busyRef.current)return;const ids=s.tracks.map(t=>t.videoId),from=ids.indexOf(id),to=ids.indexOf(target);if(from<0||to<0)return;ids.splice(from,1);ids.splice(to,0,id);try{if(await mutate('/order','PATCH',{ids}))notify('Đã lưu thứ tự bài hát.');}catch(e){notify((e as Error).message,true);}};
 const shift=(id:string,direction:number)=>{const tracks=sessionRef.current?.tracks||[],i=tracks.findIndex(t=>t.videoId===id),target=tracks[i+direction];if(target)void reorder(id,target.videoId);};
 const shareUrl=()=>{const u=new URL(window.location.href);u.pathname='/';u.search='';if(sessionRef.current?.slug===ALL_SONGS_SLUG)u.searchParams.set('view','all');else if(sessionRef.current)u.searchParams.set('s',sessionRef.current.slug);u.hash='';return u.href;};
 const copy=async()=>{try{await navigator.clipboard.writeText(shareUrl());setCopied(true);notify('Đã sao chép liên kết chỉ nghe.');setTimeout(()=>setCopied(false),2500);}catch{setDialog('share');}};
 const exportList=()=>{if(!session)return;const blob=new Blob([session.tracks.map(t=>t.url).join('\n')+'\n'],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=session.kind==='all'?'tat-ca-bai-hat.txt':`${session.slug}.txt`;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);notify('Đã xuất danh sách URL.');};
 const openDialog=(type:typeof dialog)=>{setLibraryOpen(false);if(matchMedia('(max-width: 1199px)').matches)setQueueOpen(false);setDialogError('');setSlugInput('');setNameInput(type==='rename'?session?.name||'':'');setDialog(type);};
 const refreshAccess=async(fallback:Me)=>{
  setUser(fallback);setCollections(items=>items.map(c=>({...c,canEdit:false})));
  if(sessionRef.current)setSnapshot({...sessionRef.current,canEdit:false});
  const slug=sessionRef.current?.slug??ALL_SONGS_SLUG;
  const results=await Promise.allSettled([api<Me>('/me').then(setUser),api<{collections:CollectionSummary[]}>('/collections').then(d=>{setCollections(d.collections);setCollectionsError('');}),loadSession(slug)]);
  if(results.some(r=>r.status==='rejected'))notify('Chưa cập nhật được đầy đủ quyền truy cập. Hãy mở lại playlist để thử lại.',true);
 };
 const logout=async()=>{
  if(busyRef.current)return;busyRef.current=true;setBusy(true);
  try{await api<Me>('/auth/logout',{method:'POST'});await refreshAccess({signedIn:false,sessions:[]});notify('Đã đăng xuất. Bạn vẫn có thể tiếp tục nghe nhạc.');onSignedOut?.();}
  catch(error){notify((error as Error).message,true);}finally{busyRef.current=false;setBusy(false);}
 };
 const submitDialog=async(e:React.FormEvent)=>{e.preventDefault();setDialogError('');
  try{
   if(dialog==='open'){const s=slugInput.trim();slugValue(s);setDialog(null);await loadSession(s);return;}
   if(dialog==='create'){
    if(busyRef.current)return;const slug=slugValue(slugInput.trim());busyRef.current=true;setBusy(true);
    try{const d=await api('/sessions',{method:'POST',body:JSON.stringify({slug,name:nameInput.trim()||slug}),headers:{'X-Request-ID':crypto.randomUUID()}});setDialog(null);await loadSession(d.session.slug);api<Me>('/me').then(setUser).catch(()=>{});notify('Đã tạo phòng nghe. Playlist sẽ tự lưu khi bạn chỉnh sửa.');}finally{busyRef.current=false;setBusy(false);}
   }
   if(dialog==='rename'){await mutate('','PATCH',{name:nameInput});setDialog(null);notify('Đã đổi tên. Liên kết session được giữ nguyên.');}
   if(dialog==='delete'){const slug=session?.slug;await mutate('','DELETE');setDialog(null);setCollections(items=>items.filter(c=>c.slug!==slug));api<Me>('/me').then(setUser).catch(()=>{});await loadSession(ALL_SONGS_SLUG);if(queueRef.current?.slug===slug){const d=await api('/library');reconcilePlayback(d.session);}else if(queueRef.current?.kind==='all')await refreshAggregateQueue();notify(`Đã xóa session ${slug}.`);}
  }catch(e){setDialogError((e as Error).message);}
 };
 useEffect(()=>{const key=(e:KeyboardEvent)=>{if(e.key==='/'&&!e.ctrlKey&&!e.metaKey&&!['INPUT','TEXTAREA','SELECT'].includes((e.target as HTMLElement)?.tagName)){e.preventDefault();searchRef.current?.focus();}if(e.key==='Escape'){setLibraryOpen(false);setQueueOpen(false);}};window.addEventListener('keydown',key);return()=>window.removeEventListener('keydown',key);},[]);
 useEffect(()=>{if(!(libraryOpen&&matchMedia('(max-width: 900px)').matches||queueOpen&&matchMedia('(max-width: 1199px)').matches))return;const panel=document.getElementById(libraryOpen?'library-panel':'queue-panel'),previous=document.activeElement as HTMLElement|null;const old=document.body.style.overflow;document.body.style.overflow='hidden';panel?.setAttribute('role','dialog');panel?.setAttribute('aria-modal','true');const focusables=()=>Array.from(panel?.querySelectorAll<HTMLElement>('button:not(:disabled),a[href],input,select,[tabindex="0"]')||[]);focusables()[0]?.focus();const trap=(e:KeyboardEvent)=>{if(e.key!=='Tab')return;const list=focusables(),first=list[0],last=list.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}};document.addEventListener('keydown',trap);return()=>{document.body.style.overflow=old;panel?.removeAttribute('role');panel?.removeAttribute('aria-modal');document.removeEventListener('keydown',trap);previous?.focus();};},[libraryOpen,queueOpen]);
 const isAll=session?.kind==='all';
 const collection=collections.find(c=>c.slug===session?.slug);
 const firstLongTrack=collection?.longformVideoIds?.find(id=>session?.tracks.some(t=>t.videoId===id));
 const visibleCollections=collections.filter(c=>libraryFilter==='all'||c.category===libraryFilter);
 const playAll=()=>{const s=sessionRef.current,first=s?.tracks[0];if(s&&first){remember();queueSequence.current++;putQueue(s);setShuffle(false);setRepeat('off');select(first.videoId,true,0,true);}};
 const playFromBrowse=(id:string)=>{const s=sessionRef.current;if(!s)return;remember();queueSequence.current++;putQueue(s);if(id===currentRef.current&&!playerError){if(player.current?.getPlayerState()!==1)togglePlay();}else select(id,true,0,true);};
 const playLong=()=>{if(firstLongTrack){setShuffle(false);setRepeat('off');playFromBrowse(firstLongTrack);}};
 const previousTrack=()=>{if((player.current?.getCurrentTime()||0)>3){player.current?.seekTo(0,true);setProgress(0);}else move(-1);};
 const changeLightMode=(value:boolean)=>{setLightMode(value);writeLocal('listen:light-mode',value);};
 const track=queue?.tracks.find(t=>t.videoId===currentId),playing=playerState===1;
 const trackIndexes=useMemo(()=>new Map<string,number>(session?.tracks.map((t,index)=>[t.videoId,index])||[]),[session?.tracks]);
 const filtered=useMemo(()=>{const term=query.toLocaleLowerCase('vi');return session?.tracks.filter(t=>`${t.title} ${t.channel||''} ${t.videoId} ${t.sourcePlaylists?.map(p=>p.name).join(' ')||''}`.toLocaleLowerCase('vi').includes(term))||[];},[session?.tracks,query]);
 const queueIndex=queue?.tracks.findIndex(t=>t.videoId===currentId)??-1;
 return <div className={`app-shell ${queueOpen?'queue-open':'queue-collapsed'}`}>
  <a className="skip-link" href="#track-list">Đến danh sách bài hát</a>
  <header className="site-header">
   <button className="brand" onClick={()=>void loadSession(ALL_SONGS_SLUG)} aria-label="Listen · Tất cả bài hát"><span className="brand-mark"><Disc3 size={25}/></span><span>listen<span className="brand-period">.</span></span><span className="brand-mini">LISTENING ROOM</span></button>
   <label className="global-search"><Search size={18}/><input ref={searchRef} type="search" placeholder={isAll?'Tìm bài hát, nghệ sĩ, playlist…':'Tìm trong playlist này…'} aria-label={isAll?'Tìm trong tất cả bài hát':'Tìm trong playlist hiện tại'} value={query} onChange={e=>{setQuery(e.target.value);if(e.target.value)document.getElementById('track-list')?.scrollIntoView({behavior:'auto',block:'nearest'});}}/><kbd>/</kbd></label>
   <div className="header-right"><button className={`view-toggle ${!lightMode?'selected':''}`} onClick={()=>changeLightMode(!lightMode)} aria-pressed={!lightMode} title={lightMode?'Bật bàn đĩa 3D':'Chuyển sang giao diện nhẹ'}><Box size={16}/><span>{lightMode?'Chế độ nhẹ':'Không gian 3D'}</span></button>{user.signedIn?<><span className="account-badge" title={`Đã đăng nhập: ${user.name||''}`}><ShieldCheck size={16}/><span>{user.name||'Đã đăng nhập'}</span></span><IconButton label="Đăng xuất" onClick={()=>void logout()} disabled={busy}><LogOut size={16}/></IconButton></>:null}</div>
  </header>
  <div className="mobile-navigation"><button className="button" onClick={()=>{setQueueOpen(false);setLibraryOpen(true);}} aria-controls="library-panel" aria-expanded={libraryOpen}><PanelLeft size={17}/>Playlist <span>{collections.length}</span></button><button className="button" onClick={()=>{setLibraryOpen(false);setQueueOpen(true);}} aria-controls="queue-panel" aria-expanded={queueOpen}><ListMusic size={17}/>Hàng phát <span>{queue?.tracks.length||0}</span></button></div>
  {(libraryOpen||queueOpen)&&<button className="drawer-backdrop" aria-label="Đóng bảng đang mở" onClick={()=>{setLibraryOpen(false);setQueueOpen(false);}}/>}
  <div className="workspace">
   <aside className={`library-panel ${libraryOpen?'drawer-open':''}`} id="library-panel" aria-label="Thư viện playlist">
    <div className="panel-heading"><h2>Thư viện</h2><div>{user.signedIn&&<IconButton label="Tạo session" onClick={()=>openDialog('create')} disabled={busy}><Plus size={17}/></IconButton>}<IconButton className="drawer-close" label="Đóng thư viện" onClick={()=>setLibraryOpen(false)}><X size={18}/></IconButton></div></div>
    <button className={`library-all ${isAll?'selected':''}`} aria-current={isAll?'page':undefined} onClick={()=>{void loadSession(ALL_SONGS_SLUG);setLibraryOpen(false);}}><span className="library-all-icon"><Layers size={20}/></span><span><strong>Tất cả bài hát</strong><small>Mọi playlist · Một hàng phát</small></span>{isAll&&<span className="library-dot"/>}</button>
    <section className="library-categories" aria-labelledby="library-category-title">
     <h3 id="library-category-title">Danh mục playlist</h3>
     <div className="library-filters" role="group" aria-label="Lọc thư viện">
      <button aria-label="Lọc tất cả playlist" aria-pressed={libraryFilter==='all'} onClick={()=>setLibraryFilter('all')}><ListMusic size={16} aria-hidden="true"/><span className="library-filter-label">Tất cả playlist</span><span className="library-filter-count">{collections.length}</span></button>
      <button aria-label="Lọc playlist nhạc Việt" aria-pressed={libraryFilter==='viet'} onClick={()=>setLibraryFilter('viet')}><Music2 size={16} aria-hidden="true"/><span className="library-filter-label">Nhạc Việt</span><span className="library-filter-count">{collections.filter(c=>c.category==='viet').length}</span></button>
      <button aria-label="Lọc playlist Nhạc AI" aria-pressed={libraryFilter==='ai'} onClick={()=>setLibraryFilter('ai')}><Bot size={16} aria-hidden="true"/><span className="library-filter-label">Nhạc AI</span><span className="library-filter-count">{collections.filter(c=>c.category==='ai').length}</span></button>
      <button aria-label="Lọc playlist Try Hard" aria-pressed={libraryFilter==='tryhard'} onClick={()=>setLibraryFilter('tryhard')}><Headphones size={16} aria-hidden="true"/><span className="library-filter-label">Try Hard</span><span className="library-filter-count">{collections.filter(c=>c.category==='tryhard').length}</span></button>
      <button aria-label="Lọc playlist Ride · Mô tô" aria-pressed={libraryFilter==='ride'} onClick={()=>setLibraryFilter('ride')}><Motorbike size={16} aria-hidden="true"/><span className="library-filter-label">Ride · Mô tô</span><span className="library-filter-count">{collections.filter(c=>c.category==='ride').length}</span></button>
      <button aria-label="Lọc playlist Active · Thể thao" aria-pressed={libraryFilter==='active'} onClick={()=>setLibraryFilter('active')}><Dumbbell size={16} aria-hidden="true"/><span className="library-filter-label">Active · Thể thao</span><span className="library-filter-count">{collections.filter(c=>c.category==='active').length}</span></button>
      <button aria-label="Lọc playlist Dopamine" aria-pressed={libraryFilter==='dopamine'} onClick={()=>setLibraryFilter('dopamine')}><Sparkles size={16} aria-hidden="true"/><span className="library-filter-label">Dopamine</span><span className="library-filter-count">{collections.filter(c=>c.category==='dopamine').length}</span></button>
      <button aria-label="Lọc playlist Gaming" aria-pressed={libraryFilter==='gaming'} onClick={()=>setLibraryFilter('gaming')}><Gamepad2 size={16} aria-hidden="true"/><span className="library-filter-label">Gaming</span><span className="library-filter-count">{collections.filter(c=>c.category==='gaming').length}</span></button>
     </div>
    </section>
    <div className="library-caption"><span>{libraryFilter==='viet'?'NHẠC VIỆT':libraryFilter==='ai'?'NHẠC AI · BALLAD / COVER':libraryFilter==='tryhard'?'TRY HARD · FOCUS / ENERGY':libraryFilter==='gaming'?'GAMING · SOUNDTRACK / RADIO':libraryFilter==='ride'?'RIDE · MÔ TÔ / ROAD TRIP':libraryFilter==='active'?'ACTIVE · WORKOUT / OUTDOOR':libraryFilter==='dopamine'?'DOPAMINE · EUPHORIA / FEEL GOOD':'PLAYLIST TUYỂN CHỌN'}</span><span>{String(visibleCollections.length).padStart(2,'0')}</span></div>
    {collectionsError&&<button className="collection-retry" onClick={()=>{if(!sessionRef.current&&!requestedSlug.current){void retryEntry.current();return;}setCollectionsError('');api<{collections:CollectionSummary[]}>('/collections').then(d=>setCollections(d.collections)).catch(()=>setCollectionsError('Chưa tải được bộ sưu tập. Chạm để thử lại.'));}}><RefreshCw size={15}/>{collectionsError}</button>}
    <nav className="library-list" aria-label="Chọn playlist">{visibleCollections.map(c=><button key={c.slug} className={`library-item ${c.slug===session?.slug?'selected':''}`} aria-current={c.slug===session?.slug?'page':undefined} onClick={()=>{void loadSession(c.slug);setLibraryOpen(false);}} disabled={busy}><span className="library-cover">{c.cover?<img src={c.cover} alt="" loading="lazy" width="40" height="40"/>:<Disc3 size={22}/>}</span><span><strong>{c.name}</strong><small>{c.count} bài · {c.mood}</small></span>{c.slug===session?.slug&&<span className="library-dot"/>}</button>)}</nav>
    {!!user.sessions.filter(s=>!collections.some(c=>c.slug===s.slug)).length&&<><div className="library-caption">SESSION CỦA BẠN</div>{user.sessions.filter(s=>!collections.some(c=>c.slug===s.slug)).map(s=><button className="library-item" key={s.slug} onClick={()=>{void loadSession(s.slug);setLibraryOpen(false);}}><Music2 size={20}/><span><strong>{s.name}</strong><small>{s.slug}</small></span></button>)}</>}
    <button className="button open-session" onClick={()=>openDialog('open')} disabled={busy}><Link2 size={15}/>Mở bằng session slug</button>
    <div className="library-bottom"><span className="tiny-dot"/><span>Một chút nhạc.<br/>Một khoảng riêng.</span><span className="library-coordinate">LN / 01</span></div>
   </aside>
   <main className="listening-main" id="main-content">
    {!online&&<div className="notice error" role="status"><AlertCircle size={18}/>Bạn đang ngoại tuyến. Kết nối lại để nghe và lưu playlist.</div>}
    {error&&<div className="notice error" role="alert"><AlertCircle size={19}/><span>{error}</span><button className="button compact" onClick={()=>requestedSlug.current?loadSession(requestedSlug.current):retryEntry.current()}><RefreshCw size={16}/>Thử lại</button></div>}
    <section className="session-heading" aria-label="Playlist hiện tại"><div><p className="eyebrow">YOUR SOUND, YOUR SPACE <span>—</span> {isAll?'THE COLLECTION':'SELECTED PLAYLIST'}</p><h1>{session?.name||(loading?'Đang chuẩn bị âm nhạc…':'Phòng nghe của bạn')}</h1><p className="session-description">{isAll?`${session.tracks.length} bài hát từ ${session.sourceCount} playlist. Để giai điệu nối tiếp nhau.`:collection?.description||'Những giai điệu dành cho khoảng riêng của bạn.'}</p>{collection?.source&&<div className="playlist-source"><p><span>{collection.source.curator}</span><span>Bản nhập {new Date(collection.source.fetchedAt).toLocaleDateString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'})}</span><a href={collection.source.url} target="_blank" rel="noopener noreferrer" title={collection.source.title}>{collection.source.kind==='curated'||collection.source.kind==='video'?'Xem video nguồn':'Mở playlist gốc'}<ArrowUpRight size={13}/></a></p>{(collection.source.unavailableCount>0||collection.source.duplicateCount>0)&&<p className="source-note">{collection.source.unavailableCount>0?`${collection.source.unavailableCount} mục nguồn không truy xuất được khi nhập. `:''}{collection.source.duplicateCount>0?`Đã gộp ${collection.source.duplicateCount} mục trùng video ID.`:''}</p>}</div>}</div><div className={`session-actions ${firstLongTrack?'has-longform':''}`}>{firstLongTrack&&<button className="button primary" onClick={playLong} disabled={!ready||loading} title="Phát từ bản ru dài đầu tiên. Quảng cáo do YouTube quyết định."><Play size={15} fill="currentColor"/>Nghe bản dài</button>}<button className={firstLongTrack?'button':'button primary'} onClick={playAll} disabled={!ready||!session?.tracks.length}><Play size={15} fill="currentColor"/>Phát tất cả</button><IconButton label={copied?'Đã sao chép liên kết':'Chia sẻ playlist'} onClick={copy} disabled={!session}>{copied?<Check size={18}/>:<Link2 size={18}/>}</IconButton>{session?.canEdit&&<IconButton label="Đổi tên session" onClick={()=>openDialog('rename')} disabled={busy}><Pencil size={16}/></IconButton>}</div></section>
    <section className="console-room" aria-label="Không gian nghe nhạc">
     <div className="now-playing"><div className="track-info"><p className="eyebrow now-label"><span className={`status-dot ${playing?'on':''}`}/>{playing?'ĐANG PHÁT':playerState===3?'ĐANG TẢI NHẠC':'TRÊN BÀN ĐĨA'}<span className="now-separator">/</span>{queue?.kind==='all'?'Tất cả bài hát':queue?.name||'LISTEN'}</p><h2>{track?.title||'Chọn một bài để bắt đầu'}</h2><p>{track?.channel||(track?'YouTube · Chưa có thông tin kênh':'Một không gian nhỏ cho những giai điệu lớn.')}</p></div>{track&&<a href={track.url} target="_blank" rel="noopener noreferrer" className="icon-button original-link" aria-label="Mở video đang nghe trên YouTube"><ArrowUpRight size={19}/></a>}</div>
     <Turntable loadReady={!loading} signal={{videoId:currentId,playerState,progress,duration}} title={track?.title||'Listen — Selected'} channel={track?.channel||'YouTube'} lightMode={lightMode} onLightMode={changeLightMode} onAction={action=>{if(action==='toggle')togglePlay();else if(action==='previous')previousTrack();else move(1);}}/>
    </section>
    {blocked&&<div className="notice"><Play size={18}/><span>Trình duyệt đang chờ thao tác để phát nhạc.</span><button className="button primary compact" onClick={togglePlay}>Chạm để phát</button></div>}
    {playerError&&<div className="notice error" role="alert"><AlertCircle size={18}/><span>{playerError}</span>{track&&<a className="button compact" href={track.url} target="_blank" rel="noopener noreferrer">YouTube<ArrowUpRight size={16}/></a>}<button className="button compact" onClick={()=>move(1)}>Chuyển bài<SkipForward size={16}/></button></div>}
    <section className="media-panel" aria-label="Video YouTube chính thức">
     <div className="player-frame"><PlayerSurface onReady={p=>{player.current=p;readyRef.current=true;setReady(true);setApiError('');apply();}} onState={onState} onError={onPlayerError} onBlocked={()=>setBlocked(true)} onLoadError={m=>{readyRef.current=false;setReady(false);setApiError(m);}} attempt={playerAttempt}/>{!ready&&!apiError&&<div className="player-loading" aria-live="polite"><LoaderCircle className="spin" size={24}/><span>Đang kết nối YouTube…</span></div>}</div>
     <div className="media-caption"><span className="youtube-badge"><svg viewBox="0 0 24 18" width="20" height="15" aria-hidden="true"><rect y="1" width="24" height="16" rx="4" fill="currentColor"/><path d="m10 5 6 4-6 4" fill="#17191a"/></svg>YOUTUBE PLAYER</span><h3>Âm nhạc thật.<br/>Một không gian khác.</h3><p>Video gốc và điều khiển YouTube luôn hiển thị. Bàn đĩa chuyển động theo trạng thái phát.</p><span className="media-status"><span className={`status-dot ${playing?'on':''}`}/>{ready?'ĐÃ KẾT NỐI':'ĐANG KẾT NỐI'}<span>INLINE PLAYBACK</span></span></div>
    </section>
    {apiError&&<div className="notice error"><AlertCircle size={18}/><span>{apiError}</span><button className="button compact" onClick={()=>{setApiError('');player.current=null;readyRef.current=false;if(currentRef.current)pending.current={id:currentRef.current,play:false,start:progress};setPlayerAttempt(a=>a+1);}}>Thử lại</button></div>}
    <section className="playlist-card" aria-label="Danh sách bài hát" id="track-list" tabIndex={-1}>
     <div className="playlist-heading"><div className="section-title"><h2>{isAll?'Tất cả bài hát':'Danh sách phát'}</h2><span className="count-badge">{session?.tracks.length||0}</span></div><div className="playlist-tools">{metaLoading?<span className="metadata-indicator"><LoaderCircle className="spin" size={14}/>Đang lấy thông tin</span>:session?.tracks.some(t=>t.metadataStatus!=='ready')&&<IconButton label="Tải lại thông tin từ YouTube" onClick={()=>void hydrate(session.slug,session.tracks,sequence.current,true)}><RefreshCw size={16}/></IconButton>}{session?.canEdit&&<button className="button compact" onClick={()=>openDialog('add')} disabled={busy}><Plus size={16}/>Thêm bài</button>}<IconButton label="Xuất danh sách URL" onClick={exportList} disabled={!session?.tracks.length}><Download size={17}/></IconButton>{session?.canEdit&&<IconButton label="Xóa session" className="danger" onClick={()=>openDialog('delete')} disabled={busy}><Trash2 size={16}/></IconButton>}</div></div>
     <div className="list-meta"><span>{query?`${filtered.length} kết quả cho “${query}”`:isAll?'Đã gộp bài trùng · Thứ tự nghe ổn định':session?.canEdit?'Tự lưu trực tuyến · Kéo để sắp xếp':'Playlist chia sẻ · Chỉ nghe'}</span>{query?<button className="text-button" onClick={()=>setQuery('')}>Xóa tìm kiếm<X size={13}/></button>:<span className="mono">{session?.canEdit?'EDITABLE':'SELECT / PLAY'}</span>}</div>
     <div className="track-column-head" aria-hidden="true"><span>#</span><span>BÀI HÁT / NGHỆ SĨ</span><span>THAO TÁC</span></div>
    <div className="song-list" aria-busy={loading||busy}>
     {loading&&!session?<div className="empty-state"><LoaderCircle className="spin" size={28}/><h3>Đang mở playlist</h3><p>Một chút nữa thôi, âm nhạc sẽ ở đây.</p></div>:!session?<div className="empty-state"><Headphones size={34}/><h3>Một phòng nghe mới đang chờ</h3><p>Tạo session của bạn hoặc mở một liên kết được chia sẻ.</p><button className="button primary" onClick={()=>openDialog('open')}>Mở session<ChevronRight size={17}/></button></div>:!session.tracks.length?<div className="empty-state"><Music2 size={34}/><h3>Bắt đầu bằng một bài bạn thích</h3><p>{session.canEdit?'Dán link YouTube phía trên. Mọi bài hát sẽ tự động được lưu.':'Người tạo chưa thêm bài vào playlist này.'}</p></div>:!filtered.length?<div className="empty-state"><Search size={30}/><h3>Chưa tìm thấy bài hát</h3><p>Thử tiêu đề, tên kênh hoặc video ID khác.</p><button className="button compact" onClick={()=>setQuery('')}>Xóa tìm kiếm</button></div>:filtered.map(t=>{const index=trackIndexes.get(t.videoId)??0,active=t.videoId===currentId;return <div key={t.videoId} className={`song-row ${active?'current':''} ${dragged===t.videoId?'dragging':''}`} onDragOver={e=>{if(session.canEdit&&!query){e.preventDefault();e.dataTransfer.dropEffect='move';}}} onDrop={e=>{e.preventDefault();if(dragged&&session.canEdit&&!query)void reorder(dragged,t.videoId);setDragged(null);}}>
      <div className="row-index" data-index={String(index+1).padStart(2,'0')}>{session.canEdit&&!query?<span className="drag-handle" title={`Kéo để di chuyển bài ${index+1}`} draggable={!busy} onDragStart={e=>{setDragged(t.videoId);e.dataTransfer.setData('text/plain',t.videoId);e.dataTransfer.effectAllowed='move';}} onDragEnd={()=>setDragged(null)}><GripVertical size={16}/></span>:<span>{String(index+1).padStart(2,'0')}</span>}</div>
      <button className="song-select" onClick={()=>playFromBrowse(t.videoId)} disabled={!ready} aria-label={`Phát ${t.title}`}><span className="thumbnail"><img src={t.thumbnail} alt="" loading="lazy" width="72" height="48" onError={e=>{e.currentTarget.style.visibility='hidden';}}/><span className={`thumb-play ${active?'show':''}`}>{active&&playing?<Equalizer active/>:<Play size={18} fill="currentColor"/>}</span></span><span className="song-text"><span className="song-title">{t.title}</span><span className="song-channel">{t.channel||(t.metadataStatus==='pending'?'Đang chờ thông tin YouTube':'Chưa lấy được metadata · YouTube')}{active&&<span className="current-tag">{playing?'Đang phát':'Đã chọn'}</span>}</span>{isAll&&t.sourcePlaylists?.length&&<span className="song-sources" title={t.sourcePlaylists.map(p=>p.name).join(' · ')}>{t.sourcePlaylists[0].name}{t.sourcePlaylists.length>1?` +${t.sourcePlaylists.length-1}`:''}</span>}</span></button>
      <div className="row-actions">{session.canEdit&&<><IconButton label={`Đưa bài ${index+1} lên`} className="move-button" disabled={busy||index===0||!!query} onClick={()=>shift(t.videoId,-1)}><ArrowUp size={16}/></IconButton><IconButton label={`Đưa bài ${index+1} xuống`} className="move-button" disabled={busy||index===session.tracks.length-1||!!query} onClick={()=>shift(t.videoId,1)}><ArrowDown size={16}/></IconButton></>}<a className="icon-button" href={t.url} target="_blank" rel="noopener noreferrer" aria-label={`Mở ${t.title} trên YouTube`} title="Mở trên YouTube"><ArrowUpRight size={18}/></a>{session.canEdit&&<IconButton label={`Xóa ${t.title}`} className="danger" onClick={()=>remove(t.videoId)} disabled={busy}><Trash2 size={16}/></IconButton>}</div>
     </div>;})}
    </div>     <div className="playlist-footer"><span><span className={`save-dot ${busy?'working':''}`}/>{busy?'Đang lưu thay đổi…':isAll?`Tổng hợp trực tuyến · ${session?.sourceCount||0} playlist`:session?'Đã lưu trực tuyến':'Chưa có playlist'}</span><span>{session?.tracks.length||0} TRACKS</span></div>
    </section>
    <footer className="site-footer"><span className="footer-brand">listen.</span><details><summary>Về trải nghiệm nghe<ChevronDown size={13}/></summary><p>Video phát bằng YouTube IFrame Player API chính thức. Trình duyệt có thể tạm dừng khi chuyển ứng dụng hoặc khóa màn hình; chưa xác minh phát nền trên iPhone/Android thật. Trạng thái nghe được nhớ riêng trên thiết bị này. Chỉ chủ session sau khi đăng nhập mới được chỉnh sửa. <a href="https://www.youtube.com/t/terms" target="_blank" rel="noopener noreferrer">Điều khoản YouTube</a> · <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer">Quyền riêng tư Google</a>.</p></details><span className="mono">MADE FOR SLOW NIGHTS</span></footer>
   </main>
   <aside className={`queue-panel ${queueOpen?'drawer-open':''}`} id="queue-panel" aria-label="Hàng phát hiện tại">
    <div className="panel-heading"><h2>Hàng phát<span>{queue?.tracks.length||0}</span></h2><IconButton label="Đóng hàng phát" onClick={()=>setQueueOpen(false)}><PanelRightClose size={18}/></IconButton></div>
    <p className="queue-context">{queue?.name||'Chưa chọn hàng phát'}<small>{repeat==='one'?'Lặp lại bài đang nghe':shuffle?'Ngẫu nhiên · Chọn bài kế tiếp khi chuyển':'Phát theo thứ tự'}</small></p>
    {track&&<><div className="library-caption"><span>ĐANG TRÊN BÀN ĐĨA</span><Equalizer active={playing}/></div><button className="queue-current" onClick={togglePlay} disabled={!ready} aria-label={playing?'Tạm dừng bài hiện tại':'Phát bài hiện tại'}><span className="queue-art"><img src={track.thumbnail} alt="" width="184" height="104" loading="lazy"/>{playing?<Pause size={20} fill="currentColor"/>:<Play size={20} fill="currentColor"/>}</span><strong>{track.title}</strong><small>{track.channel||'YouTube'}</small></button></>}
    <div className="library-caption"><span>{shuffle?'TRONG HÀNG PHÁT':'TIẾP THEO'}</span><span>{Math.max(0,(queue?.tracks.length||0)-queueIndex-1)}</span></div>
    <div className="queue-list">{(queue?.tracks.slice(Math.max(queueIndex+1,0))||[]).map((t,i)=><button className="queue-item" key={t.videoId} onClick={()=>select(t.videoId,true,0,true)} disabled={!ready}><span className="queue-number">{String(i+1).padStart(2,'0')}</span><img src={t.thumbnail} alt="" width="42" height="32" loading="lazy"/><span><strong>{t.title}</strong><small>{t.channel||'YouTube'}</small></span><Play size={12}/></button>)}{queue&&queueIndex===queue.tracks.length-1&&<p className="queue-empty">Cuối hàng phát.{repeat!=='off'?' Chế độ lặp đang bật.':' Chọn một bài hoặc playlist để nghe tiếp.'}</p>}</div>
    <div className="queue-bottom"><span className="tiny-dot"/><span>Đổi playlist để khám phá.<br/>Bài đang nghe vẫn ở đây.</span></div>
   </aside>
  </div>
  <section className="transport-dock" aria-label="Điều khiển phát nhạc">
   <div className="dock-track">{track?<img src={track.thumbnail} alt="" width="48" height="48"/>:<span className="dock-empty"><Disc3 size={24}/></span>}<div><strong>{track?.title||'Chưa có bài hát'}</strong><span>{track?.channel||'Chọn một giai điệu bạn thích'}</span></div><span className="dock-playing"><Equalizer active={playing}/></span></div>
   <div className="dock-center"><div className="transport"><IconButton label={shuffle?'Tắt phát ngẫu nhiên':'Bật phát ngẫu nhiên'} aria-pressed={shuffle} className={shuffle?'selected':''} onClick={()=>setShuffle(!shuffle)}><Shuffle size={17}/></IconButton><IconButton label="Bài trước" onClick={previousTrack} disabled={!track||!ready}><SkipBack size={19} fill="currentColor"/></IconButton><IconButton label={playing?'Tạm dừng':'Phát nhạc'} className="play-main" onClick={togglePlay} disabled={!track||!ready}>{playerState===3?<LoaderCircle size={22} className="spin"/>:playing?<Pause size={22} fill="currentColor"/>:<Play size={22} fill="currentColor"/>}</IconButton><IconButton label="Bài tiếp theo" onClick={()=>move(1)} disabled={!track||!ready}><SkipForward size={19} fill="currentColor"/></IconButton><IconButton label={`Chế độ lặp: ${repeat==='off'?'tắt':repeat==='one'?'một bài':'toàn bộ'}. Chạm để đổi`} aria-pressed={repeat!=='off'} className={repeat!=='off'?'selected':''} onClick={()=>setRepeat(repeat==='off'?'all':repeat==='all'?'one':'off')}>{repeat==='one'?<Repeat1 size={17}/>:<Repeat size={17}/>}</IconButton></div><div className="progress-wrap"><span>{time(progress)}</span><input type="range" aria-label="Tua vị trí phát" min="0" max={Math.max(duration,1)} step="1" value={Math.min(progress,duration||1)} disabled={!ready||!track||!duration} onChange={e=>{const n=Number(e.target.value);player.current?.seekTo(n,true);setProgress(n);}} style={{'--progress':`${duration?progress/duration*100:0}%`} as React.CSSProperties}/><span>{time(duration)}</span></div></div>
   <div className="dock-right"><span className="source-status"><span className={`status-dot ${playing?'on':''}`}/>{playing?'ĐANG PHÁT':playerState===3?'ĐANG TẢI':'SẴN SÀNG'}<small>YOUTUBE / {lightMode?'LIGHT':'3D'}</small></span><IconButton label={queueOpen?'Đóng hàng phát':'Mở hàng phát'} aria-expanded={queueOpen} aria-controls="queue-panel" className={queueOpen?'selected':''} onClick={()=>{setLibraryOpen(false);setQueueOpen(!queueOpen);}}>{queueOpen?<PanelRightClose size={20}/>:<PanelRightOpen size={20}/>}</IconButton></div>
  </section>
  {message&&<div className={`toast ${message.error?'error':''}`} role={message.error?'alert':'status'}>{message.error?<AlertCircle size={19}/>:<Check size={19}/>}<span>{message.text}</span><IconButton label="Đóng thông báo" onClick={()=>setMessage(null)}><X size={16}/></IconButton></div>}
  {dialog==='add'&&<Modal title="Thêm vào playlist" onClose={()=>{if(!busy)setDialog(null);}}><p>Dán URL YouTube, Shorts hoặc video ID. Mỗi dòng một bài.</p><label htmlFor="add-tracks">Danh sách liên kết</label><textarea id="add-tracks" rows={7} autoFocus value={addText} onChange={e=>setAddText(e.target.value)} placeholder={'https://www.youtube.com/watch?v=…\nhttps://youtu.be/…'} disabled={busy}/><p className="small">Giữ thứ tự nhập · Tự bỏ bài trùng · Dòng lỗi không ảnh hưởng các bài hợp lệ.</p><div className="modal-actions"><button className="button" onClick={()=>setDialog(null)} disabled={busy}>Đóng</button><button className="button primary" onClick={addTracks} disabled={busy||!addText.trim()||!session?.canEdit}>{busy?<LoaderCircle size={16} className="spin"/>:<Plus size={16}/>}Thêm bài</button></div></Modal>}
  {(dialog==='create'||dialog==='open'||dialog==='rename'||dialog==='share'||dialog==='delete')&&<Modal title={dialog==='create'?'Tạo một phòng nghe':dialog==='open'?'Mở session':dialog==='rename'?'Đổi tên phòng nghe':dialog==='share'?'Liên kết chia sẻ':'Xóa session?'} onClose={()=>{if(!busy)setDialog(null);}}>
   {dialog==='share'?<><p>Ai có liên kết này đều có thể nghe. Quyền chỉnh sửa vẫn thuộc người tạo.</p><input aria-label="Liên kết chia sẻ chỉ nghe" readOnly value={shareUrl()} onFocus={e=>e.currentTarget.select()}/><p className="small">Chọn và sao chép liên kết nếu trình duyệt chưa cấp quyền clipboard.</p></>:<form onSubmit={submitDialog}>
    {(dialog==='create'||dialog==='open')&&<><label htmlFor="session-slug">Session slug</label><input id="session-slug" value={slugInput} onChange={e=>setSlugInput(e.target.value.toLowerCase())} autoFocus placeholder="ví dụ: midnight-drive" autoComplete="off" maxLength={48} required/><p className="small">3–48 ký tự: chữ thường, số, dấu gạch ngang.</p></>}
    {(dialog==='create'||dialog==='rename')&&<><label htmlFor="session-name">Tên hiển thị {dialog==='create'&&<span className="muted">(tùy chọn)</span>}</label><input id="session-name" value={nameInput} onChange={e=>setNameInput(e.target.value)} placeholder="Một đêm nhiều nhạc" autoFocus={dialog==='rename'} maxLength={100} required={dialog==='rename'}/>{dialog==='rename'&&<p className="small">Liên kết ?s={session?.slug} sẽ được giữ nguyên.</p>}</>}
    {dialog==='open'&&user.sessions.length>0&&<div className="recent-sessions"><p className="eyebrow">SESSION CỦA BẠN</p>{user.sessions.map(s=><button type="button" key={s.slug} onClick={()=>{setDialog(null);void loadSession(s.slug);}}><Music2 size={15}/><span>{s.name}</span><ChevronRight size={16}/></button>)}</div>}
    {dialog==='delete'&&<p>Playlist <strong>{session?.name}</strong> và toàn bộ {session?.tracks.length} bài sẽ bị xóa khỏi hệ thống. Liên kết chia sẻ sẽ không mở được nữa. Thao tác này không thể hoàn tác.</p>}
    {dialogError&&<p className="field-error" role="alert">{dialogError}</p>}
    <div className="modal-actions"><button type="button" className="button" onClick={()=>setDialog(null)} disabled={busy}>Hủy</button><button type="submit" className={`button ${dialog==='delete'?'danger-solid':'primary'}`} disabled={busy}>{busy?<LoaderCircle className="spin" size={17}/>:dialog==='delete'?<Trash2 size={17}/>:null}{dialog==='create'?'Tạo session':dialog==='open'?'Mở phòng nghe':dialog==='rename'?'Lưu tên mới':'Xóa session'}</button></div>
   </form>}
  </Modal>} </div>;
}
