'use client';
import {useEffect,useMemo,useRef,useState,type CSSProperties,type PointerEvent} from 'react';
import {ArrowDown,ArrowRight,Check,CheckCheck,Download,FileText,FileUp,FolderPlus,LayoutList,LoaderCircle,MousePointer2,RefreshCw,Upload,X} from 'lucide-react';
import {nameValue,slugValue,type AdminPlaylist,type Session} from '@/lib/domain';
import {MAX_IMPORT_BYTES,parseUrlFile,suggestSlug,type ImportReport,type ImportTarget} from '@/lib/file-import';
import {advanceFlight,clamp,createFlight,createShot,predictFlight,pullPower,shotPath,shotWillScore,type ShotGeometry,type ShotPlan} from '@/lib/basketball';
import './file-import.css';

type Saved={session:Session;report:ImportReport;replayed?:boolean};
type Props={playlists:AdminPlaylist[];initialSlug?:string;request:<T>(path:string,init?:RequestInit,signal?:AbortSignal)=>Promise<T>;onBusy:(busy:boolean)=>void;onImported:(session:Session,ids:string[])=>void;onOpen:(slug:string)=>void};
type FileData={name:string;text:string;size:number};
type DragInput={pointerId:number;clientX:number;clientY:number;preventDefault:()=>void};
export default function FileImport({playlists,initialSlug,request,onBusy,onImported,onOpen}:Props){
 const [mode,setMode]=useState<'new'|'existing'>(initialSlug?'existing':'new'),[name,setName]=useState(''),[slug,setSlug]=useState(''),[customSlug,setCustomSlug]=useState(false),[selected,setSelected]=useState(initialSlug||'');
 const [targetSession,setTargetSession]=useState<Session|null>(null),[targetLoading,setTargetLoading]=useState(false),[targetError,setTargetError]=useState('');
 const [file,setFile]=useState<FileData|null>(null),[reading,setReading]=useState(false),[working,setWorking]=useState(false),[hover,setHover]=useState(false),[error,setError]=useState(''),[feedback,setFeedback]=useState(''),[result,setResult]=useState<Saved|null>(null),[score,setScore]=useState(0),[shot,setShot]=useState(false);
 const [offset,setOffset]=useState({x:0,y:0}),[dragging,setDragging]=useState(false);
 const [flying,setFlying]=useState(false),[power,setPower]=useState(0),[aim,setAim]=useState<ShotPlan|null>(null);
 const [cardHover,setCardHover]=useState(false);
 const [rimImpact,setRimImpact]=useState<{count:number;side:'left'|'right'}|null>(null),[netCatching,setNetCatching]=useState(false);
 const frame=useRef<number|null>(null),inFlight=useRef(false),ignoreClickUntil=useRef(0);
 const gestureCleanup=useRef<(()=>void)|null>(null);
 const alive=useRef(true),locked=useRef(false),readSequence=useRef(0),targetSequence=useRef(0),targetController=useRef<AbortController|null>(null),importController=useRef<AbortController|null>(null);
 const input=useRef<HTMLInputElement>(null),court=useRef<HTMLDivElement>(null),paper=useRef<HTMLButtonElement>(null),hoop=useRef<HTMLSpanElement>(null);
 const drag=useRef<{id:number;x:number;y:number;dx:number;dy:number;box:DOMRect;geometry:ShotGeometry}|null>(null),attempt=useRef<{key:string;id:string}|null>(null),depth=useRef(0);
 const api=useRef(request),callbacks=useRef({onBusy,onImported});api.current=request;callbacks.current={onBusy,onImported};
 const currentTarget=useRef(targetSession);currentTarget.current=targetSession;
 useEffect(()=>{alive.current=true;return()=>{alive.current=false;gestureCleanup.current?.();gestureCleanup.current=null;inFlight.current=false;if(frame.current!==null)cancelAnimationFrame(frame.current);readSequence.current++;targetSequence.current++;targetController.current?.abort();importController.current?.abort();callbacks.current.onBusy(false);};},[]);
 async function loadTarget(id:string){
  const token=++targetSequence.current;targetController.current?.abort();const controller=new AbortController();targetController.current=controller;setTargetLoading(true);setTargetError('');
  try{const data=await api.current<{session:Session}>(`/sessions/${id}`,{},controller.signal);if(alive.current&&token===targetSequence.current){if(!data.session.canEdit)throw new Error('Bạn không có quyền thêm bài vào playlist này.');setTargetSession(data.session);}}
  catch(e){if(alive.current&&token===targetSequence.current&&(e as Error).name!=='AbortError')setTargetError((e as Error).message);}
  finally{if(alive.current&&token===targetSequence.current)setTargetLoading(false);}
 }
 useEffect(()=>{targetSequence.current++;targetController.current?.abort();setTargetLoading(false);setTargetError('');if(mode==='existing'&&selected){if(currentTarget.current?.slug!==selected){setTargetSession(null);void loadTarget(selected);}}else setTargetSession(null);},[mode,selected]);
 const target=useMemo(()=>{try{if(mode==='new')return {kind:'new',name:nameValue(name),slug:slugValue(slug)} satisfies ImportTarget;if(!selected||targetLoading||targetError||targetSession?.slug!==selected||!targetSession.canEdit)return null;return {kind:'existing',slug:selected,version:targetSession.version} satisfies ImportTarget;}catch{return null;}},[mode,name,slug,selected,targetLoading,targetError,targetSession]);
 const preview=useMemo(()=>{if(!file)return null;try{return {data:parseUrlFile(file.name,file.text,mode==='existing'&&targetSession?.slug===selected?targetSession.tracks.map(t=>t.videoId):[]),error:''};}catch(e){return {data:null,error:(e as Error).message};}},[file,mode,targetSession,selected]);
 const ready=!!file&&!!target&&!!preview?.data&&(preview.data.report.added>0||preview.data.report.duplicates>0)&&!reading&&!working&&!flying&&!result;
 const interactionBusy=working||reading||flying;
 const canDrag=!!file&&!interactionBusy&&!result;
 const targetName=mode==='new'?name.trim():targetSession?.name||'';
 async function send(data:FileData){
  if(locked.current)return;
  if(!target){setError('Đặt tên và đường dẫn playlist mới, hoặc chọn playlist có sẵn trước khi ném.');setShot(false);callbacks.current.onBusy(false);return;}
  let parsed;try{parsed=parseUrlFile(data.name,data.text,mode==='existing'&&targetSession?targetSession.tracks.map(t=>t.videoId):[]);if(!parsed.ids.length&&!parsed.report.duplicates)throw new Error('Chưa tìm thấy URL YouTube hợp lệ trong file.');}catch(e){setError((e as Error).message);setShot(false);callbacks.current.onBusy(false);return;}
  locked.current=true;setWorking(true);callbacks.current.onBusy(true);setError('');setFeedback('Đang lưu bài hát vào playlist…');setResult(null);setOffset({x:0,y:0});setShot(true);
  const payload={target,fileName:data.name,text:data.text},key=JSON.stringify(payload);if(attempt.current?.key!==key)attempt.current={key,id:crypto.randomUUID()};
  const controller=new AbortController();importController.current=controller;
  try{
   const saved=await api.current<Saved>('/admin/import',{method:'POST',headers:{'X-Request-ID':attempt.current.id},body:JSON.stringify(payload)},controller.signal);
   if(!alive.current)return;
   setResult(saved);setScore(value=>value+saved.report.added);setFeedback(saved.replayed?'Đã xác nhận lần nhập trước. Playlist đã được lưu.':saved.report.added?'Vào rổ! Nhạc đã có trong playlist.':'Đã kiểm tra: các bài hợp lệ đều có sẵn trong playlist.');
   setTargetSession(saved.session);setSelected(saved.session.slug);setMode('existing');attempt.current=null;
   callbacks.current.onImported(saved.session,parsed.ids);
  }catch(e){if(!alive.current||(e as Error).name==='AbortError')return;setError((e as Error).message);setFeedback('File vẫn ở đây. Bạn có thể thử lại.');setShot(false);if((e as Error&{status?:number}).status===409){attempt.current=null;if(target.kind==='existing')void loadTarget(target.slug);}}
  finally{locked.current=false;if(alive.current){setWorking(false);callbacks.current.onBusy(false);}}
 }
 async function receive(files:File[]){
  if(locked.current||reading||inFlight.current)return;
  if(files.length!==1){setError('Mỗi lượt chọn một file để giữ đúng thứ tự bài.');return;}
  const source=files[0],token=++readSequence.current;setError('');setResult(null);setShot(false);setFeedback('');setOffset({x:0,y:0});setReading(true);attempt.current=null;
  try{
   if(source.size>MAX_IMPORT_BYTES)throw new Error('File tối đa 256 KB.');
   const bytes=await source.arrayBuffer();let text:string;try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{throw new Error('Không đọc được UTF-8. Hãy xuất danh sách thành file .txt UTF-8.');}
   const data={name:source.name,text,size:source.size};parseUrlFile(data.name,data.text);
   if(!alive.current||token!==readSequence.current)return;
   if(mode==='new'&&!name.trim()){const suggested=source.name.replace(/\.[^.]+$/,'').replace(/[_-]+/g,' ').trim().slice(0,100)||'Playlist của tôi';setName(suggested);if(!customSlug){const id=suggestSlug(suggested);setSlug(id.length>=3?id:`playlist-${id||'nhac'}`);}}
   setFile(data);setFeedback('File đã sẵn sàng. Giữ chuột ở bất kỳ góc nào của thẻ, kéo để chỉnh hướng và lực, rồi thả tay.');setPower(0);setAim(null);setCardHover(false);setRimImpact(null);setNetCatching(false);
  }catch(e){if(alive.current&&token===readSequence.current){setFile(null);setError((e as Error).message);}}
  finally{if(alive.current&&token===readSequence.current)setReading(false);if(input.current)input.current.value='';}
 }
 function geometry():{box:DOMRect;geometry:ShotGeometry}|null{
  const box=paper.current?.getBoundingClientRect(),bounds=court.current?.getBoundingClientRect(),rim=hoop.current?.getBoundingClientRect();if(!box||!bounds||!rim)return null;
  return {box,geometry:{origin:{x:(box.left+box.right)/2-bounds.left,y:(box.top+box.bottom)/2-bounds.top},rim:{left:rim.left-bounds.left,right:rim.right-bounds.left,y:(rim.top+rim.bottom)/2-bounds.top},width:bounds.width,height:bounds.height,maxPull:Math.max(24,Math.min(96,bounds.bottom-box.bottom-12))}};
 }
 function clearFlightStyle(){for(const key of ['--drag-x','--drag-y','--drag-tilt','--flight-rotation','--flight-scale'])paper.current?.style.removeProperty(key);}
 function cancelGesture(){if(!drag.current)return;drag.current=null;gestureCleanup.current?.();gestureCleanup.current=null;setDragging(false);setOffset({x:0,y:0});setPower(0);setAim(null);setFeedback('Đã dừng thao tác. Giữ và kéo thẻ để thử lại.');}
 function cancelFlight(){if(!inFlight.current)return;inFlight.current=false;if(frame.current!==null)cancelAnimationFrame(frame.current);frame.current=null;clearFlightStyle();setFlying(false);setShot(false);setOffset({x:0,y:0});setPower(0);setAim(null);setNetCatching(false);callbacks.current.onBusy(false);setFeedback('Đã hủy cú ném. File vẫn sẵn sàng để thử lại.');}
 function fly(plan:ShotPlan,data:FileData){
  if(locked.current||inFlight.current)return;inFlight.current=true;setFlying(true);setDragging(false);setCardHover(false);setAim(null);setOffset({x:0,y:0});setError('');setRimImpact(null);setNetCatching(false);setFeedback('Thẻ đang bay…');callbacks.current.onBusy(true);
  const body=createFlight(plan);let last:number|null=null;
  const finish=(scored:boolean)=>{
   if(!inFlight.current||!alive.current)return;inFlight.current=false;if(frame.current!==null)cancelAnimationFrame(frame.current);frame.current=null;clearFlightStyle();setFlying(false);setPower(0);setOffset({x:0,y:0});setNetCatching(false);
   if(scored){setShot(true);void send(data);}else{setShot(false);callbacks.current.onBusy(false);setFeedback(body.rimHits?'Bật vành ra ngoài rồi! Đổi góc hoặc giảm lực để thử lại.':plan.power<.52?'Hơi nhẹ! Tăng lực và canh chấm đỏ vào giữa vành rổ.':plan.power>.84?'Hơi mạnh! Giảm lực một chút rồi thử lại.':'Suýt vào rồi! Đổi góc kéo, canh chấm đỏ vào giữa vành rổ rồi thả.');}
  };
  if(typeof matchMedia==='function'&&matchMedia('(prefers-reduced-motion: reduce)').matches){const predicted=predictFlight(plan);body.rimHits=predicted.rimHits;finish(predicted.scored);return;}
  const tick=(now:number)=>{
   if(!alive.current||!inFlight.current)return;
   const delta=last===null?0:Math.max(0,Math.min(.04,(now-last)/1000));last=now;
   const event=advanceFlight(body,delta),point=body.position;
   paper.current?.style.setProperty('--drag-x',`${point.x-plan.geometry.origin.x}px`);paper.current?.style.setProperty('--drag-y',`${point.y-plan.geometry.origin.y}px`);paper.current?.style.setProperty('--flight-rotation',`${body.angle}deg`);paper.current?.style.setProperty('--flight-scale',String(body.scale));
   if(event.rimHit){setRimImpact({count:body.rimHits,side:body.lastRim!});setFeedback('Chạm vành! Thẻ vẫn đang nảy…');}
   if(event.entered){setNetCatching(true);setFeedback('Thẻ đang lọt qua lưới…');}
   if(event.done){finish(body.scored);return;}
   frame.current=requestAnimationFrame(tick);
  };
  frame.current=requestAnimationFrame(tick);
 }
 function assistedShot(){if(!ready||!file)return;const measured=geometry();if(measured)fly(createShot(measured.geometry,{x:0,y:0},true),file);}
 function pointerDown(e:PointerEvent<HTMLButtonElement>){
  if(!canDrag||e.button!==0||e.isPrimary===false||drag.current)return;const measured=geometry();if(!measured)return;e.preventDefault();
  drag.current={id:e.pointerId,x:e.clientX,y:e.clientY,dx:0,dy:0,...measured};setDragging(true);setShot(false);setPower(0);setError('');setRimImpact(null);setNetCatching(false);setAim(createShot(measured.geometry,{x:0,y:0}));setFeedback('Đang ngắm: di chuyển thẻ theo chuột, canh chấm đỏ vào rổ rồi thả.');
  const surface=paper.current?.ownerDocument?.defaultView||(typeof window!=='undefined'?window:null);
  if(surface?.addEventListener){
   const move=(event:globalThis.PointerEvent)=>pointerMove(event),up=(event:globalThis.PointerEvent)=>pointerUp(event),cancel=(event:globalThis.PointerEvent)=>{if(event.pointerId===drag.current?.id)cancelGesture();},blur=()=>cancelGesture();
   surface.addEventListener('pointermove',move,{capture:true,passive:false});surface.addEventListener('pointerup',up,true);surface.addEventListener('pointercancel',cancel,true);surface.addEventListener('blur',blur);
   gestureCleanup.current=()=>{surface.removeEventListener('pointermove',move,true);surface.removeEventListener('pointerup',up,true);surface.removeEventListener('pointercancel',cancel,true);surface.removeEventListener('blur',blur);};
  }
  // Capture can be unavailable in a frame or interrupted by the browser. The
  // window listeners above still finish the same gesture outside the card.
  try{e.currentTarget.focus({preventScroll:true});e.currentTarget.setPointerCapture(e.pointerId);}catch{}
 }
 function updatePull(d:NonNullable<typeof drag.current>,x:number,y:number){
  const g=d.geometry;d.dx=x-d.x;d.dy=y-d.y;
  // The visual card follows the pointer across the court. Only the power meter
  // is capped; reaching 100% must not pin the card to a 96px tether.
  paper.current?.style.setProperty('--drag-x',`${d.dx}px`);paper.current?.style.setProperty('--drag-y',`${d.dy}px`);paper.current?.style.setProperty('--drag-tilt',`${clamp(d.dx*.055,-12,12)}deg`);
  setOffset({x:d.dx,y:d.dy});setPower(pullPower({x:d.dx,y:d.dy},g));setAim(createShot(g,{x:d.dx,y:d.dy}));
 }
 function pointerMove(e:DragInput){const d=drag.current;if(d&&d.id===e.pointerId){e.preventDefault();updatePull(d,e.clientX,e.clientY);}}
 function pointerUp(e:DragInput){
  const d=drag.current;if(!d||d.id!==e.pointerId)return;e.preventDefault();updatePull(d,e.clientX,e.clientY);drag.current=null;setDragging(false);ignoreClickUntil.current=Date.now()+500;
  gestureCleanup.current?.();gestureCleanup.current=null;try{if(paper.current?.hasPointerCapture(e.pointerId))paper.current.releasePointerCapture(e.pointerId);}catch{}
  const centre={x:d.geometry.origin.x+d.dx,y:d.geometry.origin.y+d.dy},inside=centre.x>=0&&centre.x<=d.geometry.width&&centre.y>=0&&centre.y<=d.geometry.height;
  if(file&&Math.hypot(d.dx,d.dy)>=8&&inside){fly(createShot(d.geometry,{x:d.dx,y:d.dy}),file);}else{clearFlightStyle();setOffset({x:0,y:0});setAim(null);setPower(0);setFeedback(inside?'Giữ chuột trên thẻ, kéo để chỉnh hướng và lực rồi thả tay.':'Đưa thẻ vào trong sân rồi thả để ném.');}
 }
 function showRadar(){setCardHover(true);if(canDrag&&!drag.current){const measured=geometry();if(measured)setAim(createShot(measured.geometry,{x:0,y:measured.geometry.maxPull*.68}));}}
 function sample(){const url=URL.createObjectURL(new Blob(['https://www.youtube.com/watch?v=RzhIXHc6_80\nhttps://youtu.be/_U8S-uFZrHA\n'],{type:'text/plain;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='playlist-mau.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 const style={'--drag-x':`${offset.x}px`,'--drag-y':`${offset.y}px`} as CSSProperties;
 return <section className="file-import-page" aria-labelledby="file-import-title">
  <div className="manager-page-heading"><div><p className="manager-eyebrow">MỘT CÚ NÉM · CẢ PLAYLIST</p><h1 id="file-import-title">Thả nhạc vào rổ<span>.</span></h1><p>Một file liên kết, một cú ném. Để chúng tôi lo phần còn lại.</p></div><span className="import-beta-tag"><span/> NHẬP PLAYLIST</span></div>
  <div className="import-layout">
   <div className="import-config"><div className="import-step"><span>01</span><div><h2>Nhạc sẽ đi đâu?</h2><p>Chọn nơi lưu trước khi thực hiện cú ném.</p></div></div>
    <div className="import-target-tabs" role="group" aria-label="Loại playlist đích"><button type="button" aria-pressed={mode==='new'} onClick={()=>{setMode('new');setResult(null);setShot(false);}} disabled={interactionBusy}><FolderPlus size={16}/>Playlist mới</button><button type="button" aria-pressed={mode==='existing'} onClick={()=>{setMode('existing');setResult(null);setShot(false);}} disabled={interactionBusy}><LayoutList size={16}/>Có sẵn</button></div>
    {mode==='new'?<div className="import-fields"><label htmlFor="import-name">Tên playlist</label><input id="import-name" value={name} maxLength={100} placeholder="Ví dụ: Những đêm không ngủ" onChange={e=>{setName(e.target.value);if(!customSlug)setSlug(suggestSlug(e.target.value));}} disabled={interactionBusy}/><label htmlFor="import-slug">Đường dẫn playlist</label><div className="import-slug-field"><span>/</span><input id="import-slug" value={slug} maxLength={48} placeholder="nhung-dem-khong-ngu" autoCapitalize="none" spellCheck={false} onChange={e=>{setSlug(e.target.value.toLowerCase());setCustomSlug(true);}} disabled={interactionBusy}/></div><p>3–48 ký tự: chữ thường không dấu, số và gạch ngang. Tên tiếng Việt được chuyển thành đường dẫn tự động.</p>{slug&&!target&&<small className="import-field-note">Điền tên và đường dẫn hợp lệ trước khi ném.</small>}</div>:<div className="import-fields"><label htmlFor="import-target">Playlist của bạn</label><select id="import-target" value={selected} onChange={e=>{setSelected(e.target.value);setResult(null);setShot(false);}} disabled={interactionBusy}><option value="">Chọn một playlist…</option>{playlists.map(p=><option key={p.slug} value={p.slug}>{p.name} · {p.count} bài</option>)}{targetSession&&!playlists.some(p=>p.slug===targetSession.slug)&&<option value={targetSession.slug}>{targetSession.name}</option>}</select>{targetLoading?<p role="status"><LoaderCircle size={14} className="spin"/>Đang kiểm tra playlist…</p>:targetSession?.slug===selected&&<p>{targetSession.tracks.length} / 300 bài · Tự bỏ qua bài đã có.</p>}{targetError&&<div className="import-error" role="alert"><span>{targetError}</span><button className="manager-button" onClick={()=>void loadTarget(selected)}><RefreshCw size={14}/>Tải lại đích</button></div>}</div>}
    <div className="import-note"><CheckCheck size={18}/><div><strong>Ngăn nắp từ cú ném đầu tiên</strong><p>Giữ thứ tự trong file, chuẩn hóa URL và loại trùng theo video ID. Chỉ lưu khi có bài hợp lệ.</p></div></div>
    <div className="import-formats"><span className="import-small-label">FILE ĐƯỢC HỖ TRỢ</span><div><code>TXT</code><code>CSV</code><code>M3U</code><code>M3U8</code></div><p>UTF-8 · Tối đa 256 KB · 300 dòng bài hát.<br/>TXT: mỗi dòng một URL hoặc video ID.<br/>CSV: cột URL/link, có thể kèm tên bài.</p><button className="import-text-button" onClick={sample}><Download size={14}/>Tải file mẫu</button></div>
   </div>
   <div className={`import-experience ${dragging?'is-dragging':''}`}><header className="import-court-header"><div><span className="import-small-label">02 / CÚ NÉM CỦA BẠN</span><h2>Ném file. Thêm nhạc.</h2></div><span className="import-score" aria-label={`${score} bài đã nhập trong lượt này`}>Đã thêm <strong>{score}</strong></span></header>
    <div ref={court} className={`hoop-court ${hover?'is-over':''} ${working?'is-saving':''} ${result?'is-scored':''} ${dragging?'is-dragging':''} ${flying?'is-flying':''}`}
      onDragEnter={e=>{if(e.dataTransfer.types.includes('Files')){e.preventDefault();depth.current++;setHover(true);}}} onDragOver={e=>{if(e.dataTransfer.types.includes('Files')){e.preventDefault();e.dataTransfer.dropEffect=working||flying?'none':'copy';}}} onDragLeave={e=>{e.preventDefault();depth.current=Math.max(0,depth.current-1);if(!depth.current)setHover(false);}} onDrop={e=>{e.preventDefault();depth.current=0;setHover(false);if(!working&&!flying)void receive(Array.from(e.dataTransfer.files));}}>
     <div className="hoop-floor-mark" aria-hidden="true"/><span className="hoop-corner top-left" aria-hidden="true"/><span className="hoop-corner bottom-right" aria-hidden="true"/>
     <button type="button" className="hoop-drop-target" onClick={()=>input.current?.click()} disabled={interactionBusy} aria-label="Chọn file URL để nhập playlist"><Upload size={23} strokeWidth={1.4}/><strong>{hover?'Thả tay. Ghi điểm!':'Thả file vào đây'}</strong><small>chọn file · kéo quanh thẻ để ngắm · thả để ném</small></button>
     <div className={`hoop-anchor ${netCatching?'is-catching':''}`} aria-hidden="true"><svg viewBox="0 0 210 170" fill="none" className="import-hoop"><rect className="hoop-board" x="66" y="1" width="78" height="55" rx="2"/><path d="M105 56v10" stroke="#e97139" strokeWidth="2"/>
      <g className="hoop-net" stroke="#7d8793" strokeWidth=".8"><path d="M58 71l23 78M70 73l20 77M82 75l15 76M94 76l9 76M106 76v77M118 76l-9 76M130 75l-15 76M142 73l-20 77M154 71l-23 78"/><path d="M58 72l32 78M77 75l26 77M97 76l19 75M116 76l14 74M154 72l-32 78M135 75l-26 77M115 76l-19 75M96 76l-14 74M63 91h86M68 109h76M74 129h64"/></g><ellipse className="hoop-rim" cx="106" cy="70" rx="49" ry="6" stroke="#ef7235" strokeWidth="3.5"/><path d="M59 71q47 12 94 0" stroke="#ff9d63" strokeWidth="1.5"/>{rimImpact&&<ellipse key={rimImpact.count} className="hoop-impact-ring" cx={rimImpact.side==='left'?58:154} cy="70" rx="13" ry="9"/>}</svg><span ref={hoop} className="hoop-hit"/>{result&&<span className="hoop-success-mark"><Check size={15}/></span>}</div>
     {aim&&(dragging||cardHover)&&<svg className="hoop-aim" viewBox={`0 0 ${aim.geometry.width} ${aim.geometry.height}`} preserveAspectRatio="none" aria-hidden="true"><line x1={aim.geometry.origin.x} y1={aim.geometry.origin.y} x2={aim.start.x} y2={aim.start.y} className="hoop-pull-line"/><path d={shotPath(aim)} className={shotWillScore(aim)?'will-score':''}/><g className={`hoop-radar ${shotWillScore(aim)?'will-score':''}`} transform={`translate(${clamp(predictFlight(aim).target.x,14,aim.geometry.width-14)} ${clamp(predictFlight(aim).target.y,14,aim.geometry.height-14)})`}><circle className="hoop-radar-ring" r="11"/><path d="M-16 0h8M8 0h8M0-16v8M0 8v8"/><circle className="hoop-radar-dot" r="3.5"/></g></svg>}
     {file&&!result&&<div className="hoop-power"><div className="hoop-power-label"><span id="hoop-pull-help"><ArrowDown size={13}/>{dragging?'Thả chuột để ném':'Giữ và kéo thẻ để ngắm'}</span><strong>{aim?`${Math.round(Math.atan2(-aim.velocity.y,aim.velocity.x)*180/Math.PI)}° · `:''}{Math.round(power*100)}%</strong></div><div className="hoop-power-track" role="progressbar" aria-label="Lực ném" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(power*100)}><span className="hoop-power-zone"/><span className="hoop-power-fill" style={{width:`${power*100}%`}}/></div><small>Chấm đỏ: điểm rơi · Canh vào giữa vành rổ rồi thả</small></div>}
     <div className="hoop-floor-caption" aria-hidden="true">LISTEN COURT<span>VOL. 01</span></div>
     {file&&!reading?<button ref={paper} type="button" className={`hoop-file ${dragging?'is-grabbed':''} ${flying?'is-flying':''} ${shot?'is-shot':''}`} style={style} disabled={!canDrag} draggable={false} onDragStart={e=>e.preventDefault()} onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={cancelGesture} onLostPointerCapture={()=>{if(!gestureCleanup.current)cancelGesture();}} onPointerEnter={showRadar} onPointerLeave={()=>{setCardHover(false);if(!drag.current)setAim(null);}} onKeyDown={e=>{if(e.key==='Escape')cancelFlight();}} onClick={e=>{if(e.detail===0&&Date.now()>ignoreClickUntil.current)assistedShot();}} aria-describedby="hoop-pull-help" aria-label={`Ném file ${file.name} vào rổ`}><span className="hoop-paper-fold"/><FileText size={25} strokeWidth={1.5}/><span className="hoop-file-type">{file.name.split('.').at(-1)?.toUpperCase()}</span><small>{file.name}</small></button>:!file&&<button type="button" className="hoop-file-placeholder" onClick={()=>input.current?.click()} disabled={interactionBusy} aria-label="Chọn file trước khi kéo và ném"><span className="hoop-paper-fold"/><FileText size={28} strokeWidth={1.4}/><span className="hoop-file-type">CHỌN FILE</span></button>}
     {reading&&<div className="hoop-working" role="status"><LoaderCircle size={19} className="spin"/>Đang đọc file…</div>}{working&&<div className="hoop-working" role="status"><LoaderCircle size={19} className="spin"/>Đang lưu playlist…</div>}
    </div>
    <input ref={input} className="import-file-input" tabIndex={-1} type="file" accept=".txt,.csv,.m3u,.m3u8,text/plain,text/csv,audio/x-mpegurl" aria-label="File danh sách URL YouTube" disabled={interactionBusy} onChange={e=>{if(e.target.files?.length)void receive(Array.from(e.target.files));}}/>
    <div className="import-game-toolbar"><span><MousePointer2 size={15}/><span>{file?`${file.name} · ${(file.size/1024).toFixed(1)} KB`:'Kéo file từ máy tính vào sân'}</span></span><button type="button" className="manager-button" onClick={()=>input.current?.click()} disabled={interactionBusy}><FileUp size={16}/>{file?'Đổi file':'Chọn file'}</button>{flying?<button type="button" className="manager-button" onClick={cancelFlight}><X size={16}/>Hủy cú ném</button>:<button type="button" className="manager-button primary" onClick={assistedShot} disabled={!ready||!!result}>{working?<LoaderCircle className="spin" size={16}/>:<ArrowRight size={16}/>}Ném vào rổ</button>}</div>
   </div>
   {(file||error||feedback)&&<div className="import-summary" aria-live="polite">
    {error&&<div className="import-error" role="alert"><X size={17}/><span>{error}</span></div>}
    {preview?.error&&!result&&<div className="import-error" role="alert">{preview.error}</div>}
    {preview?.data&&<><div className="import-summary-heading"><div><span className="import-small-label">{result?'ĐÃ LƯU TRỰC TUYẾN':'PHÂN TÍCH FILE'}</span><h3>{result?'Playlist đã sẵn sàng':targetName||'Chọn playlist đích'}</h3><p role="status">{feedback}</p></div>{result&&<button className="manager-button" onClick={()=>onOpen(result.session.slug)}>Quản lý playlist<ArrowRight size={16}/></button>}</div><div className="import-report"><span><strong>{(result?.report||preview.data.report).added}</strong>{result?'bài đã thêm':'bài sẽ thêm'}</span><span><strong>{(result?.report||preview.data.report).duplicates}</strong>bài trùng</span><span><strong>{(result?.report||preview.data.report).invalid}</strong>dòng không hợp lệ</span><span><strong>{result?.session.tracks.length??(mode==='existing'?targetSession?.tracks.length??0:0)}</strong>{result?'bài trong playlist':'bài đang có'}</span></div>{(result?.report||preview.data.report).invalidLines.length>0&&<details className="import-invalid"><summary>Xem số dòng không hợp lệ</summary><p>Dòng {(result?.report||preview.data.report).invalidLines.join(', ')}. Những dòng này được bỏ qua; các bài hợp lệ vẫn được nhập.</p></details>}{result?.report.blocked? <p className="import-save-note">{result.report.blocked} video đã gỡ trước đây được bỏ qua, không thêm lại.</p>:null}{result&&<p className="import-save-note"><CheckCheck size={15}/>{result.session.name} · {result.session.tracks.length} bài · Nghe được qua liên kết playlist.</p>}</>}
   </div>}
  </div>
 </section>;
}
