CREATE TABLE IF NOT EXISTS video_checks (
 video_id TEXT PRIMARY KEY NOT NULL,
 checked_at INTEGER NOT NULL DEFAULT 0,
 next_check_at INTEGER NOT NULL DEFAULT 0,
 outcome TEXT NOT NULL DEFAULT 'unknown',
 reason TEXT NOT NULL DEFAULT '',
 source TEXT NOT NULL DEFAULT '',
 failures INTEGER NOT NULL DEFAULT 0,
 first_failed_at INTEGER,
 reported_at INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS video_blocks (
 video_id TEXT PRIMARY KEY NOT NULL,
 reason TEXT NOT NULL,
 source TEXT NOT NULL,
 evidence TEXT NOT NULL,
 confirmed_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS video_removals (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 video_id TEXT NOT NULL,
 slug TEXT NOT NULL,
 playlist_name TEXT NOT NULL,
 position INTEGER NOT NULL,
 track TEXT NOT NULL,
 removed_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS video_removals_video_idx ON video_removals(video_id);
CREATE TABLE IF NOT EXISTS maintenance_runs (
 id TEXT PRIMARY KEY NOT NULL,
 started_at INTEGER NOT NULL,
 finished_at INTEGER,
 summary TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS maintenance_daily (
 day TEXT PRIMARY KEY NOT NULL,
 checked INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS maintenance_locks (
 key TEXT PRIMARY KEY NOT NULL,
 token TEXT NOT NULL,
 expires_at INTEGER NOT NULL
);
-- The invariant lives in storage: seeds, imports and stale writes cannot
-- resurrect a confirmed unusable video. The surrounding write owns its version.
CREATE TRIGGER IF NOT EXISTS block_video_insert AFTER INSERT ON sessions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.tracks) t JOIN video_blocks b ON b.video_id=json_extract(t.value,'$.videoId'))
BEGIN
 UPDATE sessions SET tracks=(SELECT json_group_array(json(t.value)) FROM json_each(NEW.tracks) t WHERE NOT EXISTS (SELECT 1 FROM video_blocks b WHERE b.video_id=json_extract(t.value,'$.videoId'))) WHERE slug=NEW.slug;
END;
CREATE TRIGGER IF NOT EXISTS block_video_update AFTER UPDATE OF tracks ON sessions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.tracks) t JOIN video_blocks b ON b.video_id=json_extract(t.value,'$.videoId'))
BEGIN
 UPDATE sessions SET tracks=(SELECT json_group_array(json(t.value)) FROM json_each(NEW.tracks) t WHERE NOT EXISTS (SELECT 1 FROM video_blocks b WHERE b.video_id=json_extract(t.value,'$.videoId'))) WHERE slug=NEW.slug;
END;
