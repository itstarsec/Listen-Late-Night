CREATE TABLE `playlist_imports` (
 `owner_id` text NOT NULL,
 `request_id` text NOT NULL,
 `slug` text NOT NULL,
 `fingerprint` text NOT NULL,
 `report` text NOT NULL,
 `created_at` integer NOT NULL,
 PRIMARY KEY (`owner_id`, `request_id`)
);
