# Phạm vi kiểm tra

Thực hiện ngày 18/10/2026. Không gửi thao tác ghi tới Listen Mini hoặc backend tham khảo.

## Đã kiểm tra bằng code/SQLite

- Tạo session, thêm bài và đọc lại dữ liệu từ database độc lập với frontend.
- Người nghe ẩn danh đọc được session; người khác và người ẩn danh không được sửa/xóa; tạo session yêu cầu danh tính đã xác thực.
- URL watch, youtu.be, Shorts, embed, music/mobile và video ID; loại tracking/list/index khi chuẩn hóa.
- Nhập hàng loạt đúng thứ tự, trùng ID, dòng lỗi, dòng trống và giới hạn dữ liệu; một dòng lỗi không làm mất dòng đúng.
- Đổi tên không đổi slug, slug trùng trả xung đột.
- Thứ tự mới phải là hoán vị chính xác các video hiện tại. Xóa bài giữ thứ tự các bài còn lại.
- Kiểm tra phiên bản nguyên tử, hai request đồng thời chỉ một request ghi thành công, request cũ trả 409.
- Retry mã thao tác gần nhất không làm trùng dữ liệu.
- Session Shelby có đúng 25 ID, seed lặp không thêm trùng, xóa xong không tự khôi phục.
- Chuyển bài theo lặp tắt/một/toàn bộ; shuffle tránh bài hiện tại và kết thúc khi đã nghe hết ở chế độ không lặp; lựa chọn bài khi xóa bài hiện tại.
- Danh sách lỗi có giới hạn, xử lý tình huống không còn video khả dụng.
- Loader YouTube xử lý API có sẵn hoặc sẵn sàng muộn, chỉ chèn một script.
- Metadata chỉ truy xuất YouTube oEmbed và ID có trong playlist; tối đa 3 request đồng thời, có cache và fallback.
- Chuỗi người dùng được giữ như dữ liệu text; tên quá dài, slug lỗi, JSON sai, request khác origin bị từ chối.

Lệnh kiểm tra: `node tests/run.mjs` (57 trường hợp), `pnpm exec tsc --noEmit`.

Các test YouTube dùng mock API, không xác nhận có âm thanh hoặc quyền phát của video. Adapter D1 dùng SQLite thật để kiểm tra SQL/đọc ghi và cập nhật có điều kiện; không thay thế hoàn toàn D1 production.

## Khảo sát thực tế

Đã tải và đọc HTML, CSS, JavaScript công khai của Listen Mini bằng HTTP. Đã gọi YouTube oEmbed thật cho 25 ID, nhận được metadata của 23 video. Hai video còn lại được giữ nguyên ID và hiển thị fallback; chưa kết luận video bị xóa chỉ từ việc không lấy được metadata.

## Chưa kiểm tra bằng trình duyệt/thiết bị thật

Công cụ control-browser được Sites hỗ trợ không có trong phiên làm việc, nên không thực hiện preview/browser QA hoặc giả lập thành kết quả kiểm thử thực tế. Các mục sau cần kiểm thử bằng máy thật:

- Bấm phát, pause, seek, video ended tự chuyển, autoplay bị chặn và lỗi nhúng/giới hạn vùng trong YouTube thật.
- Thêm/xóa/sắp xếp/đổi tên lúc video đang phát, xác nhận player và âm thanh liên tục.
- Đăng nhập Sites trong trình duyệt, tạo playlist rồi reload, mở URL trong cửa sổ/thiết bị khác và xác nhận chủ sở hữu.
- Kéo thả desktop, thao tác cảm ứng ở 320px, Safari iPhone, Chrome Android tầm trung, clipboard/download và bàn phím.
- Mở trên thiết bị khác, chạy nền, chuyển ứng dụng và khóa màn hình. Không cam kết phát nền; trình duyệt/YouTube có thể tạm dừng.

Giao diện có media query từ 320px, vùng chạm thiết yếu 44px, input 16px, safe area cho toast, reduced motion, khung player tối thiểu 200px và thumbnail cố định. Đây là thuộc tính triển khai, chưa phải kết quả đo tốc độ/cuộn hay xác nhận bố cục trên điện thoại.

## Production

Kết quả publish và smoke test HTTP được ghi ở `DELIVERY.md` sau khi hoàn tất triển khai. Bản dùng thử công khai dùng D1 production riêng; không cần API key YouTube. Sự khả dụng từng video, kết nối Google/YouTube và quy trình đăng nhập tùy thuộc dịch vụ nền tảng.

## Bổ sung 10 playlist (18/10/2026)

Đã xác minh metadata YouTube của toàn bộ 111 video dùng trong 10 playlist mới. Mỗi playlist có 12 ID hợp lệ, duy nhất trong playlist, có tên/kênh/thumbnail thật; tổng cộng 120 vị trí bài hát. Có bài lặp giữa các tuyển chọn theo tâm trạng.

Sáu kiểm tra tích hợp bổ sung: catalogue gồm Shelby và 10 playlist; đọc từng session đúng 12 bài với metadata; mở trực tiếp trước khi tải catalogue; quyền sửa của chủ Site và chống chiếm slug; giữ nguyên chỉnh sửa người dùng qua lần seed tiếp theo; xóa playlist không bị tạo lại hoặc liệt kê lại. Bản build và TypeScript được kiểm tra lại. Không thực hiện browser QA trong môi trường hiện tại; xác minh oEmbed không xác nhận quyền nhúng theo vùng hay phát âm thanh trên thiết bị thật.

## Mặc định nghe tổng hợp (18/10/2026)

Bổ sung chín kiểm tra: URL không có s luôn chọn tổng hợp; s có giá trị vẫn là session slug; hàng phát gộp đúng thứ tự, duy nhất và đầy đủ; giữ membership của bài trùng; phản ánh thêm/xóa từ playlist nguồn mà không sao chép session; chặn ghi vào tổng hợp; kiểm tra metadata theo membership; xóa nguồn giữ bài còn trong nguồn khác; session riêng tên all vẫn độc lập và session không nằm trong catalogue không tự bị công khai trong tổng hợp. Tổng cộng 43 test; TypeScript và build được chạy lại. Browser QA vẫn chưa khả dụng trong môi trường này.


## Nâng cấp Turntable — 18/10/2026

57 test đã qua, gồm 14 kiểm tra bổ sung so với bản tổng hợp trước:

- Component integration (React test renderer, API YouTube giả lập): tạo player đúng một lần; Phát tất cả, nút trên mô hình và transport dùng chung handler; pause/play/seek cập nhật tín hiệu cho bàn đĩa; mở playlist khác, bật/tắt hàng phát và chế độ nhẹ không mất thời gian 83s; xóa bài khác không load lại; xóa bài đang nghe chuyển đúng bài kế tiếp mà giữ cùng instance player.
- Reconciliation hàng phát: thêm, đổi tên, đổi thứ tự, xóa nguồn và đổi nguồn giữ video còn tồn tại mà không load; khi mất current ID chọn successor/previous/null nhất quán.
- Motion: chỉ PLAYING tăng tốc, pause/buffering giảm về 0, vị trí kim theo tiến độ, cue khi đổi ID, reduced motion, delta thời gian lớn được giới hạn. Không mô phỏng tín hiệu âm thanh.
- Geometry: mô hình thực có các bộ phận yêu cầu; ba raycast target có chức năng; nguồn geometry được tái dùng và dispose đúng một lần; chế độ nhẹ ít groove hơn; tính toán thế giới xác nhận đầu kim hạ đúng mặt đĩa và đi từ rãnh ngoài vào trong.
- Server render: một player surface, điều khiển HTML và SVG fallback, title độc hại được escape.

TypeScript và Vinext build đã thành công. Three.js ở chunk `turntable-stage` tải động; bản build đầu có khoảng 585 KiB JS chưa nén dành cho 3D, tách khỏi bundle giao diện. Chưa đo thời gian tải mạng thực hoặc FPS GPU.

Đã đọc frontend công khai ISO-GLOW `/demo/3d` và iframe `/demo/gallery/3d.html?embed`: màu nền #121314, accent #ff9d3c, viền mảnh, cấu trúc cần kim/đĩa và chuyển động. Chưa chạy WebGL của website mẫu. Mô hình mới dùng code riêng và liên kết trạng thái YouTube hiện tại, không dùng audio engine riêng của mẫu.

Công cụ `$control-browser` mà Sites hỗ trợ không có trong phiên làm việc. Quy trình Sites yêu cầu “If `$control-browser` is unavailable, skip browser QA: do not start a preview server, install a browser, or improvise another browser-control path.” Do đó không khởi chạy preview server hoặc thay bằng trình duyệt khác. Các kiểm tra component/geometry ở trên không được gọi là xác minh WebGL, âm thanh, layout browser hay thiết bị thật.

Ảnh desktop/mobile trong `docs/previews` là bản dựng tĩnh sử dụng SVG fallback/metadata của ứng dụng; vùng video là minh họa. Không phải screenshot, không chứng minh responsive hoặc hiệu năng thực tế. Cần kiểm tra Safari iPhone/Chrome Android thật, touch/orbit, play nhúng, context loss, cuộn 320px, ended/seek thật, chuyển app/khóa màn hình. Chưa cam kết phát nền.
