# Listen — Listening Room

Ứng dụng nghe YouTube tiếng Việt lấy cảm hứng từ Listen Mini, gồm session chia sẻ, playlist lưu trong Cloudflare D1 và YouTube IFrame Player API chính thức.


## Bàn đĩa tương tác (18/10/2026)

Giao diện lấy cảm hứng từ ngôn ngữ hình khối/viền/ánh sáng của ISO-GLOW Turntable. Mô hình Three.js được dựng riêng, không lấy audio engine của mẫu. YouTube IFrame Player API là nguồn trạng thái phát duy nhất; video gốc luôn hiển thị riêng bên dưới cảnh 3D.

- `app/turntable.tsx`: tải bất đồng bộ cảnh 3D khi vùng bàn đĩa sắp hiển thị; SVG trong lúc tải, khi người nghe chọn chế độ nhẹ, khi mất WebGL/context hoặc chunk tải lỗi. Tự xoay mặc định tắt. Giảm chuyển động theo hệ điều hành.
- `app/turntable-stage.tsx`: một WebGLRenderer/canvas, camera trực giao và OrbitControls có giới hạn. Tách click khỏi drag theo ngưỡng 6px, raycast ba nút play/pause, trước và tiếp. Trên thiết bị cảm ứng phải bật tương tác 3D để kéo; mặc định giữ thao tác cuộn trang.
- `lib/turntable-model.ts`: thân máy, chân, mâm, vinyl/grooves, nhãn thực, trục, cần kim, đối trọng, cartridge, đèn và nút cơ khí. Geometry/material dùng chung. Không có điều khiển pitch/volume giả.
- `lib/turntable-motion.ts`: quán tính đĩa 33⅓ rpm khi YouTube xác nhận PLAYING; pause/buffering giảm tốc. Cần kim nhấc khi chờ, đi từ rãnh ngoài vào trong theo `currentTime/duration`, nhấc ngắn khi đổi bài. Đèn buffering là tín hiệu trạng thái, không được gọi là phân tích nhịp nhạc.
- `lib/playback-queue.ts`: hàng đang phát tách khỏi playlist đang duyệt. Đổi playlist, tìm kiếm, mở/đóng bảng, đổi SVG/3D và đổi tên không tải lại video hiện tại. Chọn bài/Phát tất cả mới chuyển nguồn hàng phát. Khi nguồn tổng hợp thay đổi, giữ video còn tồn tại; nếu bị xóa thì chọn bài kế tiếp hợp lệ.

Pixel ratio tối đa 1.5 desktop / 1.2 cấu hình nhẹ, mục tiêu giới hạn lịch render 45/30 Hz. Đây là giới hạn lập lịch, **không phải FPS đã đo**. Không dùng bloom/post-processing toàn màn hình hay audio analyser. Render dừng khi scene ngoài viewport hoặc tab ẩn, không can thiệp trạng thái YouTube. Cleanup dọn RAF, observer, listener, controls, texture, geometry/material và renderer.

Desktop có tìm kiếm ở đầu, thư viện trái, console giữa, hàng phát phải có thể thu gọn và transport cố định dưới. Mobile ưu tiên tìm kiếm → thông tin bài → bàn đĩa → video/list; playlist/hàng phát mở bottom sheet có Escape/focus trap, thanh điều khiển có safe-area. Phím `/` đưa con trỏ đến tìm kiếm.

Ảnh ở `docs/previews/desktop-static.png` và `mobile-static.png` là **bản dựng tĩnh** từ SVG fallback và metadata thật, không phải ảnh chụp browser/WebGL. `scripts/render-design-previews.mjs` tái tạo chúng sau `node tests/run.mjs`; có thể đặt `PREVIEW_THUMBNAILS` tới thư mục ảnh YouTube mang tên `<videoId>.jpg`. Xem `VERIFICATION.md` để phân biệt test thực tế và phần chưa kiểm thử.

## Playlist ru ngủ cho bé

**Baby Sleep Instantly** giữ URL `?s=be-ngu-ngoan`. Theo lựa chọn mới nhất của người dùng, playlist chỉ còn video **377o0R09Y0U** của **Baby Sleep Music Melody**; toàn bộ sáu video trước đó được thay thế. Dữ liệu cập nhật một lần trong D1, không tự khôi phục video bị xóa sau cập nhật. [Nguồn và kiểm chứng](docs/baby-single-video.md). Bản sao trước thay đổi: [v35](docs/archives/be-ngu-ngoan-v35.json), [v32](docs/archives/be-ngu-ngoan-v32.json). YouTube vẫn quyết định quảng cáo và khả năng phát trên từng thiết bị.

## Trang mặc định và khởi đầu trên điện thoại

**iPad/iPhone cũ:** iOS/Safari trước 16.4 tự nhận giao diện nghe tương thích, giữ nguyên `?s=session-slug`. Có thể mở trực tiếp `/lite?s=be-ngu-ngoan`. Phiên bản này dùng JavaScript ES5, không tải React/3D; cùng dữ liệu và YouTube player, danh sách 20 bài mỗi trang. [Cách hoạt động và giới hạn kiểm chứng](docs/ios12-compatibility.md).

Mở `/` trên màn hình rộng tối đa 900px sẽ chọn ngẫu nhiên một playlist có bài trong catalogue công khai. Lần đầu chỉ tải danh mục tóm tắt và playlist được chọn, không gọi `/api/library`, không tải bài/metadata của mọi playlist. URL được cập nhật thành `?s=<slug>` để tải lại hoặc chia sẻ vẫn mở đúng playlist đó. Không dùng playlist gần nhất để thay lựa chọn ngẫu nhiên; không đổi playlist khi xoay màn hình. Nếu danh mục lỗi hoặc trống, hiện trạng thái rõ ràng và cho thử lại, không tự chuyển sang tải toàn bộ thư viện.

Desktop vẫn mở **Tất cả bài hát** mặc định. Người nghe trên mọi thiết bị có thể chọn **Tất cả bài hát** trong thư viện hoặc logo để tải danh sách tổng hợp theo yêu cầu. `?view=all` mở trực tiếp chế độ này, kể cả trên điện thoại; liên kết chia sẻ tổng hợp giữ tham số đó. `?s=<slug>` luôn có ưu tiên cao hơn và vẫn là session slug. Nút **Phát tất cả** bắt đầu từ bài đầu của danh sách đang xem. YouTube chỉ phát sau thao tác người dùng. Nút play chính vẫn hỗ trợ tiếp tục vị trí nghe riêng của thiết bị; shuffle/lặp vẫn dùng được. Chọn playlist khác hoặc mở thư viện tổng hợp không khởi tạo lại player hay gián đoạn hàng đang phát.

Luồng tải, kiểm thử và giới hạn thiết bị: [docs/mobile-random-entry.md](docs/mobile-random-entry.md).

Danh sách được đọc từ các playlist trong bộ sưu tập công khai hiện tại, theo thứ tự Shelby rồi các playlist tuyển chọn và các playlist được nhập theo yêu cầu. Cùng video ID chỉ xuất hiện một lần, giữ vị trí xuất hiện đầu tiên; mỗi bài có thông tin tất cả playlist nguồn. Khi playlist nguồn được sửa hoặc xóa, lần tải tổng hợp tiếp theo phản ánh dữ liệu mới. Các session chỉ được chia sẻ bằng liên kết riêng không tự bị đưa vào catalogue công khai.

- `GET /api/library`: trả một view session chỉ nghe (`kind: all`), tổng số playlist/vị trí, các bài đã gộp và `sourcePlaylists` cho từng bài.
- `GET /api/library/metadata?ids=...`: cùng cơ chế giới hạn, cache và kiểm tra ID thuộc bộ sưu tập như playlist riêng.
- View tổng hợp không tạo session/bản sao playlist trong D1. Đổi tên, xóa và sửa bài thực hiện trên playlist gốc.
- `?s=<slug>` tiếp tục mở playlist riêng. Tên session `all` vẫn hợp lệ và độc lập với view tổng hợp nội bộ.
- Logo, liên kết chia sẻ tổng hợp và trạng thái sau khi xóa session mở `/?view=all`. Bộ chọn playlist có mục **Tất cả bài hát** để trở lại từ bất kỳ playlist nào.
- Tìm kiếm hỗ trợ tiêu đề, kênh và tên playlist nguồn. Xuất URL của view tổng hợp tạo `tat-ca-bai-hat.txt`, mỗi video ID một URL.

## Playlist nhập từ YouTube Music

`/?s=dia-nhac-loi-khuan` mở **Đĩa nhạc - Lợi Khuẩn** của Dfoxie37: 12 bài theo đúng thứ tự của playlist nguồn `OLAK5uy_lzTVK28HYcOzir0qVg-Mxgk2jX8eTNAqw`. Snapshot trong `lib/imported-playlists.json` được đối chiếu từ dữ liệu công khai trên trang YouTube của cùng playlist ngày 19/10/2026, đủ 12/12 mục và không còn trang tiếp theo; bao gồm tiêu đề, tên kênh và thumbnail.

Mỗi playlist nhập có marker riêng theo ID nguồn, lưu vào D1 một lần và xuất hiện trong catalogue cùng **Tất cả bài hát**. Tải lại hoặc triển khai lại không thêm trùng, không ghi đè chỉnh sửa và không khôi phục playlist đã xóa. Quyền sửa/xóa thuộc tài khoản chủ Site như các playlist mẫu. Đây là bản nhập tại thời điểm trên, không tự đồng bộ các thay đổi về sau của nguồn YouTube.

## Thư viện Nhạc Việt

Bổ sung 13 playlist có sẵn trên YouTube Music ngày 19/10/2026: hai bảng xếp hạng Việt Nam của YouTube Music Global Charts, nhạc Việt nổi bật/mới của Redlist, indie, R&B của NDMT, Đen Vâu, Ngọt, Xuân Hạ Thu Đông Rồi Lại Xuân mùa 3, Rap Việt mùa 3, deep chill, acoustic và remix. Nhập **918 vị trí công khai**, gộp một video ID lặp trong một playlist, ghi rõ **35 mục nguồn không truy xuất được**. Đọc hết các trang bài hát; các mục gợi ý không được nhập. Chi tiết nguồn, số lượng, trang và ngoại lệ ở `docs/vietnam-playlists-import.md`.

Trước đợt bổ sung Try Hard, bộ sưu tập có 25 playlist, 1.075 vị trí và **944 video ID khác nhau** trong Tất cả bài hát. Số thực tế phản ánh các chỉnh sửa/xóa trong D1. Bộ lọc **Tất cả / Nhạc Việt / Try Hard** chỉ lọc thư viện, không đổi hàng đang phát. Khi mở playlist nhập, giao diện hiện người tuyển chọn, ngày nhập, liên kết YouTube Music gốc và các mục nguồn thiếu/trùng. Đây là snapshot, không tự đồng bộ nguồn và không khẳng định mọi playlist cộng đồng là bảng xếp hạng chính thức.

Seed đọc marker theo lô, chỉ tạo playlist được yêu cầu khi mở liên kết trực tiếp; dùng JSON và `json_each` của D1 để nhập metadata và session theo lô, giảm truy vấn khi bộ sưu tập lớn. Session và marker được ghi trong cùng transaction; retry không nhân bản hay khôi phục dữ liệu đã xóa. Kiểm thử cả khởi tạo từ D1 trống trong giới hạn 50 query và tiếp tục từ dữ liệu đã chỉnh sửa.

## Try Hard · Nhạc cho phiên làm lab / CTF

Bổ sung tám nguồn YouTube Music ngày 20/10/2026: **Try Hard · Mr. Robot** (31), **Recon · Ambient Focus** (11), **Night Shift · HOME** (12), **Synthwave · Lofi Girl** (29), **Cyberpunk · Coding Sessions** (95), **Darksynth · Perturbator** (13), **Adrenaline · Carpenter Brut** (19) và **Flow State · Liquid DnB** (33). Có 243 video/mix mới, giữ thứ tự nguồn; ghi nhận 14 mục không truy xuất và gộp một ID lặp. Không khẳng định đây là bảng xếp hạng nhạc của giới pentester.

Bộ lọc **Try Hard** ở thư viện và trang quản trị giúp tìm nhóm này. Mọi video được gộp vào trang mặc định **Tất cả bài hát**. Bộ seed sau bổ sung có 33 playlist, 1.318 vị trí và 1.187 ID khác nhau; số thực tế phản ánh chỉnh sửa của quản trị viên. Seed không ghi đè chỉnh sửa hoặc khôi phục playlist đã xóa. Nguồn và kiểm chứng: [docs/tryhard-playlists-import.md](docs/tryhard-playlists-import.md).

## Gaming · Nhạc cho phiên chơi game

Bổ sung **10 playlist, 220 video mới** ngày 23/10/2026: Call of Duty · Modern Warfare II (26), Forza Horizon 5 · Horizon Pulse (24), Bass Arena (19), Hospital Records (30), DOOM · Rip & Tear (31), Cyberpunk 2077 · Phantom Liberty (15), Need for Speed · Most Wanted 2005 (32), League of Legends · Worlds Anthems (13), VALORANT · Champions Anthems (6) và Minecraft · Volume Alpha (24).

Bộ lọc **Gaming** có trong thư viện và trang quản trị; toàn bộ bài được thêm vào **Tất cả bài hát**, giữ thứ tự tổng hợp và gộp trùng theo video ID. Seed idempotent giữ nguyên các chỉnh sửa/xóa trước đó. Đây là bản tuyển chọn nhạc game/radio/anthem, không phải bảng xếp hạng thói quen nghe của game thủ. Chi tiết nguồn, số lượng và kiểm chứng tại [docs/gaming-playlists-import.md](docs/gaming-playlists-import.md).

## Ride · Mô tô — Nhạc cho người yêu cung đường

Bổ sung tám playlist ngày 23/10/2026: **Cruiser · Harley Road Songs** (30), **Touring · Southern Rock** (17), **Open Road · Country** (24), **Café Racer · Blues & Garage** (44), **Night Ride · The Midnight** (14), **Neon Ride · FM-84** (11), **Sportbike · Phonk** (99) và **Đi để trở về · Nhạc Việt** (21).

Có 260 vị trí bài hát, 248 video ID mới và 12 video đã thuộc thư viện cũ; ghi rõ 24 mục nguồn không khả dụng. Bộ lọc **Ride · Mô tô** có ở trang nghe và quản trị; tất cả bài được gộp vào **Tất cả bài hát** theo thứ tự ổn định, không lặp video ID. Đây là tuyển chọn theo phong cách, không phải thống kê playlist phổ biến nhất của mọi người chơi mô tô. Chi tiết: [docs/ride-playlists-import.md](docs/ride-playlists-import.md).

## Active · Thể thao — Workout, chạy bộ và đạp xe

Bổ sung tám playlist ngày 24/10/2026: **Workout Pulse · NCS** (96), **Run Flow · Drum & Bass** (73), **Power Set · Hip-Hop** (62), **Run & Rock · Guitar Energy** (23), **Move Together · Pop Classics** (71), **Pedal Flow · House Mixes** (27 video/mix), **Workout Việt · Remix** (76) và **After Move · Chill & Acoustic** (16).

Có 444 vị trí, 432 ID khác nhau trong nhóm Active và 428 video mới so với bộ seed cũ; ghi rõ 25 mục nguồn không truy xuất. Danh mục **Active · Thể thao** có ở trang nghe và quản trị. Tất cả bài được tổng hợp ở trang mặc định, gộp trùng theo ID và giữ thứ tự ổn định. Bản nhập mới có thể điền metadata còn thiếu khi mới hơn cache lỗi; giữ metadata thành công đang có và mọi chỉnh sửa playlist. Nguồn và kiểm chứng: [docs/active-playlists-import.md](docs/active-playlists-import.md).

## Dopamine — Euphoria, bass và giai điệu giàu cảm xúc

Bổ sung tám playlist ngày 24/10/2026: **Festival Euphoria · Avicii** (10), **Vocal Lift · OceanLab** (13), **Euphoric · Enter Your Mind** (16), **Bass Impact · NCS** (81), **Night Pulse · Skeler & Wave** (10 video/mix), **Cinematic Lift · Battlecry** (25), **Afterglow · ODESZA** (16) và **Feel Good · Daft Punk** (14).

Có 185 vị trí, bảy ID đã thuộc thư viện cũ và **178 video mới**, ghi rõ một mục nguồn không truy xuất. Bộ lọc **Dopamine** có ở trang nghe và quản trị; toàn bộ bài được tổng hợp vào **Tất cả bài hát**, gộp trùng theo ID và giữ thứ tự. Tên danh mục thể hiện chủ đề âm nhạc, không phải cam kết tác động sinh học. Nguồn và kiểm chứng: [docs/dopamine-playlists-import.md](docs/dopamine-playlists-import.md).

## 10 playlist tuyển chọn mới

Thư viện playlist nằm bên trái trên desktop và mở bằng nút **Playlist** trên điện thoại. Mỗi playlist mới có 12 bài, lưu trực tiếp trong D1, nghe công khai và chỉ tài khoản chủ Site được quản lý. Có 120 vị trí bài hát với 111 video khác nhau; một số bài xuất hiện ở các tâm trạng khác nhau.

| Slug | Tên | Hướng nghe |
| --- | --- | --- |
| `shelby-after-dark` | Shelby — After Dark | Blues, alternative rock, Shelby |
| `midnight-drive` | Midnight Drive | The Weeknd, synth, nhạc đêm |
| `dark-indie` | Dark Indie Club | Arctic Monkeys, The Neighbourhood |
| `lana-noir` | Lana — Velvet Noir | Lana Del Rey, Billie Eilish |
| `broken-at-2am` | Broken at 2 AM | SYML, Tom Odell, indie ballad |
| `cinematic-soul` | Cinematic Soul | Ruelle, Fleurie, Woodkid, nhạc phim |
| `neon-phonk` | Neon — Phonk & Bass | Drift phonk và bass |
| `rainy-memories` | Rainy Memories | Dream pop, ambient, hoài niệm |
| `viral-dark-edits` | Viral — Dark Edits | After Dark, Little Dark Age, The Perfect Girl |
| `viral-global` | Viral — Global Favorites | Các hit quốc tế phổ biến |

Mở bằng `/?s=<slug>`. `GET /api/collections` trả catalogue có tên, mô tả, ảnh, số bài hiện tại và thông tin nguồn tuyển chọn. Catalogue chỉ hiển thị những session mẫu còn tồn tại và do chủ Site quản lý, không liệt kê session tự tạo của người khác.

`lib/curated-playlists.json` chứa thứ tự đã biên tập; `lib/curated-metadata.json` chứa tiêu đề, kênh và thumbnail đã xác minh qua YouTube oEmbed ngày 18/10/2026. Ưu tiên video của nghệ sĩ, hãng hoặc Topic; có một số bản edit và video giới thiệu nhạc phù hợp gu Shelby. Đây là tuyển chọn theo gu, không phải bảng xếp hạng viral thời gian thực. Nguồn tham khảo phổ biến: Spotify Wrapped Global Top Songs 2025 và TikTok Top Songs 2025; các ca khúc trong playlist được chọn rộng hơn hai danh sách này.

Khởi tạo theo marker `curated-2026-10-v1` và marker riêng từng slug. Đọc lại API hoặc triển khai lại không ghi đè tên/thứ tự/bài hát người dùng đã sửa, không khôi phục playlist đã xóa. Không cần migration mới vì dùng schema session/metadata hiện tại. Shelby gốc giữ nguyên 25 bài, thứ tự và phiên bản dữ liệu.

## Sử dụng

- Mở `/?s=shelby` để nghe playlist **Shelby — Late Night**, gồm đúng 25 video theo thứ tự yêu cầu.
- `s` là session slug, không phải từ khóa tìm kiếm.
- Ai có URL đều nghe được, không cần tài khoản. Chọn **Đăng nhập** để tạo hoặc quản lý session của bạn. Form đăng nhập dùng username/password; backend xác thực phiên và kiểm tra quyền ở mọi thao tác ghi.
- Các tài khoản quản trị cấu hình qua runtime cùng quản lý playlist mẫu/đã nhập và session thuộc không gian quản trị chung. `AUTH_USERNAME`/`AUTH_PASSWORD_HASH` giữ tài khoản gốc; secret `AUTH_ADDITIONAL_ADMINS` bổ sung tài khoản cùng quyền. Header danh tính ChatGPT không cấp quyền ứng dụng.
- Tạo slug 3–48 ký tự chữ thường/số/gạch ngang. Tên hiển thị đổi độc lập với slug.
- Thêm một hoặc nhiều URL/ID, mỗi dòng một bài. Có kiểm tra trùng, thông báo dòng lỗi, giữ đúng thứ tự. Không lấy playlist từ tham số `list`.
- Chọn bài trong playlist hoặc bấm Phát. Trình duyệt chặn phát sẽ có nút **Chạm để phát**. Video và điều khiển YouTube luôn hiện.
- Kéo biểu tượng sắp xếp trên desktop, hoặc dùng mũi tên lên/xuống bằng bàn phím và thao tác chạm. Tắt sắp xếp khi đang tìm kiếm để tránh đổi nhầm vị trí.
- Xuất URL tạo tệp văn bản chuẩn, mỗi dòng một URL.

## Kiến trúc

- `app/listen-app.tsx`: giao diện React nhỏ gọn, trạng thái nghe riêng từng thiết bị.
- `app/globals.css`: giao diện charcoal/hổ phách, ba vùng trên desktop và bottom sheet trên mobile, responsive từ 320px, hỗ trợ reduced motion.
- `lib/domain.ts`: chuẩn hóa URL, kiểm tra dữ liệu, logic chuyển bài và mẫu Shelby.
- `lib/youtube.ts`: loader API một lần, kiểu dữ liệu player, thông báo lỗi.
- `lib/api.ts`: API, phân quyền, cập nhật có kiểm tra phiên bản, metadata và seed dữ liệu.
- `lib/auth.ts`: kiểm tra mật khẩu, phiên đăng nhập D1, cookie an toàn, giới hạn thử đăng nhập và thu hồi phiên.
- `scripts/hash-password.mjs`: tạo hash mật khẩu qua terminal ẩn nhập liệu; không nhận mật khẩu trong tham số lệnh.
- `app/api/[...path]/route.ts`: cầu nối Worker runtime với API.
- `db/schema.ts` và `drizzle/`: schema và migration D1.
- `lib/seed-metadata.json`: snapshot metadata thật lấy từ YouTube oEmbed khi xây dựng; nếu hết hạn, backend làm mới qua oEmbed.
- `tests/`: kiểm tra logic, API dùng SQLite thật với adapter D1, loader YouTube dùng mock.

Playlist, tên và thứ tự nằm trong D1. localStorage chỉ lưu slug gần nhất, video/vị trí đang nghe và tùy chọn shuffle/lặp. Các lỗi localStorage không làm hỏng ứng dụng. Không lưu trạng thái phát lên backend, vì mỗi thiết bị có phiên nghe riêng.

Bài hát được nhận diện theo video ID. Component player giữ nguyên khi playlist, tên hoặc metadata thay đổi. Xóa bài khác không làm tải lại video. Xóa bài đang nghe chọn bài kế tiếp; xóa bài cuối chọn bài trước; playlist rỗng dừng player. Lỗi liên tiếp chỉ tự bỏ qua tối đa 3 bài, rồi dừng để tránh vòng lặp. Bài bị lỗi vẫn còn trong playlist để chủ session quyết định xóa.

## Đăng nhập username/password

Truy cập trực tiếp `/bim` để đăng nhập và quản lý playlist. Trang nghe công khai không có nút đăng nhập/liên kết quản trị; nút tạo session chỉ xuất hiện sau khi đã xác thực. `/bim` kiểm tra cookie hiện có, hiện form khi chưa đăng nhập và mở console quản trị riêng sau khi đăng nhập. Đăng xuất tại đây trở về form đăng nhập; mở lại `/bim` khi còn phiên sẽ vào thẳng giao diện quản lý. Trang có metadata `noindex, nofollow`. Liên kết chia sẻ playlist luôn dẫn về `/?s=slug`, không dẫn người nghe vào `/bim`. API vẫn kiểm tra cookie và quyền trên server cho mọi thao tác ghi.

Console sử dụng `app/admin-dashboard.tsx` và stylesheet riêng `app/admin-dashboard.css`. Sidebar có Playlist/Bài hát; bảng playlist có tìm kiếm, lọc, sắp xếp, số bài và trạng thái hiển thị. Chi tiết playlist hỗ trợ tạo/đổi tên/xóa playlist, nhập nhiều URL với bản xem trước số bài hợp lệ/trùng/lỗi, tìm bài, kéo hoặc bấm lên/xuống, xác nhận xóa từng bài hoặc nhiều bài đã chọn, lấy lại metadata và xuất URL. Bảng bài hát có 25/50/100 dòng mỗi trang, tìm không dấu, bỏ video trùng và cho chọn playlist cần sửa khi một bài có nhiều nguồn. Không import hay khởi tạo YouTube player, bàn đĩa hoặc Three.js trong quản trị. Bảng có tiêu đề cố định và vùng cuộn riêng trên desktop; trên màn hình nhỏ sidebar chuyển thành thanh điều hướng, bảng cuộn ngang trong vùng nội dung.

Đặt runtime `ADMIN_ORIGIN` bằng origin HTTPS trực tiếp của Sites (không có `/` cuối). `/bim` mở từ một tên miền proxy sẽ chuyển sang đúng `/bim` tại origin này trước khi nhập tài khoản; chỉ giữ tham số playlist `s` hoặc chế độ `view=tracks`. Nếu đang trong iframe, giao diện cung cấp liên kết mở tab riêng để cookie được dùng ở ngữ cảnh first-party. Origin được mã hóa base64 trong props SSR để proxy thay hostname trong HTML không đổi mất đích chuyển hướng; đây là cấu hình công khai, không phải thông tin xác thực. Trang nghe qua proxy giữ nguyên. Cấu hình này xử lý trường hợp proxy không chuyển tiếp cookie: POST đăng nhập trả 200 nhưng GET quản trị tiếp theo không có Cookie và trả 401. Không lưu token vào localStorage hay URL, không thay đổi cookie HttpOnly hiện có.

Sau POST đăng nhập, frontend kiểm tra lại `/api/me?verify=<mã ngẫu nhiên>` với cookie trình duyệt trước khi mở console. Nếu cookie chưa được gửi lại, giữ nguyên form và giải thích lỗi thay vì vào console rồi bật trở lại form. Request kiểm tra đã hủy/đến muộn không được thay trạng thái phiên mới. Phiên hết hạn khi đang quản trị cũng có thông báo đăng nhập lại; nút Đăng xuất vẫn thu hồi riêng token hiện tại.

Danh mục quản trị bao gồm mọi playlist tài khoản được quản lý, kể cả playlist mới tạo chưa nằm trong danh mục tuyển chọn công khai. Nhãn “Thư viện chung”/“Qua liên kết” thể hiện đúng hành vi hiện có: các playlist tuyển chọn được tổng hợp ở trang nghe; playlist tự tạo mở bằng liên kết riêng. Console không tự công khai các playlist chưa được liệt kê. Trang nghe và dữ liệu hiện tại được giữ nguyên. Các thao tác ghi khóa trong khi lưu và gửi version/mã thao tác; xung đột 409 đóng hộp thoại, tải dữ liệu mới và yêu cầu người dùng thực hiện lại, không tự lặp thao tác xóa.

Các tài khoản quản trị được cấu hình qua runtime, không có đăng ký công khai hoặc mật khẩu mặc định trong mã nguồn. Tài khoản gốc dùng `AUTH_USERNAME` và secret `AUTH_PASSWORD_HASH`. Secret tùy chọn `AUTH_ADDITIONAL_ADMINS` là mảng JSON tối đa 20 tài khoản bổ sung, dạng `[{"username":"another_admin","passwordHash":"<salted hash>"}]`. Tạo từng hash bằng `node scripts/hash-password.mjs`, rồi nhập JSON qua cấu hình secret của Sites; không đưa giá trị thật vào repo hoặc bundle. Tên đăng nhập không phân biệt hoa/thường, chỉ gồm chữ Latin, số, `.`, `_`, `-`, tối đa 64 ký tự và không được trùng tài khoản khác. Cấu hình sai trả 503 cho đăng nhập; quyền nghe công khai vẫn hoạt động.

Mật khẩu được kiểm tra trên server bằng PBKDF2-SHA256, salt ngẫu nhiên 16 byte, 100.000 vòng theo mức tương thích Workers. Format hash: `pbkdf2-sha256$100000$<salt-base64url>$<digest-base64url>`; công cụ tạo hash tự chọn salt mới mỗi lần. Thêm tài khoản không đổi hash của tài khoản cũ hoặc thu hồi phiên đang dùng. Thay username/hash hoặc gỡ một tài khoản rồi deploy chỉ vô hiệu hóa các phiên của tài khoản đó. Mỗi tài khoản hiển thị đúng tên đăng nhập trong console, có token và thao tác đăng xuất riêng.

Phiên có token ngẫu nhiên 256 bit; D1 chỉ lưu SHA-256 của token, không lưu token thô hoặc mật khẩu. Cookie `__Host-listen_session` có `Secure`, `HttpOnly`, `SameSite=Lax`, `Path=/`, thời hạn 7 ngày. Đăng xuất xóa bản ghi D1; các thiết bị khác giữ phiên riêng. Login lại trên cùng cookie sẽ cấp token mới và thu hồi token cũ. Login/logout bắt buộc POST từ origin của ứng dụng; request ghi playlist vẫn kiểm tra origin, quyền chủ sở hữu và version.

Nếu phục vụ website qua reverse proxy (ví dụ Cloudflare Pages), cấu hình runtime `APP_ALLOWED_ORIGINS` bằng các origin HTTPS công khai được phép, ngăn cách bằng dấu phẩy, không có đường dẫn/dấu `/` cuối. Ví dụ `https://music.example.com`. Origin của URL backend luôn được chấp nhận; các alias phải khớp chính xác, không hỗ trợ wildcard. API không tin `Host`, `Forwarded`, `X-Forwarded-Host` hoặc `CF-Worker` để tự cấp quyền origin, và vẫn từ chối `Sec-Fetch-Site: cross-site`. Proxy cần chuyển tiếp `Origin`, `Cookie`, header kiểm tra phiên bản/mã thao tác và `Set-Cookie` nguyên vẹn, không cache `/api/*`. Cookie không có `Domain`, nên trình duyệt lưu phiên cho địa chỉ công khai người dùng đang mở. Gọi API bằng URL tương đối `/api/...`; không đổi frontend sang gọi chéo origin. Cập nhật biến runtime trong Sites rồi deploy để áp dụng. Cấu hình alias không đổi mật khẩu hoặc xóa phiên/playlist đang lưu.

Giới hạn 10 lần thử mỗi IP và 50 lần tổng cộng trên hệ thống đăng nhập trong cửa sổ 15 phút, trả 429/Retry-After khi vượt ngưỡng. Username hoặc mật khẩu sai trả thông báo giống nhau; username không tồn tại vẫn thực hiện một lần dẫn xuất mật khẩu. Mật khẩu nhập trên form không lưu vào localStorage. Trang quản trị không có player; đăng xuất trở về form đăng nhập. Đăng xuất ở giao diện nghe công khai vẫn giữ bài đang phát.

Các tài khoản quản trị có cùng quyền tạo, đổi tên, thêm/xóa bài, nhập file, đổi thứ tự và xóa playlist trong không gian chung. Playlist mẫu có owner `__seed__`; session do bất kỳ quản trị viên nào tạo giữ owner `__local_admin__`, nên tài khoản khác cùng quản lý được và đổi tên đăng nhập vẫn giữ quyền sở hữu. Không tự nhận quyền sở hữu những session legacy thuộc tài khoản khác. Thêm quản trị viên không cần migration, không xóa phiên đăng nhập hay dữ liệu playlist.

## API

Mọi response JSON. Các request ghi kiểm tra origin backend hoặc alias HTTPS được cấu hình và quyền chủ sở hữu trên server. Backend chỉ tin cookie phiên đã được đối chiếu với D1; các header danh tính ChatGPT không được dùng làm thông tin đăng nhập ứng dụng.

| Endpoint | Hành vi |
| --- | --- |
| `POST /api/auth/login` | Username/password trong JSON; thành công cấp cookie phiên |
| `POST /api/auth/logout` | Thu hồi phiên hiện tại ở D1 và xóa cookie |
| `GET /api/me` | Trạng thái đăng nhập và session của tài khoản |
| `GET /api/admin/playlists` | Danh mục, số liệu và phiên bản mọi playlist được quản lý; yêu cầu cookie đăng nhập |
| `GET /api/admin/library` | Bài hát không trùng và danh sách playlist chứa bài; chỉ dành cho quản trị |
| `POST /api/sessions` | Tạo session, `{slug,name}`; yêu cầu đăng nhập |
| `GET /api/sessions/:slug` | Đọc công khai; trả `canEdit`, `version`, danh sách bài |
| `PATCH /api/sessions/:slug` | Đổi tên hiển thị, `{name}` |
| `DELETE /api/sessions/:slug` | Xóa session của chính người tạo |
| `POST /api/sessions/:slug/tracks` | Nhập hàng loạt, `{text}`; trả thống kê |
| `DELETE /api/sessions/:slug/tracks` | Xóa bài `{videoId}` hoặc nhiều bài `{videoIds:[...]}` nguyên tử, giữ thứ tự bài còn lại |
| `PATCH /api/sessions/:slug/order` | Lưu hoán vị chính xác, `{ids:[...]}` |
| `GET /api/sessions/:slug/metadata?ids=id1,id2` | Metadata của tối đa 10 ID đang có trong session |

Mỗi thay đổi dùng `If-Match: <version>` và `X-Request-ID`. Backend cập nhật bằng SQL có điều kiện nguyên tử, trả 409 khi dữ liệu đã thay đổi. Frontend khóa thao tác ghi trong khi request đang chạy, bỏ response tải session cũ, giữ player và tự đọc lại khi xung đột. Retry cùng mã thao tác gần nhất không thêm trùng; video ID luôn duy nhất trong session. Dữ liệu không được cập nhật trước khi server xác nhận.

Mỗi playlist tối đa 300 bài, tên tối đa 100 ký tự, mỗi tài khoản tối đa 100 session. Có giới hạn tần suất trên server. Metadata chỉ truy cập `https://www.youtube.com/oembed` với ID hợp lệ đã thuộc playlist, tối đa 3 request đồng thời, timeout 4,5 giây. Tiêu đề/kênh được render dưới dạng text; không dùng HTML của oEmbed. Thumbnail lấy từ đường dẫn YouTube cố định. Cache thành công 24 giờ, lỗi 15 phút với fallback ghi rõ ID và tình trạng thiếu metadata.

Seed Shelby nằm ngoài migration schema. Marker `shelby-v1` giúp khởi tạo đúng một lần, không thêm trùng và không tự tạo lại sau khi chủ sở hữu xóa. Tạo lại session tên Shelby sau khi xóa sẽ tạo một playlist trống thuộc chủ mới, không khôi phục dữ liệu đã xóa.

## Phát triển và triển khai qua Sites

Yêu cầu Node.js 22.13+ (khuyến nghị 24) và pnpm. Mã nguồn có lockfile đầy đủ.

1. Chạy `pnpm install --frozen-lockfile`.
2. Tạo Site mới hoặc mở checkout của Site đích. Giữ nguyên helper và tích hợp `sites()` trong Vite. Bản tải về có định danh Site hiện tại trong `.openai/hosting.json`; chỉ thay khi thật sự triển khai sang Site khác.
3. Cấu hình `.openai/hosting.json` với `d1: "DB"`, `r2: null`. Không đưa bí mật vào manifest.
4. Đặt `AUTH_USERNAME` và secret `AUTH_PASSWORD_HASH` trong runtime Sites; dùng thêm secret `AUTH_ADDITIONAL_ADMINS` khi cần nhiều quản trị viên. Tạo hash bằng `node scripts/hash-password.mjs`; không lưu mật khẩu/hash thật vào repo, manifest hay bundle trình duyệt. Không cần YouTube Data API key.
5. Chạy `pnpm exec tsc --noEmit` và `node tests/run.mjs`.
6. Chạy build qua helper Sites hoặc `pnpm run build` khi dùng starter độc lập. Bộ build tạo artifact Worker và kèm migration D1.
7. Push đúng source commit, package artifact, lưu phiên bản và publish bằng Sites. Sites tạo D1 và chạy migration trước khi đưa Worker lên.
8. Đặt audience **public** để người có liên kết nghe không cần đăng nhập. Quyền chỉnh sửa vẫn do API bảo vệ. Giao diện đăng nhập ngay trên trang bằng username/password; không chuyển tới đăng nhập ChatGPT.
9. Mở `/api/sessions/shelby` hoặc `/?s=shelby` để seed idempotent và kiểm tra 25 bài.

Đối với local preview, dùng workflow preview của Sites. Áp dụng migration SQL vào D1 local đúng một lần theo hướng dẫn starter; D1 local độc lập với production. Cookie đăng nhập có cờ Secure; kiểm tra trình duyệt qua HTTPS. D1 của bản kiểm thử không chứa phiên thật.

Thay schema cần chỉnh `db/schema.ts`, chạy `pnpm run db:generate`, kiểm tra migration mới. Không chỉnh lại migration đã chạy, không tạo bảng trong request handler.

## Giới hạn trình duyệt và YouTube

YouTube quyết định quyền nhúng, giới hạn vùng và khả năng phát từng video. Tiêu đề/thumbnail hợp lệ không chứng minh video có thể nhúng ở mọi thiết bị/vùng. Không tải hoặc tách audio, không che player, không loại quảng cáo và không lách giới hạn phát nền.

Khung video ưu tiên 16:9; khi màn hình hẹp, chiều cao tối thiểu 200px để giữ kích thước YouTube yêu cầu. `playsinline=1`, input 16px, vùng chạm thiết yếu tối thiểu 44px, lazy thumbnail và không dùng blur nền nặng. Các điều khiển video gốc vẫn nằm trong iframe.

Safari iPhone/Chrome Android có thể dừng phát khi ứng dụng vào nền hoặc màn hình khóa. Listen không cam kết hoặc cố duy trì phát nền. Chưa kiểm thử vật lý trên hai loại thiết bị này trong môi trường thực hiện; cần kiểm tra bằng máy thật, bao gồm autoplay, Bluetooth, chuyển tab và khóa màn hình. Xem `VERIFICATION.md` để biết phạm vi xác minh thực tế.

Nguồn tham khảo: frontend công khai `https://nhac.pages.dev/?s=shelby`, `style.css`, `app.js`; Google YouTube IFrame API: `https://developers.google.com/youtube/iframe_api_reference`. Không có request ghi nào gửi tới backend gốc. Tất cả API, storage và dữ liệu của ứng dụng mới độc lập.

### Nhập playlist bằng file — Listen Court

Trong `/bim`, mở **Nhập file** trên thanh bên, hoặc **Nhập từ file** trong một playlist. Chọn playlist có sẵn hoặc đặt tên playlist mới (đường dẫn được gợi ý từ tên tiếng Việt). Thả một file vào sân hoặc dùng **Chọn file** để đọc và xem kết quả phân tích trước. Rê chuột vào thẻ để thấy đường chấm và tâm ngắm đỏ. Giữ chuột ở bất kỳ góc nào của thẻ, kéo theo nhiều hướng để thay đổi góc/lực, rồi thả tay. Chấm đỏ dự đoán điểm rơi từ đúng vận tốc và trọng lực dùng khi bay; góc kéo ảnh hưởng cả quỹ đạo và tốc độ xoay. Tên playlist được gợi ý từ tên file nếu chưa nhập và vẫn sửa được; chưa chọn đích cũng không khóa thao tác kéo/ngắm. Chỉ gọi API nhập khi thẻ đi qua vành rổ từ trên xuống; cú ném trượt trả thẻ về để thử lại. Nút **Ném vào rổ** hỗ trợ một cú ném đã canh sẵn; nút **Hủy cú ném** dừng chuyến bay trước khi ghi dữ liệu. Nút HTML hỗ trợ bàn phím; điện thoại có thể chọn file và bấm nút mà không cần kéo.

- UTF-8, tối đa 256 KB, 1–300 dòng bài; playlist tối đa 300 bài.
- `.txt`: mỗi dòng một URL YouTube hoặc video ID. `.m3u`/`.m3u8`: bỏ qua các dòng `#EXT…`. `.csv`: cột `url`, `link`, `youtube_url`, `video_url`, `video_id` hoặc `liên kết`; hỗ trợ dấu phẩy/chấm phẩy/tab và trường có ngoặc kép. Nếu không có header, mỗi hàng dùng ô chứa URL/ID hợp lệ đầu tiên.
- Giữ đúng thứ tự, chuẩn hóa URL, đếm trùng trong file và trong playlist đích, báo số dòng lỗi theo vị trí gốc. File nhị phân/PDF/Word không được hỗ trợ.
- API `POST /api/admin/import`: `{target:{kind:'new',slug,name}|{kind:'existing',slug,version},fileName,text}`; cần cookie quản trị, Origin hợp lệ và `X-Request-ID`. Backend tự phân tích lại file. Playlist mới và bài hát được lưu nguyên tử; playlist cũ dùng version để chống ghi đè.
- Migration `0002_playlist_imports.sql` bổ sung biên nhận thao tác. Giữ nguyên request ID khi thử lại sau lỗi mạng để lấy lại kết quả đã lưu, kể cả khi playlist đã được sửa sau đó. Biên nhận chỉ lưu fingerprint và báo cáo, không lưu toàn bộ file. Không khôi phục playlist đã xóa khi gửi lại request cũ.
- Bộ đếm “Đã thêm” tăng sau khi API xác nhận lưu. Chuyển động ném và rung lưới là phản hồi giao diện; `prefers-reduced-motion` tắt các chuyển động này. Playlist mới tiếp tục có cơ chế nghe qua liên kết như luồng tạo playlist hiện tại.

Kiểm thử nhập file nằm trong `tests/file-import.test.mjs` và `tests/import-ui.test.mjs`: parser, quyền truy cập, lưu nguyên tử/rollback, chống trùng, version conflict, retry mất phản hồi, thả file, nút nhập và kéo thẻ vào rổ. Đây là kiểm thử React/API với SQLite, không thay thế kiểm tra trực quan trình duyệt hoặc thiết bị cảm ứng thực.

Cơ chế ném dùng `lib/basketball.ts` và một vòng requestAnimationFrame; dọn vòng vẽ khi hủy/unmount, kẹp bước thời gian khi tab tạm ẩn. Pointer capture và `touch-action: none` chỉ áp dụng cho thẻ file; vùng còn lại vẫn cuộn bình thường. `prefers-reduced-motion` bỏ phần bay, giữ thanh lực, tính điểm và thao tác nhập. `tests/basketball.test.mjs` kiểm tra lực/hướng và va chạm ở 30/60/120 fps; `tests/throw-ui.test.mjs` kiểm tra kéo xuống bằng chuột/cảm ứng mô phỏng, không lưu lúc tích lực, chỉ lưu sau va chạm, cú trượt, hủy, click tổng hợp và dọn animation loop. Kiểm thử này không xác nhận cảm giác thao tác trên thiết bị thật.

Điều khiển kéo dùng Pointer Events ở thẻ và listener capture trên cửa sổ, nên chuột đi ra ngoài thẻ vẫn cập nhật và nhận thả tay. Lỗi setPointerCapture không chặn việc bắt đầu kéo; lostpointercapture chỉ hủy khi không có đường theo dõi thay thế. Blur/pointercancel/unmount dọn listener. Nội dung con của thẻ không nhận hit riêng để các góc, nhãn và biểu tượng đều kéo được. Các kiểm thử bổ sung xác nhận thẻ không bị HTML-disabled khi thiếu tên/slug, nhận chuyển động/thả qua cửa sổ khi capture thất bại, radar hiện khi hover, và có vòng xoay đầy đủ trước khi vào rổ. Chỉ báo thành công khi API lưu playlist xác nhận.

### Vật lý vành rổ và kéo tự do

Thẻ theo đúng độ dịch chuyển của chuột, không khóa vào bán kính tích lực 96px. Vùng sân mở clipping trong lúc giữ kéo; thả ngoài sân sẽ trả thẻ về để thử lại. Giới hạn 100% chỉ áp dụng cho thanh lực, không áp dụng cho vị trí thẻ.

`createFlight`/`advanceFlight` mô phỏng với bước cố định 1/240s: trọng lực, va chạm proxy tròn của thẻ đang xoay với hai đầu vành kim loại, hệ số nảy/phân tán năng lượng, thay đổi xoáy theo xung tiếp tuyến, lưới mềm và tối đa hai lần nảy sàn. Va chạm có thể bật ra hoặc bật vào tùy vị trí/vận tốc; không dùng xác suất giả. Vòng sáng tại điểm chạm và lưới giãn chỉ xuất hiện theo sự kiện của mô phỏng.

Thẻ phải đi từ trên xuống qua khoảng trống, cả proxy lọt dưới vành, rồi rơi thêm 72px qua lưới mới gọi API. Chạm vành hoặc xuất hiện dưới vành từ bên cạnh không đủ để nhập nhạc. Radar dùng cùng mô phỏng (cache theo shot plan), gồm cả các đoạn bật nảy; dự đoán và kết quả bay giữ cùng mô hình. Các lượt ném được giới hạn thời gian/va chạm để tránh lặp vô hạn.

Kiểm thử có fixture bật vành ra ngoài, bật vành vào trong, chưa lưu khi chạm vành, chờ xuyên qua lưới, không tính điểm từ phía dưới, kết quả ổn định ở 30/60/120fps và kéo theo chuột vượt 96px. Kiểm thử React dùng tọa độ DOM mô phỏng; chưa kiểm chứng trực quan trên trình duyệt/thiết bị thật.
