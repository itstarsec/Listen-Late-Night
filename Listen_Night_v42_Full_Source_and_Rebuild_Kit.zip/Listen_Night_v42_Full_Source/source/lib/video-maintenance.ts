import {ApiError} from './domain';

export type MaintenanceRuntime={DB:D1Database;YOUTUBE_API_KEY?:string;MAINTENANCE_OWNER_EMAIL?:string;MAINTENANCE_DAILY_LIMIT?:string};
export type Verdict={outcome:'available'|'unavailable'|'unknown';reason:string;source:'youtube-embed'|'youtube-data-api';evidence?:string};
type Check={video_id:string;checked_at:number;next_check_at:number;failures:number;first_failed_at:number|null;reason:string};
const VIDEO_ID=/^[A-Za-z0-9_-]{11}$/;
const HOUR=3600000,DAY=24*HOUR;
export const CONFIRMATION_DELAY=6*HOUR;
const unknown=(source:Verdict['source'],reason:string):Verdict=>({outcome:'unknown',reason,source});

// Parse JSON literals only. Never execute scripts returned by an external page.
function jsonObject(text:string,start:number):Record<string,unknown>|null{
 let depth=0,quoted=false,escaped=false;
 for(let i=start;i<text.length;i++){
  const c=text[i];if(quoted){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')quoted=false;continue;}
  if(c==='"')quoted=true;else if(c==='{')depth++;else if(c==='}'&&--depth===0){try{return JSON.parse(text.slice(start,i+1));}catch{return null;}}
 }
 return null;
}
export function classifyEmbed(html:string,id:string):Verdict{
 const source='youtube-embed' as const;
 for(const match of html.matchAll(/ytcfg\.set\(\s*(\{)/g)){
  const config=jsonObject(html,match.index!+match[0].lastIndexOf('{'));
  const vars=config?.PLAYER_VARS as Record<string,unknown>|undefined;
  if(vars?.video_id!==id||typeof vars.embedded_player_response!=='string')continue;
  try{
   const response=JSON.parse(vars.embedded_player_response),status=response.previewPlayabilityStatus;
   if(!status||typeof status.status!=='string')return unknown(source,'missing_playability');
   const code=String(status.errorCode??''),reason=String(status.reason??'');
   // Configuration, login, regional and challenge failures are never deletion evidence.
   const text=JSON.stringify(status);
   if(/REFERRER|IDENTITY|BOT|LOGIN|AGE|REGION|COUNTRY|SIGN_IN|153/i.test(code)||/sign in|confirm your age|not available in your country|not available in your region|not made this video available in your country|unusual traffic|not a bot/i.test(reason+' '+text))return unknown(source,'restricted_or_challenge');
   if(status.status==='OK'&&(status.playableInEmbed===true||response.videoFlags?.playableInEmbed===true))return {outcome:'available',reason:'embed_preview_ok',source};
   let failure:string|null=null;
   if(/EMBED(?:DING)?_(?:NOT_ALLOWED|DISABLED)|EMBEDDING_NOT_ALLOWED/.test(code)||['101','150'].includes(code)||/owner has disabled playback (?:on|in) other websites|playback on other websites has been disabled by the video owner|does not allow (?:it|this video) to be played in embedded players|embedding (?:is |has been )?disabled/i.test(reason+' '+text))failure='embedding_disabled';
   else if(/(?:VIDEO_)?(?:DELETED|REMOVED|NOT_FOUND|PRIVATE)(?:_|$)/.test(code)||code==='100'||/this video is private|video has been (?:removed|deleted)|video is no longer available|video does not exist/i.test(reason+' '+text))failure='deleted_or_private';
   if(failure)return {outcome:'unavailable',reason:failure,source,evidence:JSON.stringify({status:status.status,errorCode:code,reason:reason.slice(0,300),playableInEmbed:status.playableInEmbed}).slice(0,1000)};
   return unknown(source,'unrecognized_playability');
  }catch{return unknown(source,'invalid_playability');}
 }
 return unknown(source,'page_format_or_consent');
}
export function classifyApi(data:unknown,ids:string[]):Map<string,Verdict>{
 const result=new Map<string,Verdict>(),source='youtube-data-api' as const;
 const d=data as {kind?:string;items?:{id?:string;status?:{embeddable?:boolean;privacyStatus?:string;uploadStatus?:string;publishAt?:string};contentDetails?:{regionRestriction?:unknown;contentRating?:{ytRating?:string}}}[];error?:unknown};
 if(!d||d.error||d.kind!=='youtube#videoListResponse'||!Array.isArray(d.items))return result;
 const items=new Map(d.items.map(item=>[item.id,item]));
 for(const id of ids){
  const item=items.get(id),s=item?.status;let verdict:Verdict;
  if(!item)verdict={outcome:'unavailable',reason:'deleted_or_private',source,evidence:'Successful videos.list response omitted this requested ID.'};
  else if(!s||s.publishAt||item.contentDetails?.regionRestriction||item.contentDetails?.contentRating?.ytRating==='ytAgeRestricted')verdict=unknown(source,'restricted_or_scheduled');
  else if(s.embeddable===false)verdict={outcome:'unavailable',reason:'embedding_disabled',source,evidence:'status.embeddable=false'};
  else if(s.privacyStatus==='private'||['deleted','failed','rejected'].includes(s.uploadStatus??''))verdict={outcome:'unavailable',reason:'deleted_or_private',source,evidence:JSON.stringify(s)};
  else if(s.embeddable===true)verdict={outcome:'available',reason:'embeddable',source};
  else verdict=unknown(source,'incomplete_status');
  result.set(id,verdict);
 }
 return result;
}
async function limitedText(response:Response,max=1000000){
 const reader=response.body?.getReader();if(!reader)throw new Error('Empty response');const chunks:Uint8Array[]=[];let bytes=0;
 try{while(true){const r=await reader.read();if(r.done)break;bytes+=r.value.byteLength;if(bytes>max)throw new Error('Response too large');chunks.push(r.value);}}finally{await reader.cancel().catch(()=>{});}
 const all=new Uint8Array(bytes);let offset=0;for(const chunk of chunks){all.set(chunk,offset);offset+=chunk.length;}return new TextDecoder().decode(all);
}
export async function probeVideos(ids:string[],env:MaintenanceRuntime,origin:string):Promise<Map<string,Verdict>>{
 if(ids.some(id=>!VIDEO_ID.test(id))||ids.length>20)throw new ApiError(400,'Lô kiểm tra video không hợp lệ.');
 const output=new Map<string,Verdict>();
 if(env.YOUTUBE_API_KEY){
  try{
   const url=new URL('https://www.googleapis.com/youtube/v3/videos');url.search=new URLSearchParams({part:'status,contentDetails',id:ids.join(','),key:env.YOUTUBE_API_KEY,fields:'kind,items(id,status(embeddable,privacyStatus,uploadStatus,publishAt),contentDetails(regionRestriction,contentRating(ytRating)))'}).toString();
   const res=await fetch(url,{signal:AbortSignal.timeout(6500),redirect:'manual'});
   if(res.ok){const verdicts=classifyApi(JSON.parse(await limitedText(res)),ids);if(verdicts.size===ids.length)return verdicts;}
  }catch{ /* A rejected/quota-limited API request is not evidence against a video. */ }
 }
 let cursor=0;
 await Promise.all(Array.from({length:Math.min(2,ids.length)},async()=>{while(cursor<ids.length){
  const id=ids[cursor++];
  try{
   const url=new URL('https://www.youtube.com/embed/'+id);url.searchParams.set('hl','en');url.searchParams.set('origin',origin);
   const res=await fetch(url,{signal:AbortSignal.timeout(6500),redirect:'manual',headers:{Referer:origin+'/',Accept:'text/html'}});
   output.set(id,res.ok?classifyEmbed(await limitedText(res),id):unknown('youtube-embed','http_'+res.status));
  }catch(error){
   // Public embed URLs contain no credentials. Keep diagnostics in server logs,
   // never interpret a transport/parser failure as an unavailable video.
   console.warn('youtube-maintenance-probe',id,error instanceof Error?error.name+': '+error.message.slice(0,160):'Unknown error');
   output.set(id,unknown('youtube-embed','network_or_timeout'));
  }
 }}));
 return output;
}
export async function blockedVideoIds(db:D1Database,ids:string[]){
 if(!ids.length)return [];
 const result=await db.prepare('SELECT video_id FROM video_blocks WHERE video_id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(ids)).all<{video_id:string}>();
 return result.results.map(row=>row.video_id);
}
export async function recordVerdict(db:D1Database,id:string,v:Verdict,now:number){
 if(!VIDEO_ID.test(id))throw new ApiError(400,'Video ID không hợp lệ.');
 const old=await db.prepare('SELECT * FROM video_checks WHERE video_id=?').bind(id).first<Check>();
 const same=old?.failures&&old.reason===v.reason&&old.first_failed_at!==null;
 // Unknown results break the chain. A previous failure must never be reused
 // after a timeout, an OK response, or a change in the reason for failure.
 const failures=v.outcome==='unavailable'?(same?old!.failures+1:1):0;
 const first=v.outcome==='unavailable'?(same?old!.first_failed_at:now):null;
 const confirmed=v.outcome==='unavailable'&&failures>=2&&first!==null&&now-first>=CONFIRMATION_DELAY;
 const update=db.prepare('INSERT INTO video_checks (video_id,checked_at,next_check_at,outcome,reason,source,failures,first_failed_at,reported_at) VALUES (?,?,?,?,?,?,?,?,0) ON CONFLICT(video_id) DO UPDATE SET checked_at=excluded.checked_at,next_check_at=excluded.next_check_at,outcome=excluded.outcome,reason=excluded.reason,source=excluded.source,failures=excluded.failures,first_failed_at=excluded.first_failed_at,reported_at=0').bind(id,now,now+(v.outcome==='unavailable'?CONFIRMATION_DELAY:DAY),v.outcome,v.reason,v.source,failures,first);
 if(!confirmed){await update.run();return false;}
 // The archive, block and removal use one D1 transaction and current DB rows.
 // No stale playlist snapshot can overwrite an admin's additions or ordering.
 const result=await db.batch([
  update,
  db.prepare('INSERT INTO video_removals (video_id,slug,playlist_name,position,track,removed_at) SELECT ?,s.slug,s.name,CAST(t.key AS INTEGER),t.value,? FROM sessions s,json_each(s.tracks) t WHERE json_extract(t.value,\'$.videoId\')=? AND NOT EXISTS (SELECT 1 FROM video_blocks WHERE video_id=?)').bind(id,now,id,id),
  db.prepare('INSERT OR IGNORE INTO video_blocks (video_id,reason,source,evidence,confirmed_at) VALUES (?,?,?,?,?)').bind(id,v.reason,v.source,(v.evidence||'').slice(0,1000),now),
  db.prepare("UPDATE sessions SET tracks=(SELECT json_group_array(json(t.value)) FROM json_each(sessions.tracks) t WHERE json_extract(t.value,'$.videoId')!=?),version=version+1,last_request=?,updated_at=? WHERE EXISTS (SELECT 1 FROM json_each(sessions.tracks) t WHERE json_extract(t.value,'$.videoId')=?)").bind(id,'maintenance:'+id+':'+now,now,id),
 ]);
 return result[2].meta.changes>0;
}
export async function maintenanceStatus(db:D1Database){
 const [counts,last,blocked]=await Promise.all([
  db.prepare('SELECT (SELECT COUNT(*) FROM video_blocks) AS blocked,(SELECT COUNT(*) FROM video_checks WHERE failures>0 AND video_id NOT IN (SELECT video_id FROM video_blocks)) AS pending,(SELECT COUNT(*) FROM video_checks) AS checked').first(),
  db.prepare('SELECT * FROM maintenance_runs ORDER BY started_at DESC LIMIT 1').first<{summary:string}>(),
  db.prepare('SELECT b.video_id,b.reason,b.confirmed_at,m.title,(SELECT COUNT(*) FROM video_removals r WHERE r.video_id=b.video_id) AS removed_from_playlists FROM video_blocks b LEFT JOIN metadata m ON m.video_id=b.video_id ORDER BY b.confirmed_at DESC LIMIT 100').all(),
 ]);
 return {counts,lastRun:last?{...last,summary:JSON.parse(last.summary)}:null,blocked:blocked.results,confirmationHours:6,timezone:'Asia/Bangkok',dailyLimitDefault:360};
}
export async function runMaintenance(env:MaintenanceRuntime,origin:string,options:{limit?:number;now?:number}={}){
 const limit=options.limit??20,now=options.now??Date.now();
 if(!Number.isInteger(limit)||limit<1||limit>20)throw new ApiError(400,'Mỗi lô kiểm tra từ 1–20 video.');
 const token=crypto.randomUUID(),db=env.DB;
 const lock=await db.prepare("INSERT INTO maintenance_locks (key,token,expires_at) VALUES ('videos',?,?) ON CONFLICT(key) DO UPDATE SET token=excluded.token,expires_at=excluded.expires_at WHERE maintenance_locks.expires_at<?").bind(token,now+120000,now).run();
 if(!lock.meta.changes)return {status:'busy',checked:0};
 try{
  const day=new Date(now+7*HOUR).toISOString().slice(0,10),budget=Math.min(1000,Math.max(20,Math.floor(Number(env.MAINTENANCE_DAILY_LIMIT)||360)));
  const used=await db.prepare('SELECT checked FROM maintenance_daily WHERE day=?').bind(day).first<{checked:number}>();
  if((used?.checked||0)>=budget)return {status:'daily_limit',checked:0};
  const selected=await db.prepare("SELECT DISTINCT json_extract(t.value,'$.videoId') AS video_id,COALESCE(c.checked_at,0) AS checked_at,COALESCE(c.reported_at,0) AS reported_at,COALESCE(c.failures,0) AS failures FROM sessions s,json_each(s.tracks) t LEFT JOIN video_checks c ON c.video_id=json_extract(t.value,'$.videoId') WHERE NOT EXISTS (SELECT 1 FROM video_blocks b WHERE b.video_id=json_extract(t.value,'$.videoId')) AND COALESCE(c.next_check_at,0)<=? ORDER BY (COALESCE(c.failures,0)>0) DESC,(COALESCE(c.reported_at,0)>0) DESC,checked_at,video_id LIMIT ?").bind(now,Math.min(limit,budget-(used?.checked||0))).all<{video_id:string}>();
  const ids=selected.results.map(r=>r.video_id).filter(id=>VIDEO_ID.test(id));
  if(!ids.length)return {status:'complete',checked:0};
  await db.batch([
   db.prepare('INSERT INTO maintenance_daily (day,checked) VALUES (?,?) ON CONFLICT(day) DO UPDATE SET checked=checked+excluded.checked').bind(day,ids.length),
   db.prepare('INSERT INTO maintenance_runs (id,started_at) VALUES (?,?)').bind(token,now),
  ]);
  const verdicts=await probeVideos(ids,env,origin),summary={status:'ok',checked:ids.length,available:0,pending:0,removed:0,unknown:0,ids:[] as {videoId:string;outcome:string;reason:string}[]};
  for(const id of ids){const v=verdicts.get(id)??unknown('youtube-embed','no_result');const removed=await recordVerdict(db,id,v,now);if(removed)summary.removed++;else if(v.outcome==='unavailable')summary.pending++;else summary[v.outcome]++;summary.ids.push({videoId:id,outcome:removed?'removed':v.outcome,reason:v.reason});}
  await db.prepare('UPDATE maintenance_runs SET finished_at=?,summary=? WHERE id=?').bind(Date.now(),JSON.stringify(summary),token).run();
  // Keep the detailed audit bounded; permanent blocks/removal backups are retained.
  await db.batch([db.prepare('DELETE FROM maintenance_runs WHERE started_at<?').bind(now-90*DAY),db.prepare('DELETE FROM maintenance_daily WHERE day<?').bind(new Date(now-90*DAY).toISOString().slice(0,10))]);
  return summary;
 }finally{await db.prepare("DELETE FROM maintenance_locks WHERE key='videos' AND token=?").bind(token).run();}
}
