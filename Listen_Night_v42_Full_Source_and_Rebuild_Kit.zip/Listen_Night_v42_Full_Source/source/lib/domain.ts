export const MAX_TRACKS = 300;
export const ALL_SONGS_SLUG = '__all__';
export function resolveViewSlug(search:string){return new URLSearchParams(search).get('s')||ALL_SONGS_SLUG;}
export function entryViewSlug(search:string,compact:boolean,collections:Pick<CollectionSummary,'slug'|'count'>[]=[],random:()=>number=Math.random):string|null{
 const params=new URLSearchParams(search),requested=params.get('s');
 if(requested)return requested;
 if(!compact||params.get('view')==='all')return ALL_SONGS_SLUG;
 const available=collections.filter(c=>c.count>0);
 return available.length?available[Math.floor(random()*available.length)].slug:null;
}
export function viewApiPath(slug:string){return slug===ALL_SONGS_SLUG?'/library':`/sessions/${slug}`;}
export type PlaylistSource={slug:string;name:string};
export const SEED_IDS = ['RzhIXHc6_80','_U8S-uFZrHA','_NA_QD7zHmQ','V1Pl8CzNzCw','AIqG6Gnvm90','MoN9ql6Yymw','0-7IHOXkiV8','MwpMEbgC7DA','tt2k8PGm-TI','TdrL3QxjyVw','n6nkNKSvl2Y','BboMpayJomw','TG1lH-__u8g','AZeU5_YpqsA','SA7AIQw-7Ms','xaKjrM8xk3I','QHXXARHONaA','maCzU3_SRos','D97Zog2PBXM','NKgykg-lzKs','-rKwPblSdQA','zHh4t38f9AM','09R4LQb71wg','-SJzxfQYCxE','J9ymya-bQzU'];
export type Track = { videoId:string; url:string; title:string; channel:string|null; thumbnail:string; metadataStatus:string; addedAt:number; sourcePlaylists?:PlaylistSource[] };
export type Session = { slug:string; name:string; tracks:Track[]; version:number; canEdit:boolean; updatedAt:number; kind?:'all'|'playlist'; sourceCount?:number; totalEntries?:number };
export type User = { name:string; signedIn:boolean };
export class ApiError extends Error { constructor(public status:number, message:string,public retryAfter?:number){super(message);} }
export function slugValue(value:unknown){
  if(typeof value!=='string'||! /^[a-z0-9](?:[a-z0-9-]{1,46}[a-z0-9])$/.test(value)) throw new ApiError(400,'Slug cần 3–48 ký tự chữ thường, số hoặc dấu gạch ngang; không bắt đầu hay kết thúc bằng gạch ngang.');
  return value;
}
export function nameValue(value:unknown){
  if(typeof value!=='string'||!value.trim()||value.trim().length>100||/[\u0000-\u001f]/.test(value))throw new ApiError(400,'Tên session cần từ 1 đến 100 ký tự.');
  return value.trim();
}
export function videoId(value:string):string|null{
  const raw=value.trim(); if(/^[A-Za-z0-9_-]{11}$/.test(raw))return raw;
  try{
    const u=new URL(raw); if(!['https:','http:'].includes(u.protocol)||u.username||u.password||u.port)return null;
    const host=u.hostname.toLowerCase(); let id:string|null=null;
    if(host==='youtu.be')id=u.pathname.split('/')[1];
    else if(['youtube.com','www.youtube.com','m.youtube.com','music.youtube.com'].includes(host)){
      if(u.pathname==='/watch')id=u.searchParams.get('v');
      else if(/^\/(shorts|embed|live)\/[A-Za-z0-9_-]{11}\/?$/.test(u.pathname))id=u.pathname.split('/')[2];
    }
    return id&&/^[A-Za-z0-9_-]{11}$/.test(id)?id:null;
  }catch{return null;}
}
export const canonicalUrl=(id:string)=>`https://www.youtube.com/watch?v=${id}`;
export function fallbackTrack(id:string,addedAt=Date.now()):Track{
 return {videoId:id,url:canonicalUrl(id),title:`Video YouTube · ${id}`,channel:null,thumbnail:`https://i.ytimg.com/vi/${id}/hqdefault.jpg`,metadataStatus:'pending',addedAt};
}
export function parseBatch(text:unknown,existing:string[]=[]){
 if(typeof text!=='string'||text.length>60000)throw new ApiError(400,'Nội dung nhập tối đa 60.000 ký tự.');
 const lines=text.split(/\r?\n/).map((x,i)=>({value:x.trim(),line:i+1})).filter(x=>x.value);
 if(!lines.length||lines.length>300)throw new ApiError(400,'Nhập từ 1 đến 300 dòng, mỗi dòng một URL hoặc video ID.');
 const seen=new Set(existing),ids:string[]=[],invalidLines:number[]=[];let duplicates=0;
 lines.forEach(line=>{const id=videoId(line.value);if(!id){invalidLines.push(line.line);return;}if(seen.has(id)){duplicates++;return;}seen.add(id);ids.push(id);});
 if(existing.length+ids.length>MAX_TRACKS)throw new ApiError(400,`Mỗi playlist có tối đa ${MAX_TRACKS} bài.`);
 return {ids,added:ids.length,duplicates,invalid:invalidLines.length,invalidLines};
}
export function nextId(ids:string[],current:string|null,opts:{direction?:number;repeat?:string;shuffle?:boolean;automatic?:boolean;failed?:Set<string>;played?:Set<string>}={}){
 const available=ids.filter(x=>!opts.failed?.has(x));if(!available.length)return null;
 if(opts.automatic&&opts.repeat==='one'&&current&&available.includes(current))return current;
 if(opts.shuffle){const pool=available.filter(x=>x!==current&&!opts.played?.has(x));if(pool.length)return pool[Math.floor(Math.random()*pool.length)];if(opts.automatic&&opts.repeat!=='all')return null;const reset=available.filter(x=>x!==current);return reset.length?reset[Math.floor(Math.random()*reset.length)]:available[0];}
 const start=ids.indexOf(current||''),direction=opts.direction??1;
 for(let step=1;step<=ids.length;step++){
   const raw=start+step*direction;
   if(opts.automatic&&opts.repeat!=='all'&&(raw<0||raw>=ids.length))return null;
   const candidate=ids[(raw%ids.length+ids.length)%ids.length];if(available.includes(candidate))return candidate;
 }
 return null;
}
export function replacementAfterDelete(ids:string[],removed:string){const index=ids.indexOf(removed);const rest=ids.filter(x=>x!==removed);return rest[Math.min(index,rest.length-1)]??null;}

export type CollectionSource={url:string;title:string;curator:string;kind?:'curated'|'video';fetchedAt:number;trackCount:number;unavailableCount:number;duplicateCount:number};
export type CollectionSummary={slug:string;name:string;description:string;mood:string;accent:string;count:number;cover:string|null;canEdit:boolean;category?:'viet'|'ai'|'tryhard'|'gaming'|'ride'|'active'|'dopamine';source?:CollectionSource;longformVideoIds?:string[]};
export type AdminPlaylist={slug:string;name:string;count:number;cover:string|null;version:number;updatedAt:number;listed:boolean;category:'viet'|'ai'|'tryhard'|'gaming'|'ride'|'active'|'dopamine'|'curated'|'personal';sourceUrl:string|null};
export type AdminCatalogue={playlists:AdminPlaylist[];stats:{playlists:number;entries:number;uniqueTracks:number};user:{name:string}};
