import {ApiError} from './domain';
import {maintenanceStatus,runMaintenance,type MaintenanceRuntime} from './video-maintenance';
const tools=[
 {name:'video_maintenance_status',description:'Owner only. Read persisted video audit, blocked videos and the last maintenance batch. No playlist changes.',inputSchema:{type:'object',properties:{},additionalProperties:false}},
 {name:'run_video_maintenance',description:'Owner only. Check up to 20 existing video IDs using YouTube. Two matching definitive failures at least six hours apart are required before archiving and removing a video from every playlist. Unknown/network/configuration errors never remove a video. Daily budget and overlap lock are enforced by the server. Repeat bounded batches until daily_limit or complete; stop after two batches with only unknown results. No republish needed.',inputSchema:{type:'object',properties:{limit:{type:'integer',minimum:1,maximum:20,default:20}},additionalProperties:false}},
];
export async function handleMaintenanceMcp(req:Request,env:MaintenanceRuntime){
 const headers={'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
 if(req.method!=='POST')return new Response('Method not allowed',{status:405,headers:{Allow:'POST'}});
 let id:unknown=null;
 const reply=(value:unknown,status=200)=>Response.json(value,{status,headers});
 try{
  const raw=await req.text();if(raw.length>10000)throw new ApiError(413,'Request too large');
  const d=JSON.parse(raw);id=d.id??null;
  if(d.jsonrpc!=='2.0')throw new ApiError(400,'Invalid JSON-RPC');
  if(d.method==='notifications/initialized')return new Response(null,{status:202});
  let result:unknown;
  if(d.method==='server/discover')result={supportedVersions:['2026-07-28'],capabilities:{tools:{}}};
  else if(d.method==='initialize')result={protocolVersion:'2026-07-28',serverInfo:{name:'listen-night-maintenance',version:'1.0.0'},capabilities:{tools:{}}};
  else if(d.method==='tools/list')result={tools};
  else if(d.method==='tools/call'){
   // Sites validates and injects identity on /mcp. Public viewing access alone
   // never grants maintenance rights. App username/password login is unchanged.
   const email=req.headers.get('oai-authenticated-user-email')?.trim().toLowerCase();
   if(!env.MAINTENANCE_OWNER_EMAIL||email!==env.MAINTENANCE_OWNER_EMAIL.trim().toLowerCase()||!req.headers.get('oai-authenticated-user-id'))throw new ApiError(403,'Chỉ chủ website được chạy tác vụ bảo trì.');
   const args=d.params?.arguments??{};
   if(!args||typeof args!=='object'||Array.isArray(args)||Object.keys(args).some(k=>k!=='limit'))throw new ApiError(400,'Invalid arguments');
   let data:unknown;
   if(d.params?.name==='video_maintenance_status')data=await maintenanceStatus(env.DB);
   else if(d.params?.name==='run_video_maintenance')data=await runMaintenance(env,new URL(req.url).origin,{limit:args.limit});
   else throw new ApiError(404,'Unknown tool');
   result={content:[{type:'text',text:JSON.stringify(data)}]};
  }else if(d.method==='ping')result={};
  else return reply({jsonrpc:'2.0',id,error:{code:-32601,message:'Method not found'}});
  return reply({jsonrpc:'2.0',id,result});
 }catch(e){const known=e instanceof ApiError;return reply({jsonrpc:'2.0',id,error:{code:known?-32000:-32603,message:known?e.message:'Maintenance request failed; no unverified videos were removed.'}},known?e.status:500);}
}
