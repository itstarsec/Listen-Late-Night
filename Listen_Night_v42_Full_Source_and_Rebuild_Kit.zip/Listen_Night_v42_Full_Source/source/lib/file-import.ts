import {ApiError,MAX_TRACKS,videoId,canonicalUrl} from './domain';

export const MAX_IMPORT_BYTES=256*1024;
export const IMPORT_EXTENSIONS=['txt','csv','m3u','m3u8'];
export type ImportReport={added:number;duplicates:number;invalid:number;invalidLines:number[];total:number;blocked?:number};
export type ImportTarget={kind:'new';slug:string;name:string}|{kind:'existing';slug:string;version:number};
export function suggestSlug(name:string){return name.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/đ/g,'d').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,48).replace(/-+$/,'');}

function csvRows(text:string){
 const first=text.split(/\r?\n/,1)[0],delimiter=[';',',','\t'].sort((a,b)=>first.split(b).length-first.split(a).length)[0];
 const rows:{cells:string[];line:number}[]=[];let cells:string[]=[],cell='',quoted=false,afterQuote=false,line=1,start=1;
 const finish=()=>{cells.push(cell.trim());if(cells.some(Boolean))rows.push({cells,line:start});cells=[];cell='';afterQuote=false;start=line+1;};
 for(let i=0;i<text.length;i++){
  const c=text[i];
  if(quoted){if(c==='"'){if(text[i+1]==='"'){cell+='"';i++;}else{quoted=false;afterQuote=true;}}else{cell+=c;if(c==='\n')line++;}continue;}
  if(c==='"'&&!cell.trim()&&!afterQuote){quoted=true;cell='';}
  else if(c===delimiter){cells.push(cell.trim());cell='';afterQuote=false;}
  else if(c==='\n'){finish();line++;start=line;}
  else if(c==='\r'&&text[i+1]==='\n')continue;
  else if(afterQuote&&!/\s/.test(c))throw new ApiError(400,'CSV có dấu ngoặc kép chưa đúng định dạng.');
  else cell+=c;
 }
 if(quoted)throw new ApiError(400,'CSV có dấu ngoặc kép chưa đóng.');
 finish();return rows;
}
export function parseUrlFile(filename:unknown,content:unknown,existing:string[]=[]){
 if(typeof filename!=='string'||!filename.trim()||filename.length>200||/[\u0000-\u001f/\\]/.test(filename))throw new ApiError(400,'Tên file không hợp lệ.');
 const extension=filename.split('.').at(-1)!.toLowerCase();
 if(!IMPORT_EXTENSIONS.includes(extension))throw new ApiError(400,'Chọn file .txt, .csv, .m3u hoặc .m3u8 chứa URL YouTube.');
 if(typeof content!=='string'||new TextEncoder().encode(content).byteLength>MAX_IMPORT_BYTES)throw new ApiError(400,'File tối đa 256 KB.');
 if(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffd]/.test(content))throw new ApiError(400,'File phải là văn bản UTF-8. Hãy xuất danh sách URL thành file .txt UTF-8.');
 const text=content.replace(/^\ufeff/,'').replace(/\r\n?/g,'\n');
 let entries:{value:string;line:number}[];
 if(extension==='csv'){
  const rows=csvRows(text),headers=rows[0]?.cells.map(x=>suggestSlug(x))||[];
  const column=headers.findIndex(x=>['url','link','youtube','youtube-url','video-url','video-id','videoid','lien-ket'].includes(x));
  entries=(column>=0?rows.slice(1):rows).map(row=>({value:column>=0?row.cells[column]||'':row.cells.find(x=>videoId(x))||row.cells[0],line:row.line}));
 }else entries=text.split('\n').map((value,index)=>({value:value.trim(),line:index+1})).filter(x=>x.value&&(!(extension==='m3u'||extension==='m3u8')||!x.value.startsWith('#')));
 if(!entries.length||entries.length>MAX_TRACKS)throw new ApiError(400,'File cần từ 1 đến 300 dòng bài hát. Mỗi dòng một URL hoặc video ID.');
 const seen=new Set(existing),ids:string[]=[],invalidLines:number[]=[];let duplicates=0;
 for(const entry of entries){const id=videoId(entry.value);if(!id){invalidLines.push(entry.line);continue;}if(seen.has(id)){duplicates++;continue;}seen.add(id);ids.push(id);}
 if(existing.length+ids.length>MAX_TRACKS)throw new ApiError(400,`Playlist tối đa ${MAX_TRACKS} bài. Còn ${MAX_TRACKS-existing.length} chỗ, file có ${ids.length} bài mới.`);
 return {ids,urls:ids.map(canonicalUrl),report:{added:ids.length,duplicates,invalid:invalidLines.length,invalidLines,total:entries.length} satisfies ImportReport};
}
