export interface YouTubePlayer {
 loadVideoById(v:{videoId:string;startSeconds?:number}):void;cueVideoById(v:{videoId:string;startSeconds?:number}):void;
 playVideo():void;pauseVideo():void;stopVideo():void;seekTo(n:number,a:boolean):void;
 getPlayerState():number;getCurrentTime():number;getDuration():number;
 getVideoData():{video_id?:string;title?:string;author?:string};getIframe():HTMLIFrameElement;destroy():void;
}
export interface YouTubeAPI {Player:new (el:HTMLElement,options:Record<string,unknown>)=>YouTubePlayer;}
declare global {interface Window {YT?:YouTubeAPI;onYouTubeIframeAPIReady?:()=>void;}}
let pending:Promise<YouTubeAPI>|null=null;
export function loadYouTube():Promise<YouTubeAPI>{
 if(window.YT?.Player)return Promise.resolve(window.YT);
 if(pending)return pending;
 pending=new Promise((resolve,reject)=>{
  const timeout=window.setTimeout(()=>fail(),15000);
  const previous=window.onYouTubeIframeAPIReady;
  const fail=()=>{window.clearTimeout(timeout);pending=null;document.getElementById('youtube-iframe-api')?.remove();reject(new Error('Không tải được trình phát YouTube. Kiểm tra kết nối hoặc trình chặn nội dung rồi thử lại.'));};
  window.onYouTubeIframeAPIReady=()=>{previous?.();window.clearTimeout(timeout);if(window.YT?.Player)resolve(window.YT);else fail();};
  if(!document.getElementById('youtube-iframe-api')){const script=document.createElement('script');script.id='youtube-iframe-api';script.src='https://www.youtube.com/iframe_api';script.async=true;script.onerror=fail;document.head.appendChild(script);}
 });return pending;
}
export const PLAYER_ERROR:Record<number,string>={2:'Video ID không hợp lệ.',5:'Trình duyệt không phát được video này.',100:'Video đã bị xóa hoặc chuyển sang riêng tư.',101:'Chủ video không cho phép phát nhúng. Bạn có thể mở trên YouTube.',150:'Chủ video không cho phép phát nhúng. Bạn có thể mở trên YouTube.',153:'YouTube không xác nhận được nguồn nhúng. Thử mở trang trực tiếp hoặc xem trên YouTube.'};
