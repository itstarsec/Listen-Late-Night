/** Visual motion only. The YouTube player remains the source of playback truth. */
export type TurntableSignal = {
  videoId: string | null;
  playerState: number;
  progress: number;
  duration: number;
  reducedMotion: boolean;
};
export type TurntableMotion = {
  rotation: number; speed: number; armAngle: number; armLift: number;
  cue: number; videoId: string | null; engaged: boolean; light: number;
};
export const NOMINAL_RPM = 33 + 1 / 3;
export const PARK_ANGLE = .08;
export const initialMotion = (): TurntableMotion => ({rotation:0,speed:0,armAngle:PARK_ANGLE,armLift:.13,cue:0,videoId:null,engaged:false,light:.12});
const clamp = (n:number, a:number, b:number) => Math.max(a, Math.min(b, Number.isFinite(n)?n:a));
const approach = (a:number,b:number,rate:number,dt:number) => a+(b-a)*(1-Math.exp(-rate*dt));
export function stepMotion(previous:TurntableMotion,signal:TurntableSignal,elapsed:number,clock:number):TurntableMotion {
  const dt=clamp(elapsed,0,.08),changed=signal.videoId!==previous.videoId;
  const playing=signal.playerState===1,buffering=signal.playerState===3;
  const cue=changed&&previous.videoId!==null? .48 : Math.max(0,previous.cue-dt);
  const engaged=changed?playing||buffering:previous.engaged||playing||buffering;
  const fraction=signal.duration>0?clamp(signal.progress/signal.duration,0,1):0;
  const targetAngle=engaged&&signal.videoId?-.68-fraction*.39:PARK_ANGLE;
  const targetLift=cue>.06?.24:playing?.008:buffering?.09:.14;
  let speed=signal.reducedMotion?0:approach(previous.speed,playing?NOMINAL_RPM*Math.PI*2/60:0,playing?2.2:3.6,dt);
  if(speed<.0008)speed=0;
  return {
    videoId:signal.videoId,engaged,cue,
    speed,rotation:(previous.rotation+speed*dt)%(Math.PI*2),
    armAngle:signal.reducedMotion?targetAngle:approach(previous.armAngle,targetAngle,cue>.1?5:3.5,dt),
    armLift:signal.reducedMotion?targetLift:approach(previous.armLift,targetLift,8,dt),
    light:playing?1:buffering?(signal.reducedMotion?.45:.40+.20*Math.sin(clock*3)):.12,
  };
}
export function motionSettled(m:TurntableMotion,s:TurntableSignal) {
  const angle=m.engaged&&s.videoId?-.68-(s.duration>0?clamp(s.progress/s.duration,0,1):0)*.39:PARK_ANGLE;
  const lift=s.playerState===1?.008:s.playerState===3?.09:.14;
  return m.speed===0&&m.cue===0&&Math.abs(m.armAngle-angle)<.001&&Math.abs(m.armLift-lift)<.001;
}
