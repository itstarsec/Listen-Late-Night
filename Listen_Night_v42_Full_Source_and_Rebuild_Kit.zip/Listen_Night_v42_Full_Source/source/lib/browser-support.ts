/** Keep this decision on the server: a legacy browser cannot parse the modern app. */
export function needsCompatiblePlayer(userAgent:string):boolean{
 const ios=/(?:CPU(?: iPhone)? OS|iPhone OS) (\d+)(?:_(\d+))?/i.exec(userAgent);
 const safari=/Version\/(\d+)(?:\.(\d+))?/i.exec(userAgent);
 const version=ios||(/AppleWebKit/i.test(userAgent)&&/Safari/i.test(userAgent)&&!/(?:Chrome|Chromium|Android|Edg|OPR)\//i.test(userAgent)?safari:null);
 return !!version&&(Number(version[1])<16||Number(version[1])===16&&Number(version[2]||0)<4);
}

// ES5 classic script. Feature detection also catches a desktop/masked user agent.
// Runs before hydration and preserves the complete session query and fragment.
export const COMPATIBILITY_BOOTSTRAP="(function(){if(window.location.pathname!=='/')return;var e=window.Element&&window.Element.prototype,m=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)');if(!window.Promise||!window.fetch||!e||!e.replaceChildren||!Array.prototype.at||!String.prototype.replaceAll||!m||!m.addEventListener){window.location.replace('/lite'+window.location.search+window.location.hash);}}());";

export type CompatibilityAssets={html:string;script:string;style:string};
export function compatibilityResponse(request:Request,assets:CompatibilityAssets):Response|null{
 const url=new URL(request.url),path=url.pathname;
 let content:string,type:string;
 if(path==='/lite'||path==='/lite/') {content=assets.html;type='text/html; charset=utf-8';}
 else if(path==='/listen-lite.js'){content=assets.script;type='text/javascript; charset=utf-8';}
 else if(path==='/listen-lite.css'){content=assets.style;type='text/css; charset=utf-8';}
 else if(path==='/'&&request.headers.get('RSC')!=='1'&&needsCompatiblePlayer(request.headers.get('User-Agent')||'')){content=assets.html;type='text/html; charset=utf-8';}
 else return null;
 const headers={'Content-Type':type,'Cache-Control':'private, no-store','Vary':'User-Agent','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'};
 if(request.method!=='GET'&&request.method!=='HEAD')return new Response('Method not allowed',{status:405,headers:{...headers,Allow:'GET, HEAD'}});
 return new Response(request.method==='HEAD'?null:content,{headers});
}

export function varyListeningResponse(request:Request,response:Response):Response{
 if(new URL(request.url).pathname!=='/')return response;
 const headers=new Headers(response.headers),vary=headers.get('Vary')||'';
 if(vary!=='*'&&!vary.toLowerCase().split(',').some(v=>v.trim()==='user-agent'))headers.set('Vary',vary?vary+', User-Agent':'User-Agent');
 headers.set('Cache-Control','private, no-store');
 return new Response(response.body,{status:response.status,statusText:response.statusText,headers});
}
