import * as THREE from 'three';
export type ConsoleAction='toggle'|'previous'|'next';

/** Original, deliberately restrained mechanical model. No DOM or audio engine. */
export function createTurntableModel({lowPower=false,labelTexture}:{lowPower?:boolean;labelTexture?:THREE.Texture}={}) {
  const group=new THREE.Group();group.name='listening-console';
  const geometries=new Set<THREE.BufferGeometry>(),materials=new Set<THREE.Material>();
  const geometryCache=new Map<string,THREE.BufferGeometry>(),edgeCache=new Map<THREE.BufferGeometry,THREE.EdgesGeometry>();
  const segments=lowPower?40:72;
  function material(color:string,metalness=.25,roughness=.65){const m=new THREE.MeshStandardMaterial({color,metalness,roughness});materials.add(m);return m;}
  const bodyMat=material('#292b2c'),sideMat=material('#202223'),black=material('#111314',.25,.42),silver=material('#858582',.75,.36),darkMetal=material('#424647',.65,.5),rubber=material('#0b0c0d',0,.95),amber=material('#ff9d3c',.15,.62);
  const lineMat=new THREE.LineBasicMaterial({color:'#6a6d6c',transparent:true,opacity:.42});materials.add(lineMat);
  function geom(key:string,create:()=>THREE.BufferGeometry){let g=geometryCache.get(key);if(!g){g=create();geometryCache.set(key,g);geometries.add(g);}return g;}
  function box(w:number,h:number,d:number){return geom(`b:${w},${h},${d}`,()=>new THREE.BoxGeometry(w,h,d));}
  function cylinder(r:number,h:number,s=segments){return geom(`c:${r},${h},${s}`,()=>new THREE.CylinderGeometry(r,r,h,s));}
  function mesh(name:string,g:THREE.BufferGeometry,m:THREE.Material,parent:THREE.Object3D=group,pos:[number,number,number]=[0,0,0],outline=false){
    const o=new THREE.Mesh(g,m);o.name=name;o.position.set(...pos);parent.add(o);
    if(outline){let e=edgeCache.get(g);if(!e){e=new THREE.EdgesGeometry(g,28);edgeCache.set(g,e);geometries.add(e);}o.add(new THREE.LineSegments(e,lineMat));}return o;
  }
  mesh('lower-plinth',box(5.62,.23,3.82),sideMat,group,[0,.22,0],true);
  mesh('upper-deck',box(5.62,.17,3.82),bodyMat,group,[0,.42,0],true);
  mesh('front-panel-inlay',box(5.19,.055,.012),darkMetal,group,[0,.27,1.918]);
  for(const x of [-2.25,2.25])for(const z of [-1.4,1.4]){
    mesh(`foot-${x}-${z}`,cylinder(.24,.18,24),rubber,group,[x,.05,z]);
    mesh('foot-collar',cylinder(.215,.04,24),darkMetal,group,[x,.15,z]);
  }
  const platter=new THREE.Group();platter.name='platter';platter.position.set(-.73,.535,-.13);group.add(platter);
  mesh('platter-rim',cylinder(1.48,.12),silver,platter,[0,0,0]);
  mesh('platter-gasket',cylinder(1.445,.06),black,platter,[0,.075,0]);
  const disc=new THREE.Group();disc.name='vinyl';disc.position.y=.12;platter.add(disc);
  mesh('record',cylinder(1.385,.025),black,disc);
  const groovePoints:number[]=[];
  for(let r=.59;r<1.36;r+=lowPower?.055:.026){for(let i=0;i<segments;i++){const a=i/segments*Math.PI*2,b=(i+1)/segments*Math.PI*2;groovePoints.push(Math.cos(a)*r,.015,Math.sin(a)*r,Math.cos(b)*r,.015,Math.sin(b)*r);}}
  const grooveGeo=new THREE.BufferGeometry();grooveGeo.setAttribute('position',new THREE.Float32BufferAttribute(groovePoints,3));geometries.add(grooveGeo);
  const grooveMat=new THREE.LineBasicMaterial({color:'#787a79',transparent:true,opacity:.17});materials.add(grooveMat);const grooves=new THREE.LineSegments(grooveGeo,grooveMat);grooves.name='record-grooves';disc.add(grooves);
  const labelMat=new THREE.MeshStandardMaterial({color:labelTexture?'#ffffff':'#d98c43',...(labelTexture?{map:labelTexture}:{}),roughness:.9,metalness:0});materials.add(labelMat);
  mesh('record-label',cylinder(.515,.028),labelMat,disc,[0,.02,0]);
  mesh('label-center',cylinder(.10,.032,32),black,disc,[0,.028,0]);
  mesh('center-spindle',cylinder(.035,.17,20),silver,platter,[0,.21,0]);
  const strobeGeometry=box(.022,.019,.022),count=lowPower?64:104,strobe=new THREE.InstancedMesh(strobeGeometry,silver,count),matrix=new THREE.Matrix4();
  for(let i=0;i<count;i++){const a=i/count*Math.PI*2;matrix.makeTranslation(Math.cos(a)*1.482,.005,Math.sin(a)*1.482);strobe.setMatrixAt(i,matrix);}strobe.name='strobe-markings';platter.add(strobe);

  const pivot=new THREE.Group();pivot.name='tonearm-base';pivot.position.set(1.87,.53,-1.18);group.add(pivot);
  mesh('pivot-mount',cylinder(.29,.12,40),black,pivot,[0,.04,0]);mesh('pivot-tower',cylinder(.18,.33,40),silver,pivot,[0,.21,0]);
  mesh('pivot-cap',cylinder(.21,.07,40),darkMetal,pivot,[0,.40,0]);
  const arm=new THREE.Group();arm.name='tonearm';arm.position.y=.36;pivot.add(arm);arm.rotation.y=.08;
  mesh('tonearm-bearing',box(.30,.13,.24),darkMetal,arm,[0,.035,0],true);
  // A single swept tube: tangent-aligned joins keep the metal and its shading
  // continuous, with both ends buried inside the counterweight and headshell.
  const armPath=new THREE.CurvePath<THREE.Vector3>();
  armPath.add(new THREE.LineCurve3(new THREE.Vector3(0,.025,-.44),new THREE.Vector3(0,.025,1.50)));
  armPath.add(new THREE.CubicBezierCurve3(
    new THREE.Vector3(0,.025,1.50),new THREE.Vector3(0,.025,1.74),
    new THREE.Vector3(-.16,.025,1.78),new THREE.Vector3(-.16,.025,1.98),
  ));
  armPath.add(new THREE.LineCurve3(new THREE.Vector3(-.16,.025,1.98),new THREE.Vector3(-.16,.025,2.04)));
  mesh('tonearm-tube',geom('continuous-tonearm',()=>new THREE.TubeGeometry(armPath,lowPower?40:72,.038,lowPower?10:16,false)),silver,arm);
  const socket=mesh('headshell-socket',cylinder(.055,.18,24),darkMetal,arm,[-.16,.025,1.99]);socket.rotation.x=Math.PI/2;
  mesh('headshell',box(.18,.055,.36),darkMetal,arm,[-.16,.035,2.06],true);
  mesh('cartridge',box(.12,.11,.19),black,arm,[-.16,-.045,2.10],true);
  const stylusMaterial=new THREE.MeshStandardMaterial({color:'#e8aa64',emissive:'#ff9d3c',emissiveIntensity:.1,roughness:.5});materials.add(stylusMaterial);
  const stylus=mesh('stylus',box(.035,.06,.04),stylusMaterial,arm,[-.16,-.12,2.13]);
  const stylusLight=new THREE.PointLight('#ff9d3c',0,.48,2);stylusLight.name='stylus-glow';stylusLight.position.set(-.16,-.13,2.13);arm.add(stylusLight);
  const counter=mesh('counterweight',cylinder(.145,.35,32),darkMetal,arm,[0,.02,-.31],true);counter.rotation.x=Math.PI/2;
  mesh('armrest-post',cylinder(.042,.23,20),silver,group,[2.05,.64,.52]);mesh('armrest-cradle',box(.22,.05,.12),black,group,[2.05,.78,.52],true);

  const actionTargets:THREE.Mesh[]=[];
  const ledMaterial=new THREE.MeshStandardMaterial({color:'#ffae59',emissive:'#ff8e26',emissiveIntensity:.1,roughness:.5});materials.add(ledMaterial);
  function button(action:ConsoleAction,x:number,z:number,w:number,label:'play'|'previous'|'next'){
    const buttonGroup=new THREE.Group();buttonGroup.name=`control-${action}`;buttonGroup.position.set(x,.55,z);group.add(buttonGroup);
    mesh('button-bezel',box(w+.08,.025,.49),black,buttonGroup,[0,-.015,0],true);
    const bmat=material(action==='toggle'?'#b16f34':'#383b3b',.42,.5);
    const cap=mesh(`button-${action}`,box(w,.055,.41),bmat,buttonGroup,[0,.024,0],true);cap.userData.action=action;cap.userData.baseY=.024;actionTargets.push(cap);
    const signMat=action==='toggle'?amber:silver;
    if(label==='play'){
      const shape=new THREE.Shape();shape.moveTo(-.055,-.075);shape.lineTo(.075,0);shape.lineTo(-.055,.075);shape.closePath();
      const g=new THREE.ShapeGeometry(shape);geometries.add(g);const icon=mesh('play-inscription',g,signMat,cap,[0,.030,0]);icon.rotation.x=-Math.PI/2;
    }else{
      const g=geom('triangle',()=>new THREE.ConeGeometry(.065,.12,3));const sign=mesh(`${label}-inscription`,g,signMat,cap,[0,.035,0]);sign.rotation.z=label==='next'?-Math.PI/2:Math.PI/2;sign.rotation.x=Math.PI/2;
      mesh('skip-bar',box(.018,.008,.13),signMat,cap,[label==='next'?.09:-.09,.034,0]);
    }return cap;
  }
  const playButton=button('toggle',-2.13,1.22,.56,'play');button('previous',1.52,1.38,.4,'previous');button('next',2.13,1.38,.4,'next');
  const led=mesh('status-led',cylinder(.045,.02,20),ledMaterial,group,[-1.67,.515,1.23]);
  mesh('status-led-bezel',cylinder(.075,.01,24),black,group,[-1.67,.505,1.23]);
  // Small physical details that do not pretend to be additional audio controls.
  for(let i=0;i<5;i++)mesh('vent-slot',box(.40,.004,.025),black,group,[.70,.508,-1.50+i*.095]);
  const nameplate=mesh('nameplate',box(.72,.012,.25),black,group,[-2.10,.51,-1.44],true);
  const seam=mesh('top-seam',box(5.1,.003,.008),darkMetal,group,[0,.508,1.04]);
  void nameplate;void seam;void led;
  let disposed=false;
  return {group,disc,arm,platter,playButton,actionTargets,ledMaterial,stylusMaterial,stylusLight,
    dispose(){if(disposed)return;disposed=true;for(const g of geometries)g.dispose();for(const m of materials)m.dispose();strobe.dispose();group.clear();},
    resourceCounts:{geometry:geometries.size,material:materials.size},
  };
}
