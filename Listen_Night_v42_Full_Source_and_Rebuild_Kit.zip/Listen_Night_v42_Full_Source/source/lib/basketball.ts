// Coordinates are CSS pixels local to the court, independent of pixel density.
export type Point={x:number;y:number};
export type ShotGeometry={origin:Point;rim:{left:number;right:number;y:number};width:number;height:number;maxPull:number};
export type ShotPlan={start:Point;velocity:Point;gravity:number;duration:number;geometry:ShotGeometry;power:number;spin:number};
export const clamp=(value:number,min:number,max:number)=>Math.max(min,Math.min(max,value));
export function pullPower(pull:Point,geometry:ShotGeometry){return clamp(Math.hypot(pull.x,pull.y)/geometry.maxPull,0,1);}
export function createShot(geometry:ShotGeometry,pull:Point,assisted=false):ShotPlan{
 const power=assisted ? .68 : pullPower(pull,geometry),rimX=(geometry.rim.left+geometry.rim.right)/2;
 const start={x:geometry.origin.x+pull.x,y:geometry.origin.y+pull.y};
 const gravity=Math.max(600,geometry.height*1.5),rise=Math.max(0,start.y-geometry.rim.y);
 const calibratedTime=Math.max(geometry.width<360?1.4:1.03,Math.sqrt(2*rise/gravity)+.5);
 const base={x:(rimX-start.x)/calibratedTime,y:(geometry.rim.y-start.y-.5*gravity*calibratedTime*calibratedTime)/calibratedTime};
 // Strength and angle change actual launch velocity. Upward/sideways pulls
 // also produce a preview and a flight; they are not silently discarded.
 const velocity=assisted?base:{x:base.x*(power/.68)-pull.x*2.4,y:base.y*clamp(pull.y/(geometry.maxPull*.68),-1.5,1.5)};
 const discriminant=velocity.y*velocity.y-2*gravity*(start.y-geometry.rim.y);
 const rimTime=discriminant>=0?(-velocity.y+Math.sqrt(discriminant))/gravity:-1;
 const floorTime=(-velocity.y+Math.sqrt(Math.max(0,velocity.y*velocity.y+2*gravity*(geometry.height-start.y))))/gravity;
 const duration=rimTime>0?rimTime:Math.max(.1,floorTime);
 return {start,gravity,duration,geometry,power,velocity,spin:(420+power*420+Math.abs(pull.x)*3)*(pull.x>0?-1:1)};
}
export function shotPoint(plan:ShotPlan,time:number):Point{return {x:plan.start.x+plan.velocity.x*time,y:plan.start.y+plan.velocity.y*time+.5*plan.gravity*time*time};}
export function crossesBasket(plan:ShotPlan,previous:Point,current:Point,time:number){
 const rim=plan.geometry.rim;if(plan.velocity.y+plan.gravity*time<=0||previous.y>rim.y||current.y<rim.y||current.y===previous.y)return false;
 const fraction=(rim.y-previous.y)/(current.y-previous.y),x=previous.x+(current.x-previous.x)*fraction;
 const padding=Math.min(14,(rim.right-rim.left)*.15);
 return x>=rim.left+padding&&x<=rim.right-padding;
}
export type Flight={plan:ShotPlan;position:Point;velocity:Point;time:number;angle:number;spin:number;radius:number;scale:number;rimHits:number;floorHits:number;lastRim:'left'|'right'|null;cooldown:[number,number];throughRim:boolean;entered:boolean;entry:Point|null;scored:boolean;done:boolean;accumulator:number};
const STEP=1/240,RIM_RADIUS=3.5;
export function createFlight(plan:ShotPlan):Flight{return {plan,position:{...plan.start},velocity:{...plan.velocity},time:0,angle:-10,spin:plan.spin,radius:32,scale:1,rimHits:0,floorHits:0,lastRim:null,cooldown:[-1,-1],throughRim:false,entered:false,entry:null,scored:false,done:false,accumulator:0};}

// A circular collision proxy follows the spinning card's projected size. Fixed
// substeps keep fast shots from tunnelling through the small metal rim ends.
export function advanceFlight(body:Flight,delta:number){
 const beforeHits=body.rimHits,beforeFloor=body.floorHits,wasEntered=body.entered;
 body.accumulator+=Math.max(0,Math.min(delta,.1));
 while(body.accumulator+1e-10>=STEP&&!body.done){
  body.accumulator-=STEP;body.time+=STEP;
  const {geometry,gravity}=body.plan,rim=geometry.rim,centre=(rim.left+rim.right)/2;
  const previous={...body.position},progress=clamp(body.time/Math.max(.8,body.plan.duration),0,1);
  body.scale=1-progress*.64;body.radius=14+18*(1-progress);
  body.position.x+=body.velocity.x*STEP;body.position.y+=body.velocity.y*STEP+.5*gravity*STEP*STEP;body.velocity.y+=gravity*STEP;
  body.angle+=body.spin*STEP;body.spin*=Math.exp(-STEP*.12);
  // Resolve real normal/tangent impulses. No random in/out choice is used.
  for(const [index,x] of [rim.left,rim.right].entries()){
   const dx=body.position.x-x,dy=body.position.y-rim.y,distance=Math.hypot(dx,dy),reach=body.radius+RIM_RADIUS;
   if(distance>=reach||distance<.0001)continue;
   const nx=dx/distance,ny=dy/distance,normal=body.velocity.x*nx+body.velocity.y*ny;
   body.position.x=x+nx*(reach+.05);body.position.y=rim.y+ny*(reach+.05);
   if(normal>=0||body.time-body.cooldown[index]<.045)continue;
   const tangent=-body.velocity.x*ny+body.velocity.y*nx,restitution=.61;
   body.velocity.x-=(1+restitution)*normal*nx;body.velocity.y-=(1+restitution)*normal*ny;
   body.velocity.x+=tangent*ny*.13;body.velocity.y-=tangent*nx*.13;
   body.spin=clamp(body.spin+tangent/body.radius*38,-1440,1440);body.cooldown[index]=body.time;body.rimHits++;body.lastRim=index===0?'left':'right';
   body.throughRim=false;body.entered=false;body.entry=null;
  }
  // Merely touching or crossing the rim is not a score. The whole proxy must
  // pass below it, then travel through the net before the import may begin.
  const gapLeft=rim.left+body.radius,gapRight=rim.right-body.radius;
  if(!body.entered&&previous.y<=rim.y&&body.position.y>=rim.y&&body.velocity.y>0){const f=(rim.y-previous.y)/(body.position.y-previous.y),x=previous.x+(body.position.x-previous.x)*f;if(x>gapLeft&&x<gapRight){body.throughRim=true;body.entry={x,y:rim.y};}}
  if(!body.entered&&(body.position.y<rim.y-1||body.position.x<gapLeft||body.position.x>gapRight))body.throughRim=false;
  if(!body.entered&&body.throughRim&&body.velocity.y>0&&body.position.y>=rim.y+body.radius+4&&body.position.x>gapLeft&&body.position.x<gapRight)body.entered=true;
  if(body.entered){
   const depth=body.position.y-rim.y,netDepth=72;
   if(depth<0){body.entered=false;body.entry=null;}
   else{
    const half=Math.max(8,(rim.right-rim.left)/2-14-clamp(depth/netDepth,0,1)*17);
    if(Math.abs(body.position.x-centre)>half){body.position.x=centre+Math.sign(body.position.x-centre)*half;body.velocity.x*=-.18;body.spin*=.88;}
    body.velocity.x*=Math.exp(-STEP*4);body.velocity.y*=Math.exp(-STEP*.45);
    if(depth>=netDepth){body.scored=true;body.done=true;}
   }
  }
  const floor=geometry.height-body.radius-6;
  if(body.position.y>floor&&body.velocity.y>0){body.position.y=floor;body.velocity.y*=-.36;body.velocity.x*=.7;body.spin*=.58;body.floorHits++;if(body.floorHits>=2||Math.abs(body.velocity.y)<45)body.done=true;}
  if(body.time>=6||body.rimHits>=16||body.position.x< -100||body.position.x>geometry.width+100)body.done=true;
 }
 return {rimHit:body.rimHits>beforeHits,floorHit:body.floorHits>beforeFloor,entered:body.entered&&!wasEntered,scored:body.scored,done:body.done};
}

export type Prediction={points:Point[];target:Point;scored:boolean;rimHits:number;floorHits:number};
const predictions=new WeakMap<ShotPlan,Prediction>();
export function predictFlight(plan:ShotPlan):Prediction{
 const cached=predictions.get(plan);if(cached)return cached;
 const body=createFlight(plan),points=[{...body.position}];let count=0;
 while(!body.done&&count++<1500){const event=advanceFlight(body,1/120);if(count%6===0||event.rimHit||event.done)points.push({...body.position});}
 const prediction={points,target:body.scored&&body.entry?body.entry:{...body.position},scored:body.scored,rimHits:body.rimHits,floorHits:body.floorHits};predictions.set(plan,prediction);return prediction;
}
export function shotWillScore(plan:ShotPlan){return predictFlight(plan).scored;}
export function shotPath(plan:ShotPlan){return predictFlight(plan).points.map((p,i)=>`${i?'L':'M'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');}
