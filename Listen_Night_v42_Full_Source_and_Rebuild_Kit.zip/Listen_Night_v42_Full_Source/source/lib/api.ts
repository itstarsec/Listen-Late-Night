import { ApiError, ALL_SONGS_SLUG, SEED_IDS, MAX_TRACKS, slugValue, nameValue, parseBatch, fallbackTrack, type Track, type PlaylistSource } from './domain';
import seedMetadata from './seed-metadata.json';
import curatedPlaylists from './curated-playlists.json';
import curatedMetadata from './curated-metadata.json';
import importedPlaylists from './imported-playlists.json';
import {currentUser,signIn,signOut,digest,type Identity,type AuthRuntime} from './auth';
import {parseUrlFile,type ImportReport} from './file-import';
import {blockedVideoIds,maintenanceStatus,runMaintenance,type MaintenanceRuntime} from './video-maintenance';
type DB = D1Database;
export type Runtime = AuthRuntime & MaintenanceRuntime & {APP_ALLOWED_ORIGINS?:string};
type Row={slug:string;name:string;owner_id:string;tracks:string;version:number;last_request:string|null;created_at:number;updated_at:number};
const json=(value:unknown,status=200,headers:Record<string,string>={})=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
function isAppOrigin(req:Request,env:Runtime){
 const origin=req.headers.get('origin');if(!origin)return false;
 if(origin===new URL(req.url).origin)return true;
 // Public reverse proxies retain the browser's Origin. Trust only configured
 // HTTPS origins, never client-supplied Host/Forwarded headers or wildcards.
 return (env.APP_ALLOWED_ORIGINS||'').split(',').some(value=>{
  const allowed=value.trim();if(origin!==allowed)return false;
  try{const u=new URL(allowed);return u.protocol==='https:'&&u.origin===allowed;}catch{return false;}
 });
}
function canEdit(user:Identity|null,row:Row){return !!user&&(row.owner_id===user.id||row.owner_id==='__seed__');}
type SeedMetadata={videoId:string;title:string;channel:string|null;thumbnail:string;fetchedAt:number};
async function insertSeedMetadata(db:DB,records:SeedMetadata[]){
 for(let i=0;i<records.length;i+=250){
  const chunk=records.slice(i,i+250);
  // A fresh audited import can fill an unavailable cache entry without replacing
  // successful metadata or letting an older snapshot overwrite a newer cache.
  await db.prepare("INSERT INTO metadata (video_id,title,channel,thumbnail,status,expires_at) SELECT json_extract(value,'$.videoId'),json_extract(value,'$.title'),json_extract(value,'$.channel'),json_extract(value,'$.thumbnail'),'ready',json_extract(value,'$.fetchedAt')+86400000 FROM json_each(?) WHERE 1 ON CONFLICT(video_id) DO UPDATE SET title=excluded.title,channel=excluded.channel,thumbnail=excluded.thumbnail,status=excluded.status,expires_at=excluded.expires_at WHERE (metadata.status!='ready' OR metadata.channel IS NULL) AND excluded.channel IS NOT NULL AND excluded.expires_at-86400000>=metadata.expires_at-CASE WHEN metadata.status='ready' THEN 86400000 ELSE 900000 END").bind(JSON.stringify(chunk)).run();
 }
}
async function seed(db:DB){
 if(await db.prepare("SELECT key FROM seeds WHERE key='shelby-v1'").first())return;
 const now=Date.now(),tracks=JSON.stringify(SEED_IDS.map(id=>({videoId:id,addedAt:now})));
 await insertSeedMetadata(db,seedMetadata);
 await db.batch([
 db.prepare("INSERT OR IGNORE INTO sessions (slug,name,owner_id,tracks,version,created_at,updated_at) SELECT 'shelby','Shelby — Late Night','__seed__',?,1,?,? WHERE NOT EXISTS (SELECT 1 FROM seeds WHERE key='shelby-v1')").bind(tracks,now,now),
 db.prepare("INSERT OR IGNORE INTO seeds (key) VALUES ('shelby-v1')")]);
}
async function seedCurated(db:DB){
 const marker='curated-2026-10-v1';
 if(await db.prepare('SELECT key FROM seeds WHERE key=?').bind(marker).first())return;
 await insertSeedMetadata(db,curatedMetadata);
 for(const collection of curatedPlaylists){
  const key=`curated:${collection.slug}:v1`,now=Date.now();
  const tracks=JSON.stringify(collection.videoIds.map(videoId=>({videoId,addedAt:now})));
  await db.batch([
   db.prepare('INSERT OR IGNORE INTO sessions (slug,name,owner_id,tracks,version,created_at,updated_at) SELECT ?,?,\'__seed__\',?,1,?,? WHERE NOT EXISTS (SELECT 1 FROM seeds WHERE key=?)').bind(collection.slug,collection.name,tracks,now,now,key),
   db.prepare('INSERT OR IGNORE INTO seeds (key) VALUES (?)').bind(key),
  ]);
 }
 await db.prepare('INSERT OR IGNORE INTO seeds (key) VALUES (?)').bind(marker).run();
}
type ImportedTrack=Omit<SeedMetadata,'fetchedAt'>&{fetchedAt?:number;durationSeconds?:number};
type ImportedCollection={slug:string;name:string;sourcePlaylistId:string|null;seedKey?:string;fetchedAt:number;tracks:ImportedTrack[];additionalTracks?:ImportedTrack[];additionalRevision?:string;replacement?:{revision:string;previousName:string;videoIds:string[];replaceAll?:boolean}};
const importedTracks=(collection:ImportedCollection)=>[...collection.tracks,...(collection.additionalTracks||[])];
const importKey=(collection:ImportedCollection)=>collection.seedKey??`imported:${collection.sourcePlaylistId}:v1`;
const additionKey=(collection:ImportedCollection)=>`imported-additions:${collection.sourcePlaylistId}:${collection.additionalRevision}`;
const replacementKey=(collection:ImportedCollection)=>`imported-replacement:${collection.slug}:${collection.replacement!.revision}`;
async function applyImportedReplacement(db:DB,collection:ImportedCollection){
 const marker=replacementKey(collection),tag=`seed:${marker}`,obsolete=new Set(collection.replacement!.videoIds);
 for(let attempt=0;attempt<3;attempt++){
  const row=await db.prepare('SELECT * FROM sessions WHERE slug=?').bind(collection.slug).first<Row>();
  if(!row||row.owner_id!=='__seed__'){await db.prepare('INSERT OR IGNORE INTO seeds (key) VALUES (?)').bind(marker).run();return;}
  const old=JSON.parse(row.tracks) as {videoId:string;addedAt:number}[],now=Date.now(),seen=new Set<string>();
  const next=importedTracks(collection).filter(t=>{if(seen.has(t.videoId))return false;seen.add(t.videoId);return true;}).map(({videoId})=>old.find(t=>t.videoId===videoId)??{videoId,addedAt:now});
  // A user-requested full replacement keeps exactly the configured videos.
  // Other curation updates retain admin additions outside the retired snapshot.
  if(!collection.replacement!.replaceAll)next.push(...old.filter(t=>!obsolete.has(t.videoId)&&!seen.has(t.videoId)));
  if(next.length>MAX_TRACKS)return;
  const name=row.name===collection.replacement!.previousName?collection.name:row.name;
  const result=await db.batch([
   db.prepare("UPDATE sessions SET tracks=?,name=?,version=version+1,last_request=?,updated_at=? WHERE slug=? AND owner_id='__seed__' AND version=? AND NOT EXISTS (SELECT 1 FROM seeds WHERE key=?)").bind(JSON.stringify(next),name,tag,now,row.slug,row.version,marker),
   db.prepare("INSERT OR IGNORE INTO seeds (key) SELECT ? WHERE EXISTS (SELECT 1 FROM sessions WHERE slug=? AND owner_id='__seed__' AND version=? AND last_request=?)").bind(marker,row.slug,row.version+1,tag),
  ]);
  if(result[0].meta.changes||await db.prepare('SELECT key FROM seeds WHERE key=?').bind(marker).first())return;
 }
 throw new ApiError(409,'Playlist đang được chỉnh sửa trên thiết bị khác. Hãy tải lại để cập nhật tuyển chọn.');
}
async function applyImportedAdditions(db:DB,collection:ImportedCollection){
 const marker=additionKey(collection),tag=`seed:${marker}`;
 for(let attempt=0;attempt<3;attempt++){
  const row=await db.prepare('SELECT * FROM sessions WHERE slug=?').bind(collection.slug).first<Row>();
  // A one-time addition never reclaims another owner's playlist or restores a deleted one.
  if(!row||row.owner_id!=='__seed__'){await db.prepare('INSERT OR IGNORE INTO seeds (key) VALUES (?)').bind(marker).run();return;}
  const old=JSON.parse(row.tracks) as {videoId:string;addedAt:number}[],seen=new Set(old.map(t=>t.videoId));
  const now=Date.now(),extra=(collection.additionalTracks||[]).filter(t=>{if(seen.has(t.videoId))return false;seen.add(t.videoId);return true;}).map(({videoId})=>({videoId,addedAt:now}));
  if(!extra.length){await db.prepare('INSERT OR IGNORE INTO seeds (key) VALUES (?)').bind(marker).run();return;}
  // Keep a full playlist readable/editable; retry the addition once space is available.
  if(old.length+extra.length>MAX_TRACKS)return;
  const result=await db.batch([
   db.prepare("UPDATE sessions SET tracks=?,version=version+1,last_request=?,updated_at=? WHERE slug=? AND owner_id='__seed__' AND version=? AND NOT EXISTS (SELECT 1 FROM seeds WHERE key=?)").bind(JSON.stringify([...old,...extra]),tag,now,row.slug,row.version,marker),
   db.prepare("INSERT OR IGNORE INTO seeds (key) SELECT ? WHERE EXISTS (SELECT 1 FROM sessions WHERE slug=? AND owner_id='__seed__' AND version=? AND last_request=?)").bind(marker,row.slug,row.version+1,tag),
  ]);
  if(result[0].meta.changes||await db.prepare('SELECT key FROM seeds WHERE key=?').bind(marker).first())return;
 }
 throw new ApiError(409,'Playlist đang được chỉnh sửa trên thiết bị khác. Hãy tải lại để bổ sung bản dài.');
}
async function seedImported(db:DB,slug?:string){
 const collections:ImportedCollection[]=slug?importedPlaylists.filter(p=>p.slug===slug):importedPlaylists;
 if(!collections.length)return;
 const additions=collections.filter(p=>p.additionalTracks?.length&&p.additionalRevision);
 const replacements=collections.filter(p=>p.replacement?.revision);
 const keys=[...collections.map(importKey),...additions.map(additionKey),...replacements.map(replacementKey)];
 const existing=await db.prepare(`SELECT key FROM seeds WHERE key IN (${keys.map(()=>'?').join(',')})`).bind(...keys).all<{key:string}>();
 const done=new Set(existing.results.map(row=>row.key));
 const pending=collections.filter(p=>!done.has(importKey(p)));
 const pendingAdditions=additions.filter(p=>!done.has(additionKey(p)));
 const pendingReplacements=replacements.filter(p=>!done.has(replacementKey(p))&&!pending.includes(p));
 if(!pending.length&&!pendingAdditions.length&&!pendingReplacements.length)return;
 const metadata=new Map<string,SeedMetadata>();
 for(const collection of pending)for(const track of importedTracks(collection))if(!metadata.has(track.videoId))metadata.set(track.videoId,{...track,fetchedAt:track.fetchedAt??collection.fetchedAt});
 for(const collection of pendingAdditions)for(const track of collection.additionalTracks||[])if(!metadata.has(track.videoId))metadata.set(track.videoId,{...track,fetchedAt:track.fetchedAt??collection.fetchedAt});
 for(const collection of pendingReplacements)for(const track of importedTracks(collection))if(!metadata.has(track.videoId))metadata.set(track.videoId,{...track,fetchedAt:track.fetchedAt??collection.fetchedAt});
 await insertSeedMetadata(db,[...metadata.values()]);
 const now=Date.now(),batch=JSON.stringify(pending.map(collection=>({slug:collection.slug,name:collection.name,key:importKey(collection),revisionKey:collection.replacement?replacementKey(collection):null,now,tracks:importedTracks(collection).map(({videoId})=>({videoId,addedAt:now}))})));
 if(pending.length)await db.batch([
  db.prepare("INSERT OR IGNORE INTO sessions (slug,name,owner_id,tracks,version,created_at,updated_at) SELECT json_extract(item.value,'$.slug'),json_extract(item.value,'$.name'),'__seed__',json_extract(item.value,'$.tracks'),1,json_extract(item.value,'$.now'),json_extract(item.value,'$.now') FROM json_each(?) AS item WHERE NOT EXISTS (SELECT 1 FROM seeds WHERE key=json_extract(item.value,'$.key'))").bind(batch),
  db.prepare("INSERT OR IGNORE INTO seeds (key) SELECT json_extract(value,'$.key') FROM json_each(?) UNION ALL SELECT json_extract(value,'$.revisionKey') FROM json_each(?) WHERE json_extract(value,'$.revisionKey') IS NOT NULL").bind(batch,batch),
 ]);
 for(const collection of pendingReplacements)await applyImportedReplacement(db,collection);
 for(const collection of pendingAdditions)await applyImportedAdditions(db,collection);
}
async function collectionRecords(env:Runtime){
 await seed(env.DB);await seedCurated(env.DB);await seedImported(env.DB);
 const definitions=[{slug:'shelby',name:'Shelby — Late Night',description:'Thành phố đã ngủ. Để những giai điệu ở lại.',mood:'BẢN GỐC',accent:'#7dd3fc',videoIds:SEED_IDS},...curatedPlaylists,...importedPlaylists];
 const rows=await env.DB.prepare(`SELECT * FROM sessions WHERE owner_id='__seed__' AND slug IN (${definitions.map(()=>'?').join(',')})`).bind(...definitions.map(x=>x.slug)).all<Row>();
 const bySlug=new Map(rows.results.map(row=>[row.slug,row]));
 return {definitions,bySlug,rows:rows.results};
}
async function listCollections(user:Identity|null,env:Runtime){
 const {definitions,bySlug}=await collectionRecords(env);
 const imports=new Map(importedPlaylists.map(p=>[p.slug,p]));
 return definitions.flatMap(def=>{
  const row=bySlug.get(def.slug);if(!row)return [];
  const tracks=JSON.parse(row.tracks) as {videoId:string}[],origin=imports.get(row.slug);
  const longform=origin?importedTracks(origin).filter(t=>(t.durationSeconds??0)>=3600).map(t=>t.videoId):[];
  return [{slug:row.slug,name:row.name,description:def.description,mood:def.mood,accent:def.accent,count:tracks.length,cover:tracks[0]?`https://i.ytimg.com/vi/${tracks[0].videoId}/hqdefault.jpg`:null,canEdit:canEdit(user,row),category:origin?.category,longformVideoIds:longform.length?longform:undefined,source:origin?{url:origin.sourceUrl,title:origin.sourceTitle,curator:origin.curator,kind:origin.sourceKind,fetchedAt:origin.fetchedAt,trackCount:origin.sourceTrackCount,unavailableCount:origin.unavailableCount,duplicateCount:origin.duplicateCount}:undefined}];
 });
}
async function load(db:DB,slug:string){const row=await db.prepare('SELECT * FROM sessions WHERE slug=?').bind(slug).first<Row>();if(!row)throw new ApiError(404,'Không tìm thấy session. Kiểm tra lại slug hoặc tạo một session mới.');return row;}
type RawTrack={videoId:string;addedAt:number;sourcePlaylists?:PlaylistSource[]};
// JSON keeps this to one bound parameter per bounded metadata batch.
async function enrichTracks(env:Runtime,raw:RawTrack[],chunkSize=500):Promise<Track[]>{
 const records:Record<string,unknown>[]=[];
 for(let i=0;i<raw.length;i+=chunkSize){const chunk=raw.slice(i,i+chunkSize);const result=await env.DB.prepare('SELECT * FROM metadata WHERE video_id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(chunk.map(x=>x.videoId))).all();records.push(...result.results as Record<string,unknown>[]);}
 const meta=new Map(records.map(x=>[x.video_id,x]));
 return raw.map(x=>{const m=meta.get(x.videoId),t={...fallbackTrack(x.videoId,x.addedAt),...(x.sourcePlaylists?{sourcePlaylists:x.sourcePlaylists}:{})};return m?{...t,title:String(m.title),channel:m.channel?String(m.channel):null,thumbnail:String(m.thumbnail),metadataStatus:Number(m.expires_at)>Date.now()?String(m.status):'pending'}:t;});
}
async function snapshot(user:Identity|null,row:Row,env:Runtime){
 return {slug:row.slug,name:row.name,tracks:await enrichTracks(env,JSON.parse(row.tracks)),version:row.version,canEdit:canEdit(user,row),updatedAt:row.updated_at};
}
async function library(env:Runtime){
 const {definitions,bySlug,rows}=await collectionRecords(env);
 const seen=new Map<string,RawTrack>();let totalEntries=0;
 for(const definition of definitions){
  const row=bySlug.get(definition.slug);if(!row)continue;
  const raw=JSON.parse(row.tracks) as RawTrack[];totalEntries+=raw.length;
  for(const track of raw){
   const source={slug:row.slug,name:row.name},existing=seen.get(track.videoId);
   if(existing){if(!existing.sourcePlaylists!.some(p=>p.slug===source.slug))existing.sourcePlaylists!.push(source);}
   else seen.set(track.videoId,{videoId:track.videoId,addedAt:track.addedAt,sourcePlaylists:[source]});
  }
 }
 const updatedAt=Math.max(0,...rows.map(row=>row.updated_at));
 return {slug:ALL_SONGS_SLUG,name:'Tất cả bài hát',kind:'all' as const,tracks:await enrichTracks(env,[...seen.values()]),version:updatedAt,canEdit:false,updatedAt,sourceCount:rows.length,totalEntries};
}
async function metadataResponse(req:Request,env:Runtime,allowed:Set<string>){
 const input=(new URL(req.url).searchParams.get('ids')||'').split(',').filter(Boolean);
 if(input.length>10||input.some(x=>!allowed.has(x)||!/^[A-Za-z0-9_-]{11}$/.test(x)))throw new ApiError(400,'Chỉ lấy tối đa 10 video đang có trong danh sách phát.');
 await rate(env.DB,'metadata',req.headers.get('cf-connecting-ip')||'shared',240);
 const ids=[...new Set(input)],output:Track[]=new Array(ids.length);let cursor=0;
 await Promise.all(Array.from({length:Math.min(3,ids.length)},async()=>{while(cursor<ids.length){const i=cursor++;output[i]=await metadata(env,ids[i]);}}));
 return json({tracks:output});
}
async function adminData(user:Identity,env:Runtime,includeTracks:boolean){
 const {definitions}=await collectionRecords(env);
 const result=await env.DB.prepare('SELECT * FROM sessions WHERE owner_id=? OR owner_id=? ORDER BY created_at,slug').bind(user.id,'__seed__').all<Row>();
 const listed=new Set(definitions.map(d=>d.slug)),imports=new Map(importedPlaylists.map(p=>[p.slug,p]));
 const videos=new Map<string,RawTrack>();let entries=0;
 const playlists=result.results.map(row=>{
  const tracks=JSON.parse(row.tracks) as RawTrack[];entries+=tracks.length;
  for(const track of tracks){const source={slug:row.slug,name:row.name},existing=videos.get(track.videoId);if(existing)existing.sourcePlaylists!.push(source);else videos.set(track.videoId,{...track,sourcePlaylists:[source]});}
  const imported=imports.get(row.slug);
  return {slug:row.slug,name:row.name,count:tracks.length,cover:tracks[0]?`https://i.ytimg.com/vi/${tracks[0].videoId}/hqdefault.jpg`:null,version:row.version,updatedAt:row.updated_at,listed:listed.has(row.slug),category:row.owner_id!=='__seed__'?'personal':imported?.category==='viet'?'viet':imported?.category==='tryhard'?'tryhard':imported?.category==='gaming'?'gaming':imported?.category==='ride'?'ride':imported?.category==='active'?'active':imported?.category==='dopamine'?'dopamine':imported?.category==='ai'?'ai':'curated',sourceUrl:imported?.sourceUrl??null};
 });
 return includeTracks?{tracks:await enrichTracks(env,[...videos.values()],1000)}:{playlists,stats:{playlists:playlists.length,entries,uniqueTracks:videos.size},user:{name:user.name}};
}
async function rate(db:DB,scope:string,key:string,max:number){
 const window=Math.floor(Date.now()/3600000),name=`${scope}:${key}:${window}`;
 const r=await db.prepare('INSERT INTO limits (key,count,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count').bind(name,(window+2)*3600000).first<{count:number}>();
 if((r?.count??0)>max)throw new ApiError(429,'Bạn thao tác hơi nhanh. Vui lòng thử lại sau.');
 if(Math.random()<0.01)await db.prepare('DELETE FROM limits WHERE expires_at<?').bind(Date.now()).run();
}
async function metadata(env:Runtime,id:string):Promise<Track>{
 const cached=await env.DB.prepare('SELECT * FROM metadata WHERE video_id=? AND expires_at>?').bind(id,Date.now()).first<Record<string,unknown>>();
 const base=fallbackTrack(id);
 if(cached)return {...base,title:String(cached.title),channel:cached.channel?String(cached.channel):null,thumbnail:String(cached.thumbnail),metadataStatus:String(cached.status)};
 let result={...base,metadataStatus:'unavailable'};
 try{
  const url=new URL('https://www.youtube.com/oembed');url.searchParams.set('url',base.url);url.searchParams.set('format','json');
  const res=await fetch(url,{signal:AbortSignal.timeout(4500),redirect:'manual',headers:{Accept:'application/json'}});
  if(res.ok){const d=await res.json() as Record<string,unknown>;
   if(typeof d.title==='string'&&d.title.trim())result={...base,title:d.title.slice(0,500),channel:typeof d.author_name==='string'?d.author_name.slice(0,200):null,metadataStatus:'ready'};
  }
 }catch{ /* Explicit fallback; no invented metadata. */ }
 await env.DB.prepare('INSERT INTO metadata (video_id,title,channel,thumbnail,status,expires_at) VALUES (?,?,?,?,?,?) ON CONFLICT(video_id) DO UPDATE SET title=excluded.title,channel=excluded.channel,thumbnail=excluded.thumbnail,status=excluded.status,expires_at=excluded.expires_at').bind(id,result.title,result.channel,result.thumbnail,result.metadataStatus,Date.now()+(result.metadataStatus==='ready'?86400000:900000)).run();
 return result;
}
async function importFile(req:Request,user:Identity,env:Runtime){
 const requestId=req.headers.get('x-request-id');if(!requestId||!/^[a-zA-Z0-9-]{8,80}$/.test(requestId))throw new ApiError(400,'Thiếu mã thao tác hợp lệ.');
 const d=await body(req,1600000),target=d.target;
 if(!target||typeof target!=='object'||Array.isArray(target)||!['new','existing'].includes(target.kind))throw new ApiError(400,'Chọn playlist đích hợp lệ.');
 const slug=slugValue(target.slug),name=target.kind==='new'?nameValue(target.name):null;
 if(target.kind==='existing'&&(!Number.isSafeInteger(target.version)||target.version<1))throw new ApiError(400,'Tải lại playlist đích trước khi nhập file.');
 // Validate raw file again on the server; client reports and URLs are never trusted.
 const initial=parseUrlFile(d.fileName,d.text);
 const fingerprint=await digest(JSON.stringify({target,fileName:d.fileName,text:d.text}));
 type Receipt={slug:string;fingerprint:string;report:string};
 const receipt=()=>env.DB.prepare('SELECT slug,fingerprint,report FROM playlist_imports WHERE owner_id=? AND request_id=?').bind(user.id,requestId).first<Receipt>();
 const replay=async(saved:Receipt)=>{if(saved.fingerprint!==fingerprint)throw new ApiError(409,'Mã nhập file đã được dùng cho nội dung khác. Hãy chọn lại file.');const row=await load(env.DB,saved.slug);if(!canEdit(user,row))throw new ApiError(403,'Bạn không có quyền chỉnh sửa playlist này.');return json({session:await snapshot(user,row,env),report:JSON.parse(saved.report) as ImportReport,replayed:true});};
 const previous=await receipt();if(previous)return replay(previous);
 await rate(env.DB,'file-import',user.id,120);
 let row:Row|null=null;
 if(target.kind==='existing'){row=await load(env.DB,slug);if(!canEdit(user,row))throw new ApiError(403,'Bạn không có quyền chỉnh sửa playlist này.');if(row.version!==target.version)throw new ApiError(409,'Playlist vừa thay đổi. Hãy tải lại playlist đích rồi ném lại file.');}
 else{
  // Reserve all known seeds even if their public catalogue has not loaded yet.
  if(slug==='shelby')await seed(env.DB);if(curatedPlaylists.some(p=>p.slug===slug))await seedCurated(env.DB);if(importedPlaylists.some(p=>p.slug===slug))await seedImported(env.DB,slug);
  if(await env.DB.prepare('SELECT slug FROM sessions WHERE slug=?').bind(slug).first())throw new ApiError(409,'Đường dẫn playlist đã tồn tại. Hãy chọn đường dẫn khác hoặc thêm vào playlist có sẵn.');
  const count=await env.DB.prepare('SELECT COUNT(*) AS count FROM sessions WHERE owner_id=?').bind(user.id).first<{count:number}>();if((count?.count||0)>=100)throw new ApiError(400,'Mỗi tài khoản có tối đa 100 playlist.');
 }
 const old=row?JSON.parse(row.tracks) as RawTrack[]:[],parsed=row?parseUrlFile(d.fileName,d.text,old.map(t=>t.videoId)):initial;
 const blocked=new Set(await blockedVideoIds(env.DB,parsed.ids));if(blocked.size){parsed.ids=parsed.ids.filter(id=>!blocked.has(id));parsed.report.added=parsed.ids.length;(parsed.report as ImportReport).blocked=blocked.size;}
 if(!parsed.ids.length&&blocked.size)throw new ApiError(400,`${blocked.size} video đã bị gỡ do không phát được trên website và không được thêm lại.`);
 if(!parsed.ids.length&&!parsed.report.duplicates)throw new ApiError(400,'File không có URL YouTube hoặc video ID hợp lệ. Chưa lưu thay đổi nào.');
 const now=Date.now(),tracks=JSON.stringify([...old,...parsed.ids.map(videoId=>({videoId,addedAt:now}))]);
 const mutation=row?env.DB.prepare('UPDATE sessions SET tracks=?,version=version+1,last_request=?,updated_at=? WHERE slug=? AND version=? AND NOT EXISTS (SELECT 1 FROM playlist_imports WHERE owner_id=? AND request_id=?)').bind(tracks,requestId,now,slug,target.version,user.id,requestId):env.DB.prepare('INSERT OR IGNORE INTO sessions (slug,name,owner_id,tracks,version,last_request,created_at,updated_at) SELECT ?,?,?,?,1,?,?,? WHERE NOT EXISTS (SELECT 1 FROM playlist_imports WHERE owner_id=? AND request_id=?)').bind(slug,name,user.id,tracks,requestId,now,now,user.id,requestId);
 const results=await env.DB.batch([mutation,env.DB.prepare('INSERT OR IGNORE INTO playlist_imports (owner_id,request_id,slug,fingerprint,report,created_at) SELECT ?,?,?,?,?,? WHERE EXISTS (SELECT 1 FROM sessions WHERE slug=? AND last_request=? AND (owner_id=? OR owner_id=\'__seed__\'))').bind(user.id,requestId,slug,fingerprint,JSON.stringify(parsed.report),now,slug,requestId,user.id)]);
 const saved=await receipt();if(!saved)throw new ApiError(409,'Playlist vừa thay đổi hoặc đường dẫn đã được dùng. Hãy tải lại đích rồi thử lại.');
 if(!results[0].meta.changes)return replay(saved);
 return json({session:await snapshot(user,await load(env.DB,slug),env),report:parsed.report},row?200:201);
}
async function body(req:Request,maxLength=70000){if(!req.headers.get('content-type')?.includes('application/json'))throw new ApiError(415,'Yêu cầu phải dùng JSON.');const txt=await req.text();if(txt.length>maxLength)throw new ApiError(413,'Yêu cầu quá lớn.');try{const value=JSON.parse(txt);if(!value||typeof value!=='object'||Array.isArray(value))throw new Error();return value;}catch{throw new ApiError(400,'JSON không hợp lệ.');}}
export async function handleApi(req:Request,env:Runtime):Promise<Response>{
 try{
  if(!env.DB)throw new ApiError(503,'Chưa cấu hình cơ sở dữ liệu. Vui lòng thử lại sau.');
  const u=new URL(req.url),path=u.pathname.replace(/\/$/,'').split('/').filter(Boolean),method=req.method;
  if(!['GET','POST','PATCH','DELETE'].includes(method))throw new ApiError(405,'Phương thức không được hỗ trợ.');
  if(method!=='GET'){
   const origin=req.headers.get('origin');if((origin&&!isAppOrigin(req,env))||req.headers.get('sec-fetch-site')==='cross-site')throw new ApiError(403,'Yêu cầu phải đến từ ứng dụng này.');
  }
  if(path[1]==='auth'){
   if(path.length!==3||!['login','logout'].includes(path[2]))throw new ApiError(404,'API không tồn tại.');
   if(method!=='POST')throw new ApiError(405,'Đăng nhập và đăng xuất phải dùng POST.');
   if(!isAppOrigin(req,env))throw new ApiError(403,'Yêu cầu phải đến từ ứng dụng này.');
   if(path[2]==='login'){
    const result=await signIn(req,env,await body(req));
    return json({signedIn:true,name:result.user.name,sessions:[]},200,{'Set-Cookie':result.cookie});
   }
   return json({signedIn:false,name:null,sessions:[]},200,{'Set-Cookie':await signOut(req,env)});
  }
  const user=await currentUser(req,env);
  if(path.length===2&&path[1]==='video-reports'&&method==='POST'){
   if(!isAppOrigin(req,env))throw new ApiError(403,'Yêu cầu phải đến từ ứng dụng này.');
   const d=await body(req,1000);if(typeof d.videoId!=='string'||!/^[A-Za-z0-9_-]{11}$/.test(d.videoId)||![100,101,150].includes(d.code))throw new ApiError(400,'Báo cáo video không hợp lệ.');
   await rate(env.DB,'video-report',req.headers.get('cf-connecting-ip')||'shared',30);
   // Public reports only change priority. They can never confirm a failure or
   // remove music, and IDs outside existing playlists are ignored.
   await env.DB.prepare("INSERT INTO video_checks (video_id,reported_at) SELECT ?,? WHERE EXISTS (SELECT 1 FROM sessions s,json_each(s.tracks) t WHERE json_extract(t.value,'$.videoId')=?) AND NOT EXISTS (SELECT 1 FROM video_blocks WHERE video_id=?) ON CONFLICT(video_id) DO UPDATE SET reported_at=excluded.reported_at").bind(d.videoId,Date.now(),d.videoId,d.videoId).run();
   return json({queued:true});
  }
  if(path[1]==='admin'){
   if(!user)throw new ApiError(401,'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.');
   if(path.length===3&&path[2]==='maintenance'){
    if(method==='GET')return json(await maintenanceStatus(env.DB));
    if(method==='POST'){if(!isAppOrigin(req,env))throw new ApiError(403,'Yêu cầu phải đến từ ứng dụng này.');const d=await body(req,1000);return json(await runMaintenance(env,u.origin,{limit:d.limit}));}
    throw new ApiError(405,'Bảo trì hỗ trợ GET hoặc POST.');
   }
   if(path.length===3&&path[2]==='import'&&method==='POST')return await importFile(req,user,env);
   if(method!=='GET')throw new ApiError(405,'Danh mục quản trị chỉ hỗ trợ GET.');
   if(path.length!==3||!['playlists','library'].includes(path[2]))throw new ApiError(404,'API không tồn tại.');
   return json(await adminData(user,env,path[2]==='library'));
  }
  if(path[1]==='me'&&method==='GET'){
   let sessions:unknown[]=[];
   if(user){const r=await env.DB.prepare('SELECT slug,name FROM sessions WHERE owner_id=? OR owner_id=? ORDER BY updated_at DESC LIMIT 100').bind(user.id,'__seed__').all();sessions=r.results;}
   return json({signedIn:!!user,name:user?.name??null,sessions});
  }
  if(path[1]==='library'){
   if(method!=='GET')throw new ApiError(405,'Danh sách tổng hợp chỉ dùng để nghe. Hãy chỉnh sửa trong playlist gốc.');
   if(path.length!==2&&!(path.length===3&&path[2]==='metadata'))throw new ApiError(404,'API không tồn tại.');
   const session=await library(env);
   if(path[2]==='metadata')return await metadataResponse(req,env,new Set(session.tracks.map(t=>t.videoId)));
   return json({session});
  }
  if(path[1]==='collections'&&path.length===2&&method==='GET')return json({collections:await listCollections(user,env),curation:{basis:'Tuyển chọn theo sắc thái Shelby, kết hợp các bản edit nổi bật và hit phổ biến; không phải bảng xếp hạng thời gian thực.',checkedAt:'2026-10-18',sources:[{title:'Spotify Wrapped 2025 · Global Top Songs',url:'https://newsroom.spotify.com/2025-12-03/wrapped-top-artists-songs-albums-podcasts-audiobooks/'},{title:'TikTok · Top Artists and Songs of 2025',url:'https://newsroom.tiktok.com/tiktok-reveals-the-top-artists-and-songs-of-2025?lang=en'}]}});
  if(path[1]!=='sessions')throw new ApiError(404,'API không tồn tại.');
  if(path.length===2&&method==='POST'){
   if(!user)throw new ApiError(401,'Đăng nhập để tạo session. Nghe nhạc qua liên kết không cần tài khoản.');
   const d=await body(req),slug=slugValue(d.slug),name=nameValue(d.name||slug);
   if(slug==='shelby')await seed(env.DB);if(curatedPlaylists.some(p=>p.slug===slug))await seedCurated(env.DB);if(importedPlaylists.some(p=>p.slug===slug))await seedImported(env.DB,slug);
   await rate(env.DB,'create',user.id,20);
   const count=await env.DB.prepare('SELECT COUNT(*) AS count FROM sessions WHERE owner_id=?').bind(user.id).first<{count:number}>();if((count?.count||0)>=100)throw new ApiError(400,'Mỗi tài khoản có tối đa 100 session.');
   const now=Date.now();const r=await env.DB.prepare('INSERT OR IGNORE INTO sessions (slug,name,owner_id,tracks,version,last_request,created_at,updated_at) VALUES (?,?,?,\'[]\',1,?,?,?)').bind(slug,name,user.id,req.headers.get('x-request-id'),now,now).run();
   if(!r.meta.changes){const previous=await load(env.DB,slug);if(previous.last_request&&previous.last_request===req.headers.get('x-request-id')&&canEdit(user,previous))return json({session:await snapshot(user,previous,env)},200);throw new ApiError(409,'Slug này đã được sử dụng. Hãy chọn một slug khác.');}
   return json({session:await snapshot(user,await load(env.DB,slug),env)},201);
  }
  if(path.length<3||path.length>4)throw new ApiError(404,'API không tồn tại.');
  const slug=slugValue(path[2]);if(slug==='shelby')await seed(env.DB);if(curatedPlaylists.some(p=>p.slug===slug))await seedCurated(env.DB);if(importedPlaylists.some(p=>p.slug===slug))await seedImported(env.DB,slug);
  const row=await load(env.DB,slug);
  if(path.length===3&&method==='GET')return json({session:await snapshot(user,row,env)});
  if(path[3]==='metadata'&&method==='GET')return await metadataResponse(req,env,new Set((JSON.parse(row.tracks) as RawTrack[]).map(t=>t.videoId)));
  if(!canEdit(user,row))throw new ApiError(403,'Bạn đang ở chế độ chỉ nghe. Chỉ người tạo được chỉnh sửa hoặc xóa session.');
  const requestId=req.headers.get('x-request-id');if(!requestId||! /^[a-zA-Z0-9-]{8,80}$/.test(requestId))throw new ApiError(400,'Thiếu mã thao tác hợp lệ.');
  if(requestId===row.last_request&&!(method==='DELETE'&&path.length===3))return json({session:await snapshot(user,row,env),replayed:true});
  const version=Number(req.headers.get('if-match'));if(!Number.isSafeInteger(version)||version!==row.version)throw new ApiError(409,'Playlist vừa thay đổi trên thiết bị khác. Đã tải lại dữ liệu; hãy thực hiện lại thao tác.');
  await rate(env.DB,'write',user!.id,600);
  if(path.length===3&&method==='DELETE'){
   const r=await env.DB.prepare('DELETE FROM sessions WHERE slug=? AND version=?').bind(slug,version).run();if(!r.meta.changes)throw new ApiError(409,'Session vừa thay đổi. Hãy tải lại.');return json({deleted:true});
  }
  const d=await body(req);let tracks=JSON.parse(row.tracks) as {videoId:string;addedAt:number}[],name=row.name,report:unknown;
  if(path.length===3&&method==='PATCH')name=nameValue(d.name);
  else if(path[3]==='tracks'&&method==='POST'){
   const parsed=parseBatch(d.text,tracks.map(x=>x.videoId)),blocked=new Set(await blockedVideoIds(env.DB,parsed.ids));const ids=parsed.ids.filter(id=>!blocked.has(id));const {ids:_,...summary}=parsed;report={...summary,added:ids.length,...(blocked.size?{blocked:blocked.size}:{})};tracks=[...tracks,...ids.map(videoId=>({videoId,addedAt:Date.now()}))];
  }else if(path[3]==='tracks'&&method==='DELETE'){
   const ids=d.videoIds===undefined?[d.videoId]:d.videoIds;
   if(!Array.isArray(ids)||!ids.length||ids.length>MAX_TRACKS||new Set(ids).size!==ids.length||ids.some((id:unknown)=>typeof id!=='string'||!/^[A-Za-z0-9_-]{11}$/.test(id)))throw new ApiError(400,'Danh sách video ID không hợp lệ.');
   const removed=new Set(ids);if(d.videoIds!==undefined&&ids.some((id:string)=>!tracks.some(track=>track.videoId===id)))throw new ApiError(400,'Một số bài đã không còn trong playlist. Hãy tải lại danh sách.');
   tracks=tracks.filter(x=>!removed.has(x.videoId));
  }else if(path[3]==='order'&&method==='PATCH'){
   if(!Array.isArray(d.ids)||d.ids.length!==tracks.length||d.ids.length>MAX_TRACKS||new Set(d.ids).size!==tracks.length)throw new ApiError(400,'Thứ tự bài không hợp lệ.');
   const map=new Map(tracks.map(x=>[x.videoId,x]));if(d.ids.some((id:unknown)=>typeof id!=='string'||!map.has(id)))throw new ApiError(400,'Thứ tự bài không khớp playlist.');tracks=d.ids.map((id:string)=>map.get(id)!);
  }else throw new ApiError(405,'Thao tác không được hỗ trợ.');
  const result=await env.DB.prepare('UPDATE sessions SET name=?,tracks=?,version=version+1,last_request=?,updated_at=? WHERE slug=? AND version=?').bind(name,JSON.stringify(tracks),requestId,Date.now(),slug,version).run();
  if(!result.meta.changes)throw new ApiError(409,'Playlist vừa thay đổi. Hãy tải lại và thử lại.');
  return json({session:await snapshot(user,await load(env.DB,slug),env),report});
 }catch(error){if(error instanceof ApiError)return json({error:error.message},error.status,error.retryAfter?{'Retry-After':String(error.retryAfter)}:{});console.error('listen-api',error instanceof Error?error.message:'unknown');return json({error:'Không thể lưu hoặc tải dữ liệu lúc này. Vui lòng thử lại.'},503);}
}
