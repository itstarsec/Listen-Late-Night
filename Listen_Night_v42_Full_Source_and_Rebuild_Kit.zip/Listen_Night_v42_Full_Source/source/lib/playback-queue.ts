import {type Session,replacementAfterDelete} from './domain';

/** Reconcile server edits without loading the current video again if it survives. */
export function reconcileQueue(previous:Session,next:Session,currentId:string|null) {
  if(currentId&&next.tracks.some(t=>t.videoId===currentId))return {queue:next,currentId,reload:false};
  const replacement=currentId?replacementAfterDelete(previous.tracks.map(t=>t.videoId),currentId):null;
  const id=next.tracks.some(t=>t.videoId===replacement)?replacement:next.tracks[0]?.videoId??null;
  return {queue:next,currentId:id,reload:id!==currentId};
}
