import { ApiError } from './domain';

export type AuthRuntime={DB:D1Database;AUTH_USERNAME?:string;AUTH_PASSWORD_HASH?:string;AUTH_ADDITIONAL_ADMINS?:string};
export type Identity={id:string;name:string};
export const LOCAL_ACCOUNT_ID='__local_admin__';
export const AUTH_COOKIE='__Host-listen_session';
export const SESSION_TTL=7*24*60*60*1000;
const ITERATIONS=100000;
const encoder=new TextEncoder();
const encode=(bytes:Uint8Array)=>btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const decode=(value:string)=>Uint8Array.from(atob(value.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
export async function digest(value:string){const data=await crypto.subtle.digest('SHA-256',encoder.encode(value));return [...new Uint8Array(data)].map(x=>x.toString(16).padStart(2,'0')).join('');}
async function derive(password:string,salt:Uint8Array){
 const key=await crypto.subtle.importKey('raw',encoder.encode(password),'PBKDF2',false,['deriveBits']);
 return new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt:salt as BufferSource,iterations:ITERATIONS,hash:'SHA-256'},key,256));
}
export async function createPasswordHash(password:string){
 const salt=crypto.getRandomValues(new Uint8Array(16));
 return `pbkdf2-sha256$${ITERATIONS}$${encode(salt)}$${encode(await derive(password,salt))}`;
}
type Credentials={username:string;hash:string};
function config(env:AuthRuntime):Credentials[]{
 const unavailable=()=>new ApiError(503,'Đăng nhập chưa sẵn sàng. Vui lòng thử lại sau.');
 const account=(username:unknown,hash:unknown):Credentials=>{
  if(typeof username!=='string'||typeof hash!=='string')throw unavailable();
  const normalized=username.trim().toLowerCase();
  if(!/^[a-z0-9._-]{1,64}$/.test(normalized)||!/^pbkdf2-sha256\$100000\$[A-Za-z0-9_-]{22}\$[A-Za-z0-9_-]{43}$/.test(hash))throw unavailable();
  return {username:normalized,hash};
 };
 const accounts=[account(env.AUTH_USERNAME,env.AUTH_PASSWORD_HASH)];
 if(env.AUTH_ADDITIONAL_ADMINS?.trim()){
  let extra:unknown;try{extra=JSON.parse(env.AUTH_ADDITIONAL_ADMINS);}catch{throw unavailable();}
  if(!Array.isArray(extra)||extra.length>20)throw unavailable();
  for(const item of extra){
   if(!item||typeof item!=='object'||Array.isArray(item))throw unavailable();
   const credentials=account(item.username,item.passwordHash);
   if(accounts.some(a=>a.username===credentials.username))throw unavailable();
   accounts.push(credentials);
  }
 }
 return accounts;
}
export async function verifyPassword(password:string,hash:string){
 const parts=hash.split('$');
 if(parts.length!==4||parts[0]!=='pbkdf2-sha256'||parts[1]!==String(ITERATIONS))return false;
 const actual=await derive(password,decode(parts[2])),expected=decode(parts[3]);
 if(expected.length!==actual.length)return false;
 let difference=0;for(let i=0;i<actual.length;i++)difference|=actual[i]^expected[i];
 return difference===0;
}
function token(req:Request){
 const values=(req.headers.get('cookie')||'').split(';').map(x=>x.trim()).filter(x=>x.startsWith(AUTH_COOKIE+'='));
 if(values.length!==1)return null;
 const value=values[0].slice(AUTH_COOKIE.length+1);return /^[A-Za-z0-9_-]{43}$/.test(value)?value:null;
}
const cookie=(value:string,maxAge:number)=>`${AUTH_COOKIE}=${value}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Lax`;
async function credentialTag(username:string,hash:string){return digest(`listen-auth-v1\0${username}\0${hash}`);}
export async function currentUser(req:Request,env:AuthRuntime):Promise<Identity|null>{
 const value=token(req);if(!value)return null;
 let accounts:Credentials[];try{accounts=config(env);}catch{return null;}
 const record=await env.DB.prepare('SELECT username,credential_tag FROM auth_sessions WHERE token_hash=? AND expires_at>?').bind(await digest(value),Date.now()).first<{username:string;credential_tag:string}>();
 if(!record)return null;
 const credentials=accounts.find(a=>a.username===record.username);
 if(!credentials||record.credential_tag!==await credentialTag(credentials.username,credentials.hash))return null;
 // All configured accounts administer the existing shared playlist workspace.
 // Keep its owner ID and per-account credential tags stable across additions.
 return {id:LOCAL_ACCOUNT_ID,name:record.username};
}
async function loginRate(req:Request,env:AuthRuntime){
 const now=Date.now(),window=Math.floor(now/900000),expiresAt=(window+2)*900000;
 const ip=req.headers.get('cf-connecting-ip')||'shared';
 for(const [scope,max] of [[`login-ip:${ip}`,10],['login-account',50]] as const){
  const r=await env.DB.prepare('INSERT INTO limits (key,count,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count').bind(`${scope}:${window}`,expiresAt).first<{count:number}>();
  if((r?.count||0)>max)throw new ApiError(429,'Bạn đã thử đăng nhập nhiều lần. Vui lòng thử lại sau.',Math.max(1,Math.ceil(((window+1)*900000-now)/1000)));
 }
}
export async function signIn(req:Request,env:AuthRuntime,data:Record<string,unknown>){
 const accounts=config(env);
 if(typeof data.username!=='string'||typeof data.password!=='string'||data.username.length>64||!data.username.trim()||!data.password||data.password.length>128)throw new ApiError(400,'Nhập tên đăng nhập và mật khẩu hợp lệ.');
 await loginRate(req,env);
 const username=data.username.trim().toLowerCase();
 // Unknown usernames still perform one password derivation before failing.
 const credentials=accounts.find(a=>a.username===username)??accounts[0];
 const correctPassword=await verifyPassword(data.password,credentials.hash);
 if(!correctPassword||username!==credentials.username)throw new ApiError(401,'Tên đăng nhập hoặc mật khẩu chưa đúng.');
 const value=encode(crypto.getRandomValues(new Uint8Array(32))),now=Date.now(),previous=token(req);
 const writes=[env.DB.prepare('DELETE FROM auth_sessions WHERE expires_at<=?').bind(now)];
 if(previous)writes.push(env.DB.prepare('DELETE FROM auth_sessions WHERE token_hash=?').bind(await digest(previous)));
 writes.push(env.DB.prepare('INSERT INTO auth_sessions (token_hash,username,credential_tag,created_at,expires_at) VALUES (?,?,?,?,?)').bind(await digest(value),credentials.username,await credentialTag(credentials.username,credentials.hash),now,now+SESSION_TTL));
 await env.DB.batch(writes);
 return {user:{id:LOCAL_ACCOUNT_ID,name:credentials.username},cookie:cookie(value,SESSION_TTL/1000)};
}
export async function signOut(req:Request,env:AuthRuntime){
 const value=token(req);if(value)await env.DB.prepare('DELETE FROM auth_sessions WHERE token_hash=?').bind(await digest(value)).run();
 return cookie('',0);
}
