declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    SEED_OWNER_EMAIL?: string;
    BUCKET?: R2Bucket;
  }
}
