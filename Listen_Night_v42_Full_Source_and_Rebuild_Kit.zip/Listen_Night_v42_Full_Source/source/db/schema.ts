import { sqliteTable, text, integer, index, primaryKey } from 'drizzle-orm/sqlite-core';
export const sessions = sqliteTable('sessions', {
  slug: text('slug').primaryKey(), name: text('name').notNull(), ownerId: text('owner_id').notNull(),
  tracks: text('tracks').notNull().default('[]'), version: integer('version').notNull().default(1),
  lastRequest: text('last_request'), createdAt: integer('created_at').notNull(), updatedAt: integer('updated_at').notNull(),
});
export const metadata = sqliteTable('metadata', {
  videoId: text('video_id').primaryKey(), title: text('title').notNull(), channel: text('channel'),
  thumbnail: text('thumbnail').notNull(), status: text('status').notNull(), expiresAt: integer('expires_at').notNull(),
});
export const seeds = sqliteTable('seeds', { key: text('key').primaryKey() });
export const limits = sqliteTable('limits', { key: text('key').primaryKey(), count: integer('count').notNull(), expiresAt: integer('expires_at').notNull() });
export const authSessions = sqliteTable('auth_sessions', {
  tokenHash: text('token_hash').primaryKey(), username: text('username').notNull(),
  credentialTag: text('credential_tag').notNull(), createdAt: integer('created_at').notNull(),
  expiresAt: integer('expires_at').notNull(),
},table=>[index('auth_sessions_expiry_idx').on(table.expiresAt)]);
export const playlistImports = sqliteTable('playlist_imports', {
 ownerId:text('owner_id').notNull(),requestId:text('request_id').notNull(),slug:text('slug').notNull(),
 fingerprint:text('fingerprint').notNull(),report:text('report').notNull(),createdAt:integer('created_at').notNull(),
},table=>[primaryKey({columns:[table.ownerId,table.requestId]})]);
export const videoChecks=sqliteTable('video_checks',{
 videoId:text('video_id').primaryKey(),checkedAt:integer('checked_at').notNull().default(0),
 nextCheckAt:integer('next_check_at').notNull().default(0),outcome:text('outcome').notNull().default('unknown'),
 reason:text('reason').notNull().default(''),source:text('source').notNull().default(''),
 failures:integer('failures').notNull().default(0),firstFailedAt:integer('first_failed_at'),reportedAt:integer('reported_at').notNull().default(0),
});
export const videoBlocks=sqliteTable('video_blocks',{
 videoId:text('video_id').primaryKey(),reason:text('reason').notNull(),source:text('source').notNull(),
 evidence:text('evidence').notNull(),confirmedAt:integer('confirmed_at').notNull(),
});
export const videoRemovals=sqliteTable('video_removals',{
 id:integer('id').primaryKey({autoIncrement:true}),videoId:text('video_id').notNull(),slug:text('slug').notNull(),
 playlistName:text('playlist_name').notNull(),position:integer('position').notNull(),track:text('track').notNull(),removedAt:integer('removed_at').notNull(),
},t=>[index('video_removals_video_idx').on(t.videoId)]);
export const maintenanceRuns=sqliteTable('maintenance_runs',{
 id:text('id').primaryKey(),startedAt:integer('started_at').notNull(),finishedAt:integer('finished_at'),summary:text('summary').notNull().default('{}'),
});
export const maintenanceDaily=sqliteTable('maintenance_daily',{day:text('day').primaryKey(),checked:integer('checked').notNull().default(0)});
export const maintenanceLocks=sqliteTable('maintenance_locks',{key:text('key').primaryKey(),token:text('token').notNull(),expiresAt:integer('expires_at').notNull()});
