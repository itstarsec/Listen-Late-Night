#!/usr/bin/env node
// Optional CLI runner for an external scheduler. Sites' linked cloud task calls
// the same MCP tools directly and does not need this CLI or stored credentials.
// OAuth access tokens are supplied by the caller's secure runtime, never argv.
const origin=process.env.LISTEN_SITE_ORIGIN;
const accessToken=process.env.SITE_MCP_ACCESS_TOKEN;
if(!origin||!accessToken){console.error('Set LISTEN_SITE_ORIGIN and SITE_MCP_ACCESS_TOKEN (owner OAuth token for this Site MCP resource).');process.exit(1);}
const site=new URL(origin);
if(site.protocol!=='https:'||site.origin!==origin){console.error('LISTEN_SITE_ORIGIN must be an exact HTTPS origin.');process.exit(1);}
let sequence=0;
async function call(name,args={}){
 const response=await fetch(new URL('/mcp',site),{method:'POST',redirect:'error',signal:AbortSignal.timeout(110000),headers:{Authorization:'Bearer '+accessToken,'Content-Type':'application/json',Accept:'application/json, text/event-stream'},body:JSON.stringify({jsonrpc:'2.0',id:++sequence,method:'tools/call',params:{name,arguments:args}})});
 if(!response.ok)throw new Error('Maintenance HTTP '+response.status);
 const raw=await response.text();
 const data=JSON.parse(raw.trim().startsWith('{')?raw:raw.split('\n').filter(x=>x.startsWith('data: ')).map(x=>x.slice(6)).find(x=>x.includes('"result"'))||'{}');
 if(data.error||data.result?.isError)throw new Error('Maintenance request rejected; check owner authorization.');
 const text=data.result?.content?.find(x=>x.type==='text')?.text;if(!text)throw new Error('Missing maintenance response');return JSON.parse(text);
}
try{
 console.log(JSON.stringify({before:await call('video_maintenance_status')}));
 let unknownStreak=0;
 for(let batch=0;batch<18;batch++){
  const r=await call('run_video_maintenance',{limit:20});console.log(JSON.stringify({batch:batch+1,...r}));
  if(r.status!=='ok')break;
  unknownStreak=r.unknown===r.checked?unknownStreak+1:0;
  if(unknownStreak>=2){console.log('Stopped: YouTube could not be verified. No unknown videos removed.');break;}
 }
 console.log(JSON.stringify({after:await call('video_maintenance_status')}));
}catch(e){console.error(e.message);process.exitCode=1;}
