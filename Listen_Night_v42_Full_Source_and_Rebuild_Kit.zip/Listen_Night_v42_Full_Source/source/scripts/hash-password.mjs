// Operator utility. Passwords are read from hidden stdin, never argv or files.
import {pbkdf2Sync,randomBytes} from 'node:crypto';
function readLine(prompt,json=false){
 if(process.stdin.isTTY){process.stdin.setRawMode(true);process.stdout.write(prompt);}
 process.stdin.setEncoding('utf8');process.stdin.resume();
 return new Promise((resolve,reject)=>{
  let input='';
  const finish=(error)=>{process.stdin.off('data',onData);process.stdin.off('end',onEnd);process.stdin.pause();if(process.stdin.isTTY)process.stdin.setRawMode(false);error?reject(error):resolve(input);};
  const onEnd=()=>finish();
  const onData=chunk=>{for(const char of chunk){if(char==='\u0003'){finish(Error('Cancelled.'));return;}if(char==='\r'||char==='\n'){finish();return;}if(!json&&(char==='\u007f'||char==='\b'))input=[...input].slice(0,-1).join('');else input+=char;if(input.length>4096){finish(Error('Input is too large.'));return;}}};
  process.stdin.on('data',onData);process.stdin.once('end',onEnd);
 });
}
const json=process.argv.includes('--json-stdin');
if(!json&&!process.stdin.isTTY)throw Error('Run in a terminal, or pass password JSON through --json-stdin.');
try{
 const input=await readLine(json?'Ready for password JSON on hidden stdin.\n':'New password (hidden): ',json);
 const password=json?JSON.parse(input).password:input;
 if(typeof password!=='string'||!password||password.length>128)throw Error('Password must contain 1–128 characters.');
 const salt=randomBytes(16),key=pbkdf2Sync(password,salt,100000,32,'sha256');
 const hash=`pbkdf2-sha256$100000$${salt.toString('base64url')}$${key.toString('base64url')}`;
 process.stdout.write(json?JSON.stringify({password_hash:hash})+'\n':'\nAUTH_PASSWORD_HASH='+hash+'\n');
}finally{if(process.stdin.isTTY)process.stdin.setRawMode(false);process.stdin.destroy();}
