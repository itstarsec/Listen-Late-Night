/* Classic ES5, deliberately independent of React, modules and WebGL. */
(function (window, document) {
  'use strict';
  var PAGE_SIZE = 20;
  var state = { catalogue: [], browse: null, queue: null, current: null, loading: true,
    ready: false, created: false, player: null, playerState: -1, intent: false,
    pending: null, sequence: 0, catalogueSequence: 0, requested: null, page: 0, query: '', filtered: [],
    shuffle: false, repeat: 'off', failed: Object.create(null), played: Object.create(null), failures: 0, started: false,
    lastEnded: '', lastError: '', seeking: false, queueOpen: true };
  var apiTimer = null, blockedTimer = null, skipTimer = null, searchTimer = null;
  var metadataBusy = false, metadataJobs = [], metadataSeen = Object.create(null), sessionRequest = null;
  var lastSaved = 0, apiScript = null;
  function el(id) { return document.getElementById(id); }
  function text(id, value) { el(id).textContent = value; }
  function hide(id, value) { el(id).hidden = value; }
  function empty(node) { while (node.firstChild) { node.removeChild(node.firstChild); } }
  function read(key, fallback) { try { var value = JSON.parse(window.localStorage.getItem(key)); return value === null ? fallback : value; } catch (error) { return fallback; } }
  function write(key, value) { try { window.localStorage.setItem(key, JSON.stringify(value)); } catch (error) { /* Private mode and full storage must not stop playback. */ } }
  function parameters(search) {
    var out = {}, pairs = search.replace(/^\?/, '').split('&'), i, split, key;
    for (i = 0; i < pairs.length; i++) {
      split = pairs[i].split('=');
      try { key = decodeURIComponent(split[0].replace(/\+/g, ' ')); if (key && !Object.prototype.hasOwnProperty.call(out, key)) { Object.defineProperty(out, key, { value: decodeURIComponent(split.slice(1).join('=').replace(/\+/g, ' ')), enumerable: true }); } } catch (error) { /* Ignore a malformed query parameter. */ }
    }
    return out;
  }
  function validSlug(slug) { return /^[a-z0-9](?:[a-z0-9-]{1,46}[a-z0-9])$/.test(slug); }
  function apiPath(slug) { return slug === '__all__' ? '/library' : '/sessions/' + encodeURIComponent(slug); }
  function canonical(id) { return 'https://www.youtube.com/watch?v=' + id; }
  function clock(value) { value = Math.max(0, Math.floor(Number(value) || 0)); return Math.floor(value / 60) + ':' + ('0' + value % 60).slice(-2); }
  function status(id, value, error) { text(id, value); el(id).className = error ? 'status error' : 'status'; }
  function request(path, callback) {
    var xhr = new window.XMLHttpRequest(), finished = false;
    function complete(error, data) { if (finished) { return; } finished = true; callback(error, data); }
    xhr.open('GET', '/api' + path, true); xhr.timeout = 20000;
    xhr.setRequestHeader('Accept', 'application/json');
    xhr.onload = function () {
      var data;
      try { data = JSON.parse(xhr.responseText); } catch (error) { complete('Máy chủ trả dữ liệu không hợp lệ. Hãy thử lại.'); return; }
      if (xhr.status < 200 || xhr.status >= 300) { complete(data && typeof data.error === 'string' ? data.error : 'Chưa tải được dữ liệu. Hãy thử lại.'); return; }
      complete(null, data);
    };
    xhr.onerror = function () { complete('Mất kết nối mạng. Kiểm tra Wi-Fi rồi thử lại.'); };
    xhr.ontimeout = function () { complete('Kết nối mất quá nhiều thời gian. Hãy thử lại.'); };
    xhr.onabort = function () { complete('Đã chuyển sang playlist khác.'); };
    xhr.send(); return xhr;
  }
  function safeTrack(raw) {
    if (!raw || typeof raw.videoId !== 'string' || !/^[A-Za-z0-9_-]{11}$/.test(raw.videoId)) { return null; }
    return { videoId: raw.videoId, title: typeof raw.title === 'string' ? raw.title.slice(0, 500) : 'Video YouTube · ' + raw.videoId,
      channel: typeof raw.channel === 'string' ? raw.channel.slice(0, 200) : '', url: canonical(raw.videoId),
      thumbnail: 'https://i.ytimg.com/vi/' + raw.videoId + '/hqdefault.jpg', metadataStatus: raw.metadataStatus || 'pending' };
  }
  function sessionData(raw, slug) {
    var tracks = [], seen = Object.create(null), i, track;
    if (!raw || raw.slug !== slug || Object.prototype.toString.call(raw.tracks) !== '[object Array]' || raw.tracks.length > 20000) { return null; }
    for (i = 0; i < raw.tracks.length; i++) { track = safeTrack(raw.tracks[i]); if (track && !seen[track.videoId]) { seen[track.videoId] = true; tracks.push(track); } }
    return { slug: slug, name: typeof raw.name === 'string' ? raw.name.slice(0, 100) : slug, tracks: tracks };
  }
  function collection(slug) { for (var i = 0; i < state.catalogue.length; i++) { if (state.catalogue[i].slug === slug) { return state.catalogue[i]; } } return null; }
  function findTrack(tracks, id) { for (var i = 0; i < tracks.length; i++) { if (tracks[i].videoId === id) { return tracks[i]; } } return null; }
  function currentTrack() { return state.queue ? findTrack(state.queue.tracks, state.current) : null; }
  function address(slug) {
    var path = window.location.pathname.indexOf('/lite') === 0 ? '/lite' : '/';
    var query = slug === '__all__' ? '?view=all' : '?s=' + encodeURIComponent(slug);
    try { window.history.replaceState(null, '', path + query + window.location.hash); } catch (error) { /* Listening also works without history access. */ }
  }
  function sharingUrl() { return window.location.protocol + '//' + window.location.host + '/' + (state.browse.slug === '__all__' ? '?view=all' : '?s=' + encodeURIComponent(state.browse.slug)); }
  function updateButtons() {
    var hasSongs = !!(state.browse && state.browse.tracks.length), hasCurrent = !!currentTrack();
    el('play-all').disabled = !hasSongs || state.loading; el('share').disabled = !state.browse; el('export').disabled = !hasSongs;
    el('play-long').disabled = !hasSongs || state.loading;
    el('play').disabled = !hasCurrent; el('previous').disabled = !hasCurrent; el('next').disabled = !hasCurrent;
    text('play', state.playerState === 1 ? 'Ⅱ Tạm dừng' : '▶ Phát'); el('play').setAttribute('aria-label', state.playerState === 1 ? 'Tạm dừng' : 'Phát nhạc');
    text('shuffle', 'Ngẫu nhiên: ' + (state.shuffle ? 'bật' : 'tắt')); el('shuffle').setAttribute('aria-pressed', state.shuffle ? 'true' : 'false');
    text('repeat', 'Lặp: ' + (state.repeat === 'one' ? 'một bài' : state.repeat === 'all' ? 'toàn bộ' : 'tắt'));
    var labels = { '-1': 'SẴN SÀNG', '0': 'ĐÃ KẾT THÚC', '1': 'ĐANG PHÁT', '2': 'TẠM DỪNG', '3': 'ĐANG TẢI', '5': 'CHỜ PHÁT' };
    text('player-state', state.ready ? (labels[String(state.playerState)] || 'SẴN SÀNG') : 'ĐANG KẾT NỐI');
  }
  function renderCatalogue() {
    var select = el('playlist'), option, groups = Object.create(null), group, i, item;
    var names = { viet: 'Nhạc Việt', ai: 'Nhạc AI', tryhard: 'Try Hard', gaming: 'Gaming', ride: 'Ride · Mô tô', active: 'Active · Thể thao', dopamine: 'Dopamine', curated: 'Playlist tuyển chọn' };
    empty(select); option = document.createElement('option'); option.value = ''; option.textContent = 'Chọn một playlist…'; select.appendChild(option);
    for (i = 0; i < state.catalogue.length; i++) {
      item = state.catalogue[i]; group = item.category || 'curated';
      if (!groups[group]) { groups[group] = document.createElement('optgroup'); groups[group].label = names[group] || 'Playlist tuyển chọn'; select.appendChild(groups[group]); }
      option = document.createElement('option'); option.value = item.slug; option.textContent = item.name + ' · ' + item.count + ' bài'; groups[group].appendChild(option);
    }
    select.value = state.browse && state.browse.slug !== '__all__' ? state.browse.slug : '';
    status('catalogue-status', state.catalogue.length + ' playlist · Chỉ tải bài của playlist bạn mở.');
    describe();
  }
  function describe() {
    if (!state.browse) { return; }
    var origin = collection(state.browse.slug), ids = origin && origin.longformVideoIds || [], longExists = false;
    for (var i = 0; i < ids.length; i++) { if (findTrack(state.browse.tracks, ids[i])) { longExists = true; break; } }
    text('description', state.browse.slug === '__all__' ? state.browse.tracks.length + ' bài tổng hợp từ mọi playlist, loại trùng theo video ID.' : origin && origin.description || 'Những giai điệu dành cho khoảng riêng của bạn.');
    hide('play-long', !longExists);
  }
  function loadCatalogue() {
    var catalogueToken = ++state.catalogueSequence;
    hide('retry-catalogue', true); status('catalogue-status', 'Đang tải thư viện…');
    request('/collections', function (error, data) {
      if (catalogueToken !== state.catalogueSequence) { return; }
      if (error || !data || Object.prototype.toString.call(data.collections) !== '[object Array]') {
        status('catalogue-status', error || 'Chưa đọc được thư viện.', true); hide('retry-catalogue', false);
        if (!state.requested && !state.browse) { status('load-status', 'Chưa chọn được playlist. Bạn có thể mở bằng slug bên trên.', true); }
        return;
      }
      state.catalogue = data.collections.filter(function (item) { return item && validSlug(item.slug) && typeof item.name === 'string' && typeof item.count === 'number'; });
      renderCatalogue();
      if (!state.requested && !state.browse) {
        var nonempty = state.catalogue.filter(function (item) { return item.count > 0; });
        if (nonempty.length) { loadSession(nonempty[Math.floor(Math.random() * nonempty.length)].slug); }
        else { status('load-status', 'Chưa có playlist có bài hát. Hãy thử tải thư viện lại.', true); hide('retry-catalogue', false); }
      }
    });
  }
  function loadSession(slug) {
    if (slug !== '__all__' && !validSlug(slug)) { state.requested = slug; state.loading = false; if (!state.browse) { text('playlist-title', 'Chưa mở được playlist'); } status('load-status', 'Slug cần 3–48 ký tự chữ thường, số hoặc dấu gạch ngang.', true); updateButtons(); return; }
    var token = ++state.sequence; state.requested = slug; state.loading = true; metadataJobs = []; metadataSeen = Object.create(null);
    if (sessionRequest) { sessionRequest.abort(); }
    hide('retry-session', true); status('load-status', slug === '__all__' ? 'Đang tải danh sách tổng hợp…' : 'Đang mở playlist…'); updateButtons();
    sessionRequest = request(apiPath(slug), function (error, data) {
      if (token !== state.sequence) { return; }
      sessionRequest = null; state.loading = false;
      var session = !error && data ? sessionData(data.session, slug) : null;
      if (!session) { status('load-status', error || 'Playlist trả về dữ liệu không hợp lệ.', true); hide('retry-session', false); updateButtons(); return; }
      state.browse = session; state.page = 0; state.query = ''; el('search').value = '';
      text('playlist-title', session.name); document.title = session.name + ' — Listen'; text('song-count', String(session.tracks.length));
      el('slug').value = slug === '__all__' ? '' : slug; el('playlist').value = slug === '__all__' ? '' : slug;
      address(slug); describe(); renderTracks(); status('load-status', 'Đã tải ' + session.tracks.length + ' bài · Playlist lưu trực tuyến.');
      if (!state.queue) { putQueue(session); var saved = read('listen:position:' + slug, {}), first = findTrack(session.tracks, saved.id) || session.tracks[0]; if (first) { select(first.videoId, false, first.videoId === saved.id ? Number(saved.time) || 0 : 0, false); } }
      updateButtons();
    });
  }
  function renderTracks() {
    var list = el('track-list'), term = state.query.toLocaleLowerCase(), tracks = state.browse ? state.browse.tracks : [];
    state.filtered = tracks.filter(function (track) { return !term || (track.title + ' ' + track.channel + ' ' + track.videoId).toLocaleLowerCase().indexOf(term) !== -1; });
    var pages = Math.max(1, Math.ceil(state.filtered.length / PAGE_SIZE)); state.page = Math.max(0, Math.min(state.page, pages - 1));
    var start = state.page * PAGE_SIZE, visible = state.filtered.slice(start, start + PAGE_SIZE);
    empty(list);
    visible.forEach(function (track) {
      var row = document.createElement('li'), image = document.createElement('img'), button = document.createElement('button'), title = document.createElement('strong'), channel = document.createElement('small'), link = document.createElement('a');
      row.className = 'track-row' + (track.videoId === state.current ? ' selected' : ''); row.setAttribute('data-video-id', track.videoId);
      image.src = track.thumbnail; image.alt = ''; image.width = 80; image.height = 45; image.setAttribute('loading', 'lazy');
      image.onerror = function () { image.style.visibility = 'hidden'; };
      button.type = 'button'; button.className = 'track-play'; button.setAttribute('aria-label', 'Phát ' + track.title); title.textContent = track.title; channel.textContent = track.channel || 'Chưa có tên kênh'; button.appendChild(title); button.appendChild(channel);
      button.onclick = function () { playFromBrowse(track.videoId, false); };
      link.className = 'track-source'; link.href = track.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = '↗'; link.setAttribute('aria-label', 'Mở ' + track.title + ' trên YouTube');
      row.appendChild(image); row.appendChild(button); row.appendChild(link); list.appendChild(row);
    });
    hide('empty', visible.length > 0); text('empty', tracks.length ? 'Không có bài phù hợp với từ khóa này.' : 'Playlist chưa có bài hát.');
    text('page-info', state.filtered.length ? (start + 1) + '–' + (start + visible.length) + ' / ' + state.filtered.length + ' bài' : '0 bài');
    el('page-prev').disabled = state.page === 0; el('page-next').disabled = state.page + 1 >= pages;
    queueMetadata(visible);
  }
  function queueMetadata(tracks) {
    if (!state.browse) { return; }
    var slug = state.browse.slug, token = state.sequence, ids = [];
    tracks.forEach(function (track) { var key = slug + ':' + track.videoId; if (track.metadataStatus !== 'ready' && !metadataSeen[key]) { metadataSeen[key] = true; ids.push(track.videoId); } });
    for (var i = 0; i < ids.length; i += 6) { metadataJobs.push({ slug: slug, token: token, ids: ids.slice(i, i + 6) }); }
    processMetadata();
  }
  function processMetadata() {
    if (metadataBusy || !metadataJobs.length) { return; }
    var job = metadataJobs.shift(); if (job.token !== state.sequence) { processMetadata(); return; }
    metadataBusy = true;
    request(apiPath(job.slug) + '/metadata?ids=' + job.ids.join(','), function (error, data) {
      metadataBusy = false;
      if (!error && data && Object.prototype.toString.call(data.tracks) === '[object Array]' && job.token === state.sequence && state.browse && state.browse.slug === job.slug) {
        data.tracks.forEach(function (raw) {
          var track = safeTrack(raw), existing; if (!track || job.ids.indexOf(track.videoId) === -1) { return; }
          existing = findTrack(state.browse.tracks, track.videoId); if (existing) { existing.title = track.title; existing.channel = track.channel; existing.metadataStatus = track.metadataStatus; }
          existing = state.queue && findTrack(state.queue.tracks, track.videoId); if (existing) { existing.title = track.title; existing.channel = track.channel; existing.metadataStatus = track.metadataStatus; }
        });
        renderTracks(); renderNow(); renderQueue();
      }
      processMetadata();
    });
  }
  function putQueue(session) { state.queue = { slug: session.slug, name: session.name, tracks: session.tracks.slice(0) }; renderQueue(); }
  function renderQueue() {
    var list = el('queue-list'); empty(list); hide('queue-list', !state.queueOpen);
    text('queue-name', state.queue ? state.queue.name + ' · ' + state.queue.tracks.length + ' bài. Đổi playlist không làm gián đoạn bài đang nghe.' : 'Chưa chọn hàng phát.');
    if (!state.queue) { return; }
    var tracks = state.queue.tracks, index = -1, start, end;
    for (var i = 0; i < tracks.length; i++) { if (tracks[i].videoId === state.current) { index = i; break; } }
    start = Math.max(0, index); end = Math.min(tracks.length, start + 12);
    tracks.slice(start, end).forEach(function (track) {
      var row = document.createElement('li'), button = document.createElement('button'), channel = document.createElement('small');
      row.className = track.videoId === state.current ? 'current' : ''; button.type = 'button'; button.textContent = track.title; channel.textContent = track.channel; button.appendChild(channel);
      button.onclick = function () { select(track.videoId, true, 0, true); }; row.appendChild(button); list.appendChild(row);
    });
    if (end < tracks.length) { var more = document.createElement('li'); more.className = 'footnote'; more.textContent = 'Còn ' + (tracks.length - end) + ' bài trong hàng phát.'; list.appendChild(more); }
  }
  function renderNow() {
    var track = currentTrack(); if (!track) { return; }
    text('now-title', track.title); text('now-channel', track.channel || 'Chưa có tên kênh'); text('transport-title', track.title);
    el('video-source').href = track.url; hide('video-source', false);
  }
  function remember() {
    if (!state.queue || !state.current) { return; }
    var position = 0; try { if (state.ready) { position = state.player.getCurrentTime() || 0; } } catch (error) { /* A loading player has no time yet. */ }
    write('listen:position:' + state.queue.slug, { id: state.current, time: position });
  }
  function clearPlaybackTimers() { window.clearTimeout(skipTimer); window.clearTimeout(blockedTimer); }
  function select(id, play, start, userAction) {
    if (!state.queue || !findTrack(state.queue.tracks, id)) { return; }
    remember(); clearPlaybackTimers();
    if (userAction) { state.failed = Object.create(null); state.failures = 0; }
    state.current = id; state.intent = play; state.playerState = -1; state.lastError = ''; state.lastEnded = ''; state.started = false;
    state.played[id] = true; state.pending = { videoId: id, startSeconds: Math.min(86400, Math.max(0, start || 0)), play: play };
    text('elapsed', clock(start)); text('duration', '0:00'); el('seek').value = '0'; el('seek').max = '0'; el('seek').disabled = true;
    hide('tap-play', true); renderNow(); renderQueue(); updateSelection(); updateButtons(); applySelection();
  }
  function updateSelection() {
    var rows = el('track-list').children;
    for (var i = 0; i < rows.length; i++) { rows[i].className = 'track-row' + (rows[i].getAttribute('data-video-id') === state.current ? ' selected' : ''); }
  }
  function applySelection() {
    if (!state.ready || !state.pending) { return; }
    var pending = state.pending; state.pending = null;
    try {
      if (pending.play) { state.player.loadVideoById({ videoId: pending.videoId, startSeconds: pending.startSeconds }); watchBlocked(); }
      else { state.player.cueVideoById({ videoId: pending.videoId, startSeconds: pending.startSeconds }); status('player-message', 'Sẵn sàng. Chạm nút phát để nghe nhạc.'); }
    } catch (error) { status('player-message', 'Trình phát chưa sẵn sàng. Hãy chạm lại nút phát hoặc mở video trên YouTube.', true); hide('tap-play', false); }
  }
  function watchBlocked() {
    window.clearTimeout(blockedTimer);
    blockedTimer = window.setTimeout(function () {
      if (!state.intent || !state.ready) { return; }
      var actual = state.player.getPlayerState();
      if (actual !== 1 && actual !== 3) { showBlocked(); }
    }, 2500);
  }
  function showBlocked() { hide('tap-play', false); status('player-message', 'Chạm để phát. Nếu Safari vẫn chặn, chạm nút phát ngay trong khung YouTube.'); }
  function togglePlay() {
    if (!state.current) { return; }
    if (!state.ready) { state.intent = true; if (state.pending) { state.pending.play = true; } status('player-message', 'Đang kết nối YouTube. Khi khung video sẵn sàng, hãy chạm để phát.'); return; }
    if (state.player.getPlayerState() === 1) { state.intent = false; clearPlaybackTimers(); state.player.pauseVideo(); remember(); }
    else { state.intent = true; state.failed = Object.create(null); state.failures = 0; state.player.playVideo(); watchBlocked(); }
  }
  function playFromBrowse(id, reset) {
    if (!state.browse || !findTrack(state.browse.tracks, id)) { return; }
    remember(); putQueue(state.browse);
    if (reset) { state.shuffle = false; state.repeat = 'off'; state.played = Object.create(null); savePreferences(); }
    select(id, true, 0, true);
  }
  function nextId(direction, automatic) {
    if (!state.queue) { return null; }
    var tracks = state.queue.tracks, available = [], pool = [], index = -1, i, id, raw;
    for (i = 0; i < tracks.length; i++) {
      id = tracks[i].videoId; if (id === state.current) { index = i; }
      if (!state.failed[id]) { available.push(id); if (id !== state.current && !state.played[id]) { pool.push(id); } }
    }
    if (!available.length) { return null; }
    if (automatic && state.repeat === 'one' && !state.failed[state.current]) { return state.current; }
    if (state.shuffle) {
      if (!pool.length) { if (automatic && state.repeat !== 'all') { return null; } state.played = Object.create(null); pool = available.filter(function (value) { return value !== state.current; }); }
      return pool.length ? pool[Math.floor(Math.random() * pool.length)] : available[0];
    }
    for (i = 1; i <= tracks.length; i++) {
      raw = index + i * direction;
      if (automatic && state.repeat !== 'all' && (raw < 0 || raw >= tracks.length)) { return null; }
      id = tracks[(raw % tracks.length + tracks.length) % tracks.length].videoId; if (!state.failed[id]) { return id; }
    }
    return null;
  }
  function move(direction, automatic) {
    if (!automatic) { state.failures = 0; state.failed = Object.create(null); }
    var id = nextId(direction, automatic);
    if (id) { select(id, true, 0, !automatic); }
    else { state.intent = false; status('player-message', 'Đã hết hàng phát. Bấm Phát tất cả để nghe lại.'); updateButtons(); }
  }
  function onPlayerState(event) {
    if (!state.player || !state.current) { return; }
    try { var actual = state.player.getVideoData(); if (actual.video_id && actual.video_id !== state.current) { return; } } catch (error) { /* Some old embeds expose video details only after PLAYING. */ }
    state.playerState = event.data;
    if (event.data === 1) { state.started = true; state.intent = true; state.failures = 0; state.lastEnded = ''; hide('tap-play', true); status('player-message', 'Đang phát từ YouTube.'); }
    else if (event.data === 2) { state.intent = false; status('player-message', 'Đã tạm dừng.'); remember(); }
    else if (event.data === 3) { status('player-message', 'YouTube đang tải video…'); }
    else if (event.data === 0 && state.started && state.lastEnded !== state.current) { state.lastEnded = state.current; if (state.intent) { move(1, true); } }
    updateButtons(); updateProgress();
  }
  function onPlayerError(event) {
    var messages = { 2: 'Video ID không hợp lệ.', 5: 'YouTube không phát được video trên trình duyệt này.', 100: 'Video đã bị xóa hoặc chuyển sang riêng tư.', 101: 'Chủ video không cho phép nhúng.', 150: 'Chủ video không cho phép nhúng.', 153: 'YouTube chưa xác nhận được nguồn nhúng. Hãy mở trang trực tiếp hoặc xem trên YouTube.' };
    status('player-message', (messages[event.data] || 'YouTube chưa phát được video này.') + ' Bạn có thể chọn bài tiếp theo hoặc mở video gốc.', true);
    hide('tap-play', true); state.playerState = -1; updateButtons();
    if (!state.current || state.lastError === state.current) { return; }
    if (event.data === 100 || event.data === 101 || event.data === 150) {
      try { var report = new window.XMLHttpRequest(); report.open('POST', '/api/video-reports', true); report.timeout = 5000; report.setRequestHeader('Content-Type', 'application/json'); report.send(JSON.stringify({ videoId: state.current, code: event.data })); } catch (error) { /* A report must never interrupt listening. */ }
    }
    state.lastError = state.current; state.failed[state.current] = true; state.failures++;
    var failedId = state.current;
    if (state.intent && state.failures < 3) { skipTimer = window.setTimeout(function () { if (state.intent && state.current === failedId) { move(1, true); } }, 600); }
    else if (state.failures >= 3) { state.intent = false; status('player-message', 'Đã dừng tự chuyển sau 3 video lỗi. Chọn bài khác hoặc mở video trên YouTube.', true); }
  }
  function resizeVideo() { var width = el('video-shell').clientWidth; if (width) { el('video-shell').style.height = Math.max(200, Math.round(width * 9 / 16)) + 'px'; } }
  function loadPlayer() {
    if (state.created) { return; }
    hide('retry-player', true); status('player-message', 'Đang kết nối YouTube…');
    function createPlayer() {
      if (state.created || !window.YT || !window.YT.Player) { return; }
      state.created = true; window.clearTimeout(apiTimer);
      try {
        state.player = new window.YT.Player('youtube-player', { width: '100%', height: '100%', playerVars: { autoplay: 0, controls: 1, playsinline: 1, rel: 0, origin: window.location.protocol + '//' + window.location.host }, events: {
          onReady: function (event) { state.player = event.target; state.ready = true; var iframe = state.player.getIframe(); iframe.title = 'Trình phát video YouTube'; iframe.setAttribute('allow', 'autoplay; encrypted-media; picture-in-picture'); iframe.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin'); resizeVideo(); applySelection(); updateButtons(); },
          onStateChange: onPlayerState, onError: onPlayerError, onAutoplayBlocked: showBlocked
        } });
      } catch (error) { state.created = false; status('player-message', 'Chưa kết nối được trình phát. Hãy thử lại hoặc mở video trên YouTube.', true); hide('retry-player', false); }
    }
    if (window.YT && window.YT.Player) { createPlayer(); return; }
    window.onYouTubeIframeAPIReady = createPlayer;
    if (apiScript && apiScript.parentNode) { apiScript.parentNode.removeChild(apiScript); }
    apiScript = document.createElement('script'); apiScript.src = 'https://www.youtube.com/iframe_api'; apiScript.async = true;
    function failed() { window.clearTimeout(apiTimer); if (state.created) { return; } status('player-message', 'Không tải được YouTube. Kiểm tra Wi-Fi hoặc trình chặn nội dung rồi thử lại. Nếu trình duyệt quá cũ, dùng nút mở video gốc.', true); hide('retry-player', false); }
    apiScript.onerror = failed; apiTimer = window.setTimeout(failed, 15000); document.head.appendChild(apiScript);
  }
  function updateProgress() {
    if (!state.ready || document.hidden) { return; }
    try {
      var position = Math.max(0, Number(state.player.getCurrentTime()) || 0), duration = Math.max(0, Number(state.player.getDuration()) || 0);
      if (!state.seeking) { text('elapsed', clock(position)); el('seek').max = String(Math.floor(duration)); el('seek').value = String(Math.floor(Math.min(position, duration))); }
      text('duration', clock(duration)); el('seek').disabled = !duration;
      if (Date.now() - lastSaved > 10000) { remember(); lastSaved = Date.now(); }
    } catch (error) { /* Player may be changing videos. */ }
  }
  function savePreferences() { write('listen:compatible:prefs', { shuffle: state.shuffle, repeat: state.repeat }); }
  function showText(title, value) { text('text-title', title); el('text-output').value = value; text('copy-status', ''); hide('text-panel', false); }
  function copyText(value) {
    var box = el('text-output'), previous = document.activeElement, success = false;
    box.value = value; box.focus(); box.select(); try { box.setSelectionRange(0, value.length); success = document.execCommand('copy'); } catch (error) { /* Manual selection remains available on iOS. */ }
    text('copy-status', success ? 'Đã sao chép.' : 'Nhấn giữ trong ô nội dung rồi chọn Sao chép.');
    if (success && previous && previous.focus) { previous.focus(); }
  }
  el('playlist').onchange = function () { if (this.value) { loadSession(this.value); } };
  el('all').onclick = function () { loadSession('__all__'); };
  el('open-session').onsubmit = function (event) { event.preventDefault(); loadSession(el('slug').value.trim()); };
  el('retry-catalogue').onclick = loadCatalogue;
  el('retry-session').onclick = function () { if (state.requested) { loadSession(state.requested); } };
  el('retry-player').onclick = loadPlayer;
  el('play-all').onclick = function () { if (state.browse && state.browse.tracks.length) { playFromBrowse(state.browse.tracks[0].videoId, true); } };
  el('play-long').onclick = function () { var origin = state.browse && collection(state.browse.slug), ids = origin && origin.longformVideoIds || []; for (var i = 0; i < ids.length; i++) { if (findTrack(state.browse.tracks, ids[i])) { playFromBrowse(ids[i], true); return; } } };
  el('play').onclick = togglePlay; el('tap-play').onclick = togglePlay;
  el('next').onclick = function () { move(1, false); };
  el('previous').onclick = function () { if (state.ready && state.player.getCurrentTime() > 3) { state.player.seekTo(0, true); updateProgress(); } else { move(-1, false); } };
  el('shuffle').onclick = function () { state.shuffle = !state.shuffle; state.played = Object.create(null); if (state.current) { state.played[state.current] = true; } savePreferences(); updateButtons(); };
  el('repeat').onclick = function () { state.repeat = state.repeat === 'off' ? 'one' : state.repeat === 'one' ? 'all' : 'off'; savePreferences(); updateButtons(); };
  el('seek').oninput = function () { state.seeking = true; text('elapsed', clock(this.value)); };
  el('seek').onchange = function () { state.seeking = false; if (state.ready) { state.player.seekTo(Number(this.value) || 0, true); remember(); updateProgress(); } };
  el('search').oninput = function () { var query = this.value; window.clearTimeout(searchTimer); searchTimer = window.setTimeout(function () { state.query = query; state.page = 0; renderTracks(); }, 180); };
  el('page-prev').onclick = function () { state.page--; renderTracks(); };
  el('page-next').onclick = function () { state.page++; renderTracks(); };
  el('queue-toggle').onclick = function () { state.queueOpen = !state.queueOpen; this.setAttribute('aria-expanded', state.queueOpen ? 'true' : 'false'); this.textContent = state.queueOpen ? 'Thu gọn' : 'Mở hàng phát'; hide('queue-list', !state.queueOpen); };
  el('share').onclick = function () { if (state.browse) { showText('Liên kết chia sẻ playlist', sharingUrl()); copyText(sharingUrl()); } };
  el('export').onclick = function () { if (state.browse) { showText('Danh sách URL YouTube', state.browse.tracks.map(function (track) { return track.url; }).join('\n')); el('text-output').focus(); el('text-output').select(); } };
  el('text-copy').onclick = function () { copyText(el('text-output').value); };
  el('text-close').onclick = function () { hide('text-panel', true); };
  window.addEventListener('resize', resizeVideo, false); window.addEventListener('pagehide', remember, false);
  document.addEventListener('visibilitychange', function () { if (document.hidden) { remember(); } else { resizeVideo(); updateProgress(); } }, false);
  window.addEventListener('popstate', function () { var params = parameters(window.location.search); if (params.s) { loadSession(params.s); } else if (params.view === 'all') { loadSession('__all__'); } }, false);
  var preferences = read('listen:compatible:prefs', {});
  state.shuffle = preferences.shuffle === true; state.repeat = preferences.repeat === 'one' || preferences.repeat === 'all' ? preferences.repeat : 'off';
  var initial = parameters(window.location.search);
  if (initial.s) { loadSession(initial.s); } else if (initial.view === 'all') { loadSession('__all__'); }
  loadCatalogue(); loadPlayer(); resizeVideo(); updateButtons();
  window.setInterval(updateProgress, 750);
}(window, document));
