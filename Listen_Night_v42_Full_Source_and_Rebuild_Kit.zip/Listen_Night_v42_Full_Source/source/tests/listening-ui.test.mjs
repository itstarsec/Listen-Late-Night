// Component integration with a mocked official Player API; this is not browser/audio QA.
import {test} from 'node:test';import assert from 'node:assert/strict';
import React from 'react';import {create,act} from 'react-test-renderer';
import ListenApp from '../.sites-runtime/tests/listen-app.mjs';
import Turntable from '../.sites-runtime/tests/turntable.mjs';
const track=(id,title)=>({videoId:id,title,channel:'Artist',url:`https://www.youtube.com/watch?v=${id}`,thumbnail:`https://i.ytimg.com/vi/${id}/hqdefault.jpg`,metadataStatus:'ready',addedAt:0});
test('browse, queue panel and light mode preserve the one player and listening position; edits reconcile only deleted current video',async()=>{
 const original=new Map(['window','document','history','localStorage','navigator','fetch','matchMedia','IntersectionObserver','IS_REACT_ACT_ENVIRONMENT'].map(k=>[k,Object.getOwnPropertyDescriptor(globalThis,k)]));
 let root;const instances=[],calls=[],requests=[];let tracks=[track('RzhIXHc6_80','First song'),track('_U8S-uFZrHA','Second song'),track('TdrL3QxjyVw','Third song')],version=1,signedIn=false,failCheck=false;
 const library=()=>({slug:'__all__',kind:'all',name:'Tất cả bài hát',tracks:[...tracks],canEdit:false,version,sourceCount:7,totalEntries:tracks.length,updatedAt:0});
 const shelf=()=>({slug:'shelby',name:'Shelby — Late Night',tracks:[...tracks],canEdit:signedIn,version,updatedAt:0});
 const other=()=>({slug:'other',name:'Other playlist',tracks:[track('AIqG6Gnvm90','Other song')],canEdit:false,version:1,updatedAt:0});
 const media=()=>({matches:false,addEventListener(){},removeEventListener(){}});
 function install(k,value){Object.defineProperty(globalThis,k,{value,writable:true,configurable:true});}
 class Player{
  constructor(node,options){this.options=options;this.id='';this.state=5;this.position=0;instances.push(this);assert.equal(options.playerVars.controls,1);assert.equal(options.playerVars.playsinline,1);queueMicrotask(()=>options.events.onReady({target:this}));}
  cueVideoById(v){calls.push(['cue',v.videoId]);this.id=v.videoId;this.position=v.startSeconds||0;this.state=5;}
  loadVideoById(v){calls.push(['load',v.videoId]);this.id=v.videoId;this.position=v.startSeconds||0;this.state=1;this.options.events.onStateChange({data:1});}
  playVideo(){this.state=1;this.options.events.onStateChange({data:1});}
  pauseVideo(){this.state=2;this.options.events.onStateChange({data:2});}
  stopVideo(){this.state=-1;}
  seekTo(n){this.position=n;}
  getPlayerState(){return this.state;}getCurrentTime(){return this.position;}getDuration(){return 240;}
  getVideoData(){return {video_id:this.id};}getIframe(){return {setAttribute(){}};}destroy(){this.destroyed=true;}
 }
 try{
  install('IS_REACT_ACT_ENVIRONMENT',true);install('matchMedia',media);
  install('window',{YT:{Player},location:new URL('https://listen.example/'),addEventListener(){},removeEventListener(){},setTimeout,clearTimeout});
  install('document',{visibilityState:'visible',hidden:false,addEventListener(){},removeEventListener(){},createElement:()=>({}),getElementById:()=>({scrollIntoView(){}}),body:{style:{overflow:''}},activeElement:null});
  install('history',{replaceState(a,b,url){window.location=new URL(url,window.location);}});
  const memory=new Map();install('localStorage',{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v)});install('navigator',{onLine:true});
  install('IntersectionObserver',class{observe(){}disconnect(){}});
  install('fetch',async(url,init={})=>{
   requests.push({url,method:init.method||'GET',credentials:init.credentials,cache:init.cache});
   if(url==='/api/me'&&failCheck){failCheck=false;throw Error('Offline fixture');}
   let data;if(url==='/api/auth/logout'){signedIn=false;data={signedIn:false,sessions:[]};}else if(url==='/api/auth/login'){const credentials=JSON.parse(init.body);if(credentials.username!=='fixtureadmin'||credentials.password!=='fixture-password')return new Response(JSON.stringify({error:'Tên đăng nhập hoặc mật khẩu chưa đúng.'}),{status:401,headers:{'Content-Type':'application/json'}});signedIn=true;data={signedIn:true,name:'fixtureadmin',sessions:[]};}else if(url==='/api/library')data={session:library()};else if(url==='/api/collections')data={collections:[{slug:'shelby',name:'Shelby — Late Night',description:'',mood:'LATE NIGHT',accent:'#ff9d3c',count:3,cover:null},{slug:'dopamine-fixture',name:'Dopamine fixture',description:'Euphoric listening',mood:'EUPHORIA',accent:'#ff9d3c',count:1,cover:null,category:'dopamine'},{slug:'active-fixture',name:'Active fixture',description:'Outdoor workout music',mood:'ACTIVE',accent:'#ff9d3c',count:1,cover:null,category:'active'},{slug:'ride-fixture',name:'Ride fixture',description:'Motorcycle music',mood:'RIDE',accent:'#ff9d3c',count:1,cover:null,category:'ride'},{slug:'gaming-fixture',name:'Gaming fixture',description:'Game soundtracks',mood:'GAMING',accent:'#ff9d3c',count:1,cover:null,category:'gaming'},{slug:'tryhard-fixture',name:'Try Hard fixture',description:'Focus music',mood:'FOCUS',accent:'#ff9d3c',count:1,cover:null,category:'tryhard'},{slug:'ai-fixture',name:'Nhạc AI fixture',description:'Ballad and AI cover',mood:'AI BALLAD',accent:'#b9a4da',count:1,cover:null,category:'ai'},{slug:'other',name:'Other playlist',description:'',mood:'INDIE',accent:'#ff9d3c',count:1,cover:null,category:'viet',source:{url:'https://music.youtube.com/playlist?list=OLAK5uy_lzTVK28HYcOzir0qVg-Mxgk2jX8eTNAqw',title:'Original source title',curator:'Source curator',fetchedAt:1792411645351,trackCount:2,unavailableCount:1,duplicateCount:0}}]};else if(url==='/api/me')data={signedIn,name:signedIn?'fixtureadmin':null,sessions:[]};else if(url==='/api/sessions/shelby/tracks'&&init.method==='DELETE'){const id=JSON.parse(init.body).videoId;tracks=tracks.filter(t=>t.videoId!==id);version++;data={session:shelf()};}else if(url==='/api/sessions/shelby')data={session:shelf()};else if(url==='/api/sessions/other')data={session:other()};else throw Error(`Unexpected API ${url}`);return new Response(JSON.stringify(data),{headers:{'Content-Type':'application/json'}});
  });
  const settle=()=>new Promise(resolve=>setImmediate(resolve));
  await act(async()=>{root=create(React.createElement(ListenApp),{createNodeMock:()=>({replaceChildren(){},showModal(){},close(){}})});await settle();await settle();});
  const button=label=>root.root.findAllByType('button').find(n=>n.props['aria-label']===label);
  assert.equal(instances.length,1);assert.ok(!button('Đăng nhập'));assert.ok(!button('Tạo session'));assert.ok(!root.root.findAllByType('a').some(n=>String(n.props.href).includes('/bim')));assert.equal(root.root.findAllByType('input').filter(n=>n.props.type==='password').length,0);
  await act(async()=>root.unmount());instances.length=0;calls.length=0;
  signedIn=true;window.location=new URL('https://listen.example/');
  await act(async()=>{root=create(React.createElement(ListenApp),{createNodeMock:()=>({replaceChildren(){},showModal(){},close(){}})});await settle();await settle();});
  assert.ok(button('Đăng xuất'));assert.ok(button('Tạo session'));assert.ok(!button('Đăng nhập'));
  assert.equal(instances.length,1);const p=instances[0];assert.equal(calls.filter(c=>c[0]==='cue').length,1);
  const onlyDialog=title=>{const dialogs=root.root.findAllByType('dialog');assert.equal(dialogs.length,1,'Only the requested dialog may open');assert.equal(dialogs[0].findByType('h2').children.join(''),title);return dialogs[0];};
  await act(async()=>{root.root.findAllByType('button').find(n=>n.props.className==='button primary'&&n.children.some(c=>c==='Phát tất cả')).props.onClick();await settle();});
  assert.equal(p.state,1);assert.equal(p.id,'RzhIXHc6_80');
  await act(async()=>{root.root.findByType(Turntable).props.onAction('toggle');await settle();});assert.equal(p.state,2);assert.equal(root.root.findByType(Turntable).props.signal.playerState,2);
  await act(async()=>{root.root.findAllByType('button').find(n=>n.props.className?.includes('play-main')).props.onClick();await settle();});assert.equal(p.state,1);
  await act(async()=>{root.root.findAllByType('input').find(n=>n.props['aria-label']==='Tua vị trí phát').props.onChange({target:{value:'83'}});await settle();});assert.equal(p.position,83);assert.equal(root.root.findByType(Turntable).props.signal.progress,83);
  const loads=()=>calls.filter(c=>c[0]==='load').length;
  assert.equal(loads(),1);
  await act(async()=>{button('Tạo session').props.onClick();await settle();});
  const createDialog=onlyDialog('Tạo một phòng nghe');assert.equal(createDialog.findByProps({id:'session-slug'}).props.value,'');
  await act(async()=>{createDialog.findAllByType('button').find(n=>n.children.includes('Hủy')).props.onClick();await settle();});
  assert.equal(root.root.findAllByType('dialog').length,0);assert.ok(!requests.some(r=>r.method==='DELETE'));assert.equal(tracks.length,3);
  assert.equal(instances.length,1);assert.equal(p.position,83);assert.equal(p.state,1);assert.equal(loads(),1);
  await act(async()=>{root.root.findAllByType('button').find(n=>n.props.className?.startsWith('library-item')&&n.findAllByType('strong').some(x=>x.children.includes('Other playlist'))).props.onClick();await settle();});
  assert.equal(window.location.search,'?s=other');assert.equal(p.position,83);assert.equal(p.state,1);assert.equal(loads(),1);assert.equal(instances.length,1);
  const sourceLink=root.root.findAllByType('a').find(n=>n.children.some(c=>c==='Mở playlist gốc'));assert.ok(sourceLink);assert.match(sourceLink.props.href,/^https:\/\/music.youtube.com\/playlist/);assert.equal(sourceLink.props.rel,'noopener noreferrer');
  await act(async()=>{button('Lọc playlist nhạc Việt').props.onClick();await settle();});assert.equal(button('Lọc playlist nhạc Việt').props['aria-pressed'],true);assert.equal(root.root.findAllByType('nav').find(n=>n.props['aria-label']==='Chọn playlist').findAllByType('button').length,1);
  assert.equal(instances.length,1);assert.equal(p.position,83);assert.equal(loads(),1);assert.equal(p.state,1);
  await act(async()=>{button('Lọc playlist Nhạc AI').props.onClick();await settle();});assert.equal(button('Lọc playlist Nhạc AI').props['aria-pressed'],true);
  const aiItems=root.root.findAllByType('nav').find(n=>n.props['aria-label']==='Chọn playlist').findAllByType('button');assert.equal(aiItems.length,1);assert.ok(aiItems[0].findAllByType('strong').some(n=>n.children.includes('Nhạc AI fixture')));assert.equal(instances.length,1);assert.equal(p.position,83);assert.equal(loads(),1);assert.equal(p.state,1);
  await act(async()=>{button('Lọc playlist Try Hard').props.onClick();await settle();});assert.equal(button('Lọc playlist Try Hard').props['aria-pressed'],true);
  const focusItems=root.root.findAllByType('nav').find(n=>n.props['aria-label']==='Chọn playlist').findAllByType('button');assert.equal(focusItems.length,1);assert.ok(focusItems[0].findAllByType('strong').some(n=>n.children.includes('Try Hard fixture')));assert.equal(instances.length,1);assert.equal(p.position,83);assert.equal(loads(),1);assert.equal(p.state,1);
  await act(async()=>{button('Lọc playlist Gaming').props.onClick();await settle();});assert.equal(button('Lọc playlist Gaming').props['aria-pressed'],true);
  const gamingItems=root.root.findAllByType('nav').find(n=>n.props['aria-label']==='Chọn playlist').findAllByType('button');assert.equal(gamingItems.length,1);assert.ok(gamingItems[0].findAllByType('strong').some(n=>n.children.includes('Gaming fixture')));assert.equal(instances.length,1);assert.equal(p.position,83);assert.equal(loads(),1);assert.equal(p.state,1);
  await act(async()=>{button('Lọc playlist Ride · Mô tô').props.onClick();await settle();});assert.equal(button('Lọc playlist Ride · Mô tô').props['aria-pressed'],true);
  const rideItems=root.root.findAllByType('nav').find(n=>n.props['aria-label']==='Chọn playlist').findAllByType('button');assert.equal(rideItems.length,1);assert.ok(rideItems[0].findAllByType('strong').some(n=>n.children.includes('Ride fixture')));assert.equal(instances.length,1);assert.equal(p.position,83);assert.equal(loads(),1);assert.equal(p.state,1);
  await act(async()=>{button('Lọc playlist Active · Thể thao').props.onClick();await settle();});assert.equal(button('Lọc playlist Active · Thể thao').props['aria-pressed'],true);
  const activeItems=root.root.findAllByType('nav').find(n=>n.props['aria-label']==='Chọn playlist').findAllByType('button');assert.equal(activeItems.length,1);assert.ok(activeItems[0].findAllByType('strong').some(n=>n.children.includes('Active fixture')));assert.equal(instances.length,1);assert.equal(p.position,83);assert.equal(loads(),1);assert.equal(p.state,1);
  await act(async()=>{button('Lọc playlist Dopamine').props.onClick();await settle();});assert.equal(button('Lọc playlist Dopamine').props['aria-pressed'],true);
  const dopamineItems=root.root.findAllByType('nav').find(n=>n.props['aria-label']==='Chọn playlist').findAllByType('button');assert.equal(dopamineItems.length,1);assert.ok(dopamineItems[0].findAllByType('strong').some(n=>n.children.includes('Dopamine fixture')));assert.equal(instances.length,1);assert.equal(p.position,83);assert.equal(loads(),1);assert.equal(p.state,1);
  await act(async()=>{button('Lọc tất cả playlist').props.onClick();await settle();});assert.equal(button('Lọc tất cả playlist').props['aria-pressed'],true);

  await act(async()=>{button('Mở hàng phát').props.onClick();await settle();});
  await act(async()=>{button('Đóng hàng phát').props.onClick();await settle();});
  await act(async()=>{root.root.findAllByType('button').find(n=>n.props.className?.startsWith('view-toggle')).props.onClick();await settle();});
  assert.equal(instances.length,1);assert.equal(p.position,83);assert.equal(loads(),1);assert.equal(p.destroyed,undefined);
  await act(async()=>{root.root.findAllByType('button').find(n=>n.props.className?.startsWith('library-item')&&n.findAllByType('strong').some(x=>x.children.includes('Shelby — Late Night'))).props.onClick();await settle();});
  assert.ok(button('Đổi tên session'));assert.ok(button('Xóa session'));assert.ok(button('Xóa Third song'));
  await act(async()=>{await button('Chia sẻ playlist').props.onClick();await settle();});
  const shareDialog=onlyDialog('Liên kết chia sẻ');assert.equal(shareDialog.findByProps({'aria-label':'Liên kết chia sẻ chỉ nghe'}).props.value,'https://listen.example/?s=shelby');
  await act(async()=>{shareDialog.findAllByType('button').find(n=>n.props['aria-label']==='Đóng').props.onClick();await settle();});
  await act(async()=>{button('Đổi tên session').props.onClick();await settle();});
  const renameDialog=onlyDialog('Đổi tên phòng nghe');assert.equal(renameDialog.findByProps({id:'session-name'}).props.value,'Shelby — Late Night');
  await act(async()=>{renameDialog.findAllByType('button').find(n=>n.children.includes('Hủy')).props.onClick();await settle();});
  assert.ok(!requests.some(r=>r.method==='DELETE'));assert.equal(tracks.length,3);assert.equal(p.position,83);assert.equal(loads(),1);
  await act(async()=>{button('Xóa Third song').props.onClick();await settle();await settle();});
  assert.equal(p.position,83);assert.equal(loads(),1);assert.equal(p.state,1);
  await act(async()=>{button('Xóa First song').props.onClick();await settle();await settle();});
  assert.equal(p.id,'_U8S-uFZrHA');assert.equal(loads(),2);assert.equal(instances.length,1);assert.equal(p.state,1);
  await act(async()=>{root.root.findAllByType('button').find(n=>n.props.className?.includes('play-main')).props.onClick();await settle();});assert.equal(p.state,2);
  await act(async()=>{root.root.findAllByType('button').find(n=>n.props.className?.includes('play-main')).props.onClick();await settle();});assert.equal(p.state,1);
  await act(async()=>{await button('Đăng xuất').props.onClick();await settle();await settle();});
  assert.ok(!button('Đăng nhập'));assert.ok(!button('Tạo session'));assert.equal(root.root.findAllByType('form').length,0);assert.equal(p.destroyed,undefined);assert.equal(p.state,1);assert.equal(instances.length,1);
 }finally{
  if(root)await act(async()=>root.unmount());
  for(const [k,descriptor] of original){if(descriptor)Object.defineProperty(globalThis,k,descriptor);else delete globalThis[k];}
 }
});
