import {test} from 'node:test';import assert from 'node:assert/strict';
import {reconcileQueue} from '../.sites-runtime/tests/playback-queue.mjs';
const session=(ids,extra={})=>({slug:'test',name:'Test',tracks:ids.map(videoId=>({videoId})),version:1,canEdit:true,updatedAt:0,...extra});
test('add, rename and reorder preserve current video without a reload',()=>{
 const old=session(['a','b','c']);for(const next of [session(['a','b','c','d']),session(['c','b','a']),session(['a','b','c'],{name:'New name'})]){const r=reconcileQueue(old,next,'b');assert.equal(r.currentId,'b');assert.equal(r.reload,false);assert.equal(r.queue,next);}
});
test('deleting the current video chooses its successor, or previous at the end',()=>{
 const old=session(['a','b','c']);assert.deepEqual(reconcileQueue(old,session(['a','c']),'b').currentId,'c');assert.equal(reconcileQueue(old,session(['a','b']),'c').currentId,'b');assert.equal(reconcileQueue(old,session([]),'b').currentId,null);
});
test('deleting another playlist keeps a surviving aggregate track and listening position',()=>{
 const old=session(['a','b','c'],{slug:'__all__',kind:'all'}),next=session(['b','c'],{slug:'__all__',kind:'all'});const r=reconcileQueue(old,next,'b');assert.equal(r.reload,false);assert.equal(r.currentId,'b');
});
test('changing queue source preserves surviving video even when the old source is removed',()=>{
 const r=reconcileQueue(session(['a','b']),session(['b','c'],{slug:'__all__',kind:'all'}),'b');assert.equal(r.reload,false);assert.equal(r.queue.kind,'all');
});
