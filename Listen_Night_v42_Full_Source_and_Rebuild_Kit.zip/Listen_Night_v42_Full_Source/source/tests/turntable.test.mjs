import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {Box3,Vector3} from 'three';
import {createTurntableModel} from '../.sites-runtime/tests/turntable-model.mjs';
import {initialMotion,stepMotion,motionSettled,NOMINAL_RPM,PARK_ANGLE} from '../.sites-runtime/tests/turntable-motion.mjs';
import ListenApp from '../.sites-runtime/tests/listen-app.mjs';
import {TurntableFallback} from '../.sites-runtime/tests/turntable.mjs';
const signal={videoId:'RzhIXHc6_80',playerState:5,progress:0,duration:200,reducedMotion:false};
function advance(state,patch={},seconds=4){for(let i=0;i<seconds*60;i++)state=stepMotion(state,{...signal,...patch},1/60,i/60);return state;}
test('standby is still; only confirmed YouTube PLAYING accelerates the vinyl',()=>{
 const idle=advance(initialMotion());assert.equal(idle.speed,0);assert.equal(idle.armAngle,PARK_ANGLE);
 const playing=advance(idle,{playerState:1});assert.ok(playing.speed>NOMINAL_RPM*Math.PI*2/60*.99);assert.ok(playing.armLift<.012);assert.ok(playing.armAngle<-.60);
});
test('pause and buffering brake the disc; the needle lifts and waiting light is bounded',()=>{
 const playing=advance(initialMotion(),{playerState:1});
 const paused=advance(playing,{playerState:2},5);assert.equal(paused.speed,0);assert.ok(paused.armLift>.13);assert.ok(motionSettled(paused,{...signal,playerState:2}));
 const buffering=advance(playing,{playerState:3},4);assert.equal(buffering.speed,0);assert.ok(buffering.light>=.2&&buffering.light<=.61);assert.ok(buffering.armLift>.08);
});
test('needle position follows real progress, with finite and clamped positions',()=>{
 const beginning=advance(initialMotion(),{playerState:1,progress:0});
 const end=advance(beginning,{playerState:1,progress:900});assert.ok(Math.abs(end.armAngle+1.07)<.002);
 const invalid=advance(end,{playerState:1,progress:NaN,duration:0});assert.ok(Number.isFinite(invalid.armAngle));assert.ok(Math.abs(invalid.armAngle+.68)<.002);
});
test('track change cues the arm without inventing a playing state',()=>{
 const old=advance(initialMotion(),{playerState:1});const changed=stepMotion(old,{...signal,videoId:'TdrL3QxjyVw',playerState:5},.016,1);
 assert.equal(changed.cue,.48);assert.ok(changed.speed<old.speed);assert.equal(changed.engaged,false);
 const waiting=advance(changed,{videoId:'TdrL3QxjyVw',playerState:5},5);assert.equal(waiting.speed,0);assert.ok(Math.abs(waiting.armAngle-PARK_ANGLE)<.001);
});
test('reduced motion stops spinning and buffering pulse; hidden-tab delta cannot jump rotation',()=>{
 const reduced=advance(initialMotion(),{playerState:1,reducedMotion:true});assert.equal(reduced.speed,0);assert.equal(reduced.rotation,0);
 assert.equal(advance(reduced,{playerState:3,reducedMotion:true}).light,.45);
 const playing=advance(initialMotion(),{playerState:1});const resumed=stepMotion(playing,{...signal,playerState:1},300,300);
 const difference=(resumed.rotation-playing.rotation+Math.PI*2)%(Math.PI*2);assert.ok(difference<.3);
});
test('3D scene contains actual mechanical meshes and exactly three working hit targets',()=>{
 const m=createTurntableModel();for(const name of ['upper-deck','lower-plinth','platter','vinyl','record-label','record-grooves','center-spindle','tonearm','tonearm-tube','counterweight','headshell','stylus','status-led','foot--2.25--1.4'])assert.ok(m.group.getObjectByName(name),name);
 assert.deepEqual(m.actionTargets.map(x=>x.userData.action),['toggle','previous','next']);
 const bounds=new Box3().setFromObject(m.group);assert.ok(bounds.max.x-bounds.min.x<6.2);assert.ok(bounds.max.z-bounds.min.z<4.5);
 let meshes=0;m.group.traverse(o=>{if(o.isMesh)meshes++;});assert.ok(m.resourceCounts.geometry<meshes,'geometries are reused');
 let disposed=0;const g=m.actionTargets[0].geometry;g.addEventListener('dispose',()=>disposed++);m.dispose();m.dispose();assert.equal(disposed,1);
});
test('low-power scene reduces groove detail and keeps controls functional',()=>{
 const full=createTurntableModel(),lite=createTurntableModel({lowPower:true});assert.ok(lite.group.getObjectByName('record-grooves').geometry.attributes.position.count<full.group.getObjectByName('record-grooves').geometry.attributes.position.count);assert.equal(lite.actionTargets.length,3);full.dispose();lite.dispose();
});
test('playing stylus reaches the record surface and travels from lead-in toward the label',()=>{
 const m=createTurntableModel();m.arm.position.y=.288;const tip=m.group.getObjectByName('stylus'),p=new Vector3(),radii=[];
 for(const angle of [-.68,-1.07]){m.arm.rotation.y=angle;m.group.updateMatrixWorld(true);tip.getWorldPosition(p);assert.ok(Math.abs(p.y-.03-(.535+.12+.0125))<.005);radii.push(Math.hypot(p.x+.73,p.z+.13));}
 assert.ok(radii[0]<1.385&&radii[0]>1.2);assert.ok(radii[1]<.75&&radii[1]>.515);m.dispose();
});
test('SVG fallback safely renders actual title and the page keeps a single player surface',()=>{
 const markup=renderToStaticMarkup(createElement(TurntableFallback,{playing:false,title:'<script>alert(1)</script>'}));assert.match(markup,/&lt;script&gt;/);assert.doesNotMatch(markup,/<script>/);assert.match(markup,/role="img"/);
 const app=renderToStaticMarkup(createElement(ListenApp));assert.equal((app.match(/class="player-mount"/g)||[]).length,1);assert.match(app,/aria-label="Tua vị trí phát"/);assert.match(app,/aria-label="Bàn đĩa tương tác"/);assert.match(app,/id="library-panel"/);assert.match(app,/id="queue-panel"/);
});
