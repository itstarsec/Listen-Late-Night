import {test} from 'node:test';
import assert from 'node:assert/strict';
import {D1} from './test-db.mjs';
import {classifyEmbed,classifyApi,probeVideos,recordVerdict,runMaintenance,maintenanceStatus,CONFIRMATION_DELAY} from '../.sites-runtime/tests/video-maintenance.mjs';
import {handleMaintenanceMcp} from '../.sites-runtime/tests/maintenance-mcp.mjs';
import {handleApi} from '../.sites-runtime/tests/api.mjs';
import {createPasswordHash,digest,AUTH_COOKIE} from '../.sites-runtime/tests/auth.mjs';
const ID='abcdefghijk',OTHER='12345678901',THIRD='98765432100';
const page=(id,status,flags={})=>'ytcfg.set('+JSON.stringify({PLAYER_VARS:{video_id:id,embedded_player_response:JSON.stringify({previewPlayabilityStatus:status,videoFlags:flags})}})+');';
const good=id=>page(id,{status:'OK',playableInEmbed:true});
const bad=id=>page(id,{status:'ERROR',errorCode:'PLAYABILITY_ERROR_CODE_EMBEDDING_DISABLED',reason:'Playback on other websites has been disabled by the video owner'});
const failure={outcome:'unavailable',reason:'embedding_disabled',source:'youtube-embed',evidence:'confirmed fixture'};
function insert(db,slug,ids){db.raw.prepare('INSERT INTO sessions (slug,name,owner_id,tracks,version,created_at,updated_at) VALUES (?,?,?,?,1,1,1)').run(slug,'Name '+slug,'__seed__',JSON.stringify(ids.map((videoId,i)=>({videoId,addedAt:100+i}))));}
const tracks=(db,slug)=>JSON.parse(db.raw.prepare('SELECT tracks FROM sessions WHERE slug=?').get(slug).tracks);
function block(db,id){db.raw.prepare('INSERT INTO video_blocks VALUES (?,?,?,?,?)').run(id,'embedding_disabled','fixture','',1);}

test('public embed JSON detects explicit embed-disabled/deleted failures and validates requested ID',()=>{
 assert.equal(classifyEmbed(good(ID),ID).outcome,'available');
 assert.equal(classifyEmbed(bad(ID),ID).reason,'embedding_disabled');
 assert.equal(classifyEmbed(bad(OTHER),ID).outcome,'unknown');
 assert.equal(classifyEmbed(page(ID,{status:'ERROR',reason:'This video is private'}),ID).reason,'deleted_or_private');
 assert.equal(classifyEmbed('<script>throw new Error("do not execute")</script>',ID).outcome,'unknown');
 for(const status of [{status:'ERROR',errorCode:'PLAYABILITY_ERROR_CODE_EMBEDDER_IDENTITY_MISSING_REFERRER',reason:'Error 153'},{status:'LOGIN_REQUIRED',reason:'Sign in to confirm you are not a bot'},{status:'ERROR',reason:'The uploader has not made this video available in your country'},{status:'ERROR',reason:'Video unavailable'},{status:'ERROR',reason:'HTML5 error 5'},{status:'ERROR',errorCode:'REGION_BLOCKED',reason:'This video is no longer available'}])assert.equal(classifyEmbed(page(ID,status),ID).outcome,'unknown');
});
test('official videos.list validates successful envelope and never treats quota/age/region/schedule as deletion',()=>{
 assert.equal(classifyApi({error:{code:403}},[ID]).size,0);
 assert.equal(classifyApi({items:[]},[ID]).size,0);
 const data={kind:'youtube#videoListResponse',items:[{id:ID,status:{embeddable:false}},{id:OTHER,status:{embeddable:true}},{id:THIRD,status:{embeddable:false},contentDetails:{regionRestriction:{blocked:['VN']}}}]};
 const r=classifyApi(data,[ID,OTHER,THIRD,'__missing__']);assert.equal(r.get(ID).reason,'embedding_disabled');assert.equal(r.get(OTHER).outcome,'available');assert.equal(r.get(THIRD).outcome,'unknown');assert.equal(r.get('__missing__').reason,'deleted_or_private');
 assert.equal(classifyApi({kind:data.kind,items:[{id:ID,status:{embeddable:false,publishAt:'2030-01-01'}}]},[ID]).get(ID).outcome,'unknown');
});
test('two failures separated by six hours atomically archive/remove every occurrence and preserve names/order',async()=>{
 const db=new D1();insert(db,'playlist-one',[OTHER,ID,THIRD]);insert(db,'playlist-two',[ID,OTHER]);
 assert.equal(await recordVerdict(db,ID,failure,1000),false);
 assert.equal(await recordVerdict(db,ID,failure,2000),false);assert.equal(tracks(db,'playlist-one').length,3);
 assert.equal(await recordVerdict(db,ID,failure,1000+CONFIRMATION_DELAY),true);
 assert.deepEqual(tracks(db,'playlist-one'),[{videoId:OTHER,addedAt:100},{videoId:THIRD,addedAt:102}]);
 assert.deepEqual(tracks(db,'playlist-two').map(t=>t.videoId),[OTHER]);
 const archive=db.raw.prepare('SELECT * FROM video_removals ORDER BY slug').all();assert.equal(archive.length,2);assert.equal(archive[0].position,1);assert.equal(JSON.parse(archive[0].track).addedAt,101);
 assert.equal(db.raw.prepare('SELECT version FROM sessions WHERE slug=?').get('playlist-one').version,2);
 assert.equal(db.raw.prepare('SELECT name FROM sessions WHERE slug=?').get('playlist-one').name,'Name playlist-one');
 assert.equal(await recordVerdict(db,ID,failure,1000+2*CONFIRMATION_DELAY),false);assert.equal(db.raw.prepare('SELECT COUNT(*) n FROM video_removals').get().n,2);
});
test('unknown, recovery and a different failure reason restart confirmation rather than reusing old evidence',async()=>{
 for(const intermediate of [{outcome:'unknown',reason:'network_or_timeout',source:'youtube-embed'},{outcome:'available',reason:'embed_preview_ok',source:'youtube-embed'},{...failure,reason:'deleted_or_private'}]){
  const db=new D1();insert(db,'playlist-one',[ID]);await recordVerdict(db,ID,failure,1000);await recordVerdict(db,ID,intermediate,1000+CONFIRMATION_DELAY);
  assert.equal(await recordVerdict(db,ID,failure,1001+CONFIRMATION_DELAY),false);assert.equal(tracks(db,'playlist-one').length,1);
 }
});
test('storage triggers prevent blocked videos returning through new rows or stale writes',()=>{
 const db=new D1();block(db,ID);insert(db,'playlist-one',[OTHER,ID,THIRD]);assert.deepEqual(tracks(db,'playlist-one').map(t=>t.videoId),[OTHER,THIRD]);
 db.raw.prepare('UPDATE sessions SET tracks=?,version=version+1 WHERE slug=?').run(JSON.stringify([{videoId:ID,addedAt:4}]),'playlist-one');assert.deepEqual(tracks(db,'playlist-one'),[]);
});
test('confirmed removal rolls back block and archive together when a storage write fails',async()=>{
 const db=new D1();insert(db,'playlist-one',[ID]);await recordVerdict(db,ID,failure,1000);
 db.raw.exec("CREATE TRIGGER fail_removal BEFORE UPDATE ON sessions BEGIN SELECT RAISE(ABORT,'fixture disk error'); END;");
 await assert.rejects(recordVerdict(db,ID,failure,1000+CONFIRMATION_DELAY));assert.equal(tracks(db,'playlist-one').length,1);assert.equal(db.raw.prepare('SELECT COUNT(*) n FROM video_blocks').get().n,0);assert.equal(db.raw.prepare('SELECT COUNT(*) n FROM video_removals').get().n,0);
});
test('checker uses only validated official YouTube URLs, bounded concurrency and unknown fallback for network/429',async()=>{
 const original=globalThis.fetch;let concurrent=0,max=0,calls=0;
 globalThis.fetch=async(url,options)=>{if(options.redirect==='error')throw new TypeError('Invalid redirect value on Cloudflare');calls++;assert.equal(url.origin,'https://www.youtube.com');assert.equal(options.headers.Referer,'https://listen.test/');concurrent++;max=Math.max(max,concurrent);await new Promise(r=>setTimeout(r,4));concurrent--;const id=url.pathname.split('/').at(-1);return id===THIRD?new Response('',{status:429}):new Response(good(id));};
 try{await assert.rejects(probeVideos(['not-valid'],{},'https://listen.test'));assert.equal(calls,0);const r=await probeVideos([ID,OTHER,THIRD],{},'https://listen.test');assert.equal(max,2);assert.equal(r.get(ID).outcome,'available');assert.equal(r.get(THIRD).outcome,'unknown');}finally{globalThis.fetch=original;}
});
test('night batches deduplicate IDs, persist results, prioritize suspects and respect daily budget and overlap lock',async()=>{
 const db=new D1();insert(db,'playlist-one',[ID,OTHER,THIRD]);insert(db,'playlist-two',[ID]);db.raw.prepare('INSERT INTO video_checks (video_id,reported_at) VALUES (?,1)').run(ID);const original=globalThis.fetch;
 globalThis.fetch=async url=>new Response(url.pathname.endsWith(ID)?bad(ID):good(url.pathname.split('/').at(-1)));
 try{
  const now=1793420000000;const r=await runMaintenance({DB:db},'https://listen.test',{limit:2,now});assert.equal(r.checked,2);assert.equal(r.pending,1);assert.equal(r.removed,0);
  const follow=await runMaintenance({DB:db},'https://listen.test',{limit:1,now:now+CONFIRMATION_DELAY});assert.equal(follow.removed,1);assert.ok(!tracks(db,'playlist-one').some(t=>t.videoId===ID));
  const status=await maintenanceStatus(db);assert.equal(status.counts.blocked,1);assert.equal(status.blocked[0].removed_from_playlists,2);assert.ok(status.lastRun.finished_at);
  db.raw.prepare('INSERT INTO maintenance_locks VALUES (?,?,?)').run('videos','fixture',now+99*CONFIRMATION_DELAY);assert.equal((await runMaintenance({DB:db},'https://listen.test',{now})).status,'busy');db.raw.exec('DELETE FROM maintenance_locks');
  const day=new Date(now+7*3600000).toISOString().slice(0,10);db.raw.prepare('UPDATE maintenance_daily SET checked=360 WHERE day=?').run(day);assert.equal((await runMaintenance({DB:db},'https://listen.test',{now})).status,'daily_limit');
 }finally{globalThis.fetch=original;}
});
test('MCP tools require configured verified owner identity, not public access or unconfigured first caller',async()=>{
 const env={DB:new D1(),MAINTENANCE_OWNER_EMAIL:'owner@example.test'};
 const req=(method,headers={},name='video_maintenance_status')=>new Request('https://listen.test/mcp',{method:'POST',headers,body:JSON.stringify({jsonrpc:'2.0',id:1,method,params:{name,arguments:{}}})});
 assert.equal((await handleMaintenanceMcp(req('tools/list'),env)).status,200);
 for(const headers of [{},{'oai-authenticated-user-id':'visitor','oai-authenticated-user-email':'visitor@example.test'},{'oai-authenticated-user-email':'owner@example.test'}])assert.equal((await handleMaintenanceMcp(req('tools/call',headers),env)).status,403);
 const owner={'oai-authenticated-user-id':'scoped-owner','oai-authenticated-user-email':'OWNER@example.test'};assert.equal((await handleMaintenanceMcp(req('tools/call',owner),env)).status,200);assert.equal((await handleMaintenanceMcp(req('tools/call',owner),{DB:env.DB})).status,403);
});
test('seed initialization cannot resurrect a blocked ID, including full-replacement baby playlist',async()=>{
 const env={DB:new D1()};block(env.DB,'377o0R09Y0U');const r=await handleApi(new Request('https://listen.test/api/sessions/be-ngu-ngoan'),env);assert.equal(r.status,200);assert.deepEqual((await r.json()).session.tracks,[]);
 const again=await handleApi(new Request('https://listen.test/api/sessions/be-ngu-ngoan'),env);assert.deepEqual((await again.json()).session.tracks,[]);
});
test('public player reports only prioritize existing IDs; cannot force removal or report 153/network errors',async()=>{
 const env={DB:new D1()};insert(env.DB,'playlist-one',[ID]);
 const report=(id,code)=>handleApi(new Request('https://listen.test/api/video-reports',{method:'POST',headers:{Origin:'https://listen.test','Content-Type':'application/json'},body:JSON.stringify({videoId:id,code})}),env);
 assert.equal((await report(ID,153)).status,400);assert.equal((await report(ID,101)).status,200);assert.equal((await report(OTHER,100)).status,200);
 assert.equal(env.DB.raw.prepare('SELECT failures FROM video_checks WHERE video_id=?').get(ID).failures,0);assert.equal(env.DB.raw.prepare('SELECT COUNT(*) n FROM video_checks').get().n,1);assert.equal(tracks(env.DB,'playlist-one').length,1);
 assert.equal((await handleApi(new Request('https://listen.test/api/admin/maintenance'),env)).status,401);
});
test('authenticated URL and file imports skip blocked IDs, retain valid order and return truthful counts',async()=>{
 const db=new D1(),username='fixtureadmin',hash=await createPasswordHash('fixture'),token='b'.repeat(43);const env={DB:db,AUTH_USERNAME:username,AUTH_PASSWORD_HASH:hash};
 db.raw.prepare('INSERT INTO auth_sessions VALUES (?,?,?,?,?)').run(await digest(token),username,await digest(`listen-auth-v1\0${username}\0${hash}`),Date.now(),Date.now()+86400000);
 const request=async(path,method,body,version)=>{const r=await handleApi(new Request('https://listen.test/api'+path,{method,headers:{Cookie:`${AUTH_COOKIE}=${token}`,Origin:'https://listen.test','Content-Type':'application/json','X-Request-ID':crypto.randomUUID(),...(version?{'If-Match':String(version)}:{})},body:body?JSON.stringify(body):undefined}),env);assert.ok(r.ok,await r.clone().text());return r.json();};
 let s=(await request('/sessions','POST',{slug:'my-playlist',name:'Mine'})).session;block(db,ID);
 const add=await request('/sessions/my-playlist/tracks','POST',{text:ID+'\n'+OTHER+'\n'+ID+'\nbad'},s.version);s=add.session;assert.equal(add.report.added,1);assert.equal(add.report.blocked,1);assert.equal(add.report.duplicates,1);assert.equal(add.report.invalid,1);assert.deepEqual(s.tracks.map(t=>t.videoId),[OTHER]);
 const file=await request('/admin/import','POST',{target:{kind:'existing',slug:s.slug,version:s.version},fileName:'list.txt',text:ID+'\n'+THIRD});assert.equal(file.report.blocked,1);assert.equal(file.report.added,1);assert.deepEqual(file.session.tracks.map(t=>t.videoId),[OTHER,THIRD]);
});
