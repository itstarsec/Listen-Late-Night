import {test} from 'node:test';
import assert from 'node:assert/strict';
import {handleApi} from '../.sites-runtime/tests/api.mjs';
import {createPasswordHash,verifyPassword,AUTH_COOKIE,LOCAL_ACCOUNT_ID,SESSION_TTL} from '../.sites-runtime/tests/auth.mjs';
import {D1} from './test-db.mjs';
import {spawnSync} from 'node:child_process';
const username='fixtureadmin',password='fixture-password-for-tests',hash=await createPasswordHash(password);
const env=()=>({DB:new D1(),AUTH_USERNAME:username,AUTH_PASSWORD_HASH:hash});
async function call(e,path,method='GET',data,headers={}){
 const response=await handleApi(new Request('https://listen.test/api'+path,{method,headers:{...(method!=='GET'?{'Origin':'https://listen.test','Content-Type':'application/json'}:{}),...headers},body:data===undefined?undefined:JSON.stringify(data)}),e);
 return {status:response.status,data:await response.json(),cookie:response.headers.get('set-cookie'),headers:response.headers};
}
const login=(e,headers={})=>call(e,'/auth/login','POST',{username,password},headers);
const credential=r=>({cookie:r.cookie.split(';')[0]});
test('password hashes are salted, verifiable and reject a different password',async()=>{const other=await createPasswordHash(password);assert.notEqual(other,hash);assert.equal(await verifyPassword(password,hash),true);assert.equal(await verifyPassword('incorrect fixture',hash),false);assert.equal(await verifyPassword(password,'invalid'),false);});
test('password login creates an HttpOnly secure session; reload, another device and playlist permissions work',async()=>{
 const e=env(),a=await login(e);assert.equal(a.status,200);assert.equal(a.data.name,username);for(const flag of ['HttpOnly','Secure','SameSite=Lax','Path=/','Max-Age=604800'])assert.ok(a.cookie.includes(flag));assert.ok(a.cookie.startsWith(AUTH_COOKIE+'='));
 const row=e.DB.raw.prepare('SELECT * FROM auth_sessions').get();assert.ok(row);assert.equal(row.username,username);assert.equal(row.token_hash.length,64);assert.ok(!JSON.stringify(row).includes(password));assert.ok(!JSON.stringify(row).includes(a.cookie.split('=')[1].split(';')[0]));assert.ok(Math.abs(row.expires_at-row.created_at-SESSION_TTL)<2);
 assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.signedIn,true);assert.equal((await call(e,'/me')).data.signedIn,false);
 const b=await login(e);assert.notEqual(a.cookie,b.cookie);assert.equal((await call(e,'/me','GET',undefined,credential(b))).data.signedIn,true);
 let r=await call(e,'/sessions','POST',{slug:'password-room',name:'Password room'},{...credential(a),'X-Request-ID':'auth-create-test'});assert.equal(r.status,201);assert.equal(r.data.session.canEdit,true);
 assert.equal(e.DB.raw.prepare("SELECT owner_id FROM sessions WHERE slug='password-room'").get().owner_id,LOCAL_ACCOUNT_ID);
 r=await call(e,'/sessions/password-room');assert.equal(r.status,200);assert.equal(r.data.session.canEdit,false);
 r=await call(e,'/sessions/shelby','GET',undefined,credential(b));assert.equal(r.data.session.canEdit,true);
});
test('incorrect credentials fail uniformly and ChatGPT identity headers no longer log a user in',async()=>{
 const e=env();let message;
 for(const data of [{username,password:'bad fixture'},{username:'missing-user',password}]){const r=await call(e,'/auth/login','POST',data);assert.equal(r.status,401);assert.equal(r.cookie,null);if(message)assert.equal(r.data.error,message);message=r.data.error;}
 const forged={'oai-authenticated-user-id':LOCAL_ACCOUNT_ID,'oai-authenticated-user-email':'owner@example.test'};
 assert.equal((await call(e,'/me','GET',undefined,forged)).data.signedIn,false);assert.equal((await call(e,'/sessions','POST',{slug:'forged-room'},forged)).status,401);
 for(const data of [null,[],{username,password:''},{username:'x'.repeat(65),password}])assert.equal((await call(e,'/auth/login','POST',data)).status,400);
});
test('logout revokes the server-side token and clears the cookie without affecting another device',async()=>{
 const e=env(),a=await login(e),b=await login(e);
 const r=await call(e,'/auth/logout','POST',undefined,credential(a));assert.equal(r.status,200);assert.ok(r.cookie.includes('Max-Age=0'));
 assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.signedIn,false);assert.equal((await call(e,'/me','GET',undefined,credential(b))).data.signedIn,true);
 assert.equal((await call(e,'/auth/logout','POST',undefined,credential(a))).status,200);
});
test('expired, forged, malformed and duplicate session cookies cannot authenticate',async()=>{
 const e=env(),r=await login(e),auth=credential(r);e.DB.raw.prepare('UPDATE auth_sessions SET expires_at=?').run(Date.now()-1);
 for(const headers of [auth,{cookie:`${AUTH_COOKIE}=${'z'.repeat(43)}`},{cookie:`${AUTH_COOKIE}=invalid`},{cookie:auth.cookie+'; '+auth.cookie}])assert.equal((await call(e,'/me','GET',undefined,headers)).data.signedIn,false);
 assert.equal((await call(e,'/sessions','POST',{slug:'expired-room'},auth)).status,401);
});
test('login rotates a previous token and changing the configured password invalidates existing sessions',async()=>{
 const e=env(),a=await login(e),b=await login(e,credential(a));assert.notEqual(a.cookie,b.cookie);
 assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.signedIn,false);assert.equal((await call(e,'/me','GET',undefined,credential(b))).data.signedIn,true);
 e.AUTH_PASSWORD_HASH=await createPasswordHash('new-fixture-password');assert.equal((await call(e,'/me','GET',undefined,credential(b))).data.signedIn,false);assert.equal((await login(e)).status,401);
 assert.equal((await call(e,'/auth/login','POST',{username,password:'new-fixture-password'})).status,200);
});
test('login attempts are rate-limited per IP and across the account',async()=>{
 const e=env();for(let i=0;i<10;i++)assert.equal((await call(e,'/auth/login','POST',{username,password:'wrong fixture'},{'cf-connecting-ip':'192.0.2.10'})).status,401);
 let r=await login(e,{'cf-connecting-ip':'192.0.2.10'});assert.equal(r.status,429);assert.ok(Number(r.headers.get('retry-after'))>0);
 e.DB.raw.prepare("UPDATE limits SET count=50 WHERE key LIKE 'login-account:%'").run();r=await login(e,{'cf-connecting-ip':'192.0.2.11'});assert.equal(r.status,429);assert.equal(e.DB.raw.prepare('SELECT COUNT(*) AS n FROM auth_sessions').get().n,0);
});
test('authentication and playlist writes reject cross-origin requests and login is POST-only',async()=>{
 const e=env();assert.equal((await call(e,'/auth/login')).status,405);
 for(const headers of [{Origin:'https://evil.test'},{Origin:''},{Origin:'https://listen.test','sec-fetch-site':'cross-site'}])assert.equal((await login(e,headers)).status,403);
 const a=await login(e);assert.equal((await call(e,'/auth/logout','POST',undefined,{...credential(a),Origin:'https://evil.test'})).status,403);assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.signedIn,true);
 assert.equal((await call(e,'/sessions','POST',{slug:'cross-origin'},{...credential(a),Origin:'https://evil.test'})).status,403);
});
test('configured public proxy origin supports login, playlist management, reload and logout without changing existing playlists',async()=>{
 const e={...env(),APP_ALLOWED_ORIGINS:'https://nh4c.pages.dev'},proxy={Origin:'https://nh4c.pages.dev','sec-fetch-site':'same-origin'};
 await call(e,'/collections');const saved=()=>e.DB.raw.prepare('SELECT * FROM sessions ORDER BY slug').all(),before=saved();
 const a=await login(e,proxy);assert.equal(a.status,200);assert.ok(a.cookie.includes('HttpOnly'));assert.ok(!a.cookie.includes('Domain='));assert.deepEqual(saved(),before);
 const auth={...proxy,...credential(a)};
 assert.equal((await call(e,'/me','GET',undefined,auth)).data.signedIn,true);
 const shelby=await call(e,'/sessions/shelby','GET',undefined,auth);assert.equal(shelby.data.session.canEdit,true);assert.equal(shelby.data.session.tracks.length,25);
 let r=await call(e,'/sessions','POST',{slug:'proxy-room',name:'Proxy room'},{...auth,'X-Request-ID':'proxy-create'});assert.equal(r.status,201);
 r=await call(e,'/sessions/proxy-room/tracks','POST',{text:'RzhIXHc6_80\n_U8S-uFZrHA'},{...auth,'If-Match':String(r.data.session.version),'X-Request-ID':'proxy-add-tracks'});assert.equal(r.status,200);assert.equal(r.data.report.added,2);
 r=await call(e,'/sessions/proxy-room','PATCH',{name:'Playlist đã đổi tên'},{...auth,'If-Match':String(r.data.session.version),'X-Request-ID':'proxy-rename'});assert.equal(r.status,200);
 r=await call(e,'/sessions/proxy-room/order','PATCH',{ids:['_U8S-uFZrHA','RzhIXHc6_80']},{...auth,'If-Match':String(r.data.session.version),'X-Request-ID':'proxy-reorder'});assert.equal(r.status,200);
 const reloaded=await call(e,'/sessions/proxy-room','GET',undefined,auth);assert.equal(reloaded.data.session.name,'Playlist đã đổi tên');assert.deepEqual(reloaded.data.session.tracks.map(t=>t.videoId),['_U8S-uFZrHA','RzhIXHc6_80']);
 r=await call(e,'/sessions/proxy-room','DELETE',undefined,{...auth,'If-Match':String(r.data.session.version),'X-Request-ID':'proxy-remove-fixture'});assert.equal(r.status,200);assert.deepEqual(saved(),before);
 r=await call(e,'/auth/logout','POST',undefined,auth);assert.equal(r.status,200);assert.ok(r.cookie.includes('Max-Age=0'));assert.equal((await call(e,'/me','GET',undefined,auth)).data.signedIn,false);assert.deepEqual(saved(),before);
 assert.equal((await login(e)).status,200);
});
test('proxy aliases must be configured as exact HTTPS origins; forwarding headers and unlisted origins cannot authorize writes',async()=>{
 const e=env(),proxy={Origin:'https://nh4c.pages.dev','sec-fetch-site':'same-origin','x-forwarded-host':'nh4c.pages.dev','x-proxied-by':'cloudflare-pages','cf-worker':'nh4c.pages.dev'};
 assert.equal((await login(e,proxy)).status,403);
 e.APP_ALLOWED_ORIGINS='*, https://*.pages.dev, http://nh4c.pages.dev, https://nh4c.pages.dev/path, https://user:pass@nh4c.pages.dev';assert.equal((await login(e,proxy)).status,403);
 e.APP_ALLOWED_ORIGINS=' https://nh4c.pages.dev , https://second.example ';
 for(const Origin of ['https://nh4c.pages.dev.evil.test','https://sub.nh4c.pages.dev','http://nh4c.pages.dev','https://nh4c.pages.dev:444','null',''])assert.equal((await login(e,{...proxy,Origin})).status,403);
 assert.equal((await login(e,{...proxy,'sec-fetch-site':'cross-site'})).status,403);
 const a=await login(e,proxy);assert.equal(a.status,200);
 for(const Origin of ['https://evil.test','https://other.pages.dev']){
  assert.equal((await call(e,'/sessions','POST',{slug:'untrusted-room'},{...proxy,...credential(a),Origin,'X-Request-ID':'untrusted-origin'})).status,403);
  assert.equal((await call(e,'/auth/logout','POST',undefined,{...proxy,...credential(a),Origin})).status,403);
 }
 assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.signedIn,true);
 assert.equal((await call(e,'/sessions/shelby')).data.session.canEdit,false);
});
test('missing authentication configuration fails closed while public listening stays available',async()=>{
 const e={DB:new D1()};assert.equal((await login(e)).status,503);assert.equal((await call(e,'/me')).data.signedIn,false);assert.equal((await call(e,'/sessions/shelby')).status,200);
});
test('local account does not claim sessions owned by an unrelated legacy account',async()=>{
 const e=env(),a=await login(e),now=Date.now();e.DB.raw.prepare('INSERT INTO sessions (slug,name,owner_id,tracks,version,created_at,updated_at) VALUES (?,?,?,?,1,?,?)').run('legacy-other','Other account','unrelated-legacy-account','[]',now,now);
 const r=await call(e,'/sessions/legacy-other','GET',undefined,credential(a));assert.equal(r.data.session.canEdit,false);
 assert.equal((await call(e,'/sessions/legacy-other','PATCH',{name:'bad'},{...credential(a),'If-Match':'1','X-Request-ID':'cannot-claim'})).status,403);
});

test('operator hash utility matches the server verifier without exposing a plaintext password in its output',async()=>{
 const r=spawnSync(process.execPath,['scripts/hash-password.mjs','--json-stdin'],{input:JSON.stringify({password})+'\n',encoding:'utf8'});
 assert.equal(r.status,0,r.stderr);const output=JSON.parse(r.stdout);assert.equal(await verifyPassword(password,output.password_hash),true);assert.ok(!r.stdout.includes(password));
});

const extraUsername='secondadmin',extraPassword='second-fixture-password',extraHash=await createPasswordHash(extraPassword);
const extraConfig=(passwordHash=extraHash)=>JSON.stringify([{username:extraUsername,passwordHash}]);
const extraLogin=(e,headers={})=>call(e,'/auth/login','POST',{username:extraUsername,password:extraPassword},headers);
test('adding an administrator preserves original sessions, playlists and independent login identities',async()=>{
 const e=env(),a=await login(e);await call(e,'/collections');
 const saved=()=>e.DB.raw.prepare('SELECT * FROM sessions ORDER BY slug').all(),before=saved();
 e.AUTH_ADDITIONAL_ADMINS=extraConfig();
 assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.name,username);
 const b=await call(e,'/auth/login','POST',{username:'  SECONDADMIN  ',password:extraPassword});assert.equal(b.status,200);assert.equal(b.data.name,extraUsername);assert.notEqual(a.cookie,b.cookie);
 assert.equal((await call(e,'/me','GET',undefined,credential(b))).data.name,extraUsername);
 assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.signedIn,true);
 assert.equal((await login(e)).status,200);assert.deepEqual(saved(),before);
 const accounts=e.DB.raw.prepare('SELECT username,credential_tag FROM auth_sessions ORDER BY username').all();
 assert.equal(accounts.length,3);assert.equal(new Set(accounts.map(r=>r.credential_tag)).size,2);
 assert.ok(!JSON.stringify(accounts).includes(extraPassword));assert.ok(!JSON.stringify(accounts).includes(extraHash));
 await call(e,'/auth/logout','POST',undefined,credential(b));
 assert.equal((await call(e,'/me','GET',undefined,credential(b))).data.signedIn,false);
 assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.signedIn,true);assert.deepEqual(saved(),before);
});
test('additional administrators can manage seeded playlists and playlists created by either administrator',async()=>{
 const e={...env(),AUTH_ADDITIONAL_ADMINS:extraConfig()},a=await login(e),b=await extraLogin(e),authA=credential(a),authB=credential(b);
 const admin=await call(e,'/admin/playlists','GET',undefined,authB);assert.equal(admin.status,200);assert.equal(admin.data.user.name,extraUsername);assert.ok(admin.data.playlists.some(p=>p.slug==='shelby'));
 const seed=await call(e,'/sessions/shelby','GET',undefined,authB);assert.equal(seed.data.session.canEdit,true);
 let r=await call(e,'/sessions/shelby','PATCH',{name:'Shared seeded playlist'},{...authB,'If-Match':String(seed.data.session.version),'X-Request-ID':'extra-seed-rename'});assert.equal(r.status,200);assert.equal(r.data.session.name,'Shared seeded playlist');
 const original=await call(e,'/sessions','POST',{slug:'primary-shared',name:'Primary shared'},authA);assert.equal(original.status,201);
 assert.equal((await call(e,'/sessions/primary-shared','GET',undefined,authB)).data.session.canEdit,true);
 r=await call(e,'/sessions','POST',{slug:'second-shared',name:'Second shared'},authB);assert.equal(r.status,201);
 assert.equal(e.DB.raw.prepare("SELECT owner_id FROM sessions WHERE slug='second-shared'").get().owner_id,LOCAL_ACCOUNT_ID);
 const write=(headers,id)=>({...headers,'If-Match':String(r.data.session.version),'X-Request-ID':id});
 r=await call(e,'/sessions/second-shared/tracks','POST',{text:'RzhIXHc6_80\n_U8S-uFZrHA'},write(authA,'shared-add-tracks'));assert.equal(r.status,200);assert.equal(r.data.report.added,2);
 r=await call(e,'/sessions/second-shared/order','PATCH',{ids:['_U8S-uFZrHA','RzhIXHc6_80']},write(authB,'shared-reorder'));assert.equal(r.status,200);assert.deepEqual(r.data.session.tracks.map(t=>t.videoId),['_U8S-uFZrHA','RzhIXHc6_80']);
 r=await call(e,'/sessions/second-shared','PATCH',{name:'Shared editing'},write(authA,'shared-rename'));assert.equal(r.status,200);assert.equal(r.data.session.name,'Shared editing');
 r=await call(e,'/sessions/second-shared/tracks','DELETE',{videoId:'_U8S-uFZrHA'},write(authB,'shared-remove-track'));assert.equal(r.status,200);assert.equal(r.data.session.tracks.length,1);
 const personal=(await call(e,'/admin/playlists','GET',undefined,authA)).data.playlists.find(p=>p.slug==='second-shared');assert.equal(personal.name,'Shared editing');
 assert.equal((await call(e,'/sessions/second-shared','PATCH',{name:'Anonymous write'},{'If-Match':String(r.data.session.version),'X-Request-ID':'anonymous-edit'})).status,403);
 r=await call(e,'/sessions/second-shared','DELETE',undefined,write(authB,'shared-delete-playlist'));assert.equal(r.status,200);
 assert.equal((await call(e,'/sessions/second-shared')).status,404);
 const now=Date.now();e.DB.raw.prepare('INSERT INTO sessions (slug,name,owner_id,tracks,version,created_at,updated_at) VALUES (?,?,?,?,1,?,?)').run('unrelated-legacy','Legacy','unrelated-owner','[]',now,now);
 assert.equal((await call(e,'/sessions/unrelated-legacy','GET',undefined,authB)).data.session.canEdit,false);
 assert.equal((await call(e,'/sessions/unrelated-legacy','DELETE',undefined,{...authB,'If-Match':'1','X-Request-ID':'extra-no-claim'})).status,403);
});
test('rotating or removing one extra account invalidates only that account sessions',async()=>{
 const e={...env(),AUTH_ADDITIONAL_ADMINS:extraConfig()},a=await login(e),b=await extraLogin(e);
 e.AUTH_ADDITIONAL_ADMINS=extraConfig(await createPasswordHash('rotated-extra-fixture'));
 assert.equal((await call(e,'/me','GET',undefined,credential(b))).data.signedIn,false);
 assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.signedIn,true);
 assert.equal((await extraLogin(e)).status,401);
 const c=await call(e,'/auth/login','POST',{username:extraUsername,password:'rotated-extra-fixture'});assert.equal(c.status,200);
 e.AUTH_ADDITIONAL_ADMINS='[]';assert.equal((await call(e,'/me','GET',undefined,credential(c))).data.signedIn,false);
 assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.signedIn,true);assert.equal((await extraLogin(e)).status,401);
});
test('extra accounts reject wrong or mixed credentials uniformly and keep login limits',async()=>{
 const e={...env(),AUTH_ADDITIONAL_ADMINS:extraConfig()};let message;
 const data=[{username:extraUsername,password},{username,password:extraPassword},{username:'missing-account',password},{username:'missing-account',password:extraPassword}];
 for(let i=0;i<10;i++){
  const r=await call(e,'/auth/login','POST',data[i%data.length],{'cf-connecting-ip':'192.0.2.20'});assert.equal(r.status,401);assert.equal(r.cookie,null);if(message)assert.equal(r.data.error,message);message=r.data.error;
 }
 assert.equal((await extraLogin(e,{'cf-connecting-ip':'192.0.2.20'})).status,429);
 assert.equal((await extraLogin(e,{'cf-connecting-ip':'192.0.2.21'})).status,200);
});
test('malformed, duplicate and oversized extra-account configuration fails closed without affecting public access',async()=>{
 const e=env(),a=await login(e);
 const invalid=['bad json','null','{}','[null]',JSON.stringify([{username:'bad name',passwordHash:extraHash}]),JSON.stringify([{username:extraUsername,passwordHash:'plaintext'}]),JSON.stringify([{username:username.toUpperCase(),passwordHash:extraHash}]),JSON.stringify([{username:extraUsername,passwordHash:extraHash},{username:extraUsername.toUpperCase(),passwordHash:extraHash}]),JSON.stringify(Array.from({length:21},(_,i)=>({username:`admin${i}`,passwordHash:extraHash})))];
 for(const value of invalid){e.AUTH_ADDITIONAL_ADMINS=value;assert.equal((await login(e)).status,503);assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.signedIn,false);}
 assert.equal((await call(e,'/sessions/shelby')).status,200);
 e.AUTH_ADDITIONAL_ADMINS='';assert.equal((await call(e,'/me','GET',undefined,credential(a))).data.signedIn,true);
});
