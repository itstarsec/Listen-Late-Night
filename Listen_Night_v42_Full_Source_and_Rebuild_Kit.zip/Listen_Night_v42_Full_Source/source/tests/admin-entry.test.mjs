import {test} from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import {create,act} from 'react-test-renderer';
import AdminEntry from '../.sites-runtime/tests/admin-entry.mjs';
import AdminDashboard from '../.sites-runtime/tests/admin-dashboard.mjs';

const catalogue={playlists:[],stats:{playlists:0,entries:0,uniqueTracks:0},user:{name:'fixtureadmin'}};
const canonical='https://listen.test';
async function environment(url,fetcher,run,{framed=false}={}){
 const original=new Map(['window','history','document','fetch','localStorage','IS_REACT_ACT_ENVIRONMENT'].map(k=>[k,Object.getOwnPropertyDescriptor(globalThis,k)]));
 const install=(key,value)=>Object.defineProperty(globalThis,key,{value,writable:true,configurable:true});
 let root;const destinations=[],location=new URL(url);location.replace=value=>destinations.push(value);
 const browser={location};browser.self=browser;browser.top=framed?{}:browser;
 const settle=async()=>{for(let i=0;i<4;i++)await new Promise(resolve=>setImmediate(resolve));};
 try{
  install('IS_REACT_ACT_ENVIRONMENT',true);install('window',browser);install('history',{replaceState(a,b,url){browser.location=new URL(url,browser.location);}});install('document',{body:{style:{}},activeElement:null});install('fetch',fetcher);
  install('localStorage',{getItem(){throw Error('Authentication must not use localStorage');},setItem(){throw Error('Authentication must not store passwords or tokens in localStorage');}});
  const mount=async(strict=false)=>{await act(async()=>{const element=React.createElement(AdminEntry,{canonicalOriginBase64:btoa(canonical)});root=create(strict?React.createElement(React.StrictMode,null,element):element,{createNodeMock:()=>({showModal(){},close(){}})});await settle();});};
  const unmount=async()=>{if(root)await act(async()=>{root.unmount();await settle();});root=null;};
  await run({mount,unmount,get root(){return root;},destinations,settle});
 }finally{
  if(root)await act(async()=>{root.unmount();await settle();});
  for(const [key,descriptor] of original){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}
 }
}

test('proxy admin redirects to the configured direct origin before requesting or accepting credentials; only playlist context is carried',async()=>{
 const requests=[];
 await environment('https://proxy.example/bim?s=shelby&next=https://untrusted.example',async url=>{requests.push(url);return Response.json({signedIn:false});},async context=>{
  await context.mount();assert.deepEqual(context.destinations,['https://listen.test/bim?s=shelby']);assert.equal(requests.length,0);assert.equal(context.root.root.findAllByType('form').length,0);
  const direct=context.root.root.findAllByType('a').find(n=>n.children.includes('Mở trang quản trị'));assert.equal(direct.props.href,'https://listen.test/bim?s=shelby');assert.equal(direct.props.target,'_blank');
 });
});

test('framed admin offers a direct first-party tab instead of submitting credentials inside the frame',async()=>{
 let calls=0;
 await environment('https://listen.test/bim?view=tracks',async()=>{calls++;return Response.json({signedIn:false});},async context=>{
  await context.mount();assert.equal(calls,0);assert.deepEqual(context.destinations,[]);assert.equal(context.root.root.findAllByType('form').length,0);
  const direct=context.root.root.findAllByType('a').find(n=>n.children.includes('Mở trang quản trị'));assert.equal(direct.props.href,'https://listen.test/bim?view=tracks');assert.equal(direct.props.rel,'noopener noreferrer');
 },{framed:true});
});

test('successful password response without a returned cookie stays on the form with an explanation; restored cookies survive verification and reload',async()=>{
 let dropCookies=true,signedIn=false,logins=0,logouts=0,adminCalls=0;const verification=[];
 const fetcher=async(url,init={})=>{
  const parsed=new URL(url,canonical);
  assert.equal(init.credentials,'same-origin');assert.equal(init.cache,'no-store');
  if(parsed.pathname==='/api/me'){if(parsed.searchParams.has('verify'))verification.push(parsed.searchParams.get('verify'));return Response.json({signedIn});}
  if(parsed.pathname==='/api/auth/login'){logins++;signedIn=!dropCookies;return Response.json({signedIn:true});}
  if(parsed.pathname==='/api/auth/logout'){logouts++;signedIn=false;return Response.json({signedIn:false});}
  if(parsed.pathname==='/api/admin/playlists'){adminCalls++;return Response.json(catalogue);}
  throw Error('Unexpected auth fixture request');
 };
 await environment('https://listen.test/bim',fetcher,async context=>{
  await context.mount();assert.deepEqual(context.destinations,[]);
  const fill=async()=>act(async()=>{context.root.root.findByProps({id:'admin-username'}).props.onChange({target:{value:'fixtureadmin'}});context.root.root.findByProps({id:'admin-password'}).props.onChange({target:{value:'fixture-password'}});});
  const submit=async()=>act(async()=>{await context.root.root.findByType('form').props.onSubmit({preventDefault(){}});await context.settle();});
  await fill();await submit();assert.equal(logins,1);assert.equal(logouts,0);assert.equal(adminCalls,0);assert.equal(verification.length,1);assert.equal(context.root.root.findAllByType(AdminDashboard).length,0);assert.equal(context.root.root.findByProps({id:'admin-password'}).props.value,'');assert.ok(JSON.stringify(context.root.toJSON()).includes('Trình duyệt chưa giữ được phiên đăng nhập.'));
  dropCookies=false;await fill();await submit();assert.equal(context.root.root.findAllByType(AdminDashboard).length,1);assert.equal(logouts,0);assert.equal(verification.length,2);assert.notEqual(verification[0],verification[1]);
  await context.unmount();await context.mount();assert.equal(context.root.root.findAllByType(AdminDashboard).length,1);assert.equal(logins,2);
  await act(async()=>{await context.root.root.findAllByType('button').find(n=>n.props['aria-label']==='Đăng xuất').props.onClick();await context.settle();});assert.equal(logouts,1);assert.equal(context.root.root.findAllByType('form').length,1);
 });
});

test('an aborted session check returning late cannot overwrite a newly verified login',async()=>{
 let signedIn=false,checks=0,release;
 const fetcher=async(url)=>{
  const parsed=new URL(url,canonical);
  if(parsed.pathname==='/api/me'){
   if(!parsed.searchParams.has('verify')&&++checks===1){await new Promise(resolve=>{release=resolve;});return Response.json({signedIn:false});}
   return Response.json({signedIn});
  }
  if(parsed.pathname==='/api/auth/login'){signedIn=true;return Response.json({signedIn:true});}
  if(parsed.pathname==='/api/admin/playlists')return Response.json(catalogue);
  throw Error('Unexpected stale-response fixture request');
 };
 await environment('https://listen.test/bim',fetcher,async context=>{
  try{
   await context.mount(true);assert.ok(release);assert.equal(context.root.root.findAllByType('form').length,1);
   await act(async()=>{context.root.root.findByProps({id:'admin-username'}).props.onChange({target:{value:'fixtureadmin'}});context.root.root.findByProps({id:'admin-password'}).props.onChange({target:{value:'fixture-password'}});});
   await act(async()=>{await context.root.root.findByType('form').props.onSubmit({preventDefault(){}});await context.settle();});assert.equal(context.root.root.findAllByType(AdminDashboard).length,1);
   await act(async()=>{release();await context.settle();});assert.equal(context.root.root.findAllByType(AdminDashboard).length,1);assert.equal(context.root.root.findAllByType('form').length,0);
  }finally{release?.();}
 });
});
