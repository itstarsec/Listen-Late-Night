import {test} from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import {handleApi} from '../.sites-runtime/tests/api.mjs';import {SEED_IDS,MAX_TRACKS} from '../.sites-runtime/tests/domain.mjs';
import {D1} from './test-db.mjs';
import {createPasswordHash,digest,AUTH_COOKIE,LOCAL_ACCOUNT_ID} from '../.sites-runtime/tests/auth.mjs';
const fixtureUsername='fixtureadmin',fixtureHash=await createPasswordHash('fixture-password'),fixtureToken='a'.repeat(43);
const fixtureTokenHash=await digest(fixtureToken),fixtureTag=await digest(`listen-auth-v1\0${fixtureUsername}\0${fixtureHash}`);
const env=()=>{const e={DB:new D1(),AUTH_USERNAME:fixtureUsername,AUTH_PASSWORD_HASH:fixtureHash};e.DB.raw.prepare('INSERT INTO auth_sessions (token_hash,username,credential_tag,created_at,expires_at) VALUES (?,?,?,?,?)').run(fixtureTokenHash,fixtureUsername,fixtureTag,Date.now(),Date.now()+86400000);return e;};
const owner={cookie:`${AUTH_COOKIE}=${fixtureToken}`},other={'oai-authenticated-user-id':'other-002','oai-authenticated-user-email':'other@example.test'};
const importedDefinitions=JSON.parse(readFileSync('lib/imported-playlists.json','utf8'));
const curatedDefinitions=JSON.parse(readFileSync('lib/curated-playlists.json','utf8'));
const curatedSlugs=new Set(curatedDefinitions.map(p=>p.slug));
const allDefinitions=[{slug:'shelby',videoIds:SEED_IDS},...curatedDefinitions,...importedDefinitions.map(p=>({...p,videoIds:[...p.tracks,...(p.additionalTracks||[])].map(t=>t.videoId)}))];
const expectedCounts=new Map(allDefinitions.map(p=>[p.slug,p.videoIds.length]));
const CATALOGUE_COUNT=allDefinitions.length,ALL_ENTRIES=allDefinitions.flatMap(p=>p.videoIds).length,ALL_UNIQUE=new Set(allDefinitions.flatMap(p=>p.videoIds)).size;
test('admin catalogue and inventory require the app cookie and exclude playlists owned by another account',async()=>{
 const e=env();for(const path of ['/admin/playlists','/admin/library'])for(const auth of [{},other])assert.equal((await request(e,path,'GET',undefined,auth)).status,401);
 const now=Date.now();e.DB.raw.prepare('INSERT INTO sessions (slug,name,owner_id,tracks,version,created_at,updated_at) VALUES (?,?,?,?,1,?,?)').run('other-private','Other private','another-account',JSON.stringify([{videoId:'abcdefghijk',addedAt:now}]),now,now);
 const catalogue=await request(e,'/admin/playlists','GET',undefined,owner);assert.equal(catalogue.status,200);assert.equal(catalogue.data.user.name,fixtureUsername);assert.deepEqual(catalogue.data.stats,{playlists:CATALOGUE_COUNT,entries:ALL_ENTRIES,uniqueTracks:ALL_UNIQUE});assert.ok(catalogue.data.playlists.every(p=>p.listed));assert.ok(!JSON.stringify(catalogue.data).includes('other-private'));
 const inventory=await request(e,'/admin/library','GET',undefined,owner);assert.equal(inventory.status,200);assert.equal(inventory.data.tracks.length,ALL_UNIQUE);assert.ok(!inventory.data.tracks.some(t=>t.videoId==='abcdefghijk'));
 assert.equal((await request(e,'/admin/playlists','POST',{},owner)).status,405);
});
test('admin catalogue includes newly created link-only playlists with counts and stable unique track membership',async()=>{
 const e=env();let s=await create(e,'admin-created');s=(await request(e,'/sessions/admin-created/tracks','POST',{text:'RzhIXHc6_80\nabcdefghijk'},owner,s.version)).data.session;
 const catalogue=(await request(e,'/admin/playlists','GET',undefined,owner)).data;assert.equal(catalogue.stats.playlists,CATALOGUE_COUNT+1);assert.equal(catalogue.stats.entries,ALL_ENTRIES+2);assert.equal(catalogue.stats.uniqueTracks,ALL_UNIQUE+1);
 const p=catalogue.playlists.find(p=>p.slug==='admin-created');assert.equal(p.count,2);assert.equal(p.listed,false);assert.equal(p.category,'personal');assert.equal(p.version,s.version);
 const inventory=(await request(e,'/admin/library','GET',undefined,owner)).data.tracks;assert.equal(inventory.length,ALL_UNIQUE+1);assert.ok(inventory.find(t=>t.videoId==='RzhIXHc6_80').sourcePlaylists.some(p=>p.slug==='admin-created'));assert.deepEqual(inventory.find(t=>t.videoId==='abcdefghijk').sourcePlaylists,[{slug:'admin-created',name:'Đêm muộn'}]);assert.deepEqual((await request(e,'/admin/library','GET',undefined,owner)).data.tracks,inventory);
 assert.equal((await request(e,'/collections')).data.collections.length,CATALOGUE_COUNT);assert.ok(!(await request(e,'/library')).data.session.tracks.some(t=>t.videoId==='abcdefghijk'));
 await request(e,'/sessions/admin-created','DELETE',undefined,owner,s.version);assert.ok(!(await request(e,'/admin/playlists','GET',undefined,owner)).data.playlists.some(p=>p.slug==='admin-created'));
});
test('bulk track removal validates every ID before committing, preserves order and supports idempotent retries',async()=>{
 const e=env();let s=await create(e,'admin-bulk');s=(await request(e,'/sessions/admin-bulk/tracks','POST',{text:'RzhIXHc6_80\n_U8S-uFZrHA\n_NA_QD7zHmQ'},owner,s.version)).data.session;
 for(const videoIds of [[],['bad-id'],['RzhIXHc6_80','RzhIXHc6_80'],['RzhIXHc6_80','abcdefghijk'],'RzhIXHc6_80',Array.from({length:301},(_,i)=>'A'+String(i).padStart(10,'0'))]){
  assert.equal((await request(e,'/sessions/admin-bulk/tracks','DELETE',{videoIds},owner,s.version)).status,400);assert.deepEqual((await request(e,'/sessions/admin-bulk')).data.session.tracks,s.tracks);
 }
 const req=()=>new Request('https://listen.test/api/sessions/admin-bulk/tracks',{method:'DELETE',headers:{...owner,Origin:'https://listen.test','Content-Type':'application/json','If-Match':String(s.version),'X-Request-ID':'bulk-remove-repeat'},body:JSON.stringify({videoIds:['RzhIXHc6_80','_NA_QD7zHmQ']})});
 const first=await handleApi(req(),e);assert.equal(first.status,200);const data=await first.json();assert.deepEqual(data.session.tracks.map(t=>t.videoId),['_U8S-uFZrHA']);assert.equal(data.session.version,s.version+1);
 const replay=await handleApi(req(),e);assert.equal(replay.status,200);const repeated=await replay.json();assert.equal(repeated.replayed,true);assert.equal(repeated.session.version,s.version+1);
 assert.equal((await request(e,'/sessions/admin-bulk/tracks','DELETE',{videoIds:['_U8S-uFZrHA']},owner,s.version)).status,409);assert.equal((await request(e,'/sessions/admin-bulk')).data.session.tracks.length,1);
});
let counter=0;
async function request(e,path,method='GET',body,auth={},version){const headers={...auth,...(method!=='GET'?{'Content-Type':'application/json','Origin':'https://listen.test','X-Request-ID':`request-${++counter}`}:{})};if(version!==undefined)headers['If-Match']=String(version);const response=await handleApi(new Request('https://listen.test/api'+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)}),e);return {status:response.status,data:await response.json()};}
async function create(e,slug='my-night'){const r=await request(e,'/sessions','POST',{slug,name:'Đêm muộn'},owner);assert.equal(r.status,201);return r.data.session;}
test('create → add → reload persists normalized ordered tracks on backend',async()=>{const e=env();let s=await create(e);let r=await request(e,'/sessions/my-night/tracks','POST',{text:'https://youtu.be/RzhIXHc6_80?si=abc\n_U8S-uFZrHA'},owner,s.version);assert.equal(r.status,200);assert.equal(r.data.report.added,2);r=await request(e,'/sessions/my-night');assert.equal(r.data.session.tracks[0].url,'https://www.youtube.com/watch?v=RzhIXHc6_80');assert.equal(r.data.session.tracks[1].videoId,'_U8S-uFZrHA');assert.equal(r.data.session.canEdit,false);});
test('anonymous shared session is readable; anonymous and other account cannot edit/delete',async()=>{const e=env();const s=await create(e);assert.equal((await request(e,'/sessions/my-night')).status,200);for(const auth of [{},other])for(const method of ['PATCH','DELETE'])assert.equal((await request(e,'/sessions/my-night',method,{name:'attack'},auth,s.version)).status,403);assert.equal((await request(e,'/sessions','POST',{slug:'anonymous'})).status,401);});
test('bulk dedup, invalid lines and valid imports succeed together',async()=>{const e=env(),s=await create(e);const r=await request(e,'/sessions/my-night/tracks','POST',{text:'RzhIXHc6_80\nnot-a-video-url\nhttps://www.youtube.com/shorts/RzhIXHc6_80\n_U8S-uFZrHA'},owner,s.version);assert.equal(r.status,200);assert.deepEqual(r.data.report,{added:2,duplicates:1,invalid:1,invalidLines:[2]});});
test('stale write returns conflict; reorder requires exact ID permutation',async()=>{const e=env();let s=await create(e);let r=await request(e,'/sessions/my-night/tracks','POST',{text:'RzhIXHc6_80\n_U8S-uFZrHA'},owner,s.version);s=r.data.session;assert.equal((await request(e,'/sessions/my-night','PATCH',{name:'stale'},owner,1)).status,409);assert.equal((await request(e,'/sessions/my-night/order','PATCH',{ids:['RzhIXHc6_80','RzhIXHc6_80']},owner,s.version)).status,400);r=await request(e,'/sessions/my-night/order','PATCH',{ids:['_U8S-uFZrHA','RzhIXHc6_80']},owner,s.version);assert.equal(r.status,200);assert.equal(r.data.session.tracks[0].videoId,'_U8S-uFZrHA');});
test('rename retains slug; same slug cannot be claimed twice; stored text is safe data',async()=>{const e=env(),s=await create(e);assert.equal((await request(e,'/sessions','POST',{slug:'my-night'},owner)).status,409);const r=await request(e,'/sessions/my-night','PATCH',{name:'<img src=x onerror=alert(1)>'},owner,s.version);assert.equal(r.status,200);assert.equal(r.data.session.slug,'my-night');assert.equal(r.data.session.name,'<img src=x onerror=alert(1)>');});
test('seed is idempotent, public readonly and owner-managed; deleting does not resurrect it',async()=>{const e=env();let r=await request(e,'/sessions/shelby');assert.equal(r.data.session.name,'Shelby — Late Night');assert.equal(r.data.session.tracks.length,25);assert.equal(r.data.session.canEdit,false);r=await request(e,'/sessions/shelby');assert.equal(r.data.session.tracks.length,25);r=await request(e,'/sessions/shelby','GET',undefined,owner);assert.equal(r.data.session.canEdit,true);assert.equal((await request(e,'/sessions/shelby','DELETE',undefined,owner,r.data.session.version)).status,200);assert.equal((await request(e,'/sessions/shelby')).status,404);});
test('idempotent retry returns same playlist without duplicate writes',async()=>{const e=env(),s=await create(e);const req=()=>new Request('https://listen.test/api/sessions/my-night/tracks',{method:'POST',headers:{...owner,'Content-Type':'application/json','If-Match':String(s.version),'X-Request-ID':'repeated-request'},body:JSON.stringify({text:'RzhIXHc6_80'})});assert.equal((await handleApi(req(),e)).status,200);const r=await handleApi(req(),e);const d=await r.json();assert.equal(r.status,200);assert.equal(d.replayed,true);assert.equal(d.session.tracks.length,1);assert.equal(d.session.version,2);});
test('cross-origin writes are rejected',async()=>{const e=env();const r=await handleApi(new Request('https://listen.test/api/sessions',{method:'POST',headers:{...owner,'Origin':'https://evil.test','Content-Type':'application/json'},body:JSON.stringify({slug:'my-night'})}),e);assert.equal(r.status,403);});
test('invalid JSON objects and server validation fail with 400',async()=>{const e=env();for(const value of [null,[],42,'str',{slug:'ab'},{slug:'UPPER-CASE'}])assert.equal((await request(e,'/sessions','POST',value,owner)).status,400);});
test('metadata fetch is restricted to IDs already in playlist and real YouTube endpoint',async()=>{const e=env(),s=await create(e);await request(e,'/sessions/my-night/tracks','POST',{text:'RzhIXHc6_80\n_U8S-uFZrHA\n_NA_QD7zHmQ'},owner,s.version);assert.equal((await request(e,'/sessions/my-night/metadata?ids=bad')).status,400);const original=globalThis.fetch;let concurrent=0,peak=0,calls=0;globalThis.fetch=async url=>{assert.equal(new URL(url).origin,'https://www.youtube.com');assert.equal(new URL(url).pathname,'/oembed');calls++;peak=Math.max(peak,++concurrent);await new Promise(resolve=>setTimeout(resolve,5));concurrent--;return Response.json({title:'A real metadata title fixture',author_name:'YouTube fixture channel'});};try{let r=await request(e,'/sessions/my-night/metadata?ids=RzhIXHc6_80,_U8S-uFZrHA,_NA_QD7zHmQ');assert.equal(r.status,200);assert.equal(r.data.tracks[0].metadataStatus,'ready');assert.ok(peak<=3);assert.equal(calls,3);await request(e,'/sessions/my-night/metadata?ids=RzhIXHc6_80');assert.equal(calls,3);}finally{globalThis.fetch=original;}});
test('metadata failure preserves playlist with explicit fallback',async()=>{const e=env(),s=await create(e);await request(e,'/sessions/my-night/tracks','POST',{text:'RzhIXHc6_80'},owner,s.version);const original=globalThis.fetch;globalThis.fetch=async()=>{throw new Error('network');};try{const r=await request(e,'/sessions/my-night/metadata?ids=RzhIXHc6_80');assert.equal(r.status,200);assert.equal(r.data.tracks[0].metadataStatus,'unavailable');assert.match(r.data.tracks[0].title,/Video YouTube/);assert.equal((await request(e,'/sessions/my-night')).data.session.tracks.length,1);}finally{globalThis.fetch=original;}});
test('simultaneous writes from the same version have one winner',async()=>{const e=env(),s=await create(e);const results=await Promise.all([request(e,'/sessions/my-night','PATCH',{name:'device-a'},owner,s.version),request(e,'/sessions/my-night','PATCH',{name:'device-b'},owner,s.version)]);assert.deepEqual(results.map(x=>x.status).sort(),[200,409]);const loaded=await request(e,'/sessions/my-night');assert.equal(loaded.data.session.version,2);});
test('delete another track preserves remaining IDs and their order',async()=>{const e=env();let s=await create(e);s=(await request(e,'/sessions/my-night/tracks','POST',{text:'RzhIXHc6_80\n_U8S-uFZrHA\n_NA_QD7zHmQ'},owner,s.version)).data.session;const r=await request(e,'/sessions/my-night/tracks','DELETE',{videoId:'_U8S-uFZrHA'},owner,s.version);assert.deepEqual(r.data.session.tracks.map(x=>x.videoId),['RzhIXHc6_80','_NA_QD7zHmQ']);assert.equal((await request(e,'/sessions/my-night')).data.session.tracks.length,2);});
test('public collection catalogue includes ten suggestions and the requested import while keeping Shelby intact',async()=>{const e=env();const before=(await request(e,'/sessions/shelby')).data.session;const r=await request(e,'/collections');assert.equal(r.status,200);assert.equal(r.data.collections.length,CATALOGUE_COUNT);assert.equal(r.data.collections.filter(c=>curatedSlugs.has(c.slug)).length,10);assert.equal(new Set(r.data.collections.map(c=>c.slug)).size,CATALOGUE_COUNT);for(const c of r.data.collections){assert.equal(c.canEdit,false);assert.equal(c.count,expectedCounts.get(c.slug));assert.match(c.cover,/^https:\/\/i\.ytimg\.com\/vi\//);}const after=(await request(e,'/sessions/shelby')).data.session;assert.deepEqual(after,before);});
test('each suggested playlist opens directly with twelve unique normalized tracks and real metadata',async()=>{const e=env();const catalogue=await request(e,'/collections');for(const c of catalogue.data.collections.filter(c=>curatedSlugs.has(c.slug))){const r=await request(e,`/sessions/${c.slug}`);assert.equal(r.status,200);const s=r.data.session;assert.equal(s.tracks.length,12);assert.equal(new Set(s.tracks.map(t=>t.videoId)).size,12);for(const t of s.tracks){assert.equal(t.url,`https://www.youtube.com/watch?v=${t.videoId}`);assert.ok(['ready','pending'].includes(t.metadataStatus),'Cached real metadata may pass its 24-hour refresh time');assert.ok(t.channel);assert.ok(!t.title.startsWith('Video YouTube'));}}});
test('direct suggested-session URL initializes before catalogue load',async()=>{const e=env();const r=await request(e,'/sessions/midnight-drive');assert.equal(r.status,200);assert.equal(r.data.session.name,'Midnight Drive');assert.equal(r.data.session.tracks.length,12);});
test('suggested playlists retain creator-only editing and cannot be claimed by others',async()=>{const e=env();let r=await request(e,'/sessions/dark-indie','GET',undefined,owner);assert.equal(r.data.session.canEdit,true);const version=r.data.session.version;assert.equal((await request(e,'/sessions/dark-indie','PATCH',{name:'bad'},other,version)).status,403);assert.equal((await request(e,'/sessions/dark-indie','DELETE',undefined,{},version)).status,403);assert.equal((await request(e,'/sessions','POST',{slug:'dark-indie'},other)).status,401);});
test('catalogue refresh reflects rename and removal and never reseeds owner edits',async()=>{const e=env();let s=(await request(e,'/sessions/cinematic-soul','GET',undefined,owner)).data.session;s=(await request(e,'/sessions/cinematic-soul','PATCH',{name:'Âm nhạc của tôi'},owner,s.version)).data.session;const removed=s.tracks[0].videoId;s=(await request(e,'/sessions/cinematic-soul/tracks','DELETE',{videoId:removed},owner,s.version)).data.session;const r=await request(e,'/collections');const c=r.data.collections.find(x=>x.slug==='cinematic-soul');assert.equal(c.name,'Âm nhạc của tôi');assert.equal(c.count,11);const after=(await request(e,'/sessions/cinematic-soul')).data.session;assert.equal(after.name,'Âm nhạc của tôi');assert.ok(!after.tracks.some(t=>t.videoId===removed));assert.equal(after.version,3);});
test('deleted suggested session is not resurrected or listed by later catalogue reads',async()=>{const e=env();const s=(await request(e,'/sessions/rainy-memories','GET',undefined,owner)).data.session;assert.equal((await request(e,'/sessions/rainy-memories','DELETE',undefined,owner,s.version)).status,200);const r=await request(e,'/collections');assert.equal(r.data.collections.length,CATALOGUE_COUNT-1);assert.ok(!r.data.collections.some(x=>x.slug==='rainy-memories'));assert.equal((await request(e,'/sessions/rainy-memories')).status,404);});
test('anonymous full library aggregates every listed playlist with unique video IDs in stable source order',async()=>{const e=env();const r=await request(e,'/library');assert.equal(r.status,200);const s=r.data.session;assert.equal(s.kind,'all');assert.equal(s.name,'Tất cả bài hát');assert.equal(s.canEdit,false);assert.equal(s.sourceCount,CATALOGUE_COUNT);assert.equal(s.totalEntries,ALL_ENTRIES);assert.equal(s.tracks.length,ALL_UNIQUE);assert.equal(new Set(s.tracks.map(t=>t.videoId)).size,ALL_UNIQUE);const catalog=(await request(e,'/collections')).data.collections;const expected=[];for(const c of catalog){for(const t of (await request(e,`/sessions/${c.slug}`)).data.session.tracks)if(!expected.includes(t.videoId))expected.push(t.videoId);}assert.deepEqual(s.tracks.map(t=>t.videoId),expected);for(const t of s.tracks){assert.equal(t.url,`https://www.youtube.com/watch?v=${t.videoId}`);assert.ok(t.sourcePlaylists.length>=1);}});
test('duplicate songs keep membership in every source without repeating in the queue',async()=>{const e=env();const s=(await request(e,'/library')).data.session;const t=s.tracks.find(t=>t.videoId==='0-7IHOXkiV8');assert.deepEqual(t.sourcePlaylists.map(p=>p.slug),['shelby','shelby-after-dark']);assert.equal(s.tracks.filter(x=>x.videoId===t.videoId).length,1);});
test('full library refresh follows additions and removals in source playlists without copying records',async()=>{const e=env();let s=(await request(e,'/sessions/shelby','GET',undefined,owner)).data.session;const originalVersion=s.version;s=(await request(e,'/sessions/shelby/tracks','POST',{text:'abcdefghijk'},owner,s.version)).data.session;let all=(await request(e,'/library')).data.session;assert.equal(all.tracks.length,ALL_UNIQUE+1);assert.ok(all.tracks.some(t=>t.videoId==='abcdefghijk'));assert.equal((await request(e,'/sessions/shelby')).data.session.version,originalVersion+1);s=(await request(e,'/sessions/shelby/tracks','DELETE',{videoId:'0-7IHOXkiV8'},owner,s.version)).data.session;all=(await request(e,'/library')).data.session;assert.equal(all.tracks.length,ALL_UNIQUE+1);assert.deepEqual(all.tracks.find(t=>t.videoId==='0-7IHOXkiV8').sourcePlaylists.map(p=>p.slug),['shelby-after-dark']);const databaseRow=e.DB.raw.prepare('SELECT slug FROM sessions WHERE slug=?').get(all.slug);assert.equal(databaseRow,undefined);});
test('full library cannot be modified or deleted even by site owner',async()=>{const e=env();await request(e,'/library');for(const method of ['POST','PATCH','DELETE'])for(const auth of [{},owner])assert.equal((await request(e,'/library',method,{name:'bad'},auth,1)).status,405);assert.equal((await request(e,'/sessions/shelby')).data.session.version,1);assert.equal(e.DB.raw.prepare('SELECT COUNT(*) AS count FROM sessions').get().count,CATALOGUE_COUNT);});
test('library metadata uses the existing membership guard and fallback pipeline',async()=>{const e=env();assert.equal((await request(e,'/library/metadata?ids=zzzzzzzzzzz')).status,400);const original=globalThis.fetch;globalThis.fetch=async url=>{assert.equal(new URL(url).origin,'https://www.youtube.com');return Response.json({title:'Library metadata fixture',author_name:'Fixture channel'});};try{const r=await request(e,'/library/metadata?ids=-SJzxfQYCxE,-SJzxfQYCxE');assert.equal(r.status,200);assert.equal(r.data.tracks.length,1);assert.equal(r.data.tracks[0].metadataStatus,'ready');assert.equal((await request(e,'/library')).data.session.tracks.length,ALL_UNIQUE);}finally{globalThis.fetch=original;}});
test('deleting a source removes its exclusive songs and keeps shared songs in full library',async()=>{const e=env();const s=(await request(e,'/sessions/shelby','GET',undefined,owner)).data.session;await request(e,'/sessions/shelby','DELETE',undefined,owner,s.version);const all=(await request(e,'/library')).data.session;assert.equal(all.sourceCount,CATALOGUE_COUNT-1);assert.equal(all.totalEntries,ALL_ENTRIES-25);assert.equal(all.tracks.length,ALL_UNIQUE-14);assert.ok(!all.tracks.some(t=>t.videoId==='RzhIXHc6_80'));assert.ok(all.tracks.some(t=>t.videoId==='0-7IHOXkiV8'));assert.equal((await request(e,'/sessions/shelby')).status,404);});
test('a user session named all stays independently addressable and link-only sessions stay outside discovery',async()=>{const e=env();const own=await create(e,'all');assert.equal(own.slug,'all');assert.equal((await request(e,'/sessions/all')).status,200);const s=(await request(e,'/library')).data.session;assert.equal(s.kind,'all');assert.notEqual(s.slug,'all');assert.equal(s.sourceCount,CATALOGUE_COUNT);});

const importedIds=['62ppUtuSwds','wNWC1pXIfZk','PqLrVg6AxSc','UJtHpF-Ma9g','QfAFl391w5M','QvtQxDlvECs','RoVLIQ7EfzA','OQI4dQ03CQQ','0p-SYHlHDU8','i4k4pCSoQzQ','RPmw_itg9ig','x4y9-d1k77Q'];
test('requested YouTube Music album opens directly with all twelve source tracks in order and real metadata',async()=>{
 const e=env();
 const r=await request(e,'/sessions/dia-nhac-loi-khuan');assert.equal(r.status,200);
 const s=r.data.session;assert.equal(s.name,'Đĩa nhạc - Lợi Khuẩn');assert.equal(s.canEdit,false);
 assert.deepEqual(s.tracks.map(t=>t.videoId),importedIds);
 assert.equal(s.tracks[0].title,'cà phê phin');assert.equal(s.tracks.at(-1).title,'thế giới giả lập');
 for(const t of s.tracks){assert.equal(t.channel,'Dfoxie37');assert.ok(['ready','pending'].includes(t.metadataStatus),'Imported metadata can outlive its refresh TTL');assert.equal(t.url,`https://www.youtube.com/watch?v=${t.videoId}`);assert.equal(t.thumbnail,`https://i.ytimg.com/vi/${t.videoId}/hqdefault.jpg`);}
 const source=JSON.parse(readFileSync('lib/imported-playlists.json','utf8'))[0];assert.equal(source.sourcePlaylistId,'OLAK5uy_lzTVK28HYcOzir0qVg-Mxgk2jX8eTNAqw');assert.equal(source.sourceTrackCount,12);
 assert.deepEqual((await request(e,'/sessions/dia-nhac-loi-khuan')).data.session,s);
});
test('import adds to an existing seeded database without changing edited playlists and aggregates in stable order',async()=>{
 const e=env();let old=(await request(e,'/sessions/midnight-drive','GET',undefined,owner)).data.session;
 old=(await request(e,'/sessions/midnight-drive','PATCH',{name:'Playlist đã sửa'},owner,old.version)).data.session;
 const reordered=old.tracks.map(t=>t.videoId).reverse();old=(await request(e,'/sessions/midnight-drive/order','PATCH',{ids:reordered},owner,old.version)).data.session;
 assert.equal(e.DB.raw.prepare("SELECT COUNT(*) AS count FROM sessions WHERE slug='dia-nhac-loi-khuan'").get().count,0);
 const all=(await request(e,'/library')).data.session;
 assert.deepEqual(all.tracks.filter(t=>importedIds.includes(t.videoId)).map(t=>t.videoId),importedIds);
 for(const id of importedIds){const t=all.tracks.filter(t=>t.videoId===id);assert.equal(t.length,1);assert.deepEqual(t[0].sourcePlaylists,[{slug:'dia-nhac-loi-khuan',name:'Đĩa nhạc - Lợi Khuẩn'}]);}
 assert.deepEqual((await request(e,'/sessions/midnight-drive','GET',undefined,owner)).data.session,old);
 await request(e,'/collections');await request(e,'/library');
 assert.equal(e.DB.raw.prepare("SELECT COUNT(*) AS count FROM sessions WHERE slug='dia-nhac-loi-khuan'").get().count,1);
 assert.equal((await request(e,'/sessions/dia-nhac-loi-khuan')).data.session.version,1);
});
test('imported album stays owner-managed, preserves edits and does not return after deletion',async()=>{
 const e=env();let s=(await request(e,'/sessions/dia-nhac-loi-khuan','GET',undefined,owner)).data.session;assert.equal(s.canEdit,true);
 assert.equal((await request(e,'/sessions','POST',{slug:'dia-nhac-loi-khuan'},other)).status,401);
 for(const auth of [{},other])for(const method of ['PATCH','DELETE'])assert.equal((await request(e,'/sessions/dia-nhac-loi-khuan',method,{name:'bad'},auth,s.version)).status,403);
 s=(await request(e,'/sessions/dia-nhac-loi-khuan','PATCH',{name:'Lợi Khuẩn của tôi'},owner,s.version)).data.session;
 s=(await request(e,'/sessions/dia-nhac-loi-khuan/tracks','DELETE',{videoId:importedIds[0]},owner,s.version)).data.session;
 const c=(await request(e,'/collections')).data.collections.find(x=>x.slug===s.slug);assert.equal(c.name,s.name);assert.equal(c.count,11);
 assert.deepEqual((await request(e,'/sessions/dia-nhac-loi-khuan','GET',undefined,owner)).data.session,s);
 assert.equal((await request(e,'/sessions/dia-nhac-loi-khuan','DELETE',undefined,owner,s.version)).status,200);
 assert.ok(!(await request(e,'/collections')).data.collections.some(c=>c.slug===s.slug));
 assert.ok(!(await request(e,'/library')).data.session.tracks.some(t=>importedIds.includes(t.videoId)));
 assert.equal((await request(e,'/sessions/dia-nhac-loi-khuan')).status,404);
});

test('Vietnam catalogue contains the thirteen complete source imports with audited counts and source links',async()=>{
 const e=env(),viet=importedDefinitions.filter(p=>p.slug.startsWith('viet-'));
 assert.equal(viet.length,13);assert.equal(viet.reduce((n,p)=>n+p.tracks.length,0),918);
 const r=await request(e,'/collections');assert.equal(r.status,200);assert.equal(r.data.collections.length,CATALOGUE_COUNT);
 for(const p of viet){
  assert.ok(p.tracks.length>0&&p.tracks.length<=MAX_TRACKS);
  assert.equal(p.tracks.length+p.duplicateCount+p.unavailableCount,p.sourceTrackCount);
  assert.equal(p.publicTrackCount,p.tracks.length+p.duplicateCount);
  assert.equal(new Set(p.tracks.map(t=>t.videoId)).size,p.tracks.length);
  const c=r.data.collections.find(c=>c.slug===p.slug);assert.equal(c.count,p.tracks.length);assert.equal(c.category,'viet');assert.equal(c.canEdit,false);
  const u=new URL(c.source.url);assert.equal(u.origin,'https://music.youtube.com');assert.equal(u.pathname,'/playlist');assert.equal(u.searchParams.get('list'),p.sourcePlaylistId);
  assert.equal(c.source.title,p.sourceTitle);assert.equal(c.source.curator,p.curator);assert.equal(c.source.unavailableCount,p.unavailableCount);
  const s=(await request(e,`/sessions/${p.slug}`)).data.session;
  assert.deepEqual(s.tracks.map(t=>t.videoId),p.tracks.map(t=>t.videoId));
  for(const t of s.tracks){assert.match(t.videoId,/^[A-Za-z0-9_-]{11}$/);assert.ok(t.channel);assert.ok(['ready','pending'].includes(t.metadataStatus),'Imported metadata can outlive its refresh TTL');}
 }
 const indie=viet.find(p=>p.slug==='viet-indie');assert.equal(indie.sourcePageCount,2);assert.equal(indie.tracks.length,110);assert.equal(indie.duplicateCount,1);
 const rnb=viet.find(p=>p.slug==='viet-rnb-tiktok');assert.equal(rnb.sourcePageCount,2);assert.equal(rnb.tracks.length,134);
 const all=(await request(e,'/library')).data.session;assert.equal(all.tracks.length,ALL_UNIQUE);assert.equal(all.totalEntries,ALL_ENTRIES);assert.equal(all.sourceCount,CATALOGUE_COUNT);
});
test('direct Vietnam URL initializes only the requested playlist and stays persistent and owner-managed',async()=>{
 const e=env();let s=(await request(e,'/sessions/viet-top-100')).data.session;
 assert.equal(s.tracks.length,100);assert.equal(s.tracks[0].videoId,'eedlpxUw8zg');assert.equal(s.tracks.at(-1).videoId,'naaL77_fymE');assert.equal(s.canEdit,false);
 assert.equal(e.DB.raw.prepare('SELECT COUNT(*) AS count FROM sessions').get().count,1);
 assert.equal((await request(e,'/sessions','POST',{slug:'viet-top-100'},other)).status,401);
 assert.equal((await request(e,'/sessions/viet-top-100','PATCH',{name:'bad'},other,s.version)).status,403);
 s=(await request(e,'/sessions/viet-top-100','PATCH',{name:'BXH của tôi'},owner,s.version)).data.session;
 const first=s.tracks[0].videoId;s=(await request(e,'/sessions/viet-top-100/tracks','DELETE',{videoId:first},owner,s.version)).data.session;
 await request(e,'/collections');await request(e,'/library');
 assert.deepEqual((await request(e,'/sessions/viet-top-100','GET',undefined,owner)).data.session,s);
 assert.equal((await request(e,'/sessions/viet-top-100','DELETE',undefined,owner,s.version)).status,200);
 assert.ok(!(await request(e,'/collections')).data.collections.some(c=>c.slug==='viet-top-100'));
 assert.equal((await request(e,'/sessions/viet-top-100')).status,404);
});
test('failed import commit can be retried without duplicate tracks or a premature seed marker',async()=>{
 const e=env(),batch=e.DB.batch.bind(e.DB);let fail=true;
 e.DB.batch=async statements=>{if(fail){fail=false;throw new Error('Temporary storage failure fixture');}return batch(statements);};
 assert.equal((await request(e,'/sessions/viet-ngot')).status,503);
 assert.equal(e.DB.raw.prepare("SELECT COUNT(*) AS count FROM seeds WHERE key LIKE 'imported:%'").get().count,0);
 const r=await request(e,'/sessions/viet-ngot');assert.equal(r.status,200);assert.equal(r.data.session.tracks.length,49);
 assert.deepEqual((await request(e,'/sessions/viet-ngot')).data.session,r.data.session);
});

test('full catalogue initialization stays within the D1 free query budget and subsequent discovery is cheap',async()=>{
 const e=env(),r=await request(e,'/library');assert.equal(r.status,200);assert.equal(r.data.session.tracks.length,ALL_UNIQUE);
 assert.ok(e.DB.queries<=50,`First request used ${e.DB.queries} queries`);
 const before=e.DB.queries;assert.equal((await request(e,'/collections')).status,200);assert.ok(e.DB.queries-before<=6);
});

const tryhardDefinitions=importedDefinitions.filter(p=>p.category==='tryhard');
test('Try Hard imports expose eight audited playlists and 243 ordered videos in public discovery and the full library',async()=>{
 assert.equal(tryhardDefinitions.length,8);
 assert.equal(tryhardDefinitions.reduce((n,p)=>n+p.tracks.length,0),243);
 assert.equal(tryhardDefinitions.reduce((n,p)=>n+p.unavailableCount,0),14);
 assert.equal(tryhardDefinitions.reduce((n,p)=>n+p.duplicateCount,0),1);
 const e=env(),catalogue=(await request(e,'/collections')).data.collections;
 assert.equal(catalogue.filter(p=>p.category==='tryhard').length,8);
 const aggregate=(await request(e,'/library')).data.session;
 const admin=(await request(e,'/admin/playlists','GET',undefined,owner)).data.playlists;
 for(const p of tryhardDefinitions){
  assert.ok(p.tracks.length>0&&p.tracks.length<=MAX_TRACKS);
  assert.equal(p.tracks.length+p.duplicateCount+p.unavailableCount,p.sourceTrackCount);
  assert.equal(new Set(p.tracks.map(t=>t.videoId)).size,p.tracks.length);
  assert.equal(p.sourceUrl,`https://music.youtube.com/playlist?list=${p.sourcePlaylistId}`);
  assert.ok(p.sourceTitle&&p.curator&&p.fetchedAt&&p.sourcePageCount);
  assert.equal(catalogue.find(c=>c.slug===p.slug).category,'tryhard');
  assert.equal(catalogue.find(c=>c.slug===p.slug).source.url,p.sourceUrl);
  assert.equal(admin.find(c=>c.slug===p.slug).category,'tryhard');
  assert.equal(admin.find(c=>c.slug===p.slug).listed,true);
  const s=(await request(e,`/sessions/${p.slug}`)).data.session;
  assert.equal(s.canEdit,false);assert.equal(s.name,p.name);
  assert.deepEqual(s.tracks.map(t=>t.videoId),p.tracks.map(t=>t.videoId));
  for(const t of s.tracks){
   assert.match(t.videoId,/^[A-Za-z0-9_-]{11}$/);assert.ok(t.title&&t.channel);assert.ok(!t.title.startsWith('Video YouTube'));
   assert.equal(t.url,`https://www.youtube.com/watch?v=${t.videoId}`);
   assert.equal(t.thumbnail,`https://i.ytimg.com/vi/${t.videoId}/hqdefault.jpg`);
   const matches=aggregate.tracks.filter(x=>x.videoId===t.videoId);assert.equal(matches.length,1);
   assert.ok(matches[0].sourcePlaylists.some(source=>source.slug===p.slug));
  }
 }
 assert.deepEqual((await request(e,'/library')).data.session,aggregate);
});
test('Try Hard addition preserves existing edits, allows only the administrator to manage it and never resurrects a deleted playlist',async()=>{
 const e=env();let old=(await request(e,'/sessions/shelby','GET',undefined,owner)).data.session;
 old=(await request(e,'/sessions/shelby','PATCH',{name:'Shelby của tôi'},owner,old.version)).data.session;
 const ids=old.tracks.map(t=>t.videoId).reverse();old=(await request(e,'/sessions/shelby/order','PATCH',{ids},owner,old.version)).data.session;
 assert.equal(e.DB.raw.prepare("SELECT count(*) AS n FROM sessions WHERE slug LIKE 'tryhard-%'").get().n,0);
 let fresh=(await request(e,'/sessions/tryhard-mr-robot','GET',undefined,owner)).data.session;
 assert.equal(fresh.canEdit,true);assert.equal(fresh.tracks.length,31);
 assert.equal((await request(e,'/sessions/tryhard-mr-robot','PATCH',{name:'Unauthorized'},other,fresh.version)).status,403);
 assert.equal((await request(e,'/sessions/tryhard-mr-robot','DELETE',undefined,{},fresh.version)).status,403);
 fresh=(await request(e,'/sessions/tryhard-mr-robot/tracks','DELETE',{videoId:fresh.tracks[0].videoId},owner,fresh.version)).data.session;
 await request(e,'/collections');await request(e,'/library');
 assert.deepEqual((await request(e,'/sessions/shelby','GET',undefined,owner)).data.session,old);
 assert.deepEqual((await request(e,'/sessions/tryhard-mr-robot','GET',undefined,owner)).data.session,fresh);
 assert.equal((await request(e,'/sessions/tryhard-mr-robot','DELETE',undefined,owner,fresh.version)).status,200);
 for(let i=0;i<2;i++){
  const catalogue=(await request(e,'/collections')).data.collections;assert.equal(catalogue.filter(p=>p.category==='tryhard').length,7);
  assert.equal((await request(e,'/sessions/tryhard-mr-robot')).status,404);
 }
 assert.deepEqual((await request(e,'/sessions/shelby','GET',undefined,owner)).data.session,old);
});

const gamingDefinitions=importedDefinitions.filter(p=>p.category==='gaming');
test('Gaming catalogue contains ten source-audited playlists, 220 ordered videos and discoverable administrator categories',async()=>{
 assert.deepEqual(gamingDefinitions.map(p=>[p.slug,p.tracks.length]),[
  ['gaming-call-of-duty',26],['gaming-forza-pulse',24],['gaming-forza-bass-arena',19],['gaming-forza-hospital',30],['gaming-doom',31],
  ['gaming-cyberpunk',15],['gaming-need-for-speed',32],['gaming-league-of-legends',13],['gaming-valorant',6],['gaming-minecraft',24],
 ]);
 assert.equal(gamingDefinitions.reduce((n,p)=>n+p.tracks.length,0),220);
 const e=env(),catalogue=(await request(e,'/collections')).data.collections,aggregate=(await request(e,'/library')).data.session;
 assert.equal(catalogue.filter(c=>c.category==='gaming').length,10);
 const admin=(await request(e,'/admin/playlists','GET',undefined,owner)).data.playlists;
 for(const p of gamingDefinitions){
  assert.equal(p.tracks.length+p.duplicateCount+p.unavailableCount,p.sourceTrackCount);
  assert.equal(new Set(p.tracks.map(t=>t.videoId)).size,p.tracks.length);
  assert.equal(p.sourceUrl,`https://music.youtube.com/playlist?list=${p.sourcePlaylistId}`);
  assert.ok(p.sourceTitle&&p.curator&&p.fetchedAt&&p.sourcePageCount&&p.musicVisibleItemCount);
  const c=catalogue.find(c=>c.slug===p.slug);assert.equal(c.category,'gaming');assert.equal(c.count,p.tracks.length);assert.equal(c.source.url,p.sourceUrl);assert.equal(c.canEdit,false);
  const managed=admin.find(c=>c.slug===p.slug);assert.equal(managed.category,'gaming');assert.equal(managed.listed,true);
  const s=(await request(e,`/sessions/${p.slug}`)).data.session;
  assert.equal(s.name,p.name);assert.equal(s.canEdit,false);assert.deepEqual(s.tracks.map(t=>t.videoId),p.tracks.map(t=>t.videoId));
  for(const t of s.tracks){
   assert.match(t.videoId,/^[A-Za-z0-9_-]{11}$/);assert.ok(t.title&&t.channel);assert.ok(!t.title.startsWith('Video YouTube'));
   assert.equal(t.url,`https://www.youtube.com/watch?v=${t.videoId}`);assert.equal(t.thumbnail,`https://i.ytimg.com/vi/${t.videoId}/hqdefault.jpg`);
   const matches=aggregate.tracks.filter(a=>a.videoId===t.videoId);assert.equal(matches.length,1);assert.ok(matches[0].sourcePlaylists.some(source=>source.slug===p.slug));
  }
 }
 assert.deepEqual((await request(e,'/library')).data.session,aggregate);
});
test('Gaming initializes on an existing edited database, preserves permissions and never restores removed songs or playlists',async()=>{
 const e=env();let old=(await request(e,'/sessions/tryhard-home','GET',undefined,owner)).data.session;
 old=(await request(e,'/sessions/tryhard-home','PATCH',{name:'HOME của tôi'},owner,old.version)).data.session;
 old=(await request(e,'/sessions/tryhard-home/order','PATCH',{ids:old.tracks.map(t=>t.videoId).reverse()},owner,old.version)).data.session;
 assert.equal(e.DB.raw.prepare("SELECT count(*) n FROM sessions WHERE slug LIKE 'gaming-%'").get().n,0);
 let game=(await request(e,'/sessions/gaming-call-of-duty','GET',undefined,owner)).data.session;
 assert.equal(game.canEdit,true);assert.equal(game.tracks.length,26);assert.equal(game.tracks[0].videoId,'DyOFoTcWwG8');
 assert.equal((await request(e,'/sessions/gaming-call-of-duty','PATCH',{name:'Unauthorized'},other,game.version)).status,403);
 assert.equal((await request(e,'/sessions/gaming-call-of-duty','DELETE',undefined,{},game.version)).status,403);
 const removed=game.tracks[0].videoId;
 game=(await request(e,'/sessions/gaming-call-of-duty/tracks','DELETE',{videoId:removed},owner,game.version)).data.session;
 await request(e,'/collections');let all=(await request(e,'/library')).data.session;assert.ok(!all.tracks.some(t=>t.videoId===removed));
 assert.deepEqual((await request(e,'/sessions/tryhard-home','GET',undefined,owner)).data.session,old);
 assert.deepEqual((await request(e,'/sessions/gaming-call-of-duty','GET',undefined,owner)).data.session,game);
 assert.equal((await request(e,'/sessions/gaming-call-of-duty','DELETE',undefined,owner,game.version)).status,200);
 for(let i=0;i<2;i++){
  assert.equal((await request(e,'/collections')).data.collections.filter(p=>p.category==='gaming').length,9);
  assert.equal((await request(e,'/sessions/gaming-call-of-duty')).status,404);
 }
 all=(await request(e,'/library')).data.session;assert.ok(!all.tracks.some(t=>game.tracks.some(g=>g.videoId===t.videoId)));
 assert.deepEqual((await request(e,'/sessions/tryhard-home','GET',undefined,owner)).data.session,old);
});

const rideDefinitions=importedDefinitions.filter(p=>p.category==='ride');
test('Ride exposes eight audited motorcycle playlists with 260 ordered public videos and shared aggregate membership',async()=>{
 assert.deepEqual(rideDefinitions.map(p=>[p.slug,p.tracks.length]),[
  ['ride-cruiser',30],['ride-southern-rock',17],['ride-country',24],['ride-cafe-racer',44],
  ['ride-the-midnight',14],['ride-fm84',11],['ride-sportbike',99],['ride-viet-roadtrip',21],
 ]);
 assert.equal(rideDefinitions.reduce((n,p)=>n+p.sourceTrackCount,0),284);
 assert.equal(rideDefinitions.reduce((n,p)=>n+p.unavailableCount,0),24);
 // This import's historical delta excludes sources appended after Ride.
 const oldIds=new Set(allDefinitions.slice(0,allDefinitions.findIndex(p=>p.category==='ride')).flatMap(p=>p.videoIds));
 const rideIds=rideDefinitions.flatMap(p=>p.tracks.map(t=>t.videoId));assert.equal(new Set(rideIds).size,260);
 assert.equal(rideIds.filter(id=>!oldIds.has(id)).length,248);
 const e=env(),catalogue=(await request(e,'/collections')).data.collections,aggregate=(await request(e,'/library')).data.session;
 const admin=(await request(e,'/admin/playlists','GET',undefined,owner)).data.playlists;
 assert.equal(catalogue.filter(p=>p.category==='ride').length,8);
 for(const p of rideDefinitions){
  assert.ok(p.tracks.length<=MAX_TRACKS);assert.equal(p.tracks.length+p.duplicateCount+p.unavailableCount,p.sourceTrackCount);
  assert.equal(p.musicVisibleItemCount,p.sourceTrackCount);assert.equal(p.sourcePageCount,1);
  const c=catalogue.find(c=>c.slug===p.slug);assert.equal(c.category,'ride');assert.equal(c.count,p.tracks.length);assert.equal(c.canEdit,false);
  assert.equal(c.source.url,`https://music.youtube.com/playlist?list=${p.sourcePlaylistId}`);assert.equal(c.source.curator,p.curator);assert.equal(c.source.unavailableCount,p.unavailableCount);
  const a=admin.find(a=>a.slug===p.slug);assert.equal(a.category,'ride');assert.equal(a.listed,true);
  const s=(await request(e,`/sessions/${p.slug}`)).data.session;assert.equal(s.canEdit,false);assert.equal(s.name,p.name);
  assert.deepEqual(s.tracks.map(t=>t.videoId),p.tracks.map(t=>t.videoId));
  for(const t of s.tracks){
   assert.ok(t.title&&t.channel);assert.equal(t.url,`https://www.youtube.com/watch?v=${t.videoId}`);
   const matches=aggregate.tracks.filter(t2=>t2.videoId===t.videoId);assert.equal(matches.length,1);assert.ok(matches[0].sourcePlaylists.some(source=>source.slug===p.slug));
   if(oldIds.has(t.videoId))assert.ok(matches[0].sourcePlaylists.some(source=>!source.slug.startsWith('ride-')));
  }
 }
 assert.deepEqual((await request(e,'/library')).data.session,aggregate);
});
test('Ride seeds on an edited database, keeps administrator-only changes and never restores deleted tracks or playlists',async()=>{
 const e=env();let old=(await request(e,'/sessions/gaming-forza-pulse','GET',undefined,owner)).data.session;
 old=(await request(e,'/sessions/gaming-forza-pulse','PATCH',{name:'Forza của tôi'},owner,old.version)).data.session;
 old=(await request(e,'/sessions/gaming-forza-pulse/order','PATCH',{ids:old.tracks.map(t=>t.videoId).reverse()},owner,old.version)).data.session;
 assert.equal(e.DB.raw.prepare("SELECT count(*) n FROM sessions WHERE slug LIKE 'ride-%'").get().n,0);
 let ride=(await request(e,'/sessions/ride-cruiser','GET',undefined,owner)).data.session;assert.equal(ride.canEdit,true);
 assert.equal((await request(e,'/sessions/ride-cruiser','PATCH',{name:'Unauthorized'},other,ride.version)).status,403);
 assert.equal((await request(e,'/sessions/ride-cruiser','DELETE',undefined,{},ride.version)).status,403);
 const removed=ride.tracks[0].videoId;
 assert.ok(!allDefinitions.filter(p=>p.slug!=='ride-cruiser').some(p=>p.videoIds.includes(removed)));
 ride=(await request(e,'/sessions/ride-cruiser/tracks','DELETE',{videoId:removed},owner,ride.version)).data.session;
 await request(e,'/collections');assert.ok(!(await request(e,'/library')).data.session.tracks.some(t=>t.videoId===removed));
 assert.deepEqual((await request(e,'/sessions/gaming-forza-pulse','GET',undefined,owner)).data.session,old);
 assert.deepEqual((await request(e,'/sessions/ride-cruiser','GET',undefined,owner)).data.session,ride);
 assert.equal((await request(e,'/sessions/ride-cruiser','DELETE',undefined,owner,ride.version)).status,200);
 for(let i=0;i<2;i++){
  assert.equal((await request(e,'/collections')).data.collections.filter(p=>p.category==='ride').length,7);
  assert.equal((await request(e,'/sessions/ride-cruiser')).status,404);
 }
 assert.deepEqual((await request(e,'/sessions/gaming-forza-pulse','GET',undefined,owner)).data.session,old);
});

const activeDefinitions=importedDefinitions.filter(p=>p.category==='active');
test('Active exposes eight audited workout and outdoor playlists with ordered metadata and deduplicated source membership',async()=>{
 assert.deepEqual(activeDefinitions.map(p=>[p.slug,p.tracks.length]),[
  ['active-workout-ncs',96],['active-running-dnb',73],['active-strength-hiphop',62],['active-running-rock',23],
  ['active-cardio-pop',71],['active-cycling-house',27],['active-viet-remix',76],['active-cool-down',16],
 ]);
 assert.equal(activeDefinitions.reduce((n,p)=>n+p.sourceTrackCount,0),469);
 assert.equal(activeDefinitions.reduce((n,p)=>n+p.unavailableCount,0),25);
 const oldIds=new Set(allDefinitions.slice(0,allDefinitions.findIndex(p=>p.category==='active')).flatMap(p=>p.videoIds));
 const activeIds=activeDefinitions.flatMap(p=>p.tracks.map(t=>t.videoId)),unique=new Set(activeIds);
 assert.equal(activeIds.length,444);assert.equal(unique.size,432);assert.equal([...unique].filter(id=>!oldIds.has(id)).length,428);
 assert.equal(activeDefinitions.filter(p=>p.curator==='NoCopyrightSounds').length,2);
 const e=env(),catalogue=(await request(e,'/collections')).data.collections,aggregate=(await request(e,'/library')).data.session;
 const admin=(await request(e,'/admin/playlists','GET',undefined,owner)).data.playlists;
 assert.equal(catalogue.filter(p=>p.category==='active').length,8);
 for(const p of activeDefinitions){
  assert.ok(p.tracks.length<=MAX_TRACKS);assert.equal(p.tracks.length+p.duplicateCount+p.unavailableCount,p.sourceTrackCount);
  assert.equal(p.musicVisibleItemCount,p.sourceTrackCount);assert.equal(p.sourcePageCount,1);
  const c=catalogue.find(c=>c.slug===p.slug);assert.equal(c.category,'active');assert.equal(c.count,p.tracks.length);assert.equal(c.canEdit,false);
  assert.equal(c.source.url,`https://music.youtube.com/playlist?list=${p.sourcePlaylistId}`);assert.equal(c.source.curator,p.curator);assert.equal(c.source.unavailableCount,p.unavailableCount);
  const a=admin.find(a=>a.slug===p.slug);assert.equal(a.category,'active');assert.equal(a.listed,true);
  const s=(await request(e,`/sessions/${p.slug}`)).data.session;assert.equal(s.canEdit,false);assert.equal(s.name,p.name);
  assert.deepEqual(s.tracks.map(t=>t.videoId),p.tracks.map(t=>t.videoId));
  for(const t of s.tracks){
   assert.ok(t.title&&t.channel);assert.equal(t.url,`https://www.youtube.com/watch?v=${t.videoId}`);
   const matches=aggregate.tracks.filter(t2=>t2.videoId===t.videoId);assert.equal(matches.length,1);assert.ok(matches[0].sourcePlaylists.some(source=>source.slug===p.slug));
   if(oldIds.has(t.videoId))assert.ok(matches[0].sourcePlaylists.some(source=>!source.slug.startsWith('active-')));
  }
 }
 assert.deepEqual((await request(e,'/library')).data.session,aggregate);
});
test('Active seeds on an edited database with creator-only changes and does not resurrect deleted songs or playlists',async()=>{
 const e=env();let old=(await request(e,'/sessions/ride-cruiser','GET',undefined,owner)).data.session;
 old=(await request(e,'/sessions/ride-cruiser','PATCH',{name:'Road Songs của tôi'},owner,old.version)).data.session;
 old=(await request(e,'/sessions/ride-cruiser/order','PATCH',{ids:old.tracks.map(t=>t.videoId).reverse()},owner,old.version)).data.session;
 assert.equal(e.DB.raw.prepare("SELECT count(*) n FROM sessions WHERE slug LIKE 'active-%'").get().n,0);
 let active=(await request(e,'/sessions/active-workout-ncs','GET',undefined,owner)).data.session;assert.equal(active.canEdit,true);
 assert.equal((await request(e,'/sessions/active-workout-ncs','PATCH',{name:'Unauthorized'},other,active.version)).status,403);
 assert.equal((await request(e,'/sessions/active-workout-ncs','DELETE',undefined,{},active.version)).status,403);
 const removed=active.tracks.find(t=>!allDefinitions.filter(p=>p.slug!=='active-workout-ncs').some(p=>p.videoIds.includes(t.videoId)))?.videoId;assert.ok(removed);
 active=(await request(e,'/sessions/active-workout-ncs/tracks','DELETE',{videoId:removed},owner,active.version)).data.session;
 await request(e,'/collections');assert.ok(!(await request(e,'/library')).data.session.tracks.some(t=>t.videoId===removed));
 assert.deepEqual((await request(e,'/sessions/ride-cruiser','GET',undefined,owner)).data.session,old);
 assert.deepEqual((await request(e,'/sessions/active-workout-ncs','GET',undefined,owner)).data.session,active);
 assert.equal((await request(e,'/sessions/active-workout-ncs','DELETE',undefined,owner,active.version)).status,200);
 for(let i=0;i<2;i++){
  assert.equal((await request(e,'/collections')).data.collections.filter(p=>p.category==='active').length,7);
  assert.equal((await request(e,'/sessions/active-workout-ncs')).status,404);
 }
 assert.deepEqual((await request(e,'/sessions/ride-cruiser','GET',undefined,owner)).data.session,old);
});
test('an audited import fills a missing metadata cache, preserves successful metadata and rejects an older fallback replacement',async()=>{
 const e=env(),p=activeDefinitions[0],[missing,successful]=p.tracks;
 let own=await create(e,'metadata-owner');own=(await request(e,'/sessions/metadata-owner/tracks','POST',{text:`${missing.videoId}\n${successful.videoId}`},owner,own.version)).data.session;
 const row=e.DB.raw.prepare('SELECT * FROM sessions WHERE slug=?').get(own.slug);
 const save=(db,t,title,channel,status,expires)=>db.raw.prepare('INSERT OR REPLACE INTO metadata (video_id,title,channel,thumbnail,status,expires_at) VALUES (?,?,?,?,?,?)').run(t.videoId,title,channel,t.thumbnail,status,expires);
 save(e.DB,missing,`Video YouTube · ${missing.videoId}`,null,'unavailable',p.fetchedAt+900000-600000);
 save(e.DB,successful,'A successful cached title','A successful cached channel','ready',p.fetchedAt+86400000-600000);
 const loaded=(await request(e,`/sessions/${p.slug}`)).data.session;
 assert.equal(loaded.tracks.find(t=>t.videoId===missing.videoId).title,missing.title);assert.equal(loaded.tracks.find(t=>t.videoId===missing.videoId).channel,missing.channel);
 assert.equal(loaded.tracks.find(t=>t.videoId===successful.videoId).title,'A successful cached title');
 assert.equal(loaded.tracks.find(t=>t.videoId===successful.videoId).channel,'A successful cached channel');
 assert.deepEqual(e.DB.raw.prepare('SELECT * FROM sessions WHERE slug=?').get(own.slug),row);
 const e2=env(),older=importedDefinitions.find(p=>p.category==='viet'),t=older.tracks[0];
 save(e2.DB,t,'A newer unavailable cache entry',null,'unavailable',older.fetchedAt+900000+60000);
 await request(e2,`/sessions/${older.slug}`);
 assert.equal(e2.DB.raw.prepare('SELECT title FROM metadata WHERE video_id=?').get(t.videoId).title,'A newer unavailable cache entry');
});

test('Paris at night exposes the original elisad jazz mix as one persistent video source',async()=>{
 const def=importedDefinitions.find(p=>p.slug==='paris-at-night-jazz');assert.ok(def);assert.equal(def.sourceKind,'video');assert.equal(def.sourcePlaylistId,null);assert.equal(def.curator,'elisad');
 assert.equal(def.sourceUrl,'https://www.youtube.com/watch?v=EQfKnvCFs1Y');assert.equal(def.tracks.length,1);assert.equal(def.tracks[0].durationSeconds,1117);
 const e=env(),r=await request(e,'/sessions/paris-at-night-jazz');assert.equal(r.status,200);let s=r.data.session;
 assert.equal(s.name,'imagine you are in Paris at night (jazz playlist)');assert.equal(s.canEdit,false);assert.deepEqual(s.tracks.map(t=>t.videoId),['EQfKnvCFs1Y']);assert.equal(s.tracks[0].channel,'elisad');assert.equal(s.tracks[0].title,def.sourceTitle);
 assert.equal(e.DB.raw.prepare('SELECT count(*) n FROM sessions').get().n,1);assert.equal(s.version,1);
 for(const auth of [{},other])assert.equal((await request(e,'/sessions/paris-at-night-jazz','DELETE',undefined,auth,s.version)).status,403);
 const c=(await request(e,'/collections')).data.collections.find(p=>p.slug===def.slug);assert.equal(c.count,1);assert.equal(c.source.kind,'video');assert.equal(c.source.url,def.sourceUrl);assert.equal(c.source.curator,'elisad');assert.equal(c.longformVideoIds,undefined);
 const all=(await request(e,'/library')).data.session;assert.equal(all.tracks.filter(t=>t.videoId==='EQfKnvCFs1Y').length,1);assert.ok(all.tracks.find(t=>t.videoId==='EQfKnvCFs1Y').sourcePlaylists.some(p=>p.slug===def.slug));
 assert.deepEqual((await request(e,'/sessions/paris-at-night-jazz')).data.session,s);
 const admin=(await request(e,'/admin/playlists','GET',undefined,owner)).data.playlists.find(p=>p.slug===def.slug);assert.equal(admin.count,1);assert.equal(admin.category,'curated');
 s=(await request(e,'/sessions/paris-at-night-jazz','PATCH',{name:'Paris của tôi'},owner,s.version)).data.session;assert.equal((await request(e,'/sessions/paris-at-night-jazz')).data.session.name,s.name);
 assert.equal((await request(e,'/sessions/paris-at-night-jazz','DELETE',undefined,owner,s.version)).status,200);
 await request(e,'/collections');assert.equal((await request(e,'/sessions/paris-at-night-jazz')).status,404);assert.ok(!(await request(e,'/library')).data.session.tracks.some(t=>t.videoId==='EQfKnvCFs1Y'));
});

test('Nhạc AI exposes three persistent, owner-managed selections with both user references and real source metadata',async()=>{
 const defs=importedDefinitions.filter(p=>p.category==='ai');assert.equal(defs.length,3);
 const ids=defs.flatMap(p=>p.tracks.map(t=>t.videoId));assert.equal(ids.length,24);assert.equal(new Set(ids).size,24);
 assert.ok(ids.includes('BFJLoa1g5Pw'));assert.ok(ids.includes('KOCVv4acEhg'));
 const e=env(),before=(await request(e,'/sessions/shelby','GET',undefined,owner)).data.session;
 const catalogue=(await request(e,'/collections')).data.collections.filter(p=>p.category==='ai');assert.equal(catalogue.length,3);
 const admin=(await request(e,'/admin/playlists','GET',undefined,owner)).data.playlists.filter(p=>p.category==='ai');assert.equal(admin.length,3);
 for(const p of defs){
  const result=await request(e,'/sessions/'+p.slug);assert.equal(result.status,200);const s=result.data.session;
  assert.equal(s.canEdit,false);assert.equal(s.name,p.name);assert.equal(s.tracks.length,8);assert.deepEqual(s.tracks.map(t=>t.videoId),p.tracks.map(t=>t.videoId));
  assert.ok(s.tracks.every(t=>t.channel&&t.title&&!t.title.startsWith('Video YouTube')));
  assert.equal(catalogue.find(c=>c.slug===p.slug).source.kind,'curated');assert.equal(admin.find(c=>c.slug===p.slug).listed,true);
  assert.deepEqual((await request(e,'/sessions/'+p.slug)).data.session,s);
  for(const auth of [{},other])assert.equal((await request(e,'/sessions/'+p.slug,'DELETE',undefined,auth,s.version)).status,403);
 }
 assert.deepEqual((await request(e,'/sessions/shelby','GET',undefined,owner)).data.session,before);
 const aggregate=(await request(e,'/library')).data.session;
 for(const id of ids){const matches=aggregate.tracks.filter(t=>t.videoId===id);assert.equal(matches.length,1);assert.ok(matches[0].sourcePlaylists.some(p=>p.slug.startsWith('ai-')));}
 const first=defs[0],s=(await request(e,'/sessions/'+first.slug,'GET',undefined,owner)).data.session;
 assert.equal((await request(e,'/sessions/'+first.slug,'DELETE',undefined,owner,s.version)).status,200);
 assert.ok(!(await request(e,'/collections')).data.collections.some(c=>c.slug===first.slug));assert.equal((await request(e,'/sessions/'+first.slug)).status,404);
});

const bimSource=importedDefinitions.find(p=>p.slug==='bim');
const bimIds=[...bimSource.tracks,...bimSource.additionalTracks].map(t=>t.videoId);
const bimAdditionMarker=`imported-additions:${bimSource.sourcePlaylistId}:${bimSource.additionalRevision}`;
function previousBimDatabase(ids=['w8r5zDA4awM']){
 const e=env(),now=Date.now(),original=ids.map(videoId=>({videoId,addedAt:now-1000}));
 e.DB.raw.prepare('INSERT INTO seeds (key) VALUES (?)').run(bimSource.seedKey);
 e.DB.raw.prepare('INSERT INTO sessions (slug,name,owner_id,tracks,version,created_at,updated_at) VALUES (?,?,?,?,4,?,?)').run('bim','bim','__seed__',JSON.stringify(original),now,now);
 return {e,original};
}
test('bim mix appends the supplied snapshot once and preserves prior admin edits and later removals',async()=>{
 assert.equal(bimIds.length,25);assert.equal(new Set(bimIds).size,25);assert.equal(bimSource.tracks.length,1);assert.equal(bimSource.additionalTracks.length,24);
 const fresh=env(),first=(await request(fresh,'/sessions/bim')).data.session;
 assert.deepEqual(first.tracks.map(t=>t.videoId),bimIds);assert.deepEqual((await request(fresh,'/sessions/bim')).data.session,first);
 const {e,original}=previousBimDatabase(['abcdefghijk',bimIds[0],bimIds[2]]);
 e.DB.raw.prepare("UPDATE sessions SET name='Bim của tôi' WHERE slug='bim'").run();
 let s=(await request(e,'/sessions/bim','GET',undefined,owner)).data.session;
 assert.equal(s.name,'Bim của tôi');assert.equal(s.version,5);assert.deepEqual(s.tracks.slice(0,original.length).map(t=>t.videoId),original.map(t=>t.videoId));
 assert.deepEqual(s.tracks.map(t=>t.videoId),[...original.map(t=>t.videoId),...bimIds.filter(id=>!original.some(t=>t.videoId===id))]);
 assert.ok(e.DB.raw.prepare('SELECT key FROM seeds WHERE key=?').get(bimAdditionMarker));
 s=(await request(e,'/sessions/bim/tracks','DELETE',{videoId:bimIds[1]},owner,s.version)).data.session;
 for(let i=0;i<2;i++){await request(e,'/collections');assert.deepEqual((await request(e,'/sessions/bim','GET',undefined,owner)).data.session,s);}
 assert.equal((await request(e,'/sessions/bim','DELETE',undefined,owner,s.version)).status,200);
 assert.ok(!(await request(e,'/collections')).data.collections.some(p=>p.slug==='bim'));assert.equal((await request(e,'/sessions/bim')).status,404);
});
test('bim addition rolls back a failed receipt and retries concurrent edits without dropping tracks',async()=>{
 for(const mode of ['failure','concurrent']){
  const {e,original}=previousBimDatabase(),batch=e.DB.batch.bind(e.DB);let intercept=true;
  e.DB.batch=async statements=>{
   if(intercept&&statements.some(s=>s.sql.startsWith('UPDATE sessions SET tracks='))){
    intercept=false;
    if(mode==='failure')statements[1].run=async()=>{throw Error('Fixture bim receipt failure');};
    else e.DB.raw.prepare("UPDATE sessions SET tracks=?,name='Concurrent bim edit',version=version+1 WHERE slug='bim'").run(JSON.stringify([...original,{videoId:'abcdefghijk',addedAt:Date.now()}]));
   }
   return batch(statements);
  };
  let r=await request(e,'/sessions/bim');
  if(mode==='failure'){
   assert.equal(r.status,503);assert.equal(e.DB.raw.prepare('SELECT key FROM seeds WHERE key=?').get(bimAdditionMarker),undefined);
   assert.deepEqual(JSON.parse(e.DB.raw.prepare("SELECT tracks FROM sessions WHERE slug='bim'").get().tracks),original);
   r=await request(e,'/sessions/bim');
  }
  assert.equal(r.status,200);const s=r.data.session;
  assert.deepEqual(s.tracks.map(t=>t.videoId),mode==='failure'?bimIds:[bimIds[0],'abcdefghijk',...bimIds.slice(1)]);
  if(mode==='concurrent')assert.equal(s.name,'Concurrent bim edit');
  assert.ok(e.DB.raw.prepare('SELECT key FROM seeds WHERE key=?').get(bimAdditionMarker));assert.deepEqual((await request(e,'/sessions/bim')).data.session,s);
 }
});

const babySource=importedDefinitions.find(p=>p.slug==='be-ngu-ngoan');
const babyArchive=JSON.parse(readFileSync('docs/archives/be-ngu-ngoan-v32.json','utf8'));
const babyOldIds=[...babyArchive.tracks,...babyArchive.additionalTracks].map(t=>t.videoId);
const babyPrevious=JSON.parse(readFileSync('docs/archives/be-ngu-ngoan-v35.json','utf8'));
const babyIds=['377o0R09Y0U'];
const babyMarker=`imported-replacement:be-ngu-ngoan:${babySource.replacement.revision}`;
test('baby playlist contains exactly the single user-provided video with real YouTube metadata',async()=>{
 assert.equal(babySource.name,'Baby Sleep Instantly');assert.equal(babySource.sourceKind,'video');assert.equal(babySource.sourcePlaylistId,null);
 assert.equal(babySource.seedKey,`imported:${babyArchive.sourcePlaylistId}:v1`);assert.equal(babyOldIds.length,23);
 assert.equal(babySource.replacement.replaceAll,true);assert.ok([...babyOldIds,...babyPrevious.tracks.map(t=>t.videoId)].every(id=>babySource.replacement.videoIds.includes(id)));assert.deepEqual(babySource.tracks.map(t=>t.videoId),babyIds);
 assert.equal(babySource.tracks.length,1);assert.ok(babySource.tracks.every(t=>t.fetchedAt&&t.channel==='Baby Sleep Music Melody'));assert.ok(!babyIds.some(id=>babyOldIds.includes(id)));
 const e=env(),direct=await request(e,'/sessions/be-ngu-ngoan');assert.equal(direct.status,200);
 const s=direct.data.session;assert.equal(s.name,babySource.name);assert.equal(s.canEdit,false);assert.equal(s.version,1);assert.deepEqual(s.tracks.map(t=>t.videoId),babyIds);
 assert.equal(e.DB.raw.prepare("SELECT count(*) n FROM sessions").get().n,1,'Direct entry initializes only this playlist');
 assert.ok(e.DB.raw.prepare('SELECT key FROM seeds WHERE key=?').get(babyMarker));
 for(const [i,t] of s.tracks.entries()){assert.equal(t.title,babySource.tracks[i].title);assert.equal(t.channel,babySource.tracks[i].channel);assert.ok(['ready','pending'].includes(t.metadataStatus));assert.equal(t.url,`https://www.youtube.com/watch?v=${t.videoId}`);}
 const entry=(await request(e,'/collections')).data.collections.find(p=>p.slug===s.slug);assert.equal(entry.count,1);assert.equal(entry.longformVideoIds,undefined);assert.equal(entry.source.kind,'video');assert.equal(entry.source.url,`https://www.youtube.com/watch?v=${babyIds[0]}`);
 const aggregate=(await request(e,'/library')).data.session;
 for(const id of babyIds){const rows=aggregate.tracks.filter(t=>t.videoId===id);assert.equal(rows.length,1);assert.ok(rows[0].sourcePlaylists.some(p=>p.slug===s.slug));}
 assert.ok(!aggregate.tracks.some(t=>babyOldIds.includes(t.videoId)&&t.sourcePlaylists.some(p=>p.slug===s.slug)));
 const admin=(await request(e,'/admin/playlists','GET',undefined,owner)).data.playlists.find(p=>p.slug===s.slug);assert.equal(admin.listed,true);assert.equal(admin.category,'curated');assert.equal(admin.count,1);
 assert.deepEqual((await request(e,'/sessions/be-ngu-ngoan')).data.session,s);
});
test('the replacement playlist retains admin permissions and does not restore later deletions',async()=>{
 const e=env();let old=(await request(e,'/sessions/shelby','GET',undefined,owner)).data.session;
 old=(await request(e,'/sessions/shelby','PATCH',{name:'Shelby của tôi'},owner,old.version)).data.session;
 let s=(await request(e,'/sessions/be-ngu-ngoan','GET',undefined,owner)).data.session;assert.equal(s.canEdit,true);
 for(const auth of [{},other]){
  assert.equal((await request(e,'/sessions/be-ngu-ngoan','PATCH',{name:'Unauthorized'},auth,s.version)).status,403);
  assert.equal((await request(e,'/sessions/be-ngu-ngoan','DELETE',undefined,auth,s.version)).status,403);
 }
 s=(await request(e,'/sessions/be-ngu-ngoan','PATCH',{name:'Nhạc ru của bé'},owner,s.version)).data.session;
 s=(await request(e,'/sessions/be-ngu-ngoan/tracks','DELETE',{videoId:babyIds[0]},owner,s.version)).data.session;
 await request(e,'/collections');assert.deepEqual((await request(e,'/sessions/be-ngu-ngoan','GET',undefined,owner)).data.session,s);assert.equal(s.tracks.length,0);
 assert.deepEqual((await request(e,'/sessions/shelby','GET',undefined,owner)).data.session,old);
 assert.equal((await request(e,'/sessions/be-ngu-ngoan','DELETE',undefined,owner,s.version)).status,200);
 for(let i=0;i<2;i++){assert.ok(!(await request(e,'/collections')).data.collections.some(p=>p.slug==='be-ngu-ngoan'));assert.equal((await request(e,'/sessions/be-ngu-ngoan')).status,404);}
 assert.deepEqual((await request(e,'/sessions/shelby','GET',undefined,owner)).data.session,old);
});
function previousBabyDatabase(ids=babyPrevious.tracks.map(t=>t.videoId)){
 const e=env(),now=Date.now(),original=ids.map(videoId=>({videoId,addedAt:now-1000}));
 e.DB.raw.prepare('INSERT INTO seeds (key) VALUES (?)').run(babySource.seedKey);
 e.DB.raw.prepare('INSERT INTO seeds (key) VALUES (?)').run(`imported-additions:${babyArchive.sourcePlaylistId}:${babyArchive.additionalRevision}`);
 e.DB.raw.prepare('INSERT INTO seeds (key) VALUES (?)').run(`imported-replacement:be-ngu-ngoan:${babyPrevious.replacement.revision}`);
 e.DB.raw.prepare('INSERT INTO sessions (slug,name,owner_id,tracks,version,created_at,updated_at) VALUES (?,?,?,?,7,?,?)').run('be-ngu-ngoan',babyPrevious.name,'__seed__',JSON.stringify(original),now,now);
 return {e,original,marker:babyMarker};
}
test('single-video replacement upgrades all three prior versions without changing unrelated playlists',async()=>{
 for(const ids of [babyOldIds,babyArchive.tracks.map(t=>t.videoId),babyPrevious.tracks.map(t=>t.videoId)]){
  const {e,marker}=previousBabyDatabase(ids);let shelby=(await request(e,'/sessions/shelby','GET',undefined,owner)).data.session;
  shelby=(await request(e,'/sessions/shelby','PATCH',{name:'Preserve this name'},owner,shelby.version)).data.session;
  const s=(await request(e,'/sessions/be-ngu-ngoan','GET',undefined,owner)).data.session;
  assert.equal(s.version,8);assert.equal(s.name,'Baby Sleep Instantly');assert.deepEqual(s.tracks.map(t=>t.videoId),babyIds);assert.ok(e.DB.raw.prepare('SELECT key FROM seeds WHERE key=?').get(marker));
  for(let i=0;i<2;i++){await request(e,'/collections');assert.deepEqual((await request(e,'/sessions/be-ngu-ngoan','GET',undefined,owner)).data.session,s);}
  assert.deepEqual((await request(e,'/sessions/shelby','GET',undefined,owner)).data.session,shelby);
 }
});
test('a pending replacement never recreates a deleted playlist or reclaims one owned by another user',async()=>{
 const deleted=previousBabyDatabase();deleted.e.DB.raw.prepare("DELETE FROM sessions WHERE slug='be-ngu-ngoan'").run();assert.equal((await request(deleted.e,'/sessions/be-ngu-ngoan')).status,404);assert.ok(deleted.e.DB.raw.prepare('SELECT key FROM seeds WHERE key=?').get(deleted.marker));
 const foreign=previousBabyDatabase();foreign.e.DB.raw.prepare("UPDATE sessions SET owner_id='unrelated-owner' WHERE slug='be-ngu-ngoan'").run();const before=foreign.e.DB.raw.prepare("SELECT * FROM sessions WHERE slug='be-ngu-ngoan'").get();
 const privateRoom=(await request(foreign.e,'/sessions/be-ngu-ngoan')).data.session;assert.equal(privateRoom.canEdit,false);assert.equal(privateRoom.tracks.length,6);assert.deepEqual(foreign.e.DB.raw.prepare("SELECT * FROM sessions WHERE slug='be-ngu-ngoan'").get(),before);assert.ok(foreign.e.DB.raw.prepare('SELECT key FROM seeds WHERE key=?').get(foreign.marker));
});
test('replacement data and receipt commit atomically, with safe bounded retries and an exact one-video result',async()=>{
 for(const mode of ['failure','concurrent']){
  const {e,original,marker}=previousBabyDatabase(),batch=e.DB.batch.bind(e.DB);let intercept=true;
  e.DB.batch=async statements=>{
   if(intercept&&statements.some(s=>s.sql.startsWith('UPDATE sessions SET tracks='))){
    intercept=false;
    if(mode==='failure')statements[1].run=async()=>{throw Error('Fixture replacement receipt failure');};
    else e.DB.raw.prepare("UPDATE sessions SET tracks=?,name='Concurrent family edit',version=version+1 WHERE slug='be-ngu-ngoan'").run(JSON.stringify([...original,{videoId:'abcdefghijk',addedAt:Date.now()}]));
   }
   return batch(statements);
  };
  let r=await request(e,'/sessions/be-ngu-ngoan','GET',undefined,owner);
  if(mode==='failure'){
   assert.equal(r.status,503);assert.equal(e.DB.raw.prepare("SELECT version FROM sessions WHERE slug='be-ngu-ngoan'").get().version,7);assert.equal(e.DB.raw.prepare('SELECT key FROM seeds WHERE key=?').get(marker),undefined);
   assert.deepEqual(JSON.parse(e.DB.raw.prepare("SELECT tracks FROM sessions WHERE slug='be-ngu-ngoan'").get().tracks),original);
   r=await request(e,'/sessions/be-ngu-ngoan','GET',undefined,owner);
  }
  assert.equal(r.status,200);assert.ok(e.DB.raw.prepare('SELECT key FROM seeds WHERE key=?').get(marker));
  const s=r.data.session;assert.equal(s.version,mode==='failure'?8:9);assert.deepEqual(s.tracks.map(t=>t.videoId),babyIds);assert.ok(!s.tracks.some(t=>babyOldIds.includes(t.videoId)));
  if(mode==='concurrent'){assert.equal(s.name,'Concurrent family edit');assert.ok(!s.tracks.some(t=>t.videoId==='abcdefghijk'));}
  assert.deepEqual((await request(e,'/sessions/be-ngu-ngoan','GET',undefined,owner)).data.session,s);
 }
});
test('continuous edits stop after bounded replacement retries without writing a receipt',async()=>{
 const {e,marker}=previousBabyDatabase(),batch=e.DB.batch.bind(e.DB);let conflicts=0;
 e.DB.batch=async statements=>{if(statements.some(s=>s.sql.startsWith('UPDATE sessions SET tracks='))){conflicts++;e.DB.raw.prepare("UPDATE sessions SET version=version+1 WHERE slug='be-ngu-ngoan'").run();}return batch(statements);};
 assert.equal((await request(e,'/sessions/be-ngu-ngoan')).status,409);assert.equal(conflicts,3);assert.equal(e.DB.raw.prepare('SELECT key FROM seeds WHERE key=?').get(marker),undefined);
 assert.deepEqual(JSON.parse(e.DB.raw.prepare("SELECT tracks FROM sessions WHERE slug='be-ngu-ngoan'").get().tracks).map(t=>t.videoId),babyPrevious.tracks.map(t=>t.videoId));
 e.DB.batch=batch;assert.deepEqual((await request(e,'/sessions/be-ngu-ngoan')).data.session.tracks.map(t=>t.videoId),babyIds);
});
test('full replacement clears every prior item, including a full playlist, and later admin changes are not reset',async()=>{
 const {e,marker}=previousBabyDatabase(),ids=Array.from({length:MAX_TRACKS},(_,i)=>String(i).padStart(11,'0'));
 e.DB.raw.prepare("UPDATE sessions SET tracks=? WHERE slug='be-ngu-ngoan'").run(JSON.stringify(ids.map(videoId=>({videoId,addedAt:0}))));
 let r=await request(e,'/sessions/be-ngu-ngoan','GET',undefined,owner);assert.equal(r.status,200);assert.deepEqual(r.data.session.tracks.map(t=>t.videoId),babyIds);assert.equal(r.data.session.version,8);assert.ok(e.DB.raw.prepare('SELECT key FROM seeds WHERE key=?').get(marker));
 r=await request(e,'/sessions/be-ngu-ngoan/tracks','POST',{text:'abcdefghijk'},owner,r.data.session.version);assert.equal(r.status,200);
 assert.deepEqual((await request(e,'/sessions/be-ngu-ngoan','GET',undefined,owner)).data.session,r.data.session);assert.deepEqual(r.data.session.tracks.map(t=>t.videoId),[...babyIds,'abcdefghijk']);
});

const dopamineDefinitions=importedDefinitions.filter(p=>p.category==='dopamine');
test('Dopamine exposes eight audited sources, 185 ordered videos and 178 new aggregate IDs',async()=>{
 assert.deepEqual(dopamineDefinitions.map(p=>[p.slug,p.tracks.length]),[
  ['dopamine-festival',10],['dopamine-vocal-trance',13],['dopamine-hardstyle',16],['dopamine-bass-drop',81],
  ['dopamine-hardwave',10],['dopamine-cinematic',25],['dopamine-afterglow',16],['dopamine-french-house',14],
 ]);
 assert.equal(dopamineDefinitions.reduce((n,p)=>n+p.sourceTrackCount,0),186);
 assert.equal(dopamineDefinitions.reduce((n,p)=>n+p.unavailableCount,0),1);
 const oldIds=new Set(allDefinitions.slice(0,allDefinitions.findIndex(p=>p.category==='dopamine')).flatMap(p=>p.videoIds));
 const ids=dopamineDefinitions.flatMap(p=>p.tracks.map(t=>t.videoId));assert.equal(new Set(ids).size,185);assert.equal(ids.filter(id=>!oldIds.has(id)).length,178);
 const e=env(),catalogue=(await request(e,'/collections')).data.collections,aggregate=(await request(e,'/library')).data.session;
 const admin=(await request(e,'/admin/playlists','GET',undefined,owner)).data.playlists;
 assert.equal(catalogue.filter(p=>p.category==='dopamine').length,8);
 for(const p of dopamineDefinitions){
  assert.ok(p.tracks.length<=MAX_TRACKS);assert.equal(p.tracks.length+p.duplicateCount+p.unavailableCount,p.sourceTrackCount);
  assert.equal(p.musicVisibleItemCount,p.sourceTrackCount);assert.equal(p.sourcePageCount,1);
  const c=catalogue.find(c=>c.slug===p.slug);assert.equal(c.category,'dopamine');assert.equal(c.count,p.tracks.length);assert.equal(c.canEdit,false);
  assert.equal(c.source.url,`https://music.youtube.com/playlist?list=${p.sourcePlaylistId}`);assert.equal(c.source.curator,p.curator);assert.equal(c.source.unavailableCount,p.unavailableCount);
  const a=admin.find(a=>a.slug===p.slug);assert.equal(a.category,'dopamine');assert.equal(a.listed,true);
  const s=(await request(e,`/sessions/${p.slug}`)).data.session;assert.equal(s.canEdit,false);assert.equal(s.name,p.name);
  assert.deepEqual(s.tracks.map(t=>t.videoId),p.tracks.map(t=>t.videoId));
  for(const t of s.tracks){
   assert.ok(t.title&&t.channel);assert.equal(t.url,`https://www.youtube.com/watch?v=${t.videoId}`);
   const matches=aggregate.tracks.filter(t2=>t2.videoId===t.videoId);assert.equal(matches.length,1);assert.ok(matches[0].sourcePlaylists.some(source=>source.slug===p.slug));
   if(oldIds.has(t.videoId))assert.ok(matches[0].sourcePlaylists.some(source=>!source.slug.startsWith('dopamine-')));
  }
 }
 assert.deepEqual((await request(e,'/library')).data.session,aggregate);
});
test('Dopamine preserves existing edits and creator-only permissions; retries cannot restore removed content',async()=>{
 const e=env();let old=(await request(e,'/sessions/active-workout-ncs','GET',undefined,owner)).data.session;
 old=(await request(e,'/sessions/active-workout-ncs','PATCH',{name:'Workout của tôi'},owner,old.version)).data.session;
 old=(await request(e,'/sessions/active-workout-ncs/order','PATCH',{ids:old.tracks.map(t=>t.videoId).reverse()},owner,old.version)).data.session;
 assert.equal(e.DB.raw.prepare("SELECT count(*) n FROM sessions WHERE slug LIKE 'dopamine-%'").get().n,0);
 let s=(await request(e,'/sessions/dopamine-festival','GET',undefined,owner)).data.session;assert.equal(s.canEdit,true);
 assert.equal((await request(e,'/sessions/dopamine-festival','PATCH',{name:'Unauthorized'},other,s.version)).status,403);
 assert.equal((await request(e,'/sessions/dopamine-festival','DELETE',undefined,{},s.version)).status,403);
 const removed=s.tracks.find(t=>!allDefinitions.filter(p=>p.slug!=='dopamine-festival').some(p=>p.videoIds.includes(t.videoId)))?.videoId;assert.ok(removed);
 s=(await request(e,'/sessions/dopamine-festival/tracks','DELETE',{videoId:removed},owner,s.version)).data.session;
 await request(e,'/collections');assert.ok(!(await request(e,'/library')).data.session.tracks.some(t=>t.videoId===removed));
 assert.deepEqual((await request(e,'/sessions/active-workout-ncs','GET',undefined,owner)).data.session,old);
 assert.deepEqual((await request(e,'/sessions/dopamine-festival','GET',undefined,owner)).data.session,s);
 assert.equal((await request(e,'/sessions/dopamine-festival','DELETE',undefined,owner,s.version)).status,200);
 for(let i=0;i<2;i++){
  assert.equal((await request(e,'/collections')).data.collections.filter(p=>p.category==='dopamine').length,7);
  assert.equal((await request(e,'/sessions/dopamine-festival')).status,404);
 }
 assert.deepEqual((await request(e,'/sessions/active-workout-ncs','GET',undefined,owner)).data.session,old);
});
