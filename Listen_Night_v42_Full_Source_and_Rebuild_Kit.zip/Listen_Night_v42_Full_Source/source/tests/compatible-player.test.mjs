import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import vm from 'node:vm';
import {needsCompatiblePlayer,compatibilityResponse,varyListeningResponse,COMPATIBILITY_BOOTSTRAP} from '../.sites-runtime/tests/browser-support.mjs';

const script=readFileSync('compat/listen.js','utf8'),html=readFileSync('compat/index.html','utf8'),style=readFileSync('compat/listen.css','utf8');
const espree=createRequire(import.meta.resolve('eslint'))('espree');
const ios12='Mozilla/5.0 (iPad; CPU OS 12_5_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1.2 Mobile/15E148 Safari/604.1';
const modern='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36';
const assets={html,script,style};
test('old Apple browsers receive the compatible document before modern JavaScript, while current browsers and admin/API routes stay intact',async()=>{
 for(const ua of [ios12,ios12.replace('iPad','iPhone').replace('CPU OS','CPU iPhone OS'),ios12.replace('Version/12.1.2','CriOS/120.0.0.0'),ios12.replace('12_5_8','15_8_3'),'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/605.1.15 Version/13.1 Safari/605.1.15']){
  assert.equal(needsCompatiblePlayer(ua),true);
  const r=compatibilityResponse(new Request('https://listen.example/?s=be-ngu-ngoan',{headers:{'User-Agent':ua}}),assets);
  assert.equal(r.status,200);assert.equal(await r.text(),html);assert.equal(r.headers.get('cache-control'),'private, no-store');assert.match(r.headers.get('vary'),/User-Agent/);
 }
 for(const ua of [modern,ios12.replace('12_5_8','16_4').replace('12.1.2','16.4'),ios12.replace('12_5_8','18_0').replace('12.1.2','18.0')])assert.equal(needsCompatiblePlayer(ua),false);
 assert.equal(compatibilityResponse(new Request('https://listen.example/',{headers:{'User-Agent':modern}}),assets),null);
 for(const path of ['/api/sessions/be-ngu-ngoan','/bim','/_next/static/chunks/entry.js'])assert.equal(compatibilityResponse(new Request('https://listen.example'+path,{headers:{'User-Agent':ios12}}),assets),null);
 assert.equal(compatibilityResponse(new Request('https://listen.example/',{headers:{'User-Agent':ios12,RSC:'1'}}),assets),null);
 for(const path of ['/lite?s=be-ngu-ngoan','/lite/','/listen-lite.js?v=1','/listen-lite.css?v=1'])assert.equal(compatibilityResponse(new Request('https://listen.example'+path),assets).status,200);
 assert.equal(compatibilityResponse(new Request('https://listen.example/lite',{method:'POST'}),assets).status,405);
 assert.equal(await compatibilityResponse(new Request('https://listen.example/lite',{method:'HEAD'}),assets).text(),'');
 const varied=varyListeningResponse(new Request('https://listen.example/'),new Response('modern',{headers:{Vary:'RSC','Content-Type':'text/html'}}));assert.equal(varied.headers.get('vary'),'RSC, User-Agent');assert.equal(await varied.text(),'modern');
});
test('compatible assets and the startup redirect parse as ES5, have no modern bundle dependencies and keep safe fallback styles',()=>{
 assert.doesNotThrow(()=>espree.parse(script,{ecmaVersion:5,sourceType:'script'}));assert.doesNotThrow(()=>espree.parse(COMPATIBILITY_BOOTSTRAP,{ecmaVersion:5,sourceType:'script'}));
 assert.doesNotMatch(script,/\b(?:fetch|Promise|Map|Set|AbortController|ResizeObserver|IntersectionObserver|globalThis)\s*[.(]/);
 assert.doesNotMatch(html,/type=["']module|_next\/|three\.js|react-dom|https?:\/\/[^"']+\.js/);
 assert.doesNotMatch(style,/(?:aspect-ratio|backdrop-filter|color-mix|gap:|:has\()/);
 assert.match(style,/min-height:48px/);assert.match(style,/min-height:200px/);assert.match(style,/font-size:16px/);assert.match(style,/prefers-reduced-motion/);
 const redirected=[],location={pathname:'/',search:'?s=be-ngu-ngoan',hash:'#songs',replace:value=>redirected.push(value)};
 vm.runInNewContext(COMPATIBILITY_BOOTSTRAP,{window:{location}});assert.deepEqual(redirected,['/lite?s=be-ngu-ngoan#songs']);
 location.pathname='/bim';vm.runInNewContext(COMPATIBILITY_BOOTSTRAP,{window:{location}});assert.equal(redirected.length,1);
});

function fixture(options={}){
 const nodes=new Map(),requests=[],players=[],calls=[],timers=new Map(),intervals=[],listeners={};let clock=0,timerId=0;
 let document;
 class Node{
  constructor(tag='div',id=''){this.tagName=tag.toUpperCase();this.id=id;this.children=[];this.attributes={};this.style={};this.hidden=false;this.disabled=false;this.value='';this.clientWidth=640;this.parentNode=null;this._text='';}
  get firstChild(){return this.children[0]||null;}get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}set textContent(v){this._text=String(v);this.children=[];}
  appendChild(node){node.parentNode=this;this.children.push(node);return node;}removeChild(node){this.children.splice(this.children.indexOf(node),1);node.parentNode=null;return node;}
  setAttribute(k,v){this.attributes[k]=String(v);}getAttribute(k){return this.attributes[k]??null;}
  focus(){document.activeElement=this;}select(){this.selected=true;}setSelectionRange(a,b){this.selection=[a,b];}
 }
 for(const match of html.matchAll(/\bid="([^"]+)"/g))nodes.set(match[1],new Node('div',match[1]));
 document={title:'',hidden:false,head:new Node('head'),activeElement:null,getElementById:id=>{assert.ok(nodes.has(id),`Known HTML node ${id}`);return nodes.get(id);},createElement:tag=>new Node(tag),execCommand:()=>!options.copyBlocked,addEventListener:(name,fn)=>listeners['document:'+name]=fn};
 function XHR(){this.headers={};this.finished=false;}
 XHR.prototype.open=function(method,path){this.method=method;this.path=path;};XHR.prototype.setRequestHeader=function(k,v){this.headers[k]=v;};XHR.prototype.send=function(){requests.push(this);};
 XHR.prototype.abort=function(){this.aborted=true;if(this.onabort)this.onabort();};
 XHR.prototype.respond=function(data,status=200){this.finished=true;this.status=status;this.responseText=JSON.stringify(data);this.onload();};
 function Player(id,config){this.id='';this.config=config;this.position=0;this.duration=5400;this.state=-1;this.iframe=new Node('iframe');players.push(this);}
 Player.prototype.cueVideoById=function(v){this.id=v.videoId;this.position=v.startSeconds||0;calls.push(['cue',this.id,this.position]);};
 Player.prototype.loadVideoById=function(v){this.id=v.videoId;this.position=v.startSeconds||0;this.state=-1;calls.push(['load',this.id,this.position]);};
 Player.prototype.playVideo=function(){calls.push(['play',this.id]);};Player.prototype.pauseVideo=function(){calls.push(['pause',this.id]);};
 Player.prototype.seekTo=function(n){this.position=n;calls.push(['seek',n]);};Player.prototype.getCurrentTime=function(){return this.position;};Player.prototype.getDuration=function(){return this.duration;};Player.prototype.getPlayerState=function(){return this.state;};Player.prototype.getVideoData=function(){return {video_id:this.id};};Player.prototype.getIframe=function(){return this.iframe;};
 const location=new URL('https://listen.example/lite'+(options.search||'')),history=[];
 const window={document,location,history:{replaceState(a,b,path){history.push(path);const u=new URL(path,location);location.search=u.search;location.hash=u.hash;}},XMLHttpRequest:XHR,
  localStorage:{getItem:k=>{if(options.storageBlocked)throw Error('Storage blocked');return JSON.stringify(options.storage?.[k]??null);},setItem:(k,v)=>{if(options.storageBlocked)throw Error('Storage full');}},
  setTimeout:(fn,delay)=>{const id=++timerId;timers.set(id,{fn,at:clock+delay});return id;},clearTimeout:id=>timers.delete(id),setInterval:fn=>{intervals.push(fn);return intervals.length;},addEventListener:(name,fn)=>listeners['window:'+name]=fn};
 if(options.apiReady!==false)window.YT={Player};
 const sandbox=vm.createContext({window,document,Promise:undefined,fetch:undefined,Map:undefined,Set:undefined,AbortController:undefined,ResizeObserver:undefined,IntersectionObserver:undefined,globalThis:undefined});
 vm.runInContext('Array.prototype.at=undefined;String.prototype.replaceAll=undefined;',sandbox);
 vm.runInContext(script,sandbox);
 const get=id=>nodes.get(id);
 function respond(path,data,status=200){const req=requests.find(r=>r.path===path&&!r.finished&&!r.aborted);assert.ok(req,'Pending request '+path);req.respond(data,status);return req;}
 function emit(value){const p=players[0];p.state=value;p.config.events.onStateChange({data:value});}
 function ready(){const p=players[0];p.config.events.onReady({target:p});}
 function tick(ms){clock+=ms;let limit=0;for(;;){const next=[...timers].find(([,t])=>t.at<=clock);if(!next)break;assert.ok(limit++<100,'Bounded timers');timers.delete(next[0]);next[1].fn();}}
 function click(id){const node=get(id);assert.equal(node.disabled,false,`${id} enabled`);node.onclick.call(node);}
 return {get,nodes,requests,players,calls,window,document,Player,history,listeners,respond,ready,emit,tick,click,poll:()=>intervals.forEach(fn=>fn())};
}
const track=(id,title=id)=>({videoId:id,title,channel:'Fixture channel',metadataStatus:'ready'});
const ids=['e5Z9UDTIieo','IDBI9cwp1Ak','i2aC7YoKPTk','EqOh9pJtsOI','QQNB9g3q6VI','3eHRjbh29QM'];
const baby={slug:'be-ngu-ngoan',name:'Baby Sleep Instantly',tracks:ids.map(id=>track(id))};
const other={slug:'other-playlist',name:'Other',tracks:[track('abcdefghijk')]};
const catalogue=[{slug:baby.slug,name:baby.name,count:6,longformVideoIds:ids,description:'Six long recordings'},{slug:other.slug,name:other.name,count:1},{slug:'empty-room',name:'Empty',count:0}];
function loadBaby(h){h.respond('/api/sessions/be-ngu-ngoan',{session:baby});h.respond('/api/collections',{collections:catalogue});}

test('compatible playlist picker labels Nhạc AI correctly without recreating or interrupting the player',()=>{
 const h=fixture({search:'?s=be-ngu-ngoan'}),ai={slug:'ai-fixture',name:'AI selection',count:1,category:'ai'};
 h.respond('/api/sessions/be-ngu-ngoan',{session:baby});h.respond('/api/collections',{collections:[...catalogue,ai]});h.ready();h.emit(1);h.players[0].position=83;
 const group=h.get('playlist').children.find(n=>n.tagName==='OPTGROUP'&&n.label==='Nhạc AI');assert.ok(group);assert.equal(group.children.length,1);assert.equal(group.children[0].value,ai.slug);
 h.get('playlist').value=ai.slug;h.get('playlist').onchange.call(h.get('playlist'));
 h.respond('/api/sessions/'+ai.slug,{session:{slug:ai.slug,name:ai.name,tracks:[track('BFJLoa1g5Pw')]}});
 assert.equal(h.players.length,1);assert.equal(h.players[0].position,83);assert.equal(h.players[0].id,ids[0]);assert.equal(h.get('playlist-title').textContent,ai.name);assert.ok(!h.requests.some(r=>r.path.startsWith('/api/library')));
});

test('explicit baby URL loads six real entries without full-library requests, autoplay, modern APIs or storage access',()=>{
 const h=fixture({search:'?s=be-ngu-ngoan',storageBlocked:true});loadBaby(h);h.ready();
 assert.equal(h.get('playlist-title').textContent,'Baby Sleep Instantly');assert.equal(h.get('track-list').children.length,6);assert.equal(h.players.length,1);
 assert.equal(h.calls.filter(c=>c[0]==='load'||c[0]==='play').length,0);assert.equal(h.players[0].id,ids[0]);
 assert.ok(!h.requests.some(r=>r.path.startsWith('/api/library')));assert.equal(h.get('video-source').getAttribute('href'),null);assert.equal(h.get('video-source').href,'https://www.youtube.com/watch?v='+ids[0]);
 assert.equal(h.get('video-shell').style.height,'360px');assert.equal(h.get('play-long').hidden,false);
});
test('API readiness before or after session loading still creates and reuses one player',()=>{
 const early=fixture({search:'?s=be-ngu-ngoan'});early.ready();loadBaby(early);assert.equal(early.players[0].id,ids[0]);assert.equal(early.players.length,1);
 const late=fixture({search:'?s=be-ngu-ngoan',apiReady:false});loadBaby(late);assert.equal(late.players.length,0);late.click('play-all');
 late.window.YT={Player:late.Player};late.window.onYouTubeIframeAPIReady();late.ready();assert.equal(late.players.length,1);assert.equal(late.calls.filter(c=>c[0]==='load').length,1);
 late.window.onYouTubeIframeAPIReady();assert.equal(late.players.length,1);
});
test('Play/Pause, seeking, ending and longform playback follow player events and stop at the end without duplicate END skips',()=>{
 const h=fixture({search:'?s=be-ngu-ngoan'});loadBaby(h);h.ready();h.click('play-long');assert.equal(h.players[0].id,ids[0]);assert.equal(h.get('play').textContent,'▶ Phát');
 h.emit(1);assert.equal(h.get('play').textContent,'Ⅱ Tạm dừng');h.click('play');assert.equal(h.calls.at(-1)[0],'pause');h.emit(2);assert.equal(h.get('play').textContent,'▶ Phát');
 h.click('play');h.emit(1);h.get('seek').value='90';h.get('seek').onchange.call(h.get('seek'));assert.equal(h.players[0].position,90);assert.equal(h.get('elapsed').textContent,'1:30');
 h.emit(0);assert.equal(h.players[0].id,ids[1]);h.emit(0);assert.equal(h.players[0].id,ids[1],'Repeated old END cannot skip a not-yet-playing track');
 for(let i=1;i<ids.length;i++){h.emit(1);h.emit(0);}
 assert.equal(h.calls.filter(c=>c[0]==='load').length,6);assert.match(h.get('player-message').textContent,/Đã hết hàng phát/);assert.equal(h.players.length,1);
});
test('browsing a different playlist, searching, pagination or queue toggle preserves the playing video and position',()=>{
 const h=fixture({search:'?s=be-ngu-ngoan'});loadBaby(h);h.ready();h.click('play-all');h.emit(1);h.players[0].position=125;
 h.get('playlist').value=other.slug;h.get('playlist').onchange.call(h.get('playlist'));h.respond('/api/sessions/'+other.slug,{session:other});
 assert.equal(h.get('playlist-title').textContent,'Other');assert.equal(h.players[0].id,ids[0]);assert.equal(h.players[0].position,125);assert.equal(h.calls.filter(c=>c[0]==='load').length,1);
 h.click('queue-toggle');assert.equal(h.get('queue-list').hidden,true);h.click('queue-toggle');assert.equal(h.players.length,1);assert.equal(h.players[0].position,125);
 h.get('search').value='not found';h.get('search').oninput.call(h.get('search'));h.tick(200);assert.equal(h.get('track-list').children.length,0);assert.equal(h.players[0].id,ids[0]);
});
test('an unparameterized old-device visit requests a random nonempty playlist and late catalogue responses cannot override a user choice',()=>{
 const h=fixture();assert.deepEqual(h.requests.map(r=>r.path),['/api/collections']);h.respond('/api/collections',{collections:catalogue});
 const selected=h.requests.find(r=>r.path.startsWith('/api/sessions/'));assert.ok(selected);assert.ok(!selected.path.endsWith('empty-room'));assert.ok(!h.requests.some(r=>r.path.includes('/library')));
 const late=fixture();late.click('all');const all={slug:'__all__',name:'Tất cả bài hát',tracks:baby.tracks};late.respond('/api/library',{session:all});late.respond('/api/collections',{collections:catalogue});assert.equal(late.get('playlist-title').textContent,'Tất cả bài hát');assert.ok(!late.requests.some(r=>r.path.startsWith('/api/sessions/')));
});
test('stale session responses and malformed session slugs do not replace the requested view',()=>{
 const h=fixture({search:'?s=be-ngu-ngoan'}),original=h.requests[0];h.get('slug').value=other.slug;h.get('open-session').onsubmit({preventDefault(){}});h.respond('/api/sessions/'+other.slug,{session:other});
 original.respond({session:baby});h.respond('/api/collections',{collections:catalogue});assert.equal(h.get('playlist-title').textContent,'Other');assert.equal(h.get('track-list').children.length,1);
 const invalid=fixture({search:'?s=%3Cscript%3E'});invalid.respond('/api/collections',{collections:catalogue});assert.ok(!invalid.requests.some(r=>r.path.startsWith('/api/sessions/')));assert.match(invalid.get('load-status').textContent,/3–48/);
});
test('network errors expose working retry paths without loading all songs; unsafe titles remain text and valid prototype-like IDs are retained',()=>{
 const h=fixture({search:'?s=be-ngu-ngoan'});h.requests[0].finished=true;h.requests[0].onerror();assert.equal(h.get('retry-session').hidden,false);h.click('retry-session');h.respond('/api/sessions/be-ngu-ngoan',{session:baby});assert.equal(h.get('track-list').children.length,6);
 const broken=fixture();broken.requests[0].finished=true;broken.requests[0].onerror();assert.equal(broken.get('retry-catalogue').hidden,false);broken.click('retry-catalogue');broken.respond('/api/collections',{collections:catalogue});assert.ok(!broken.requests.some(r=>r.path.includes('/library')));
 const unsafe=fixture({search:'?s=be-ngu-ngoan'});unsafe.respond('/api/sessions/be-ngu-ngoan',{session:{...baby,tracks:[track('constructor','<img src=x onerror=alert(1)>'),track('bad-id'),track('constructor')]}});
 assert.equal(unsafe.get('track-list').children.length,1);const row=unsafe.get('track-list').children[0];assert.equal(row.children[1].children[0].textContent,'<img src=x onerror=alert(1)>');assert.equal(row.children[2].href,'https://www.youtube.com/watch?v=constructor');
});
test('large explicit library is paginated, searchable and exportable without rendering every thumbnail',()=>{
 const h=fixture({search:'?view=all'}),tracks=Array.from({length:75},(_,i)=>track(String(i).padStart(11,'0'),'Song '+i));h.respond('/api/library',{session:{slug:'__all__',name:'All songs',tracks}});
 assert.equal(h.get('track-list').children.length,20);h.click('page-next');assert.match(h.get('page-info').textContent,/21–40/);assert.equal(h.get('track-list').children.length,20);
 h.get('search').value='Song 74';h.get('search').oninput.call(h.get('search'));h.tick(200);assert.equal(h.get('track-list').children.length,1);
 h.click('export');assert.equal(h.get('text-output').value.split('\n').length,75);assert.equal(h.get('text-output').value.split('\n')[0],'https://www.youtube.com/watch?v=00000000000');
 h.click('share');assert.equal(h.get('text-output').value,'https://listen.example/?view=all');
});
test('autoplay blocking, video errors and API loading failures remain actionable with a bounded error skip limit',()=>{
 const h=fixture({search:'?s=be-ngu-ngoan'});loadBaby(h);h.ready();h.click('play-all');h.tick(2600);assert.equal(h.get('tap-play').hidden,false);assert.match(h.get('player-message').textContent,/Chạm để phát/);
 for(let i=0;i<3;i++){h.players[0].config.events.onError({data:100});h.tick(700);}assert.equal(h.calls.filter(c=>c[0]==='load').length,3);assert.match(h.get('player-message').textContent,/3 video lỗi/);h.tick(10000);assert.equal(h.calls.filter(c=>c[0]==='load').length,3);
 h.click('next');assert.equal(h.calls.filter(c=>c[0]==='load').length,4);
 const failed=fixture({search:'?s=be-ngu-ngoan',apiReady:false});loadBaby(failed);failed.tick(16000);assert.equal(failed.get('retry-player').hidden,false);assert.equal(failed.get('video-source').hidden,false);failed.click('retry-player');failed.window.YT={Player:failed.Player};failed.window.onYouTubeIframeAPIReady();failed.ready();assert.equal(failed.players.length,1);
});
test('metadata refresh is serial, only uses the current playlist and cannot recreate or pause the player',()=>{
 const h=fixture({search:'?s=be-ngu-ngoan'}),pending=baby.tracks.map(t=>({...t,metadataStatus:'pending'}));h.respond('/api/sessions/be-ngu-ngoan',{session:{...baby,tracks:pending}});h.ready();h.click('play-all');h.emit(1);h.players[0].position=321;
 const meta=h.requests.filter(r=>r.path.includes('/metadata?'));assert.equal(meta.length,1);assert.ok(meta[0].path.startsWith('/api/sessions/be-ngu-ngoan/metadata?ids='));assert.equal(meta[0].path.split('ids=')[1].split(',').length,6);
 meta[0].respond({tracks:baby.tracks.map(t=>({...t,title:'Refreshed '+t.title}))});assert.equal(h.players.length,1);assert.equal(h.players[0].position,321);assert.equal(h.calls.filter(c=>c[0]==='load').length,1);assert.ok(h.get('now-title').textContent.startsWith('Refreshed '));
 const count=h.calls.length;h.document.hidden=true;h.listeners['document:visibilitychange']();h.poll();assert.equal(h.calls.length,count,'Hiding the page does not pause or stop playback');
});
