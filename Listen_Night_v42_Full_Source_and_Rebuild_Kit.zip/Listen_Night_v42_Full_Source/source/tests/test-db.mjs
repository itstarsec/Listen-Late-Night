import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import assert from 'node:assert/strict';
class Statement{
 constructor(db,sql,args=[]){this.db=db;this.sql=sql;this.args=args;}
 bind(...args){assert.ok(args.length<=100,'D1 maximum 100 bound parameters');return new Statement(this.db,this.sql,args);}
 async first(){return this.db.prepare(this.sql).get(...this.args)||null;}
 async all(){return {results:this.db.prepare(this.sql).all(...this.args)};}
 async run(){const r=this.db.prepare(this.sql).run(...this.args);return {success:true,meta:{changes:Number(r.changes)}};}
}
export class D1{
 constructor(){this.queries=0;this.raw=new DatabaseSync(':memory:');for(const name of readdirSync('drizzle').filter(n=>n.endsWith('.sql')).sort())this.raw.exec(readFileSync(`drizzle/${name}`,'utf8'));}
 prepare(sql){this.queries++;return new Statement(this.raw,sql);}
 async batch(statements){this.raw.exec('BEGIN');try{const result=[];for(const statement of statements)result.push(await statement.run());this.raw.exec('COMMIT');return result;}catch(error){this.raw.exec('ROLLBACK');throw error;}}
}
