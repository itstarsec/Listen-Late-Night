// Network and player integration fixtures; these do not claim real mobile/audio QA.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import React from 'react';
import {create,act} from 'react-test-renderer';
import ListenApp from '../.sites-runtime/tests/listen-app.mjs';

const track=(videoId,title)=>({videoId,title,channel:'Fixture Artist',url:`https://www.youtube.com/watch?v=${videoId}`,thumbnail:`https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,metadataStatus:'ready',addedAt:0});
const sessions={
 shelby:{slug:'shelby',name:'Shelby fixture',tracks:[track('RzhIXHc6_80','Shelby song')],canEdit:false,version:1,updatedAt:0},
 other:{slug:'other',name:'Other fixture',tracks:[track('_U8S-uFZrHA','Other song'),track('AIqG6Gnvm90','Another song')],canEdit:false,version:1,updatedAt:0}
};
const catalog=[{slug:'empty',name:'Empty',count:0},{slug:'shelby',name:'Shelby fixture',count:1},{slug:'other',name:'Other fixture',count:2}].map(c=>({...c,description:'',mood:'FIXTURE',accent:'#ff9d3c',cover:null}));
const settle=()=>new Promise(resolve=>setImmediate(resolve));
const deferred=()=>{let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve};};
async function mount(options={}){
 const bank={...sessions,...options.sessions};
 const originals=new Map(['window','document','history','localStorage','navigator','fetch','matchMedia','IntersectionObserver','IS_REACT_ACT_ENVIRONMENT'].map(k=>[k,Object.getOwnPropertyDescriptor(globalThis,k)]));
 const install=(k,value)=>Object.defineProperty(globalThis,k,{value,writable:true,configurable:true});
 const requests=[],players=[],calls=[],events=new Map();let root,width=options.width??390,catalogFailures=options.catalogFailures??0,sessionFailures=options.sessionFailures??0;
 class Player{
  constructor(node,config){this.config=config;this.state=5;this.id='';this.position=0;players.push(this);queueMicrotask(()=>config.events.onReady({target:this}));}
  cueVideoById(v){this.id=v.videoId;this.position=v.startSeconds||0;calls.push(['cue',v.videoId]);}
  loadVideoById(v){this.id=v.videoId;this.position=v.startSeconds||0;calls.push(['load',v.videoId]);this.state=1;this.config.events.onStateChange({data:1});}
  playVideo(){this.state=1;this.config.events.onStateChange({data:1});}pauseVideo(){this.state=2;this.config.events.onStateChange({data:2});}
  stopVideo(){this.state=-1;}seekTo(n){this.position=n;}getPlayerState(){return this.state;}getCurrentTime(){return this.position;}getDuration(){return 240;}
  getVideoData(){return {video_id:this.id};}getIframe(){return {setAttribute(){}};}destroy(){this.destroyed=true;}
 }
 install('IS_REACT_ACT_ENVIRONMENT',true);
 install('matchMedia',query=>({matches:query==='(max-width: 900px)'?width<=900:query==='(max-width: 1199px)'?width<=1199:query==='(min-width: 1200px)'?width>=1200:false,addEventListener(){},removeEventListener(){}}));
 install('window',{YT:{Player},location:new URL('https://listen.example/'+(options.search||'')),addEventListener:(name,fn)=>events.set(name,fn),removeEventListener:(name)=>events.delete(name),setTimeout,clearTimeout});
 const panel={scrollIntoView(){},setAttribute(){},removeAttribute(){},querySelectorAll:()=>[]};
 install('document',{visibilityState:'visible',hidden:false,addEventListener(){},removeEventListener(){},createElement:()=>({}),getElementById:()=>panel,body:{style:{overflow:''}},activeElement:null});
 install('history',{replaceState(a,b,url){window.location=new URL(url,window.location);}});
 const memory=new Map([['listen:last',JSON.stringify('__all__')],['listen:light-mode','true']]);
 install('localStorage',{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v)});install('navigator',{onLine:true});
 install('IntersectionObserver',class{observe(){}disconnect(){}});
 install('fetch',async(path,init={})=>{
  requests.push(path);let data;
  if(path==='/api/collections'){
   if(options.catalogGate)await options.catalogGate.promise;
   if(catalogFailures-->0)throw Error('Offline catalogue');
   data={collections:options.catalog??catalog};
  }else if(path==='/api/me')data={signedIn:false,sessions:[]};
  else if(path==='/api/library')data={session:{slug:'__all__',kind:'all',name:'Tất cả bài hát',tracks:Object.values(bank).flatMap(s=>s.tracks),canEdit:false,version:1,updatedAt:0,sourceCount:2,totalEntries:3}};
  else if(path.startsWith('/api/sessions/')){
   if(sessionFailures-->0)throw Error('Offline selected playlist');
   const slug=path.slice('/api/sessions/'.length);assert.ok(bank[slug],`Unexpected session request: ${path}`);data={session:bank[slug]};
  }else throw Error(`Unexpected API: ${path}`);
  return new Response(JSON.stringify(data),{headers:{'Content-Type':'application/json'}});
 });
 const flush=async()=>act(async()=>{await settle();await settle();});
 await act(async()=>{root=create(React.createElement(ListenApp),{createNodeMock:()=>({replaceChildren(){},showModal(){},close(){}})});await settle();await settle();});
 return {root,requests,players,calls,memory,events,flush,setWidth:n=>{width=n;},click:async(button)=>act(async()=>{await button.props.onClick();await settle();await settle();}),
  button:label=>root.root.findAllByType('button').find(b=>b.props['aria-label']===label),
  textButton:text=>root.root.findAllByType('button').find(b=>b.children.includes(text)),
  async close(){if(options.catalogGate)options.catalogGate.resolve();await act(async()=>root.unmount());for(const[k,value]of originals){if(value)Object.defineProperty(globalThis,k,value);else delete globalThis[k];}}
 };
}

test('phone entry loads exactly one nonempty random playlist, never the aggregate, and waits for Play',async()=>{
 const h=await mount();try{
  const selected=h.requests.filter(p=>p.startsWith('/api/sessions/'));assert.equal(selected.length,1);assert.ok(['/api/sessions/shelby','/api/sessions/other'].includes(selected[0]));
  assert.equal(h.requests.filter(p=>p==='/api/collections').length,1);assert.ok(!h.requests.some(p=>p.startsWith('/api/library')));
  const slug=selected[0].split('/').at(-1);assert.equal(window.location.search,`?s=${slug}`);assert.equal(h.root.root.findByType('h1').children.join(''),sessions[slug].name);
  assert.equal(h.players.length,1);assert.equal(h.calls.filter(c=>c[0]==='load').length,0);assert.equal(h.calls.filter(c=>c[0]==='cue').length,1);
  await h.click(h.textButton('Phát tất cả'));const player=h.players[0];assert.equal(player.state,1);player.position=83;
  await h.click(h.root.root.findAllByType('button').find(b=>b.props.className.startsWith('library-all')));
  assert.equal(h.requests.filter(p=>p==='/api/library').length,1);assert.equal(window.location.search,'?view=all');assert.equal(h.players.length,1);assert.equal(player.position,83);assert.equal(player.state,1);assert.equal(h.calls.filter(c=>c[0]==='load').length,1);
 }finally{await h.close();}
});
test('phone playlist links load immediately even while the catalogue is pending; resizing cannot reselect',async()=>{
 const gate=deferred(),h=await mount({search:'?s=other',catalogGate:gate});try{
  assert.ok(h.requests.includes('/api/sessions/other'));assert.equal(h.root.root.findByType('h1').children.join(''),'Other fixture');
  h.setWidth(1440);gate.resolve();await h.flush();assert.deepEqual(h.requests.filter(p=>p.startsWith('/api/sessions/')),['/api/sessions/other']);assert.ok(!h.requests.includes('/api/library'));
 }finally{await h.close();}
});
test('desktop and explicit all-songs phone links retain aggregate entry',async()=>{
 for(const options of [{width:1440},{width:390,search:'?view=all'}]){
  const h=await mount(options);try{assert.equal(h.requests.filter(p=>p==='/api/library').length,1);assert.ok(!h.requests.some(p=>p.startsWith('/api/sessions/')));assert.equal(h.root.root.findByType('h1').children.join(''),'Tất cả bài hát');}finally{await h.close();}
 }
});
test('catalogue failure retries compact discovery; selected playlist failure retries the same playlist',async()=>{
 for(const options of [{catalogFailures:1},{sessionFailures:1}]){
  const h=await mount(options);try{
   assert.ok(h.root.root.findAllByProps({role:'alert'}).length);const before=h.requests.filter(p=>p.startsWith('/api/sessions/'));
   await h.click(h.textButton('Thử lại'));assert.equal(h.root.root.findAllByProps({role:'alert'}).length,0);assert.ok(!h.requests.includes('/api/library'));
   const after=h.requests.filter(p=>p.startsWith('/api/sessions/'));assert.equal(after.length,options.sessionFailures?2:1);if(before.length)assert.equal(after[0],after[1]);
  }finally{await h.close();}
 }
});
test('empty compact catalogue shows a retry state without silently downloading the full library',async()=>{
 const h=await mount({catalog:[catalog[0]]});try{assert.ok(h.root.root.findAllByProps({role:'alert'}).some(n=>n.findAllByType('span').some(s=>s.children.includes('Chưa có playlist có bài hát để nghe. Vui lòng thử lại sau.'))));assert.ok(h.textButton('Thử lại'));assert.ok(!h.requests.some(p=>p.startsWith('/api/library')||p.startsWith('/api/sessions/')));}finally{await h.close();}
});
test('late catalogue response cannot replace an explicit all-songs choice made during phone startup',async()=>{
 const gate=deferred(),h=await mount({catalogGate:gate});try{
  await h.click(h.button('Listen · Tất cả bài hát'));assert.ok(h.requests.includes('/api/library'));gate.resolve();await h.flush();
  assert.equal(h.root.root.findByType('h1').children.join(''),'Tất cả bài hát');assert.ok(!h.requests.some(p=>p.startsWith('/api/sessions/')));assert.equal(h.players.length,1);
 }finally{await h.close();}
});
test('longform action starts the first hour-long video and advances through the long group using one player',async()=>{
 const tracks=[track('wDLJaMnBJ-s','Short lullaby'),track('wegIRJQdK9Y','Hush Little Baby · One hour'),track('iXC3dxZw-2A','Brahms · One hour')];
 const room={slug:'be-ngu-ngoan',name:'Bé ngủ ngoan',tracks,canEdit:false,version:1,updatedAt:0};
 const h=await mount({search:'?s=be-ngu-ngoan',sessions:{'be-ngu-ngoan':room},catalog:[{...catalog[1],slug:'be-ngu-ngoan',count:3,longformVideoIds:['wegIRJQdK9Y','iXC3dxZw-2A']}]});
 try{
  assert.equal(h.players.length,1);assert.equal(h.calls.filter(c=>c[0]==='load').length,0);assert.ok(h.textButton('Nghe bản dài'));
  await h.click(h.textButton('Nghe bản dài'));const p=h.players[0];assert.equal(p.id,'wegIRJQdK9Y');assert.equal(p.state,1);
  await act(async()=>{p.state=0;p.config.events.onStateChange({data:0});await settle();});assert.equal(p.id,'iXC3dxZw-2A');assert.equal(h.calls.filter(c=>c[0]==='load').length,2);
  await act(async()=>{p.state=0;p.config.events.onStateChange({data:0});await settle();});assert.equal(h.calls.filter(c=>c[0]==='load').length,2);assert.equal(h.players.length,1);assert.ok(!h.requests.includes('/api/library'));
 }finally{await h.close();}
});
test('baby playlist opens only the user-selected video without autoplay and uses its video source',async()=>{
 const def=JSON.parse(readFileSync('lib/imported-playlists.json','utf8')).find(p=>p.slug==='be-ngu-ngoan');
 const room={slug:def.slug,name:def.name,tracks:def.tracks.map(t=>({...track(t.videoId,t.title),channel:t.channel})),canEdit:false,version:1,updatedAt:0};
 const h=await mount({search:'?s=be-ngu-ngoan',sessions:{[def.slug]:room},catalog:[{...catalog[1],slug:def.slug,count:1,source:{url:def.sourceUrl,title:def.sourceTitle,curator:def.curator,kind:'video',fetchedAt:def.fetchedAt,unavailableCount:0,duplicateCount:0}}]});
 try{
  assert.equal(h.root.root.findByType('h1').children.join(''),'Baby Sleep Instantly');assert.equal(h.players.length,1);assert.equal(h.calls.filter(c=>c[0]==='load').length,0);
  const source=h.root.root.findAllByType('a').find(n=>n.props.href===def.sourceUrl&&n.children.includes('Xem video nguồn'));assert.ok(source);
  await h.click(h.textButton('Phát tất cả'));assert.equal(h.players[0].id,def.tracks[0].videoId);
  const p=h.players[0];await act(async()=>{p.state=0;p.config.events.onStateChange({data:0});await settle();});assert.equal(p.id,'377o0R09Y0U');assert.equal(h.calls.filter(c=>c[0]==='load').length,1);
  assert.equal(h.players.length,1);assert.ok(!h.requests.includes('/api/library'));
 }finally{await h.close();}
});
test('the Paris jazz video source opens directly on a phone with one player and the original source label',async()=>{
 const def=JSON.parse(readFileSync('lib/imported-playlists.json','utf8')).find(p=>p.slug==='paris-at-night-jazz');
 const room={slug:def.slug,name:def.name,tracks:def.tracks.map(t=>({...track(t.videoId,t.title),channel:t.channel})),canEdit:false,version:1,updatedAt:0};
 const h=await mount({search:'?s='+def.slug,sessions:{[def.slug]:room},catalog:[{...catalog[1],slug:def.slug,name:def.name,count:1,source:{url:def.sourceUrl,title:def.sourceTitle,curator:def.curator,kind:'video',fetchedAt:def.fetchedAt,unavailableCount:0,duplicateCount:0}}]});
 try{
  assert.equal(h.root.root.findByType('h1').children.join(''),def.name);assert.equal(h.players.length,1);assert.equal(h.calls.filter(c=>c[0]==='load').length,0);
  assert.ok(h.root.root.findAllByType('a').some(n=>n.props.href===def.sourceUrl&&n.children.includes('Xem video nguồn')));
  await h.click(h.textButton('Phát tất cả'));assert.equal(h.players[0].id,'EQfKnvCFs1Y');assert.equal(h.players.length,1);assert.ok(!h.requests.includes('/api/library'));
 }finally{await h.close();}
});
