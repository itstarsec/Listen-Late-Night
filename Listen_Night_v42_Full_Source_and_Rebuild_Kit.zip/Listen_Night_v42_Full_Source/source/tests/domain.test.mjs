import {test} from 'node:test';import assert from 'node:assert/strict';
import {videoId,canonicalUrl,parseBatch,slugValue,nameValue,nextId,replacementAfterDelete,SEED_IDS} from '../.sites-runtime/tests/domain.mjs';
const a='RzhIXHc6_80',b='_U8S-uFZrHA',c='_NA_QD7zHmQ';
test('all YouTube input forms normalize and remove playlist/tracking',()=>{
 for(const input of [a,`https://www.youtube.com/watch?v=${a}&list=RD${a}&index=2&si=track`,`https://youtu.be/${a}?si=track`,`https://youtube.com/shorts/${a}`,`https://m.youtube.com/watch?v=${a}`,`https://music.youtube.com/watch?v=${a}`,`https://www.youtube.com/embed/${a}`])assert.equal(videoId(input),a);
 assert.equal(canonicalUrl(a),`https://www.youtube.com/watch?v=${a}`);
});
test('parser rejects malformed IDs, malicious hosts and URL schemes',()=>{for(const x of ['bad','https://youtube.com.evil.test/watch?v='+a,'javascript:alert(1)','ftp://youtube.com/watch?v='+a,'https://user:pass@youtube.com/watch?v='+a,'https://youtube.com:444/watch?v='+a,'https://youtu.be/xxx'])assert.equal(videoId(x),null);});
test('bulk input isolates bad lines, deduplicates by ID and preserves order',()=>{const r=parseBatch(`${b}\nnope\nhttps://youtu.be/${a}?si=x\n${c}\n${b}\n`,[a]);assert.deepEqual(r.ids,[b,c]);assert.equal(r.duplicates,2);assert.equal(r.invalid,1);assert.deepEqual(r.invalidLines,[2]);});
test('empty and oversized batches fail',()=>{assert.throws(()=>parseBatch(''));assert.throws(()=>parseBatch('a\n'.repeat(301)));assert.throws(()=>parseBatch(a,Array.from({length:300},(_,i)=>String(i))));});
test('slug and name validated independently of frontend',()=>{assert.equal(slugValue('late-night'),'late-night');for(const x of ['ab','Capital','-test','test-','x y',null])assert.throws(()=>slugValue(x));assert.equal(nameValue('  Đêm yên tĩnh  '),'Đêm yên tĩnh');assert.throws(()=>nameValue('a\n'));assert.throws(()=>nameValue('x'.repeat(101)));});
test('seed has exact 25 unique, valid videos in requested order',()=>{assert.equal(SEED_IDS.length,25);assert.equal(new Set(SEED_IDS).size,25);assert.equal(SEED_IDS[0],a);assert.equal(SEED_IDS[24],'J9ymya-bQzU');for(const id of SEED_IDS)assert.equal(videoId(id),id);});
test('ended event behavior respects repeat off, one and all',()=>{const ids=[a,b,c];assert.equal(nextId(ids,c,{automatic:true,repeat:'off'}),null);assert.equal(nextId(ids,c,{automatic:true,repeat:'all'}),a);assert.equal(nextId(ids,b,{automatic:true,repeat:'one'}),b);assert.equal(nextId(ids,a,{direction:-1}),c);});
test('shuffle avoids current song when alternatives exist',()=>{for(let i=0;i<30;i++)assert.notEqual(nextId([a,b,c],a,{shuffle:true}),a);});
test('failed tracks are bounded by available set, no endless retry',()=>{assert.equal(nextId([a,b,c],a,{repeat:'all',failed:new Set([a,b])}),c);assert.equal(nextId([a,b,c],a,{repeat:'all',failed:new Set([a,b,c])}),null);});
test('deleting playing track selects successor, last selects previous, empty stops',()=>{assert.equal(replacementAfterDelete([a,b,c],b),c);assert.equal(replacementAfterDelete([a,b,c],c),b);assert.equal(replacementAfterDelete([a],a),null);});
test('bulk error line numbers include blank lines in original paste',()=>{const r=parseBatch(`\n${a}\n\ninvalid\n${b}`);assert.deepEqual(r.invalidLines,[4]);});
test('shuffle repeat off finishes after available tracks have been heard',()=>{assert.equal(nextId([a,b,c],c,{automatic:true,shuffle:true,repeat:'off',played:new Set([a,b,c])}),null);assert.equal(nextId([a,b,c],a,{automatic:true,shuffle:true,repeat:'off',played:new Set([a,b])}),c);});
test('bare entry URL always chooses all songs instead of the last visited playlist',async()=>{const {ALL_SONGS_SLUG,resolveViewSlug,viewApiPath}=await import('../.sites-runtime/tests/domain.mjs');assert.equal(resolveViewSlug(''),ALL_SONGS_SLUG);assert.equal(resolveViewSlug('?utm_source=share'),ALL_SONGS_SLUG);assert.equal(resolveViewSlug('?s='),ALL_SONGS_SLUG);assert.equal(viewApiPath(ALL_SONGS_SLUG),'/library');});
test('explicit s remains a session slug, including a real session named all',async()=>{const {resolveViewSlug,viewApiPath}=await import('../.sites-runtime/tests/domain.mjs');assert.equal(resolveViewSlug('?s=shelby'),'shelby');assert.equal(viewApiPath(resolveViewSlug('?s=midnight-drive')),'/sessions/midnight-drive');assert.equal(viewApiPath(resolveViewSlug('?s=all')),'/sessions/all');});
test('compact entry picks a nonempty playlist across the catalogue without falling back to the aggregate',async()=>{
 const {entryViewSlug}=await import('../.sites-runtime/tests/domain.mjs');
 const catalog=[{slug:'empty',count:0},{slug:'shelby',count:25},{slug:'gaming',count:15}];
 assert.equal(entryViewSlug('',true,catalog,()=>0),'shelby');assert.equal(entryViewSlug('?utm_source=mobile',true,catalog,()=>.9999),'gaming');
 assert.equal(entryViewSlug('?s=',true,[],()=>0),null);assert.equal(entryViewSlug('',true,[{slug:'empty',count:0}]),null);
});
test('explicit playlist and aggregate links take precedence over compact random entry; desktop keeps all songs',async()=>{
 const {entryViewSlug,ALL_SONGS_SLUG}=await import('../.sites-runtime/tests/domain.mjs');
 assert.equal(entryViewSlug('?s=shelby',true),'shelby');assert.equal(entryViewSlug('?s=all&view=all',true),'all');
 assert.equal(entryViewSlug('?view=all',true),ALL_SONGS_SLUG);assert.equal(entryViewSlug('',false),ALL_SONGS_SLUG);
});
