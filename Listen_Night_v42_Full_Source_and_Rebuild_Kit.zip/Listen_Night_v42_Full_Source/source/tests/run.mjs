import ts from 'typescript';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
await mkdir('.sites-runtime/tests',{recursive:true});
for(const name of ['domain','file-import','basketball','auth','api','video-maintenance','maintenance-mcp','youtube','playback-queue','turntable-motion','turntable-model','browser-support']){
 const source=await readFile(`lib/${name}.ts`,'utf8');
 const result=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,resolveJsonModule:true}});
 await writeFile(`.sites-runtime/tests/${name}.mjs`,result.outputText.replaceAll("'./video-maintenance'","'./video-maintenance.mjs'").replaceAll("'./domain'","'./domain.mjs'").replaceAll("'./auth'","'./auth.mjs'").replaceAll("'./file-import'","'./file-import.mjs'").replaceAll("'./basketball'","'./basketball.mjs'").replaceAll("'./seed-metadata.json'","'../../lib/seed-metadata.json' with {type:'json'}").replaceAll("'./curated-playlists.json'","'../../lib/curated-playlists.json' with {type:'json'}").replaceAll("'./curated-metadata.json'","'../../lib/curated-metadata.json' with {type:'json'}").replaceAll("'./imported-playlists.json'","'../../lib/imported-playlists.json' with {type:'json'}"));
}
for(const name of ['turntable','listen-app','basketball-import','admin-dashboard','admin-entry']){
 const source=await readFile(`app/${name}.tsx`,'utf8');
 const result=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX}});
 await writeFile(`.sites-runtime/tests/${name}.mjs`,result.outputText.replaceAll("'./video-maintenance'","'./video-maintenance.mjs'").replaceAll("'@/lib/", "'./").replaceAll("'./turntable'","'./turntable.mjs'").replaceAll("'./listen-app'","'./listen-app.mjs'").replaceAll("'./admin-dashboard'","'./admin-dashboard.mjs'").replaceAll("import './admin-dashboard.css';", "").replaceAll("import './file-import.css';", "").replaceAll("'./basketball-import'","'./basketball-import.mjs'").replaceAll("'./file-import'","'./file-import.mjs'").replaceAll("'./basketball'","'./basketball.mjs'").replaceAll("'./playback-queue'","'./playback-queue.mjs'").replaceAll("'./domain'","'./domain.mjs'").replaceAll("'./youtube'","'./youtube.mjs'"));
}
const r=spawnSync(process.execPath,['--test','tests/video-maintenance.test.mjs','tests/domain.test.mjs','tests/api.test.mjs','tests/auth.test.mjs','tests/youtube.test.mjs','tests/turntable.test.mjs','tests/playback-queue.test.mjs','tests/listening-ui.test.mjs','tests/mobile-entry.test.mjs','tests/admin-ui.test.mjs','tests/admin-entry.test.mjs','tests/file-import.test.mjs','tests/import-ui.test.mjs','tests/basketball.test.mjs','tests/throw-ui.test.mjs','tests/compatible-player.test.mjs'],{stdio:'inherit'});process.exit(r.status??1);
