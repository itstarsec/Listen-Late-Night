import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseUrlFile,suggestSlug,MAX_IMPORT_BYTES} from '../.sites-runtime/tests/file-import.mjs';
import {handleApi} from '../.sites-runtime/tests/api.mjs';
import {createPasswordHash} from '../.sites-runtime/tests/auth.mjs';
import {D1} from './test-db.mjs';
const hash=await createPasswordHash('fixture-import-password');
const mixed='\ufeffhttps://www.youtube.com/watch?v=RzhIXHc6_80&list=discard&index=3\r\nhttps://youtu.be/RzhIXHc6_80?si=discard\r\nnot a URL\r\nhttps://www.youtube.com/shorts/_U8S-uFZrHA?feature=share';
async function setup(){const env={DB:new D1(),AUTH_USERNAME:'fixtureadmin',AUTH_PASSWORD_HASH:hash};const r=await handleApi(new Request('https://listen.test/api/auth/login',{method:'POST',headers:{Origin:'https://listen.test','Content-Type':'application/json'},body:JSON.stringify({username:'fixtureadmin',password:'fixture-import-password'})}),env);return {env,cookie:r.headers.get('Set-Cookie').split(';')[0]};}
async function request(ctx,path,body,options={}){const headers={Origin:options.origin||'https://listen.test','Content-Type':'application/json','X-Request-ID':options.id||crypto.randomUUID(),...options.headers};if(!options.anonymous)headers.Cookie=ctx.cookie;const r=await handleApi(new Request('https://listen.test/api'+path,{method:options.method||'POST',headers,body:body===undefined?undefined:JSON.stringify(body)}),ctx.env);return {status:r.status,data:await r.json()};}
const payload=(slug='file-night',text=mixed)=>({target:{kind:'new',slug,name:'Đêm nhập từ file'},fileName:'dem-nhac.txt',text});

test('URL file parsing preserves order, normalizes YouTube URLs, counts duplicate IDs and reports original line numbers',()=>{
 const p=parseUrlFile('Nhạc.TXT',mixed);assert.deepEqual(p.ids,['RzhIXHc6_80','_U8S-uFZrHA']);assert.deepEqual(p.report,{added:2,duplicates:1,invalid:1,invalidLines:[3],total:4});assert.deepEqual(p.urls,p.ids.map(id=>'https://www.youtube.com/watch?v='+id));
 assert.equal(suggestSlug('Những Đêm Không Ngủ!'),'nhung-dem-khong-ngu');
 const m=parseUrlFile('music.m3u8','#EXTM3U\n#EXTINF:0,A title\nhttps://youtu.be/RzhIXHc6_80\n\n#EXTINF:0,B title\n_U8S-uFZrHA\nwrong');assert.deepEqual(m.ids,p.ids);assert.deepEqual(m.report.invalidLines,[7]);
 const csv=parseUrlFile('music.csv','title,url\n"Title, with comma",https://youtu.be/RzhIXHc6_80\n"Multi\nline title",_U8S-uFZrHA\nBad title,invalid');assert.deepEqual(csv.ids,p.ids);assert.deepEqual(csv.report.invalidLines,[5]);
 assert.deepEqual(parseUrlFile('music.csv','name;link\nSong;RzhIXHc6_80').ids,['RzhIXHc6_80']);
});
test('file parser rejects binary, unsupported files, oversized lists and malformed CSV, and treats non-YouTube URLs as invalid',()=>{
 for(const [name,text] of [['music.pdf','RzhIXHc6_80'],['music.txt','\0RzhIXHc6_80'],['music.txt','a'.repeat(MAX_IMPORT_BYTES+1)],['music.csv','url\n"unclosed'],['music.txt','RzhIXHc6_80\n'.repeat(301)],['music.txt','']])assert.throws(()=>parseUrlFile(name,text));
 const p=parseUrlFile('safe.txt','https://evil.test/watch?v=RzhIXHc6_80\njavascript:alert(1)\nhttps://user:pass@youtube.com/watch?v=RzhIXHc6_80');assert.equal(p.report.invalid,3);assert.equal(p.ids.length,0);
});
test('new playlist and tracks save atomically; receipts survive reloads and later edits without replaying writes',async()=>{
 const c=await setup(),body=payload(),id=crypto.randomUUID();let r=await request(c,'/admin/import',body,{id});assert.equal(r.status,201);assert.equal(r.data.session.name,body.target.name);assert.equal(r.data.session.tracks.length,2);assert.deepEqual(r.data.report,parseUrlFile(body.fileName,body.text).report);
 const saved=r.data;let replay=await request(c,'/admin/import',body,{id});assert.equal(replay.data.replayed,true);assert.deepEqual(replay.data.report,saved.report);assert.deepEqual(replay.data.session,saved.session);
 await request(c,'/sessions/file-night',{name:'Tên sau khi nhập'},{method:'PATCH',headers:{'If-Match':String(saved.session.version)}});
 replay=await request(c,'/admin/import',body,{id});assert.equal(replay.data.session.name,'Tên sau khi nhập');assert.equal(replay.data.session.version,2);assert.equal(replay.data.session.tracks.length,2);assert.deepEqual(replay.data.report,saved.report);
 const loaded=await request(c,'/sessions/file-night',undefined,{method:'GET',anonymous:true});assert.equal(loaded.status,200);assert.equal(loaded.data.session.canEdit,false);assert.equal(loaded.data.session.tracks.length,2);
 assert.equal((await request(c,'/admin/import',{...body,text:'_NA_QD7zHmQ'},{id})).status,409);assert.equal(c.env.DB.raw.prepare('SELECT count(*) n FROM sessions').get().n,1);
});
test('existing playlist import deduplicates against stored IDs, preserves ordering and rejects stale versions without partial changes',async()=>{
 const c=await setup();let r=await request(c,'/admin/import',payload('existing-file','RzhIXHc6_80'));let s=r.data.session;
 const body={target:{kind:'existing',slug:s.slug,version:s.version},fileName:'append.txt',text:'RzhIXHc6_80\n_U8S-uFZrHA\n_U8S-uFZrHA\ninvalid\n_NA_QD7zHmQ'};
 r=await request(c,'/admin/import',body);assert.equal(r.status,200);assert.deepEqual(r.data.session.tracks.map(t=>t.videoId),['RzhIXHc6_80','_U8S-uFZrHA','_NA_QD7zHmQ']);assert.deepEqual(r.data.report,{added:2,duplicates:2,invalid:1,invalidLines:[4],total:5});
 assert.equal((await request(c,'/admin/import',body)).status,409);s=(await request(c,'/sessions/'+s.slug,undefined,{method:'GET'})).data.session;assert.equal(s.tracks.length,3);
 const duplicate=await request(c,'/admin/import',{...body,target:{...body.target,version:s.version},text:'RzhIXHc6_80'});assert.equal(duplicate.data.report.added,0);assert.equal(duplicate.data.report.duplicates,1);assert.equal(duplicate.data.session.tracks.length,3);
});
test('authentication, origin, ownership, format and capacity checks run before any import mutation',async()=>{
 const c=await setup();assert.equal((await request(c,'/admin/import',payload(),{anonymous:true})).status,401);assert.equal((await request(c,'/admin/import',payload(),{origin:'https://evil.test'})).status,403);
 for(const body of [payload('bad-file','not valid'),{...payload(),fileName:'bad.exe'},{...payload(),target:{kind:'new',slug:'BAD',name:'bad'}},{...payload(),target:{kind:'new',slug:'valid-slug',name:''}}])assert.equal((await request(c,'/admin/import',body)).status,400);
 assert.equal(c.env.DB.raw.prepare('SELECT count(*) n FROM sessions').get().n,0);
 c.env.DB.raw.prepare('INSERT INTO sessions(slug,name,owner_id,tracks,version,created_at,updated_at) VALUES(?,?,?,?,1,0,0)').run('private-room','Other owner','someone-else','[]');
 assert.equal((await request(c,'/admin/import',{...payload(),target:{kind:'existing',slug:'private-room',version:1}})).status,403);
 const ids=Array.from({length:300},(_,i)=>'A'+String(i).padStart(10,'0'));let r=await request(c,'/admin/import',payload('full-file',ids.join('\n')));assert.equal(r.status,201);assert.equal(r.data.session.tracks.length,300);
 r=await request(c,'/admin/import',{...payload(),target:{kind:'existing',slug:'full-file',version:1},text:'RzhIXHc6_80'});assert.equal(r.status,400);assert.equal(c.env.DB.raw.prepare("SELECT version FROM sessions WHERE slug='full-file'").get().version,1);
});
test('concurrent imports cannot double create a slug, overwrite a version or reuse one request for two targets',async()=>{
 const c=await setup();let rs=await Promise.all([request(c,'/admin/import',payload('race-file')),request(c,'/admin/import',payload('race-file'))]);assert.deepEqual(rs.map(r=>r.status).sort(),[201,409]);
 const id=crypto.randomUUID();rs=await Promise.all([request(c,'/admin/import',payload('one-file'),{id}),request(c,'/admin/import',payload('two-file'),{id})]);assert.deepEqual(rs.map(r=>r.status).sort(),[201,409]);assert.equal(c.env.DB.raw.prepare("SELECT count(*) n FROM sessions WHERE slug IN ('one-file','two-file')").get().n,1);
 const same=crypto.randomUUID();rs=await Promise.all([request(c,'/admin/import',payload('same-file'),{id:same}),request(c,'/admin/import',payload('same-file'),{id:same})]);assert.ok(rs.some(r=>r.status===201));const replay=await request(c,'/admin/import',payload('same-file'),{id:same});assert.equal(replay.status,200);assert.equal(replay.data.session.tracks.length,2);
});
test('failed receipt insert rolls back the playlist; deleting a previously imported playlist does not allow a replay to resurrect it',async()=>{
 const c=await setup();c.env.DB.raw.exec("CREATE TRIGGER import_failure BEFORE INSERT ON playlist_imports BEGIN SELECT RAISE(ABORT, 'fixture receipt failure'); END;");
 assert.equal((await request(c,'/admin/import',payload('rollback-file'))).status,503);assert.equal(c.env.DB.raw.prepare("SELECT count(*) n FROM sessions WHERE slug='rollback-file'").get().n,0);
 c.env.DB.raw.exec('DROP TRIGGER import_failure;');const body=payload('deleted-file'),id=crypto.randomUUID(),r=await request(c,'/admin/import',body,{id});await request(c,'/sessions/deleted-file',undefined,{method:'DELETE',headers:{'If-Match':String(r.data.session.version)}});
 assert.equal((await request(c,'/admin/import',body,{id})).status,404);assert.equal(c.env.DB.raw.prepare("SELECT count(*) n FROM sessions WHERE slug='deleted-file'").get().n,0);
});
