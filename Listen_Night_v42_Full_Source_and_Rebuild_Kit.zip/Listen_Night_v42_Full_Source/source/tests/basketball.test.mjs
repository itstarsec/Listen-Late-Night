import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createShot,shotPoint,crossesBasket,shotWillScore,pullPower,createFlight,advanceFlight,predictFlight} from '../.sites-runtime/tests/basketball.mjs';
const desktop={origin:{x:98,y:263},rim:{left:210,right:310,y:190},width:520,height:430,maxPull:96};
const mobile={origin:{x:40,y:190},rim:{left:90,right:190,y:155},width:280,height:350,maxPull:96};
test('downward pull controls strength and range on desktop and mobile; both underpowered and overpowered shots can miss',()=>{
 for(const geometry of [desktop,mobile]){
  assert.equal(pullPower({x:0,y:999},geometry),1);assert.ok(pullPower({x:0,y:-20},geometry)>0);
  const good=createShot(geometry,{x:0,y:geometry.maxPull*.68});assert.equal(shotWillScore(good),true);assert.ok(good.velocity.y<0);
  assert.equal(shotWillScore(createShot(geometry,{x:0,y:geometry.maxPull*.2})),false);
  assert.equal(shotWillScore(createShot(geometry,{x:0,y:geometry.maxPull})),false);
  assert.equal(shotWillScore(createShot(geometry,{x:80,y:geometry.maxPull*.68})),false);
  assert.equal(shotWillScore(createShot(geometry,{x:0,y:0},true)),true);
 }
});
test('collision requires a descending crossing through the rim, and stays consistent at 30, 60 and 120 frames per second',()=>{
 const plan=createShot(desktop,{x:0,y:65});for(const fps of [30,60,120]){let previous=plan.start,hits=0;for(let t=1/fps;t<plan.duration+.5;t+=1/fps){const current=shotPoint(plan,t);if(crossesBasket(plan,previous,current,t))hits++;previous=current;}assert.equal(hits,1);}
 assert.equal(crossesBasket(plan,{x:260,y:191},{x:260,y:188},.1),false);
 assert.equal(crossesBasket(plan,{x:100,y:189},{x:100,y:192},plan.duration),false);
});

test('all drag quadrants produce finite trajectories and the red landing marker follows actual velocity',()=>{
 for(const pull of [{x:0,y:-65},{x:0,y:65},{x:-45,y:45},{x:45,y:45},{x:65,y:0}]){const p=createShot(desktop,pull);assert.ok(p.power>0);assert.ok(Number.isFinite(p.duration)&&p.duration>0);const end=shotPoint(p,p.duration);assert.ok(Number.isFinite(end.x)&&Number.isFinite(end.y));}
 const down=createShot(desktop,{x:0,y:65}),up=createShot(desktop,{x:0,y:-65});assert.ok(down.velocity.y<0);assert.ok(up.velocity.y>0);assert.equal(shotWillScore(up),false);
});

test('rim impacts can bounce out or bounce in, changing trajectory and spin without an immediate score',()=>{
 for(const [pull,expected] of [[{x:-40,y:50},false],[{x:-36,y:65},true]]){
  const plan=createShot(desktop,pull),body=createFlight(plan);let sawImpact=false;
  while(!body.done){const oldV={...body.velocity},oldSpin=body.spin,event=advanceFlight(body,1/240);if(event.rimHit){sawImpact=true;assert.equal(body.scored,false);assert.ok(Math.abs(body.velocity.x-oldV.x)>5||Math.abs(body.velocity.y-oldV.y)>5);assert.notEqual(body.spin,oldSpin);}}
  assert.ok(sawImpact);assert.equal(body.scored,expected);assert.equal(predictFlight(plan).scored,expected);assert.ok(body.time<6.01);
 }
});
test('score waits for a descent through the net; appearing below the rim from the side cannot score',()=>{
 const plan=createShot(desktop,{x:0,y:65}),body=createFlight(plan);let crossingTime=0,entryTime=0;
 while(!body.done){advanceFlight(body,1/240);if(body.throughRim&&!crossingTime){crossingTime=body.time;assert.equal(body.scored,false);}if(body.entered&&!entryTime){entryTime=body.time;assert.equal(body.scored,false);}}
 assert.ok(body.scored);assert.ok(entryTime>crossingTime);assert.ok(body.time>entryTime+.05);assert.ok(body.position.y>=desktop.rim.y+72);
 const side=createFlight({...plan,start:{x:260,y:225},velocity:{x:0,y:100}});while(!side.done)advanceFlight(side,1/240);assert.equal(side.scored,false);assert.equal(side.entered,false);
});
test('fixed substeps keep rim-in and rim-out outcomes stable across 30/60/120fps, with bounded floor bounces',()=>{
 for(const pull of [{x:-40,y:50},{x:-36,y:65},{x:0,y:65}]){
  const plan=createShot(desktop,pull),outcomes=[];
  for(const fps of [30,60,120]){const body=createFlight(plan);for(let i=0;i<fps*7&&!body.done;i++)advanceFlight(body,1/fps);assert.ok(body.done);assert.ok(body.floorHits<=2);outcomes.push([body.scored,body.rimHits,body.floorHits,Math.round(body.position.x*100)]);}
  assert.deepEqual(outcomes[0],outcomes[1]);assert.deepEqual(outcomes[0],outcomes[2]);
 }
});
