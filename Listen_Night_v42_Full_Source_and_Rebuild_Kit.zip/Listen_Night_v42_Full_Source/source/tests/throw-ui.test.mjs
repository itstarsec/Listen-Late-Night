// Pointer/animation integration; geometry is mocked, not measured in a browser.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import {create,act} from 'react-test-renderer';
import FileImport from '../.sites-runtime/tests/basketball-import.mjs';
import {fallbackTrack} from '../.sites-runtime/tests/domain.mjs';

test('mouse and touch can pull down and release a ballistic shot; misses, cancellation and synthetic clicks cannot import',async()=>{
 const keys=['requestAnimationFrame','cancelAnimationFrame','matchMedia','IS_REACT_ACT_ENVIRONMENT'],original=new Map(keys.map(k=>[k,Object.getOwnPropertyDescriptor(globalThis,k)]));
 const frames=new Map(),styles=new Map(),calls=[],saved=[],busy=[],rotations=[],listeners=new Map();
 const surface={addEventListener(type,fn){if(!listeners.has(type))listeners.set(type,new Set());listeners.get(type).add(fn);},removeEventListener(type,fn){listeners.get(type)?.delete(fn);},emit(type,event){for(const fn of [...listeners.get(type)||[]])fn(event);}};let nextFrame=0,now=0,root;
 const install=(k,value)=>Object.defineProperty(globalThis,k,{value,writable:true,configurable:true});
 install('IS_REACT_ACT_ENVIRONMENT',true);install('matchMedia',()=>({matches:false}));install('requestAnimationFrame',fn=>{const id=++nextFrame;frames.set(id,fn);return id;});install('cancelAnimationFrame',id=>frames.delete(id));
 const settle=async()=>{for(let i=0;i<5;i++)await new Promise(r=>setImmediate(r));};
 const pump=async(count)=>{await act(async()=>{for(let i=0;i<count;i++){now+=1000/60;const pending=[...frames.values()];frames.clear();pending.forEach(fn=>fn(now));}await settle();});};
 const text=()=>JSON.stringify(root.toJSON()),button=t=>root.root.findAllByType('button').find(n=>n.children.includes(t));
 const change=async(id,value)=>act(async()=>root.root.findByProps({id}).props.onChange({target:{value}}));
 const choose=async(id)=>{await act(async()=>{root.root.findByProps({'aria-label':'File danh sách URL YouTube'}).props.onChange({target:{files:[new File([id],id+'.txt')]}});await settle();});};
 const card=()=>root.root.findAllByType('button').find(n=>String(n.props.className).startsWith('hoop-file '));
 const capture={focus(){},setPointerCapture(){},hasPointerCapture(){return true;},releasePointerCapture(){}};
 const event=(pointerId,x,y,pointerType='mouse')=>({pointerId,clientX:x,clientY:y,pointerType,button:0,isPrimary:true,currentTarget:capture,preventDefault(){}});
 const pull=async(amount,type='mouse')=>{await act(async()=>{card().props.onPointerDown(event(1,98,263,type));card().props.onPointerMove(event(1,98,263+amount,type));});};
 const release=async(amount,type='mouse')=>{await act(async()=>{card().props.onPointerUp(event(1,98,263+amount,type));await settle();});};
 let session={slug:'throw-night',name:'Throw Night',tracks:[],version:1,canEdit:true,updatedAt:0};
 const request=async(path,init={})=>{assert.equal(path,'/admin/import');const body=JSON.parse(init.body);calls.push(body);const previous=new Set(session.tracks.map(t=>t.videoId)),ids=body.text.trim().split('\n').filter(id=>!previous.has(id));session={...session,tracks:[...session.tracks,...ids.map(id=>fallbackTrack(id))],version:session.version+1};return {session,report:{added:ids.length,duplicates:0,invalid:0,invalidLines:[],total:ids.length}};};
 const mock=({type})=>({ownerDocument:{defaultView:surface},value:'',style:{setProperty(k,v){styles.set(k,v);if(k==='--flight-rotation')rotations.push(Number.parseFloat(v));},removeProperty(k){styles.delete(k);}},getBoundingClientRect(){if(type==='span')return {left:210,right:310,top:170,bottom:210,width:100,height:40};if(type==='button')return {left:60,right:136,top:216,bottom:310,width:76,height:94};return {left:0,right:520,top:0,bottom:430,width:520,height:430};}});
 try{
  await act(async()=>{root=create(React.createElement(FileImport,{playlists:[],request,onBusy:value=>busy.push(value),onImported:s=>saved.push(s),onOpen(){}}),{createNodeMock:mock});await settle();});
  await choose('RzhIXHc6_80');assert.ok(root.root.findByProps({id:'import-name'}).props.value,'A file supplies an editable suggested playlist name');
  await change('import-name','');await change('import-slug','');assert.equal(card().props.disabled,false,'Missing destination must not disable native pointer events');assert.equal(button('Ném vào rổ').props.disabled,true);
  await act(async()=>card().props.onPointerEnter());assert.ok(root.root.findAllByProps({className:'hoop-radar-dot'}).length);
  const unavailableCapture={focus(){},setPointerCapture(){throw Error('Capture unavailable fixture');}};
  await act(async()=>{card().props.onPointerDown({...event(8,135,218),currentTarget:unavailableCapture});card().props.onLostPointerCapture();surface.emit('pointermove',event(8,135,283));});
  assert.equal(root.root.findByProps({'aria-label':'Lực ném'}).props['aria-valuenow'],68);assert.ok(root.root.findAllByType('path').some(n=>n.props.className==='will-score'));assert.equal(calls.length,0);
  await act(async()=>surface.emit('pointermove',event(8,305,438)));assert.equal(styles.get('--drag-x'),'170px','The card must follow a 170px pointer movement rather than stick at the 96px charge limit');assert.equal(card().props.style['--drag-x'],'170px');assert.equal(styles.get('--drag-y'),'220px','Dragging must also follow the pointer beyond the court edge until release');
  await act(async()=>surface.emit('pointercancel',event(8,305,438)));assert.equal([...listeners.values()].reduce((n,s)=>n+s.size,0),0);
  await change('import-name','Throw Night');await change('import-slug','throw-night');
  await pull(65);assert.equal(root.root.findByProps({'aria-label':'Lực ném'}).props['aria-valuenow'],68);assert.ok(root.root.findAllByType('path').some(n=>n.props.className==='will-score'));assert.equal(calls.length,0);
  await act(async()=>surface.emit('pointerup',event(1,98,328)));assert.equal([...listeners.values()].reduce((n,s)=>n+s.size,0),0);assert.equal(frames.size,1);assert.equal(calls.length,0);assert.ok(button('Hủy cú ném'));assert.equal(busy.at(-1),true);
  await pump(15);assert.equal(calls.length,0);assert.ok(Number.parseFloat(styles.get('--drag-y'))<65,'Released card must move upward');
  await pump(120);assert.equal(calls.length,1);assert.equal(saved.length,1);assert.ok(rotations.some(angle=>Math.abs(angle)>360),'Flight should actually complete a full rotation');assert.equal(frames.size,0);assert.equal(busy.at(-1),false);
  await choose('_U8S-uFZrHA');await pull(96,'touch');await release(96,'touch');await pump(180);assert.equal(calls.length,1);assert.ok(text().includes('Hơi mạnh'));assert.equal(card().props.disabled,false);
  await pull(65,'touch');await release(65,'touch');await act(async()=>card().props.onClick({detail:0}));assert.equal(calls.length,1);await pump(150);assert.equal(calls.length,2);assert.equal(saved.length,2);
  await choose('_NA_QD7zHmQ');
  await act(async()=>{card().props.onPointerDown(event(1,98,263));card().props.onPointerMove(event(1,58,313));card().props.onPointerUp(event(1,58,313));});
  let sawImpact=false;for(let i=0;i<360&&frames.size;i++){await pump(1);if(text().includes('Chạm vành!')){sawImpact=true;assert.equal(calls.length,2,'A rim hit must not import');assert.ok(root.root.findAllByProps({className:'hoop-impact-ring'}).length);}}
  assert.ok(sawImpact);assert.equal(calls.length,2);assert.ok(text().includes('Bật vành ra ngoài'));assert.equal(card().props.disabled,false);
  await pull(65);await act(async()=>card().props.onPointerCancel());assert.equal(frames.size,0);assert.equal(calls.length,2);assert.equal(root.root.findByProps({'aria-label':'Lực ném'}).props['aria-valuenow'],0);
  await pull(65);await release(65);await pump(5);await act(async()=>button('Hủy cú ném').props.onClick());assert.equal(frames.size,0);assert.equal(calls.length,2);assert.equal(busy.at(-1),false);assert.equal(card().props.disabled,false);
  await pull(65);await release(65);assert.equal(frames.size,1);await act(async()=>root.unmount());root=null;assert.equal(frames.size,0);assert.equal(calls.length,2);
 }finally{if(root)await act(async()=>root.unmount());for(const [k,value] of original){if(value)Object.defineProperty(globalThis,k,value);else delete globalThis[k];}}
});
