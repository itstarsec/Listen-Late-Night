// React + real API/SQLite integration; these are not visual browser tests.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import {create,act} from 'react-test-renderer';
import FileImport from '../.sites-runtime/tests/basketball-import.mjs';
import {handleApi} from '../.sites-runtime/tests/api.mjs';
import {createPasswordHash} from '../.sites-runtime/tests/auth.mjs';
import {D1} from './test-db.mjs';

test('picker and drop stage files for a shot; assisted import and lost-response retry preserve their receipt',async()=>{
 const old=Object.getOwnPropertyDescriptor(globalThis,'IS_REACT_ACT_ENVIRONMENT'),oldMedia=Object.getOwnPropertyDescriptor(globalThis,'matchMedia');globalThis.IS_REACT_ACT_ENVIRONMENT=true;globalThis.matchMedia=()=>({matches:true});
 const env={DB:new D1(),AUTH_USERNAME:'fixtureadmin',AUTH_PASSWORD_HASH:await createPasswordHash('fixture-password')};let cookie='',root,loseResponse=false;
 const calls=[],busy=[],saved=[],opened=[];
 const request=async(path,init={},signal)=>{const headers=new Headers(init.headers);headers.set('Origin','https://listen.test');if(init.body)headers.set('Content-Type','application/json');if(cookie)headers.set('Cookie',cookie);const r=await handleApi(new Request('https://listen.test/api'+path,{...init,headers,signal}),env),data=await r.json();if(r.headers.get('Set-Cookie'))cookie=r.headers.get('Set-Cookie').split(';')[0];calls.push({path,status:r.status,id:headers.get('X-Request-ID')});if(path==='/admin/import'&&loseResponse){loseResponse=false;throw Error('Mất kết nối fixture. File vẫn được giữ.');}if(!r.ok){const e=Error(data.error);e.status=r.status;throw e;}return data;};
 const settle=async()=>{for(let i=0;i<6;i++)await new Promise(r=>setImmediate(r));};
 const until=async condition=>{for(let i=0;i<350&&!condition();i++)await act(async()=>new Promise(r=>setTimeout(r,5)));assert.ok(condition(),'Import UI did not settle');};
 const text=()=>JSON.stringify(root.toJSON());const byText=t=>root.root.findAllByType('button').find(n=>n.children.includes(t));
 const choose=async(file)=>{await act(async()=>{root.root.findByProps({'aria-label':'File danh sách URL YouTube'}).props.onChange({target:{files:[file]}});await settle();});await until(()=>!text().includes('Đang đọc file…'));};
 const change=async(id,value)=>act(async()=>root.root.findByProps({id}).props.onChange({target:{value}}));
 const nodeMock=({type,props})=>({value:'',style:{setProperty(){},removeProperty(){}},click(){},getBoundingClientRect(){if(type==='span')return {left:210,right:310,top:170,bottom:210,width:100,height:40};if(type==='button')return {left:60,right:136,top:216,bottom:310,width:76,height:94};return {left:0,right:520,top:0,bottom:430,width:520,height:430};}});
 try{
  await request('/auth/login',{method:'POST',body:JSON.stringify({username:'fixtureadmin',password:'fixture-password'})});
  await act(async()=>{root=create(React.createElement(FileImport,{playlists:[],request,onBusy:value=>busy.push(value),onImported:(s,ids)=>saved.push({s,ids}),onOpen:id=>opened.push(id)}),{createNodeMock:nodeMock});await settle();});
  await change('import-name','Đêm dài');assert.equal(root.root.findByProps({id:'import-slug'}).props.value,'dem-dai');
  await choose(new File(['RzhIXHc6_80\nhttps://youtu.be/RzhIXHc6_80\ninvalid\n_U8S-uFZrHA'],'night.txt'));
  assert.equal(calls.filter(c=>c.path==='/admin/import').length,0);assert.ok(text().includes('bài sẽ thêm'));assert.ok(!byText('Ném vào rổ').props.disabled);
  loseResponse=true;await act(async()=>{await byText('Ném vào rổ').props.onClick();await settle();});await until(()=>!busy.at(-1));assert.ok(text().includes('Mất kết nối fixture'));assert.equal(env.DB.raw.prepare("SELECT count(*) n FROM sessions WHERE slug='dem-dai'").get().n,1);
  await act(async()=>{await byText('Ném vào rổ').props.onClick();await settle();});await until(()=>saved.length===1);const imports=calls.filter(c=>c.path==='/admin/import');assert.equal(imports.length,2);assert.equal(imports[0].id,imports[1].id);assert.equal(saved[0].s.tracks.length,2);assert.equal(saved[0].s.version,1);assert.ok(text().includes('Đã xác nhận lần nhập trước'));assert.ok(byText('Ném vào rổ').props.disabled);assert.equal(root.root.findByProps({id:'import-target'}).props.value,'dem-dai');
  const court=root.root.findAllByType('div').find(n=>String(n.props.className).startsWith('hoop-court'));
  await act(async()=>{court.props.onDrop({preventDefault(){},dataTransfer:{files:[new File(['url\nRzhIXHc6_80\n_NA_QD7zHmQ'],'more.csv')]}});await settle();});await until(()=>!text().includes('Đang đọc file…'));assert.equal(saved.length,1);await act(async()=>{byText('Ném vào rổ').props.onClick();await settle();});await until(()=>saved.length===2);assert.deepEqual(saved[1].s.tracks.map(t=>t.videoId),['RzhIXHc6_80','_U8S-uFZrHA','_NA_QD7zHmQ']);assert.equal(saved[1].s.version,2);assert.ok(text().includes('Vào rổ!'));assert.equal(busy.at(-1),false);
  await act(async()=>byText('Quản lý playlist').props.onClick());assert.deepEqual(opened,['dem-dai']);
  await choose(new File(['invalid'],'bad.pdf'));assert.ok(text().includes('Chọn file .txt'));assert.equal(calls.filter(c=>c.path==='/admin/import').length,3);assert.ok(byText('Ném vào rổ').props.disabled);
  await choose(new File(['n6nkNKSvl2Y'],'shot.txt'));const card=root.root.findByProps({'aria-label':'Ném file shot.txt vào rổ'}),capture={focus(){},setPointerCapture(){},hasPointerCapture(){return true;},releasePointerCapture(){}};
  await act(async()=>{card.props.onPointerDown({preventDefault(){},button:0,pointerId:1,clientX:98,clientY:263,currentTarget:capture});card.props.onPointerMove({preventDefault(){},pointerId:1,clientX:150,clientY:290});card.props.onPointerUp({preventDefault(){},pointerId:1,clientX:150,clientY:290,currentTarget:capture});await settle();});assert.equal(calls.filter(c=>c.path==='/admin/import').length,3);assert.ok(text().includes('Hơi')||text().includes('Suýt'));
  await act(async()=>{card.props.onPointerDown({preventDefault(){},button:0,pointerId:2,clientX:98,clientY:263,currentTarget:capture});card.props.onPointerMove({preventDefault(){},pointerId:2,clientX:98,clientY:328});card.props.onPointerUp({preventDefault(){},pointerId:2,clientX:98,clientY:328,currentTarget:capture});await settle();});await until(()=>saved.length===3);assert.equal(saved[2].s.tracks.length,4);
 }finally{if(root)await act(async()=>root.unmount());if(old)Object.defineProperty(globalThis,'IS_REACT_ACT_ENVIRONMENT',old);else delete globalThis.IS_REACT_ACT_ENVIRONMENT;if(oldMedia)Object.defineProperty(globalThis,'matchMedia',oldMedia);else delete globalThis.matchMedia;}
});
