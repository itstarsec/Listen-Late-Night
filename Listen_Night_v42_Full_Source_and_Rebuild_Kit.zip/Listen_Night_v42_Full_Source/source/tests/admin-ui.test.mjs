// React component integration against the real API and SQLite D1 adapter.
// These checks do not claim browser layout or real-device verification.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const initialPlaylistCount=1+JSON.parse(readFileSync('lib/curated-playlists.json','utf8')).length+JSON.parse(readFileSync('lib/imported-playlists.json','utf8')).length;
import React from 'react';
import {create,act} from 'react-test-renderer';
import AdminEntry from '../.sites-runtime/tests/admin-entry.mjs';
import AdminDashboard from '../.sites-runtime/tests/admin-dashboard.mjs';
import {handleApi} from '../.sites-runtime/tests/api.mjs';
import {createPasswordHash} from '../.sites-runtime/tests/auth.mjs';
import {D1} from './test-db.mjs';

test('dedicated admin manages playlists and tracks without a player; CRUD persists, bulk removal is scoped, conflicts and stale responses are safe',async()=>{
 const names=['window','history','document','navigator','fetch','IS_REACT_ACT_ENVIRONMENT'];
 const original=new Map(names.map(name=>[name,Object.getOwnPropertyDescriptor(globalThis,name)]));
 const install=(key,value)=>Object.defineProperty(globalThis,key,{value,writable:true,configurable:true});
 const env={DB:new D1(),AUTH_USERNAME:'fixtureadmin',AUTH_PASSWORD_HASH:await createPasswordHash('fixture-password')};
 let root,cookie='',failMe=true,failCatalogue=false,slowPath='',releaseSlow;
 const calls=[],copied=[],settle=async()=>{for(let i=0;i<5;i++)await new Promise(resolve=>setImmediate(resolve));};
 const room=()=>{const row=env.DB.raw.prepare("SELECT * FROM sessions WHERE slug='admin-ui-room'").get();return row?{...row,tracks:JSON.parse(row.tracks)}:null;};
 try{
  install('IS_REACT_ACT_ENVIRONMENT',true);
  install('window',{location:new URL('https://listen.test/bim'),YT:{Player(){throw Error('The admin must never create a YouTube player');}}});
  install('history',{replaceState(a,b,url){window.location=new URL(url,window.location);}});
  install('document',{body:{style:{}},activeElement:null});
  install('navigator',{clipboard:{async writeText(value){copied.push(value);}}});
  install('fetch',async(url,init={})=>{
   if(String(url).startsWith('https://www.youtube.com/oembed?'))return Response.json({title:'YouTube metadata fixture',author_name:'Fixture channel'});
   assert.ok(String(url).startsWith('/api/'),'Admin requests must remain same-origin API calls');
   calls.push({url,method:init.method||'GET',credentials:init.credentials});
   if(url==='/api/me'&&failMe){failMe=false;throw Error('Network failure fixture');}
   if(url==='/api/admin/playlists'&&failCatalogue){failCatalogue=false;throw Error('Catalogue unavailable fixture');}
   const headers=new Headers(init.headers);if(cookie)headers.set('Cookie',cookie);if(init.method&&init.method!=='GET')headers.set('Origin','https://listen.test');
   const response=await handleApi(new Request('https://listen.test'+url,{...init,headers}),env);
   const setCookie=response.headers.get('Set-Cookie');if(setCookie)cookie=setCookie.split(';')[0];
   if(url===slowPath){slowPath='';await new Promise(resolve=>{releaseSlow=resolve;});}
   return response;
  });
  const mount=async()=>{await act(async()=>{root=create(React.createElement(AdminEntry),{createNodeMock:()=>({showModal(){},close(){}})});await settle();});};
  const renderedText=node=>node.children.map(child=>typeof child==='object'?renderedText(child):String(child)).join('');
  const byText=(text,parent=root.root)=>parent.findAllByType('button').find(node=>node.children.includes(text)||renderedText(node)===text);
  const byLabel=(label,parent=root.root)=>parent.findAllByType('button').find(node=>node.props['aria-label']===label);
  const until=async predicate=>{for(let i=0;i<300;i++){if(predicate())return;await act(async()=>new Promise(resolve=>setTimeout(resolve,5)));}assert.ok(predicate(),'The asynchronous UI did not settle');};
  const idle=()=>!byText('Tải lại')?.props.disabled;
  const click=async node=>{assert.ok(node,'Expected an available action');assert.ok(!node.props.disabled,'Action must be enabled');await act(async()=>{await node.props.onClick();await settle();});await until(idle);};
  const change=async(node,value)=>act(async()=>node.props.onChange({target:{value}}));
  const modal=()=>{const nodes=root.root.findAllByType('dialog');assert.equal(nodes.length,1);return nodes[0];};
  const submit=async()=>act(async()=>{await modal().findByType('form').props.onSubmit({preventDefault(){}});await settle();});
  const noPlayer=()=>{assert.equal(root.root.findAllByType('iframe').length,0);assert.equal(root.root.findAllByType('canvas').length,0);assert.equal(root.root.findAllByType('audio').length,0);};
  const text=()=>JSON.stringify(root.toJSON());
  const rowFor=id=>root.root.findAllByType('code').find(n=>n.children.includes(id))?.parent.parent;
  await mount();assert.ok(text().includes('Chưa kết nối được với máy chủ'));noPlayer();
  await click(byText('Thử lại'));assert.equal(root.root.findAllByType('form').length,1);
  await change(root.root.findByProps({id:'admin-username'}),'fixtureadmin');
  await change(root.root.findByProps({id:'admin-password'}),'incorrect-fixture-password');
  await act(async()=>{await root.root.findByType('form').props.onSubmit({preventDefault(){}});await settle();});
  assert.equal(root.root.findByProps({id:'admin-password'}).props.value,'');assert.ok(text().includes('Tên đăng nhập hoặc mật khẩu chưa đúng.'));noPlayer();
  await change(root.root.findByProps({id:'admin-password'}),'fixture-password');
  await act(async()=>{await root.root.findByType('form').props.onSubmit({preventDefault(){}});await settle();});
  await until(idle);
  assert.equal(root.root.findAllByType(AdminDashboard).length,1);assert.equal(root.root.findByType('tbody').findAllByType('tr').length,initialPlaylistCount);noPlayer();
  await change(root.root.findByProps({'aria-label':'Lọc playlist'}),'tryhard');assert.equal(root.root.findByType('tbody').findAllByType('tr').length,8);assert.ok(text().includes('Try Hard · Mr. Robot'));await change(root.root.findByProps({'aria-label':'Lọc playlist'}),'gaming');assert.equal(root.root.findByType('tbody').findAllByType('tr').length,10);assert.ok(text().includes('Call of Duty · Modern Warfare II'));assert.ok(text().includes('Forza Horizon 5 · Horizon Pulse'));await change(root.root.findByProps({'aria-label':'Lọc playlist'}),'ride');assert.equal(root.root.findByType('tbody').findAllByType('tr').length,8);assert.ok(text().includes('Cruiser · Harley Road Songs'));assert.ok(text().includes('Đi để trở về · Nhạc Việt'));await change(root.root.findByProps({'aria-label':'Lọc playlist'}),'active');assert.equal(root.root.findByType('tbody').findAllByType('tr').length,8);assert.ok(text().includes('Workout Pulse · NCS'));assert.ok(text().includes('Pedal Flow · House Mixes'));await change(root.root.findByProps({'aria-label':'Lọc playlist'}),'dopamine');assert.equal(root.root.findByType('tbody').findAllByType('tr').length,8);assert.ok(text().includes('Euphoric · Enter Your Mind'));assert.ok(text().includes('Afterglow · ODESZA'));await change(root.root.findByProps({'aria-label':'Lọc playlist'}),'ai');assert.equal(root.root.findByType('tbody').findAllByType('tr').length,3);assert.ok(text().includes('Say tình · F47 Cover'));assert.ok(text().includes('Phố mưa · TRO Music'));assert.ok(text().includes('Tình ca đêm · AI Ballad'));noPlayer();await change(root.root.findByProps({'aria-label':'Lọc playlist'}),'all');
  const initialRows=env.DB.raw.prepare('SELECT * FROM sessions ORDER BY slug').all();
  await click(byText('Tạo playlist'));await change(modal().findByProps({id:'manager-name'}),'Duplicate fixture');await change(modal().findByProps({id:'manager-slug'}),'shelby');await submit();
  assert.ok(text().includes('Slug này đã được sử dụng.'));assert.equal(root.root.findAllByType('dialog').length,1);assert.equal(env.DB.raw.prepare('SELECT count(*) AS n FROM sessions').get().n,initialPlaylistCount);await click(byText('Hủy',modal()));
  await click(byText('Tạo playlist'));await change(modal().findByProps({id:'manager-name'}),'Playlist quản trị');await change(modal().findByProps({id:'manager-slug'}),'admin-ui-room');await submit();
  assert.equal(room().name,'Playlist quản trị');assert.deepEqual(room().tracks,[]);assert.equal(window.location.search,'?s=admin-ui-room');assert.ok(byText('Thêm bài'));assert.ok(text().includes('Playlist chưa có bài hát'));noPlayer();
  failCatalogue=true;await click(byText('Tải lại'));assert.ok(text().includes('Mất kết nối.'));assert.equal(room().tracks.length,0);await click(byText('Thử lại'));assert.ok(!text().includes('Mất kết nối.'));
  await click(byText('Thêm bài'));await change(modal().findByProps({id:'manager-urls'}),'https://youtu.be/RzhIXHc6_80?si=tracking\nhttps://www.youtube.com/watch?v=RzhIXHc6_80&list=ignored\nhttps://invalid.example/not-a-video\n_U8S-uFZrHA');await submit();
  assert.ok(text().includes('Đã thêm 2 bài · 1 trùng · 1 dòng không hợp lệ (dòng 3).'),JSON.stringify({messages:root.root.findAll(n=>n.props.role==='status'||n.props.role==='alert').flatMap(n=>n.findAllByType('span').flatMap(s=>s.children.filter(c=>typeof c==='string'))),stored:room().tracks.map(t=>t.videoId)}));assert.deepEqual(room().tracks.map(t=>t.videoId),['RzhIXHc6_80','_U8S-uFZrHA']);
  await click(byText('Đổi tên'));await change(modal().findByProps({id:'manager-name'}),'Nhạc quản trị');await submit();assert.equal(room().name,'Nhạc quản trị');
  await click(byText('Liên kết nghe'));assert.deepEqual(copied,['https://listen.test/?s=admin-ui-room']);
  const firstRow=rowFor('RzhIXHc6_80');await click(firstRow.findAllByType('button').find(n=>String(n.props['aria-label']).endsWith(' xuống')));assert.deepEqual(room().tracks.map(t=>t.videoId),['_U8S-uFZrHA','RzhIXHc6_80']);
  const staleVersion=room().version;env.DB.raw.prepare("UPDATE sessions SET version=version+1 WHERE slug='admin-ui-room'").run();
  await click(rowFor('RzhIXHc6_80').findAllByType('button').find(n=>String(n.props['aria-label']).startsWith('Xóa bài ')));await submit();
  assert.equal(root.root.findAllByType('dialog').length,0);assert.ok(text().includes('Dữ liệu vừa thay đổi trên phiên khác.'));assert.equal(room().tracks.length,2);assert.equal(room().version,staleVersion+1);
  const deletes=calls.filter(c=>c.method==='DELETE').length;
  await click(rowFor('RzhIXHc6_80').findAllByType('button').find(n=>String(n.props['aria-label']).startsWith('Xóa bài ')));await click(byText('Hủy',modal()));assert.equal(calls.filter(c=>c.method==='DELETE').length,deletes);
  await act(async()=>root.root.findByProps({'aria-label':'Chọn tất cả bài trên trang'}).props.onChange({target:{checked:true}}));
  await click(byText('Xóa 2 bài'));await submit();assert.equal(room().tracks.length,0);assert.ok(text().includes('Playlist chưa có bài hát'));
  await click(byText('Thêm bài'));await change(modal().findByProps({id:'manager-urls'}),'RzhIXHc6_80\n_U8S-uFZrHA\n0-7IHOXkiV8');await submit();assert.equal(room().tracks.length,3);
  await click(byText('Bài hát'));assert.equal(root.root.findByType('tbody').findAllByType('tr').length,50);assert.ok(!byLabel('Trang tiếp theo').props.disabled);await click(byLabel('Trang tiếp theo'));assert.equal(root.root.findByType('tbody').findAllByType('tr').length,50);
  await change(root.root.findByProps({'aria-label':'Tìm bài hát'}),'0-7IHOXkiV8');assert.equal(root.root.findByType('tbody').findAllByType('tr').length,1);
  await click(root.root.findAllByType('button').find(n=>String(n.props['aria-label']).startsWith('Quản lý bài ')));assert.ok(text().includes('Chọn playlist để quản lý'));
  await click(modal().findAllByType('button').find(n=>n.findAllByType('span').some(span=>span.children.includes('Nhạc quản trị'))));assert.equal(window.location.search,'?s=admin-ui-room');assert.equal(root.root.findByType('tbody').findAllByType('tr').length,1);assert.equal(root.root.findByProps({'aria-label':'Tìm bài hát'}).props.value,'0-7IHOXkiV8');noPlayer();
  await change(root.root.findByProps({'aria-label':'Tìm bài hát'}),'');
  await click(byText('Tất cả playlist'));slowPath='/api/sessions/shelby';
  await act(async()=>{void byLabel('Quản lý bài trong Shelby — Late Night').props.onClick();await settle();});await until(()=>!!releaseSlow);
  await click(byText('Tất cả playlist'));await click(byLabel('Quản lý bài trong Nhạc quản trị'));
  await act(async()=>{releaseSlow();await settle();});assert.equal(root.root.findByType('h1').children.join(''),'Nhạc quản trị');assert.ok(!byText('Tải lại').props.disabled);
  await click(rowFor('_U8S-uFZrHA').findAllByType('button').find(n=>String(n.props['aria-label']).startsWith('Xóa bài ')));await submit();assert.deepEqual(room().tracks.map(t=>t.videoId),['RzhIXHc6_80','0-7IHOXkiV8']);
  await click(byText('Tất cả playlist'));await change(root.root.findByProps({'aria-label':'Tìm playlist'}),'admin-ui-room');assert.equal(root.root.findByType('tbody').findAllByType('tr').length,1);
  await click(byLabel('Xóa playlist Nhạc quản trị'));await click(byText('Hủy',modal()));assert.ok(room());await click(byLabel('Xóa playlist Nhạc quản trị'));await submit();assert.equal(room(),null);
  assert.deepEqual(env.DB.raw.prepare('SELECT * FROM sessions ORDER BY slug').all(),initialRows);assert.ok(calls.filter(c=>c.url.startsWith('/api/')).every(c=>c.credentials==='same-origin'));noPlayer();
  await click(byLabel('Đăng xuất'));assert.equal(root.root.findAllByType(AdminDashboard).length,0);assert.equal(root.root.findAllByType('form').length,1);assert.equal(root.root.findByProps({id:'admin-password'}).props.value,'');noPlayer();
 }finally{
  releaseSlow?.();if(root)await act(async()=>{root.unmount();await settle();});
  for(const [key,descriptor] of original){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}
 }
});
