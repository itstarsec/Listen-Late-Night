# Nhạc Việt · bản nhập ngày 19/10/2026

Các playlist dưới đây đã được mở trên YouTube Music và đối chiếu với danh sách công khai của cùng playlist trên YouTube. Đọc hết continuation của danh sách bài (không lấy mục gợi ý); giữ thứ tự xuất hiện đầu tiên và loại trùng video ID trong từng playlist. Hai playlist YouTube Music Global Charts là bảng xếp hạng chính thức; các mục còn lại là tuyển chọn của nghệ sĩ, nhà phát hành hoặc cộng đồng, không phải một bảng xếp hạng playlist phổ biến tuyệt đối.

Đây là bản nhập tại thời điểm ghi trong dữ liệu, không tự đồng bộ khi nguồn thay đổi. “Không truy xuất” là chênh lệch giữa tổng mục nguồn công bố và các video công khai nguồn trả về sau khi hết trang; không suy đoán hay tạo ID thay thế. Các liên khúc, bản phối hoặc video dài được giữ nguyên như nguồn.

| Playlist trên website | Nguồn | Tổng mục nguồn | Mục công khai | Trùng ID | Đã nhập | Không truy xuất | Trang |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Top 100 bài hát · Việt Nam | [YouTube Music Global Charts](https://music.youtube.com/playlist?list=PL4fGSI1pDJn4bRKr6tjRWaGlqRg_zY_is) | 100 | 100 | 0 | 100 | 0 | 1 |
| Top MV trong ngày · Việt Nam | [YouTube Music Global Charts](https://music.youtube.com/playlist?list=PL4fGSI1pDJn57DkisEwlIpcs9FAt5yudJ) | 100 | 100 | 0 | 100 | 0 | 1 |
| Nhạc Việt nổi bật 2026 | [Redlist Charts](https://music.youtube.com/playlist?list=PLpY7hx7jry7zc4zspi_fBhWQt8z5jrJ8z) | 59 | 59 | 0 | 59 | 0 | 1 |
| Nhạc Việt mới · Tháng 10/2026 | [Redlist - Music Charts](https://music.youtube.com/playlist?list=PLw-VjHDlEOgsT_dJQiZUQRGuR1f5fmGKm) | 49 | 49 | 0 | 49 | 0 | 1 |
| Indie Việt · Những khoảng riêng | [Thanh Nguyen](https://music.youtube.com/playlist?list=PLvK306ROb6UY1RyXIKtjPLTAWg8CAVJho) | 115 | 111 | 1 | 110 | 4 | 2 |
| R&B Việt · NDMT | [NDMT](https://music.youtube.com/playlist?list=PLppJWWpZs1qqsH9pwVcWC7n0ZV3NSQ1dT) | 138 | 134 | 0 | 134 | 4 | 2 |
| Đen Vâu · Những bài rap hay nhất | [Đen Vâu Official](https://music.youtube.com/playlist?list=PLH_v4r_pvudX7lUzePWA7we1l3ANe9NW1) | 55 | 52 | 0 | 52 | 3 | 1 |
| Ngọt · Music | [Ngọt](https://music.youtube.com/playlist?list=PLnUioGkqqn5XwWaMlwhftWusPPK_KHz3T) | 50 | 49 | 0 | 49 | 1 | 1 |
| Xuân Hạ Thu Đông Rồi Lại Xuân · Mùa 3 | [FOREST STUDIO](https://music.youtube.com/playlist?list=PLxNMBnO9F8FNC1Q7AG1GsLF5tLCUuDAkQ) | 91 | 89 | 0 | 89 | 2 | 1 |
| Rap Việt · Mùa 3 · MV Lyrics | [Vie Channel - MUSIC](https://music.youtube.com/playlist?list=PL0br2ZOewY7gkWG3Hu4temHmtMC425X6Z) | 110 | 93 | 0 | 93 | 17 | 1 |
| Nhạc Việt · Deep Chill | [ACV - Nhạc Việt DeepChill](https://music.youtube.com/playlist?list=PLcPwmfKl8dWgPUN-TCyryAwpB7P3WDxg-) | 38 | 37 | 0 | 37 | 1 | 1 |
| Acoustic xưa cũ | [Chang](https://music.youtube.com/playlist?list=PLTJ_0TN1M7KVGbhmseG6t7AP9xz3WFN-p) | 13 | 13 | 0 | 13 | 0 | 1 |
| Vietnam REMIX | [𝑬𝒕𝒉𝒂𝒏@𝑴𝒖𝒔𝒊𝒄𝑩𝒐𝒙](https://music.youtube.com/playlist?list=PLUt9TPU9nTTGALM5zUAGPSPeIo8WoYMAi) | 36 | 33 | 0 | 33 | 3 | 1 |

13 playlist bổ sung: 918 vị trí sau loại trùng trong từng playlist; 35 mục nguồn không truy xuất được. View **Tất cả bài hát** tiếp tục loại trùng giữa mọi playlist theo video ID; số bài của từng playlist không bị thay đổi khi gộp.

Dữ liệu đầy đủ, tiêu đề gốc, ID nguồn, tên người tuyển chọn, metadata và thời điểm nhập ở `lib/imported-playlists.json`. Marker riêng theo ID nguồn giữ nguyên mọi chỉnh sửa/xóa ở D1 khi triển khai lại.
