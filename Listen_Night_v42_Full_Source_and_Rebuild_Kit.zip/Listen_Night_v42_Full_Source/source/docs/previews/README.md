# Ảnh dựng giao diện

`desktop-static.png` (1440×1080) và `mobile-static.png` (390×1410) là bản dựng tĩnh từ SVG fallback và metadata YouTube thật. Chúng minh họa bố cục, không phải ảnh chụp browser/WebGL. Vùng video trong ảnh là minh họa, không phải player thật được ghi hình.

Mã dựng: `scripts/render-design-previews.mjs`. Không chạy browser hoặc WebGL. Chạy `node tests/run.mjs` trước để có module render JSX đã chuyển đổi. Có thể truyền `PREVIEW_THUMBNAILS` tới thư mục thumbnail dạng `<videoId>.jpg`.

Kiểm chứng đầy đủ và giới hạn ở `VERIFICATION.md`.
