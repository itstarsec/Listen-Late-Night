# Baby Sleep Instantly

> Tài liệu lịch sử v33–v35. Theo yêu cầu tiếp theo ngày 31/10/2026, sáu video dưới đây đã được thay bằng duy nhất [video người dùng chọn](baby-single-video.md), vẫn giữ `be-ngu-ngoan`.

Theo yêu cầu ngày 30/10/2026, thay toàn bộ 23 video của `be-ngu-ngoan` bằng sáu video dưới đây, giữ URL `?s=be-ngu-ngoan`. Đổi tên hiển thị mặc định thành **Baby Sleep Instantly**. Đây là tuyển chọn của Listen Night từ nhiều kênh, không phải bản nhập từ một playlist YouTube duy nhất. Người dùng chưa cung cấp URL nguồn cụ thể cho tên này.

| Thứ tự | Tiêu đề nguồn | Kênh | Thời lượng | Nguồn |
| --- | --- | --- | --- | --- |
| 1 | Baby Sleep Instantly · Gentle Mozart & Brahms Lullabies for Deep Sleep | Baby White Noise | 1:25:40 | https://www.youtube.com/watch?v=e5Z9UDTIieo |
| 2 | Baby Sleep Music · Baby Sleep Instantly in 3 Minutes · Mozart & Brahms Lullaby | Sleep music | 1:25:40 | https://www.youtube.com/watch?v=IDBI9cwp1Ak |
| 3 | Sleep Instantly Within 3 Minutes · Mozart Brahms Lullaby | Sleep music | 1:25:40 | https://www.youtube.com/watch?v=i2aC7YoKPTk |
| 4 | Sleep Instantly Tonight · Baby Sleep Music · Mozart & Brahms Lullabies | Sleep Music for Babies | 1:07:17 | https://www.youtube.com/watch?v=EqOh9pJtsOI |
| 5 | Calming Baby Lullabies · Sleep Instantly · Baby Sleep Music | Baby Sleep Music Melody | 1:29:44 | https://www.youtube.com/watch?v=QQNB9g3q6VI |
| 6 | Sleep Instantly Within 3 Minutes · Mozart Brahms Lullaby | Healing Relaxing HDR | 1:25:39 | https://www.youtube.com/watch?v=3eHRjbh29QM |

Bảng viết gọn tiêu đề cho dễ đọc; JSON và giao diện lưu tiêu đề đầy đủ từ YouTube oEmbed. Tên kênh/thumbnail cũng từ metadata thực; thời lượng từ `ytInitialPlayerResponse.videoDetails.lengthSeconds` trên trang video công khai. Giới hạn ba video được xác minh đồng thời. Sáu video là bản ghi hữu hạn, trạng thái công khai `OK`, `playableInEmbed=true`, oEmbed trả về thành công tại thời điểm kiểm tra. Loại các nguồn không lấy được metadata và các bản dài 10–24 giờ khỏi tuyển chọn. Chỉ đọc metadata, không tải hoặc tách nội dung nghe nhìn.

Tên video do nhà xuất bản đặt có thể chứa tuyên bố “sleep instantly”, “3 minutes” hay lợi ích sức khỏe. Website không xác nhận hiệu quả gây ngủ, điều trị hoặc phát triển trí não. Giữ lời nhắc âm lượng nhỏ, đặt loa xa bé và nghe trong thời gian phù hợp. Quảng cáo, khả năng nhúng và phát nền phụ thuộc YouTube/trình duyệt; không có cơ chế bỏ quảng cáo. [Giới hạn phát YouTube và nguồn chính thức](baby-longform.md#quảng-cáo-và-phát-nền).

## Cập nhật dữ liệu

`seedKey` giữ marker khởi tạo cũ; `sourcePlaylistId=null` và `sourceKind=curated` tách nguồn hiện tại khỏi playlist Super Simple cũ. Liên kết “Xem video nguồn” mở video đầu; mỗi hàng có nút mở video gốc. Nguồn cũ được lưu ở [bản sao v32](archives/be-ngu-ngoan-v32.json).

`replacement.revision` tạo marker D1 riêng. Lần nâng cấp loại đúng 23 ID đã kiểm kê và thêm sáu ID mới theo thứ tự trên trong một transaction; tăng version một lần. Tên mặc định cũ được đổi sang tên mới, tên tự đặt của quản trị viên được giữ. Chỉnh sửa đồng thời được bảo vệ bằng version/CAS, thử lại tối đa ba lần; bài được quản trị viên thêm ngoài 23 ID đã kiểm kê được giữ ở cuối. Nếu không đủ chỗ để giữ các bài đó, playlist vẫn sửa được và bản thay thế chờ có chỗ. Không nhận playlist của chủ khác, không tạo lại playlist đã xóa. Dữ liệu mới và marker commit/rollback cùng nhau; xóa bài hoặc xóa playlist sau nâng cấp không bị phục hồi. Các playlist và tài khoản khác không bị thay đổi.

Cơ sở dữ liệu mới khởi tạo trực tiếp sáu video và marker trong cùng transaction, không tạo danh sách cũ rồi chạy lại. Truy cập trực tiếp chỉ khởi tạo playlist này; điện thoại vẫn không tải thư viện tổng hợp mặc định. Nút “Nghe bản dài” và “Phát tất cả” dùng player và hàng phát hiện có; không tự phát khi mở trang.

## Kiểm chứng

133/133 kiểm thử đạt; TypeScript và `git diff --check` đạt. Giới hạn truy vấn D1 khi khởi tạo toàn bộ catalogue vẫn nằm trong mức kiểm thử tối đa 50 truy vấn.

Các kiểm thử bao phủ dữ liệu mới, nâng cấp từ phiên bản 18 và 23 video, quyền chỉnh sửa, không khôi phục sau xóa, rollback khi lỗi ghi marker, CAS và cập nhật đồng thời, giới hạn retry, dung lượng, tổng hợp ổn định và liên kết nguồn chính xác. Component test kiểm tra tên/sáu video/nút phát, không autoplay, tự chuyển bài bằng một player và không gọi thư viện tổng hợp trên link điện thoại. Đây là kiểm thử với fixture API YouTube, không phải nghe thực tế hết video hoặc kiểm chứng giấc ngủ của bé.
