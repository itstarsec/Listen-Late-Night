# Dopamine — bản nhập ngày 24/10/2026

Dopamine là tên chủ đề tuyển chọn nhạc giàu cảm xúc, giai điệu sáng, âm trầm và cao trào: melodic EDM, vocal trance/chill, euphoric hardstyle, dubstep, wave, dàn nhạc điện ảnh và french house. Cảm giác nghe tùy người; không có đo lường hoặc cam kết tác động sinh học trong ứng dụng.

## Nguồn và phạm vi

Đã đọc frontend công khai trên YouTube Music và danh sách YouTube cùng ID của cả tám nguồn; đọc hết phần playlist trong một trang, giữ đúng thứ tự, không nhập video gợi ý.

| Playlist | Slug | Nguồn | Loại nguồn | Mục nguồn | Đã nhập | Không truy xuất |
| --- | --- | --- | --- | ---: | ---: | ---: |
| Festival Euphoria · Avicii | `dopamine-festival` | [𝘢𝘳𝘵 𝘵𝘳𝘢𝘤𝘬𝘴](https://music.youtube.com/playlist?list=PLDUEjoBVMbh8tNP12JquEPbdvBqFIVI-S) | Cộng đồng | 10 | 10 | 0 |
| Vocal Lift · OceanLab | `dopamine-vocal-trance` | [Above & Beyond](https://music.youtube.com/playlist?list=PL88E33802872748BE) | Nghệ sĩ / hãng phát hành | 13 | 13 | 0 |
| Euphoric · Enter Your Mind | `dopamine-hardstyle` | [Scantraxx](https://music.youtube.com/playlist?list=PLuoriEIb_dmna6Ltgb6etN4G65n0rlJBS) | Nghệ sĩ / hãng phát hành | 16 | 16 | 0 |
| Bass Impact · NCS | `dopamine-bass-drop` | [NoCopyrightSounds](https://music.youtube.com/playlist?list=PLRBp0Fe2Gpglq-J-Hv0p-y0wk3lQk570u) | Nghệ sĩ / hãng phát hành | 81 | 81 | 0 |
| Night Pulse · Skeler & Wave | `dopamine-hardwave` | [Jakub Janczak](https://music.youtube.com/playlist?list=PLlVBZOx2qflhZkZ3aeZ8HsnZtciK45Jhm) | Cộng đồng | 10 | 10 | 0 |
| Cinematic Lift · Battlecry | `dopamine-cinematic` | [Two Steps From Hell](https://music.youtube.com/playlist?list=PLR5APJwPaxYLbEsztLyouK8VaOqh8b3vm) | Nghệ sĩ / hãng phát hành | 26 | 25 | 1 |
| Afterglow · ODESZA | `dopamine-afterglow` | [ODESZA](https://music.youtube.com/playlist?list=PLcSHo7HfYqSJiiNoNtcFJyOHrY2s6WF4H) | Nghệ sĩ / hãng phát hành | 16 | 16 | 0 |
| Feel Good · Daft Punk | `dopamine-french-house` | [Daft Punk](https://music.youtube.com/playlist?list=PLSdoVPM5WnndSQEXRz704yQkKwx76GvPV) | Nghệ sĩ / hãng phát hành | 14 | 14 | 0 |

Có **186 mục nguồn**, **185 bài/video công khai**, **1 mục không truy xuất** trong Battlecry, **0 ID trùng trong từng nguồn hoặc giữa tám nguồn**. Bảy video ID đã thuộc thư viện cũ; danh sách tổng hợp nhận **178 ID mới**.

Sáu nguồn được tạo bởi nghệ sĩ/hãng phát hành: Above & Beyond, Scantraxx, NoCopyrightSounds, Two Steps From Hell, ODESZA và Daft Punk. Hai nguồn cộng đồng là True theo 𝘢𝘳𝘵 𝘵𝘳𝘢𝘤𝘬𝘴 và Skeler - NightDrive theo Jakub Janczak. Không gọi hai playlist này là playlist do nghệ sĩ tạo; video của True được đọc từ kênh Avicii.

- Festival Euphoria giữ 10 bài True của nguồn; không nhập bản 15 mục có bonus track từ một nguồn khác.
- Vocal Lift giữ 13 bài Sirens Of The Sea, gồm cả các đoạn nhẹ/downtempo, không mô tả thành toàn bộ club mix.
- Euphoric chọn playlist audio 16 mục của Scantraxx; không nhập playlist 32 mục của nghệ sĩ vì xen phần giới thiệu từng tập.
- Bass Impact giữ 81 video của The Best Of Dubstep, không thay bằng nguồn Top 50 khác.
- Night Pulse có 10 video/mix dài, một số là phiên bản/mix khác của cùng chất liệu. Chỉ gộp trùng theo video ID; không tự nhận diện audio, tách các bài bên trong mix hoặc gọi tất cả mục là ca khúc riêng.
- Cinematic Lift giữ thứ tự playlist Battlecry do Two Steps From Hell tạo; không tự sửa thành thứ tự track trên một phiên bản album khác.
- Afterglow giữ 16 mục A Moment Apart, gồm cả Intro. Feel Good giữ 14 mục Discovery từ playlist chính thức của Daft Punk.

Metadata có nguồn thực: video ID, tiêu đề, kênh, thumbnail. YouTube oEmbed của video đầu tiên trong cả tám playlist trả metadata hợp lệ (8/8). Metadata không chứng minh mọi video đều có quyền nhúng/phát tại mọi vùng hoặc thiết bị.

## Tích hợp

Snapshot ở `lib/imported-playlists.json` có `category: dopamine`, nguồn, curator, thời gian, số lượng và số trang. Không tự đồng bộ nguồn sau ngày nhập.

Danh mục **Dopamine** có icon Sparkles, số lượng và trạng thái chọn, xuất hiện ở thư viện nghe và bộ lọc quản trị. Nút danh mục tiếp tục là hàng riêng cao tối thiểu 48px. Lọc, duyệt playlist hoặc tìm bài không khởi tạo lại player hoặc thay hàng đang phát.

Trang mặc định **Tất cả bài hát** giữ thứ tự nguồn cũ trước tám nguồn mới, gộp một lần theo video ID và lưu mọi playlist nguồn cho các bài dùng chung. Bộ seed sau bổ sung có **67 playlist, 2.427 vị trí và 2.261 ID khác nhau**. Baseline production trước triển khai: 59 playlist, 2.240 vị trí, 2.081 ID; số thực tế phản ánh các chỉnh sửa/xóa đã lưu của quản trị viên.

Marker `imported:<sourcePlaylistId>:v1` chỉ nhập một lần, không ghi đè tên/thứ tự/bài đã sửa và không khôi phục dữ liệu bị xóa. Quyền nghe công khai và quyền quản lý của người tạo giữ cơ chế cũ. Không thay schema, xác thực hoặc mã player.

## Kiểm chứng

111/111 test và TypeScript đạt. Test bao phủ nguồn/count/order/metadata, danh mục công khai và quản trị, gộp trùng, quyền quản lý, DB đã có sửa, retry và không khôi phục bài/playlist bị xóa. Các phép đếm lịch sử của Active dùng bộ nguồn trước lần nhập đó, nên một nguồn mới tái sử dụng bài cũ không làm sai số nhập lịch sử.

Kiểm thử giao diện với player giả lập đang phát ở giây 83 xác nhận lọc Dopamine không thêm player hoặc load lại video. Kiểm thử giới hạn D1 giữ nguyên mức tối đa 50 truy vấn cho lượt khởi tạo DB trống.

Preview Chrome desktop: Dopamine hiển thị 8 playlist và đúng số lượng; Feel Good · Daft Punk mở 14 mục với metadata thực và liên kết nguồn. Tìm Digital Love trả đúng một kết quả. IFrame chính thức tải One More Time ở trạng thái chờ người dùng phát. Ảnh browser thực tế: `docs/previews/dopamine-desktop.jpg`.

WebGL không khả dụng trong browser kiểm tra, fallback SVG hoạt động. Thumbnail YouTube không tải đầy đủ trong browser này. Chưa xác nhận phát âm thanh hoặc kiểm thử trực tiếp trên iPhone/Android trong lần cập nhật này.
