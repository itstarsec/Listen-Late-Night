# Bé ngủ ngoan · Video người dùng chọn

Ngày 31/10/2026, thay toàn bộ nhạc của `be-ngu-ngoan` bằng duy nhất video người dùng chỉ định:

- URL: https://www.youtube.com/watch?v=377o0R09Y0U.
- Tiêu đề YouTube: **Baby Sleep Instantly 🎵 Soothing Lullabies by Brahms & Mozart 🌙 Fall Asleep in 3 Minutes Fast**.
- Kênh: **Baby Sleep Music Melody**.
- Giữ tên playlist **Baby Sleep Instantly** và liên kết `?s=be-ngu-ngoan`.

YouTube oEmbed trả tiêu đề/kênh/thumbnail và thông tin nhúng thành công. Lần đọc watch page bị timeout, nên không ghi thời lượng hoặc khẳng định trạng thái playability chưa xác minh. Player hiển thị thời lượng thật khi kết nối được. Tiêu đề là nội dung do nhà xuất bản đặt, không phải lời hứa bé ngủ ngay; website không loại quảng cáo và không bảo đảm phát nền trên iOS.

Marker khởi tạo cũ được giữ. Revision mới `single-video-377o0R09Y0U-2026-10-v1` dùng `replaceAll:true` để thay toàn bộ bài bằng chính xác một video trong một transaction, tăng version một lần; CAS/retry có giới hạn. Khác với các bản tuyển chọn bổ sung trước đó, lần này không giữ các bài khác trong playlist vì yêu cầu rõ ràng “duy nhất video sau”. Không nhận playlist của chủ khác hoặc khôi phục playlist đã xóa. Sau khi revision hoàn tất, các chỉnh sửa/xóa của quản trị viên vẫn được giữ, không chạy lại thao tác thay thế mỗi lần đọc.

Không sửa playlist khác hoặc tài khoản. Dữ liệu cũ lưu tại [bản sao v35](archives/be-ngu-ngoan-v35.json). Giao diện thường và giao diện tương thích iPad cùng đọc bản mới; liên kết fallback khi tắt JavaScript cũng dùng đúng video mới. Tổng hợp tất cả bài hát loại bỏ các liên kết thuộc riêng nội dung cũ, giữ các bài được playlist khác sử dụng và loại trùng video ID.

Kiểm thử bao phủ dữ liệu mới một video, nâng cấp từ ba phiên bản trước, thay toàn bộ playlist đầy, quyền nghe/sửa, không seed lại sau xóa, rollback, cập nhật đồng thời, retry giới hạn, một player và không autoplay. Chưa có iPad iOS 12 thật để kiểm thử âm thanh hoặc phát nền.

147/147 kiểm thử đạt; TypeScript và `git diff --check` đạt.
