# Bản ru dài · Bé ngủ ngoan

> Tài liệu lịch sử v32. Toàn bộ 23 video của phiên bản này đã được thay bằng [Baby Sleep Instantly](baby-sleep-instantly.md). Dữ liệu cũ được lưu tại [archives/be-ngu-ngoan-v32.json](archives/be-ngu-ngoan-v32.json).

Bổ sung ngày 30/10/2026 vào `be-ngu-ngoan`, giữ nguyên 18 video gốc và nối thêm năm video dưới đây. Tổng mặc định 23 video. Đây là tuyển chọn bổ sung từ các kênh khác; không tuyên bố năm mục này thuộc playlist Super Simple Songs gốc.

| Bản dài | Kênh | Thời lượng | Nguồn |
| --- | --- | --- | --- |
| Hush Little Baby | Wonderful Lullabies | 1:02:18 | https://www.youtube.com/watch?v=wegIRJQdK9Y |
| Brahms Lullaby | Wonderful Lullabies | 1:02:43 | https://www.youtube.com/watch?v=iXC3dxZw-2A |
| Rock-A-Bye Baby | Baby Piano Lullabies | 1:01:19 | https://www.youtube.com/watch?v=aKLsQ3SOXO8 |
| Twinkle Twinkle Little Star | STAR Kids Music | 1:00:16 | https://www.youtube.com/watch?v=61m0Fw4nZII |
| Piano Lullabies | HALIDONMUSIC | 1:24:40 | https://www.youtube.com/watch?v=cMnGfz042C4 |

Đã lấy tiêu đề/kênh qua YouTube oEmbed và thời lượng thực từ metadata công khai của từng trang video, giới hạn ba video được kiểm tra đồng thời. Tất cả là bản ghi hữu hạn, trên 3.600 giây, trạng thái phát công khai `OK` và cho phép nhúng tại thời điểm kiểm tra. Không suy ra thời lượng chỉ từ chữ “1 Hour” trong tiêu đề, không lấy bản livestream, bản reupload có ghi nhận sao chép hoặc các video chỉ quảng bá tần số chữa bệnh/phát triển trí não.

## Cách phát

Nút **Nghe bản dài** tìm video dài đầu tiên còn có trong playlist, dùng luồng player hiện tại để phát từ đó; tắt shuffle và lặp để đi tiếp theo thứ tự danh sách. Các video mới được nối ở cuối nên bản kế tiếp cũng là bản dài. Không tự phát âm thanh khi vừa tải trang. Người dùng vẫn dùng được phát/tạm dừng, trước/sau, tua và lựa chọn lặp. Không tạo thêm IFrame hoặc tách audio khỏi YouTube. Nhóm nút có thể xuống dòng trên màn hình nhỏ.

## Quảng cáo và phát nền

Website không thể cam kết không có quảng cáo trước hoặc giữa video YouTube, dù tiêu đề video có ghi “no ads”. Không có tính năng lọc/skip quảng cáo, không đổi thời điểm bắt đầu để giả vờ bỏ quảng cáo, không che hoặc thay player.

Nguồn chính thức:

- [YouTube Premium benefits](https://support.google.com/youtube/answer/6308116?hl=en): Premium hỗ trợ loại quảng cáo của YouTube; nội dung quảng bá gắn sẵn bởi người làm video có thể vẫn còn.
- [I see ads on YouTube videos](https://support.google.com/youtube/answer/7437519?hl=en): phát nhúng phụ thuộc việc nhận diện đúng tài khoản Premium và cookie YouTube. Đăng nhập quản trị Listen Night không đăng nhập YouTube. YouTube Music Premium không đồng nghĩa đầy đủ quyền lợi video YouTube Premium.

Nếu cần phát bằng tài khoản Premium, có thể dùng nút mở video gốc có sẵn. Website không đổi thiết lập cookie hoặc đăng nhập Google thay người nghe. Điện thoại có thể tạm dừng khi tab ẩn, đổi ứng dụng hoặc khóa màn hình; không bảo đảm phát nền trong trình duyệt, chưa xác minh trên iPhone/Android thật. Không kết luận đã nghe trọn một giờ hoặc không có quảng cáo chỉ từ kiểm thử phần mềm.

## Dữ liệu và quyền

`additionalTracks` lưu nguồn/thời lượng đã xác minh; `additionalRevision` tạo marker riêng trong D1. Lần nâng cấp nối các video còn thiếu vào đúng playlist mẫu đang tồn tại, giữ nguyên tên/thứ tự/bài đã sửa trước đó. Cập nhật dùng version và transaction để marker chỉ được ghi cùng lần cập nhật thành công; xung đột thử lại có giới hạn. Không khôi phục playlist đã xóa, không nhận playlist của chủ khác và không thêm lại video đã xóa sau lần nâng cấp. Playlist đầy vẫn đọc/sửa được; chỉ bổ sung khi có đủ chỗ, không tự bỏ bài cũ.

## Kiểm chứng

130/130 kiểm thử đạt, gồm trạng thái cơ sở dữ liệu đã có từ v31, không thêm trùng/không phục hồi mục đã xóa, rollback khi ghi marker lỗi, giữ thao tác chỉnh sửa đồng thời, chờ đủ dung lượng và thao tác “Nghe bản dài” tự sang bản dài tiếp theo bằng một player. TypeScript và `git diff --check` đạt; kiểm thử giới hạn truy vấn D1 vẫn đạt.

Preview quản lý trong phiên này trả nội dung của một dự án khác dù CLI báo Listen Night đang chạy; không thay mã hoặc cấu hình của dự án đó để khắc phục. Kiểm tra giao diện browser được chuyển sang tên miền Listen Night sau khi triển khai. Các kiểm thử component dùng fixture YouTube API, không thay cho thử âm thanh/quảng cáo thực tế.
