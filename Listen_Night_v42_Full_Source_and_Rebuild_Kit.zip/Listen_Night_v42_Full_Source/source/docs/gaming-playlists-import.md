# Gaming · bản nhập ngày 23/10/2026

Mười playlist được chọn để bổ sung nhiều kiểu nghe khi chơi game: nhạc chiến dịch FPS, radio đua xe, industrial metal, nhạc điện tử, anthem esports và ambient. Đây là tuyển chọn biên tập theo game/phong cách, không phải thống kê những playlist được game thủ nghe nhiều nhất.

Đã đọc frontend công khai của cả mười playlist trên YouTube Music và danh sách có cùng ID trên YouTube. Chỉ lấy các mục thuộc playlist, theo đúng thứ tự nguồn, không nhập gợi ý. Tất cả nguồn đều đọc hết trong một trang. **220/220 mục công khai** có video ID, tiêu đề, kênh và thumbnail; **0 mục trùng, 0 mục không truy xuất** trong lần lấy dữ liệu này. 220 ID đều mới so với bộ seed cũ. YouTube oEmbed của video đầu tiên trong cả mười playlist trả metadata hợp lệ (10/10).

| Playlist | Slug | Video | Nguồn | Loại nguồn |
| --- | --- | ---: | --- | --- |
| Call of Duty · Modern Warfare II | `gaming-call-of-duty` | 26 | [modENASh1](https://music.youtube.com/playlist?list=PLGzEouf2eSRQLKscNuCK2QHIM9xR4c1wA) | Playlist cộng đồng |
| Forza Horizon 5 · Horizon Pulse | `gaming-forza-pulse` | 24 | [My Playback](https://music.youtube.com/playlist?list=PLNgd0ceNt0RbXNBFeli277Z7vS09qs0ks) | Playlist cộng đồng |
| Forza Horizon 5 · Bass Arena | `gaming-forza-bass-arena` | 19 | [My Playback](https://music.youtube.com/playlist?list=PLNgd0ceNt0Ra70F9o4xUq_eF9XsapfJMa) | Playlist cộng đồng |
| Forza Horizon 5 · Hospital Records | `gaming-forza-hospital` | 30 | [F1 Game Soundtracks](https://music.youtube.com/playlist?list=PLNu6CE0lD1wem1Cnl73NB0wHkxLJ_HBbP) | Playlist cộng đồng |
| DOOM · Rip & Tear | `gaming-doom` | 31 | [Nox](https://music.youtube.com/playlist?list=PL3-Zr0Ym0Fgw9G6368AMfMKp9TR1ToaqR) | Playlist cộng đồng |
| Cyberpunk 2077 · Phantom Liberty | `gaming-cyberpunk` | 15 | [P.T. Adamczyk & Jacek Paciorkowski](https://music.youtube.com/playlist?list=OLAK5uy_nwFFMnm0uBqvjFek5ZU7HMmtF6RS_VkhA) | Album / nghệ sĩ được ghi nhận |
| Need for Speed · Most Wanted 2005 | `gaming-need-for-speed` | 32 | [Toni's Music Library](https://music.youtube.com/playlist?list=PLScfAP4C0m2yaWMUbHKqiQMqkFldG-WzR) | Playlist cộng đồng |
| League of Legends · Worlds Anthems | `gaming-league-of-legends` | 13 | [Riot Games Music](https://music.youtube.com/playlist?list=PLJP5_qSxMbkICZcBVLkrfZLAEsR19m7Xm) | Riot Games Music |
| VALORANT · Champions Anthems | `gaming-valorant` | 6 | [Mage](https://music.youtube.com/playlist?list=PLDPabrinOkbs) | Playlist cộng đồng |
| Minecraft · Volume Alpha | `gaming-minecraft` | 24 | [C418](https://music.youtube.com/playlist?list=PLHykAyQQdTart3T8wrDjEnAFEmbVstInA) | Kênh nghệ sĩ |

## Phạm vi tuyển chọn

- Call of Duty: playlist nhạc Modern Warfare II của Sarah Schachner gồm nhạc chiến dịch và menu Warzone 2.0. Chữ “Official” trong tên nguồn không biến kênh cộng đồng modENASh1 thành nhà phát hành chính thức.
- Forza Horizon 5: ba lựa chọn Pulse (indie pop), Bass Arena (EDM) và Hospital Records (drum & bass). Nguồn Hospital gồm 30 mục từ FH5, các bản mở rộng hoặc game Horizon khác; không được mô tả thành album Hospital 20 bài chính thức. Tham khảo hệ radio tại [Forza](https://forza.net/news/forza-horizon-5-gone-gold-soundtrack-reveal) và album gốc tại [Hospital Records](https://hospitalrecords.bandcamp.com/album/forza-horizon-5-hospital-soundtrack).
- DOOM: bộ OST 31 mục bao gồm cả interlude/testament. Need for Speed: 32 mục gồm ca khúc và nhạc nền/menu/logo/rap sheet từ nguồn. Giữ cấu trúc nguồn thay vì tạo tên bài hoặc tách audio.
- Cyberpunk: album Phantom Liberty, 15 mục. YouTube Music và YouTube có thể dùng video tương ứng khác nhau cho một bài album; video ID lưu là các mục công khai theo đúng thứ tự danh sách YouTube của cùng ID playlist.
- League of Legends: playlist Worlds Anthems của Riot Games Music. VALORANT: tuyển chọn cộng đồng sáu Champions Anthems, các video nguồn thuộc kênh VALORANT. Minecraft: Volume Alpha do C418 tạo, 24 mục.
- Chọn nguồn nhạc hữu hạn để nghe liên tục; không lấy playlist hỗn hợp chứa trailer/phỏng vấn hoặc livestream 24/7 chặn hàng phát phía sau.

## Tích hợp và lưu dữ liệu

Snapshot nằm trong `lib/imported-playlists.json`, có `category: gaming`, nguồn, người tạo, thời điểm, số mục và số trang. Không tự đồng bộ về sau. Bộ lọc Gaming có ở thư viện người nghe và danh mục quản trị; mỗi nút danh mục vẫn là hàng riêng cao tối thiểu 48px. Lọc chỉ đổi danh sách playlist đang xem. Mở playlist không đổi bài đang nghe; bấm bài/Phát tất cả mới chọn hàng phát đó. Không thay mã player.

Danh sách tổng hợp vẫn mặc định ở `/`, gộp trùng theo video ID và giữ thứ tự cũ trước mười nguồn mới. Bộ seed đầy đủ có **43 playlist, 1.538 vị trí và 1.407 ID khác nhau**; số đang chạy có thể thấp hơn do các sửa/xóa đã lưu của quản trị viên. Baseline trước triển khai ghi nhận 33 playlist, 1.316 vị trí, 1.185 ID; các chỉnh sửa này phải được giữ nguyên khi thêm 220 mục mới.

Marker `imported:<sourcePlaylistId>:v1` chỉ nhập một lần vào D1. Không ghi đè tên, thứ tự, bài đã sửa và không khôi phục bài/playlist bị xóa. Quyền nghe công khai và quyền quản lý bằng tài khoản quản trị được giữ nguyên. Không có migration hoặc thay cấu hình xác thực.

Đọc metadata theo lô 500 ID, dùng một tham số JSON mỗi query, để toàn bộ thư viện mới vẫn khởi tạo trong giới hạn 50 truy vấn D1 được kiểm thử. Không tăng trần kiểm thử để bỏ qua giới hạn.

## Kiểm chứng

- 104/104 test tự động đạt; TypeScript đạt. Bao phủ count/order/metadata/provenance, danh mục công khai và quản trị, tổng hợp ổn định, quyền chỉnh sửa, DB đã có sửa/xóa, seed lặp và không tái tạo nội dung bị xóa.
- Kiểm thử giao diện với player giả lập đang phát tại giây 83 xác nhận bộ lọc Gaming và mở playlist không tạo thêm player hoặc tải lại bài.
- Preview desktop trong Chrome: thấy Gaming 10, mở Forza Pulse 24 mục có tên/kênh thực; tìm “Heat Waves” ra đúng một mục; mở/đóng hàng phát và chuyển chế độ nhẹ vẫn giữ video hiện tại. D1 local được migration riêng, không thao tác dữ liệu production để kiểm thử.
- IFrame YouTube chính thức tải đúng video Forza sau Phát tất cả, nhưng vẫn buffering ở 0:00 trong trình duyệt kiểm tra; chưa xác nhận âm thanh hoặc phát liên tục thực tế. WebGL không khả dụng trong trình duyệt này, fallback SVG hoạt động. Một số ảnh thumbnail không tải trong môi trường browser này. Không thay mã ứng dụng để bù hạn chế môi trường.
- Ảnh chụp desktop thực tế: `docs/previews/gaming-desktop.jpg` (preview, không phải ảnh WebGL; cảnh dùng SVG fallback).
- Chưa thử trực tiếp trên iPhone/Android. Metadata hợp lệ không cam kết mọi video nhúng được ở mọi quốc gia/thiết bị.
