# Active · Thể thao — bản nhập ngày 24/10/2026

Tám playlist bổ sung lựa chọn nghe cho workout, chạy bộ, đạp xe và thư giãn sau vận động. Chọn theo phong cách EDM/bass, drum & bass, hip-hop, rock, pop/dance, house, nhạc Việt và acoustic. Đây là tuyển chọn biên tập từ các playlist có thật, không phải khảo sát thói quen của mọi người tập thể thao, không đo BPM/cadence hoặc đưa ra chương trình tập luyện.

## Nguồn và số lượng

Đã đọc frontend công khai của từng playlist trên YouTube Music và danh sách YouTube cùng ID, lấy đúng phần playlist theo thứ tự gốc; cả tám nguồn đều đọc hết trong một trang, không nhập video gợi ý.

| Playlist | Slug | Người tạo nguồn | Loại nguồn | Mục nguồn | Đã nhập | Không truy xuất |
| --- | --- | --- | --- | ---: | ---: | ---: |
| Workout Pulse · NCS | `active-workout-ncs` | [NoCopyrightSounds](https://music.youtube.com/playlist?list=PLRBp0Fe2GpgklJUWqAx_Yq2-yVjEfDVae) | Kênh phát hành NCS | 96 | 96 | 0 |
| Run Flow · Drum & Bass | `active-running-dnb` | [NoCopyrightSounds](https://music.youtube.com/playlist?list=PLRBp0Fe2GpgnMixb9nPG9yBOGKpCWXtyH) | Kênh phát hành NCS | 73 | 73 | 0 |
| Power Set · Hip-Hop | `active-strength-hiphop` | [stormwave](https://music.youtube.com/playlist?list=PLcDWUWbiuoCE) | Cộng đồng | 69 | 62 | 7 |
| Run & Rock · Guitar Energy | `active-running-rock` | [Kayak, Running, Games and answering questions](https://music.youtube.com/playlist?list=PLg3s2-sFy5VBg5ZLwN0CzMG51SF4bs7gj) | Cộng đồng | 25 | 23 | 2 |
| Move Together · Pop Classics | `active-cardio-pop` | [Steph Shanks](https://music.youtube.com/playlist?list=PL5sCQfX0zpD2S4foifinyLwSljBhn_Sqz) | Cộng đồng | 80 | 71 | 9 |
| Pedal Flow · House Mixes | `active-cycling-house` | [Brian Williams](https://music.youtube.com/playlist?list=PLN7JxcwkfWTYioTgj4xn-1hIhDWR6fKN5) | Cộng đồng | 28 | 27 | 1 |
| Workout Việt · Remix | `active-viet-remix` | [CÂU LẠC BỘ UP GYM](https://music.youtube.com/playlist?list=PL2mEYLxUC7SlOFDw50TQMJIgk3RHg_Vpz) | Cộng đồng | 82 | 76 | 6 |
| After Move · Chill & Acoustic | `active-cool-down` | [Chris Hunt](https://music.youtube.com/playlist?list=PLuWLfz7Wq1HJnMpOg2qdeCUY_SMwtuP3F) | Cộng đồng | 16 | 16 | 0 |

Có **469 mục nguồn**, **444 vị trí công khai được nhập**, **25 mục không truy xuất**, **0 ID lặp trong từng nguồn**. Giữa các playlist Active có 12 vị trí trùng, nên nhóm này có **432 ID khác nhau**. Có bốn ID đã thuộc bộ seed trước đó; thêm **428 ID mới** vào danh sách tổng hợp. Video vẫn xuất hiện ở mỗi playlist nguồn, chỉ gộp một lần khi nghe Tất cả bài hát.

Hai playlist đầu là nguồn do NoCopyrightSounds tạo. Các nguồn còn lại là playlist cộng đồng; không gán chúng thành bảng xếp hạng chính thức hoặc danh sách phổ biến nhất.

- Workout Pulse: nguồn NCS có EDM, trap, dubstep, bass; Run Flow là playlist drum & bass do cùng kênh tạo.
- Run & Rock: 23 mục công khai của nguồn Running Rock. Không thay bằng MV khác để che hai mục nguồn bị thiếu.
- Move Together: tên nguồn có “Top 100”, nhưng frontend thực tế có 80 mục và truy xuất được 71; giao diện dùng tên biên tập Pop Classics, không tuyên bố đã nhập 100 bài.
- Pedal Flow gồm 27 video và DJ mix house/deep house/funky/disco, có nhiều mix dài. Không đếm các bài bên trong mỗi mix thành những track giả. Không có giới hạn thời lượng buổi tập hoặc đồng bộ tốc độ đạp xe.
- Workout Việt giữ nguyên 76 mục công khai của CÂU LẠC BỘ UP GYM: gồm cả V-pop, remix, EDM và một số MV nguyên bản.
- After Move có 16 bài pop, ballad, acoustic theo Chris Hunt. Đây là lựa chọn âm nhạc thư giãn, không có tuyên bố tác dụng y tế.

Metadata thực gồm video ID, tiêu đề, kênh và thumbnail. Kiểm tra thêm video đầu tiên của tám nguồn bằng YouTube oEmbed, **8/8 trả metadata hợp lệ**; điều này không chứng minh mọi video đều nhúng/phát được tại mọi vùng hoặc thiết bị.

## Tích hợp và lưu trữ

Snapshot ở `lib/imported-playlists.json` có `category: active`, nguồn, người tạo, thời gian, số mục và số trang. Không tự đồng bộ nguồn sau ngày nhập.

Danh mục **Active · Thể thao** dùng icon tập luyện và bộ đếm, có ở thư viện nghe và bộ lọc trang quản trị. Nút danh mục giữ hàng riêng tối thiểu 48px, hỗ trợ bàn phím và trạng thái chọn. Lọc danh mục hoặc duyệt playlist không khởi tạo lại player hoặc đổi hàng đang phát.

Trang mặc định **Tất cả bài hát** giữ thứ tự các nguồn cũ rồi thêm tám nguồn mới, gộp trùng theo ID. Bộ seed có **59 playlist, 2.242 vị trí, 2.083 ID khác nhau**. Baseline production trước triển khai: 51 playlist, 1.796 vị trí, 1.653 ID; dữ liệu thực phản ánh chỉnh sửa/xóa của quản trị viên.

Marker `imported:<sourcePlaylistId>:v1` giúp nhập đúng một lần, không ghi đè tên/thứ tự/bài đã sửa hoặc khôi phục dữ liệu bị xóa. Quyền nghe công khai và quyền chỉnh sửa của quản trị viên giữ cơ chế cũ.

Bổ sung upsert metadata có điều kiện: một bản nhập đã kiểm tra, còn mới hơn cache lỗi và có kênh, có thể điền tên/kênh còn thiếu. Không ghi đè metadata thành công đang có hoặc dùng snapshot cũ thay cache mới hơn. Chỉ cập nhật cache metadata; không thay tên, thứ tự, chủ sở hữu, version hoặc thời điểm của playlist dùng chung. Giới hạn lô nhập 250 bản ghi và lô đọc 500 ID được giữ nguyên; kiểm thử khởi tạo D1 trống vẫn không vượt 50 query.

## Kiểm chứng

109/109 test tự động và TypeScript đạt. Bao phủ nguồn/count/order/metadata, danh mục công khai và quản trị, gộp trùng trong Active và với thư viện cũ, quyền chỉnh sửa, DB đã có dữ liệu sửa, retry, không tái tạo bài/playlist đã xóa và ba trường hợp cập nhật metadata (thiếu, thành công, snapshot cũ).

Kiểm thử giao diện với player giả lập đang phát ở giây 83 xác nhận lọc Active không thêm player hoặc load lại video. Preview Chrome desktop: thấy Active 8 và đủ tên/count, mở Run & Rock có 23 bài, nguồn và hai mục thiếu; tìm “Linkin Park” trả đúng Bleed It Out. YouTube IFrame tải đúng Thunderstruck ở trạng thái chờ người dùng phát. Ảnh browser thực tế: `docs/previews/active-desktop.jpg`.

WebGL không khả dụng trong browser kiểm tra, fallback SVG hoạt động. Thumbnail YouTube không tải đầy đủ trong browser này. Chưa xác nhận phát âm thanh hoặc kiểm thử vật lý trên iPhone/Android trong lần cập nhật này; không thay mã player.
