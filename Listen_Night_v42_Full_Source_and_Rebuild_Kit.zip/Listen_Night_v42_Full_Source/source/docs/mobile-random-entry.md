# Khởi đầu ngẫu nhiên trên điện thoại

Màn hình tối đa 900px mở `/` sẽ chọn đều ngẫu nhiên trong các playlist công khai có bài. Đầu tiên lấy `GET /api/collections` chứa tóm tắt danh mục, rồi chỉ gọi `GET /api/sessions/<slug>` của playlist được chọn. Không khởi chạy request tổng hợp hoặc metadata của toàn thư viện trong luồng này. Không tự phát âm thanh.

Link `?s=<slug>` mở đúng playlist ngay, không đợi danh mục. Desktop giữ mặc định Tất cả bài hát. Người nghe chủ động chọn Tất cả bài hát hoặc mở `?view=all` vẫn tải thư viện tổng hợp; liên kết chia sẻ giữ ý định này. Khi có cả hai tham số, `s` được ưu tiên. Sau lựa chọn ngẫu nhiên, URL ghi lại slug để tải lại giữ playlist đó; mở lại `/` mới sẽ chọn ngẫu nhiên lại, có thể trùng lựa chọn trước.

Không chọn lại khi đổi kích thước/xoay màn hình. Request danh mục đến muộn không được thay một lựa chọn người nghe vừa thực hiện. Danh mục lỗi/trống hiện nút thử lại; playlist tải lỗi được thử lại đúng slug, không quay sang tải toàn thư viện. Giữ player và hàng đang nghe khi xem playlist khác hoặc thư viện tổng hợp.

## Kiểm chứng

- Bộ test đầy đủ: 124 kiểm thử; bổ sung kiểm thử component cho mạng ban đầu, không tự phát, link cụ thể, desktop, link tổng hợp trên điện thoại, catalogue rỗng/lỗi, thử lại đúng playlist và request đến muộn.
- Kiểm thử component xác nhận chỉ một player, giữ trạng thái đang phát và vị trí 83 giây khi người nghe chủ động mở Tất cả bài hát. Đây là fixture YouTube API, không phải kiểm chứng âm thanh thật.
- Preview Chrome trong hai iframe rộng 320px và 390px: trang chủ chọn lần lượt **Adrenaline · Carpenter Brut** (19 bài) và **Forza Horizon 5 · Horizon Pulse** (24 bài). Cả hai hiển thị đúng danh sách riêng và một player. Không tràn ngang; chiều rộng nội dung lần lượt 305px/375px do thanh cuộn trong khung preview.
- Tìm theo video ID thật đang hiển thị trả về một bài, tìm không khớp hiển thị trạng thái rỗng. Mở thư viện và lọc Dopamine hiển thị đúng tám playlist; ID iframe YouTube giữ nguyên sau thao tác.
- Ảnh: [mobile-random-entry.jpg](previews/mobile-random-entry.jpg), ảnh chụp browser thực của hai khung preview.

## Giới hạn kiểm thử

Chưa đo tốc độ trên mạng di động hay thiết bị iPhone/Android thật. Preview sử dụng SVG fallback vì WebGL không khả dụng; một số thumbnail và metadata YouTube không tải được trong môi trường kiểm thử, nên có trạng thái fallback. Không khẳng định thời gian tải cụ thể hoặc đã xác minh âm thanh/phát nền trên thiết bị thật. Không đổi dữ liệu playlist, quyền quản trị hoặc cấu hình đăng nhập.
