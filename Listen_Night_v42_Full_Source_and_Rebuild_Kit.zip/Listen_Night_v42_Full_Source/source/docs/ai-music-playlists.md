# Nhạc AI · Tuyển chọn theo hai video tham khảo

Danh mục `ai` / **Nhạc AI** được thêm vào thư viện nghe, bộ lọc quản trị và nhóm
playlist của giao diện tương thích iOS 12. Không thay đổi player hoặc cơ chế
chọn ngẫu nhiên một playlist khi khách mở trang trên điện thoại.

Ba playlist, mỗi playlist tám video, tổng cộng **24 video khác nhau**:

- `ai-say-tinh` — **Say tình · F47 Cover**: bắt đầu bằng `BFJLoa1g5Pw`.
- `ai-pho-mua` — **Phố mưa · TRO Music**: bắt đầu bằng `KOCVv4acEhg`.
- `ai-tinh-ca-dem` — **Tình ca đêm · AI Ballad**: acoustic/R&B chill, kết hợp
  F47 Cover và TRO - Music.

Đây là playlist biên tập trong Listen Night, không phải bản sao một playlist
YouTube chính thức. Hai URL người dùng gửi là video đơn; video 26:03 của TRO
được giữ nguyên thành một mục. Liên kết nguồn mỗi playlist mở video tham khảo,
không tự tạo mã playlist hoặc lấy video từ Mix cá nhân.

## Nguồn và kiểm tra ngày 01/11/2026

- https://www.youtube.com/@chammusicboxnf47cover/videos
- https://www.youtube.com/@tro-music9c/videos
- https://www.youtube.com/watch?v=BFJLoa1g5Pw
- https://www.youtube.com/watch?v=KOCVv4acEhg

Lựa chọn theo cùng kênh/giọng F47, tiêu đề, các bản ballad, acoustic và chủ đề
hoài niệm được nhà phát hành mô tả. Không tuyên bố đã phân tích âm thanh hoặc
xếp hạng độ tương đồng. Tiêu đề, kênh, thumbnail xác minh bằng YouTube oEmbed;
24/24 preview nhúng công khai trả `OK`/`playableInEmbed=true` lúc kiểm tra.
Không tải hay lưu tệp âm thanh/video, không dùng API nội bộ của YouTube.

Bối cảnh nhạc AI/F47 và TRO - Music đối chiếu từ thông tin công khai về chính
các dự án; không khẳng định mọi khâu sáng tác, lời, phối khí đều do AI làm:

- https://www.24h.com.vn/giai-tri/ca-si-ai-hat-50-nam-ve-sau-duoc-yeu-thich-c731a1750794.html
- https://tuoitre.vn/nhac-viet-ai-hoan-hao-ve-am-thanh-tranh-cai-ve-cam-xuc-20251024090827316.htm

Danh sách ID và kết quả kiểm tra ở `ai-music-audit.json`. Không lưu HTML thô,
tracking, thông tin liên hệ hoặc token phát video vào source.

## Lưu trữ và quyền

Marker khởi tạo riêng từng slug, không dùng chung marker theo video nguồn.
Seed chỉ thêm một lần, giữ nguyên các playlist cũ, không khôi phục playlist
đã xoá hoặc ghi đè tên/thứ tự quản trị đã sửa. D1 `video_blocks` và tác vụ
bảo trì hiện tại tiếp tục có hiệu lực. Thông tin đang phát và vị trí nghe
giữ riêng trên thiết bị; đổi bộ lọc không tải lại iframe.

Nghe không cần đăng nhập; quản trị viên hiện có được sửa/xoá và quản lý bài.
Không đổi tài khoản, secret, origin quản trị hay quyền truy cập của Site.
