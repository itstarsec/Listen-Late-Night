# Kiểm tra video không phát được

Tác vụ cập nhật D1 trực tiếp, không cần mở trang nghe hoặc publish lại. Tài
khoản quản trị, session slug, tên playlist và các video còn lại được giữ nguyên.

## Luồng đã triển khai

- Tối đa **360 ID/ngày** theo giờ Việt Nam; mỗi lô 20 ID, tối đa hai request
  YouTube đồng thời, timeout 6,5 giây/request. Với khoảng 2.261 ID ban đầu,
  một vòng kiểm tra đầy đủ cần khoảng bảy đêm nếu YouTube trả lời bình thường.
- Ưu tiên video nghi lỗi và các video player báo lỗi 100/101/150. Báo cáo công
  khai chỉ là gợi ý kiểm tra, không có quyền xoá. ID được kiểm tra phải có trong DB.
- Khi có `YOUTUBE_API_KEY`, dùng `videos.list` chính thức, đọc `status.embeddable`,
  privacy/upload status và các giới hạn liên quan. Key không có hoặc API thất bại:
  đọc **trang embed công khai của chính YouTube**, gửi Referer là origin website,
  phân tích JSON preview, không chạy JavaScript hoặc gọi API nội bộ YouTube.
- Chỉ gỡ sau **hai kết quả lỗi rõ ràng cùng lý do, cách nhau ít nhất sáu giờ**.
  Chặn nhúng, video đã xoá/riêng tư là lý do hợp lệ. Lỗi mạng, quota, lỗi 5/153,
  đăng nhập, bot wall, tuổi/vùng quốc gia hoặc định dạng trang lạ là `unknown`.
  `unknown` hoặc kết quả thành công xoá chuỗi xác nhận lỗi trước đó.
- Trước khi gỡ: lưu bản sao từng mục, playlist và vị trí vào `video_removals`.
  Lưu dấu vĩnh viễn vào `video_blocks`, rồi gỡ khỏi mọi playlist trong cùng
  transaction. Trigger D1 ngăn seed, nhập file, nhập URL hay ghi đè dữ liệu cũ
  làm video đó quay lại. Bản sao không tự phục hồi; chủ website có thể yêu cầu
  kiểm tra và khôi phục có chủ đích sau khi video hoạt động lại.
- Có khoá 120 giây chống chạy chồng. Giữ nhật ký lô kiểm tra 90 ngày, giữ nguyên
  bản sao và danh sách chặn. Nếu hai lô liên tiếp toàn `unknown`, runner dừng.
- Không kiểm tra hàng nghìn video khi khách mở trang; player đang mở không bị
  khởi tạo lại. Playlist đã mở trước đợt dọn sẽ cập nhật khi người nghe tải lại.

## Chạy trên Sites

Site cung cấp MCP `POST /mcp` (khai báo capability `mcp`). Sites xác thực caller;
tool kiểm tra thêm email chủ website trong secret `MAINTENANCE_OWNER_EMAIL` và
Site-scoped user ID. Quyền xem trang công khai không cấp quyền bảo trì. Đăng nhập
username/password ở `/bim` vẫn hoạt động như trước.

Tool `video_maintenance_status` đọc trạng thái đã lưu. Tool
`run_video_maintenance({limit:20})` kiểm tra một lô. Cloud task liên kết Site gọi
hai tool này; mỗi lượt tối đa 18 lô, dừng khi `daily_limit`, `complete`, `busy`,
lỗi quyền/lưu dữ liệu hoặc hai lô liên tiếp toàn `unknown`. Đọc lại status sau
lượt chạy. Không thay secret, seed, auth, audience hoặc publish khi chạy định kỳ.
Nếu tool chưa xuất hiện, lấy `get_site(include_mcp_connection:true)` và kết nối
đúng plugin của Site; không giả lập identity header hoặc dùng public endpoint để
bỏ qua quyền. Không xoá dữ liệu dựa trên suy đoán của mô hình hay kết quả tìm kiếm.

Lịch đề xuất: **03:30 mỗi ngày, Asia/Bangkok (UTC+7)**. Đây là khung giờ giả định
ít người nghe; chưa có thống kê truy cập để khẳng định là giờ thấp điểm nhất.
Lịch được lưu riêng ở Sites cloud task, không phải cron trong trình duyệt.

## Quản trị và triển khai khác

- `/api/admin/maintenance` GET: status, cần cookie quản trị đang còn hiệu lực.
- POST cùng URL, body `{"limit":20}`: kiểm tra thủ công một lô, cùng giới hạn và
  Origin guard. Không có tham số ép xoá hoặc bỏ bước xác nhận.
- Ngoài Sites có thể chạy `node scripts/check-videos.mjs` bằng scheduler của bạn;
  truyền `LISTEN_SITE_ORIGIN` và owner OAuth `SITE_MCP_ACCESS_TOKEN` qua secret
  của môi trường. Dòng cron theo TZ Việt Nam: `30 3 * * *`. CLI không tạo/refresh
  OAuth token; ưu tiên Site cloud task vì đã có kết nối được cấp quyền.
- Tuỳ chọn thêm secret `YOUTUBE_API_KEY` để dùng schema API ổn định hơn. Public
  embed preview không phải API có hợp đồng ổn định: thay đổi HTML sẽ chuyển thành
  `unknown`, không xoá nhầm. Preview OK/embeddable không đảm bảo phát được ở mọi
  quốc gia, thiết bị, thời điểm hay mọi hạn chế bản quyền.

Tất cả cấu hình mẫu ở `.env.example`. Không lưu key, cookie, OAuth token hoặc
mật khẩu trong source, instructions hoặc prompt của lịch chạy.
