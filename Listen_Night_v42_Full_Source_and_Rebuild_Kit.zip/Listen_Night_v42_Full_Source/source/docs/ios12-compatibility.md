# iPad iOS 12 · Giao diện nghe tương thích

> Playlist `be-ngu-ngoan` hiện có duy nhất [video 377o0R09Y0U](baby-single-video.md). Các kiểm chứng sáu bài dưới đây mô tả dữ liệu ở v34; kiến trúc nghe tương thích giữ nguyên và đọc danh sách hiện tại từ cùng API.

Tình huống báo lỗi: iPad cũ chạy iOS 12.5.8 không mở được website và `?s=be-ngu-ngoan`. Mã hiện đại của v33 chứa optional chaining/nullish coalescing, dùng `replaceChildren`, `MediaQueryList.addEventListener` và các API mới hơn. Vite mặc định nhắm Safari 16.4 trở lên; chỉ bật chế độ SVG trong React không giải quyết được lỗi parse hoặc API khi khởi động. Đây là nguyên nhân tương thích xác định được từ source và bundle; chưa có thiết bị iOS 12 thật để xác nhận biểu hiện trên máy người dùng.

Nguồn kỹ thuật: [Vite · Browser compatibility](https://vite.dev/guide/build#browser-compatibility), [WebKit · Safari 13.1](https://webkit.org/blog/10247/new-webkit-features-in-safari-13-1/), [YouTube IFrame API](https://developers.google.com/youtube/iframe_api_reference).

## Cách hoạt động

Worker trả HTML nghe riêng cho iOS/Safari trước 16.4 ngay tại `/`, trước khi trình duyệt cần phân tích bundle React. Giữ nguyên query `s` là session slug, hash và liên kết playlist. Trang `/lite?s=be-ngu-ngoan` luôn mở giao diện tương thích, kể cả khi yêu cầu chế độ desktop khiến User-Agent khác đi. Script ES5 ở trang hiện đại cũng kiểm tra các tính năng cần thiết và chuyển sang `/lite` nếu thiếu, giữ query/hash. Logic này không chuyển hướng `/bim`, API hoặc các chunk của ứng dụng.

HTML/CSS/JavaScript cổ điển nằm trong `compat/`, không tải React, Three.js, WebGL, font ngoài hoặc bộ polyfill lớn. JavaScript được kiểm tra bằng parser với `ecmaVersion:5`, dùng DOM, XMLHttpRequest và mouse/touch/native controls có trên iOS 12. Không dùng fetch, Promise, module, optional chaining, `dialog`, Clipboard API hay API theo dõi bố cục mới. CSS có kích thước chạm ít nhất 48px, input 16px, khoảng đệm safe-area; không dựa vào flex-gap, aspect-ratio hoặc backdrop-filter.

Nút HTML có các chức năng phát tất cả, nghe bản dài, trước/sau, phát/tạm dừng, tua, ngẫu nhiên và ba chế độ lặp. Dùng đúng một YouTube IFrame Player API, tái sử dụng khi chuyển bài. API sẵn sàng trước/sau playlist đều được xử lý. Không phát âm thanh khi tải trang; Safari chặn phát thì hiện “Chạm để phát” và hướng dẫn chạm trực tiếp trong video. Khung player luôn hiển thị, tối thiểu 200 × 200px, ưu tiên 16:9. Trạng thái nút dựa trên sự kiện player. END lặp hoặc cũ không được bỏ qua bài chưa bắt đầu. Tự chuyển khi kết thúc; dừng tự bỏ qua sau ba video lỗi. Có thử lại tải YouTube và liên kết video gốc khi player bên YouTube không chạy được.

Mặc định máy cũ chỉ tải catalogue tóm tắt rồi chọn một playlist không trống. Link có `?s=` mở đúng playlist ngay, không đợi catalogue. Không tự tải `/api/library`; chỉ tải toàn bộ khi người nghe chọn rõ “Tất cả bài hát” hoặc `?view=all`. Danh sách hiển thị 20 bài mỗi trang; hàng phát vẫn chứa toàn bộ bài. Thumbnail chỉ tạo cho trang hiện tại, kích thước cố định. Metadata được lấy từng nhóm tối đa sáu ID, một request đang chạy; backend giữ giới hạn ba truy xuất YouTube đồng thời. Đổi playlist/tìm kiếm/ẩn hàng phát không tạo lại iframe hoặc mất vị trí đang nghe.

Session, playlist và quyền quản trị vẫn dùng backend D1 cũ. Giao diện tương thích phục vụ nghe công khai, không cung cấp đường ghi hoặc thay cơ chế đăng nhập. localStorage chỉ lưu vị trí/tùy chọn; bị chặn hoặc hết dung lượng vẫn nghe được. URL chia sẻ trở lại `/` để thiết bị mới dùng giao diện hiện đại. Sao chép/xuất URL có ô văn bản để chọn và sao chép thủ công khi Safari không cho phép sao chép tự động. Dữ liệu người dùng/tiêu đề render bằng `textContent`, URL YouTube tạo từ ID hợp lệ.

HTML đáp ứng theo User-Agent có `Vary: User-Agent` và `Cache-Control: private, no-store` để tránh trộn hai giao diện trong cache. Không sửa dữ liệu playlist `be-ngu-ngoan` hoặc các tài khoản quản trị.

## Kiểm chứng và giới hạn

145 kiểm thử đạt, gồm 12 kiểm thử mới cho phân tuyến User-Agent/HEAD/cache, cú pháp ES5, thiếu API hiện đại/localStorage, tải sáu bài Baby Sleep Instantly, race khi đổi playlist, player chỉ tạo một lần, không autoplay, thao tác phát/tua/END, phân trang/tìm/xuất, retry mạng, render tiêu đề an toàn, metadata theo hàng đợi và dừng skip lỗi. TypeScript và `git diff --check` đạt. Fixture giả lập API/DOM kiểm chứng luồng ứng dụng, không phải mô phỏng hoàn chỉnh WebKit hoặc nghe nhạc thực tế.

Lần mở preview bằng Cloud Browser ngày 30/10 bị hệ thống duyệt tự động từ chối vì hạn mức sử dụng. Không chuyển sang công cụ điều khiển trình duyệt khác để né giới hạn. Chưa kiểm thử trực tiếp iPad, Safari 12.5.8, phát âm thanh trọn bài, khóa màn hình, quảng cáo hoặc phát nền. [YouTube khuyến nghị trình duyệt cập nhật](https://support.google.com/youtube/answer/175292?hl=en); khả năng chạy mã bên trong iframe của YouTube vẫn do YouTube quyết định. Bản tương thích không sửa/chép/proxy nội dung player hay loại quảng cáo. Khi YouTube từ chối chính trình duyệt đó, người nghe vẫn thấy thông tin playlist và nút mở video gốc.
