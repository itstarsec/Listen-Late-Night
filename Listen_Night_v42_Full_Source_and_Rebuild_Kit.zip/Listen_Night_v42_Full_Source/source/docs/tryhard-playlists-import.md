# Try Hard · bản nhập ngày 20/10/2026

Tám playlist được tuyển chọn cho những buổi làm lab, CTF, đọc tài liệu hoặc làm việc đêm. Đây là đề xuất biên tập, không phải bảng xếp hạng hoặc thống kê thói quen của mọi pentester. Cách chọn tham khảo chia sẻ trực tiếp của chuyên gia tại [Bishop Fox](https://bishopfox.com/blog/music-to-hack-to) và [thảo luận OSCP](https://www.reddit.com/r/oscp/comments/hm3crt): sở thích rất đa dạng, từ ambient, nhạc phim đến synthwave. Không có quan hệ tài trợ hoặc chứng thực từ những nguồn này.

Đã đọc frontend công khai của từng playlist trên YouTube Music và danh sách bài công khai của cùng ID trên YouTube. Chỉ lấy phần playlist, đọc hết continuation nếu có, giữ thứ tự xuất hiện đầu tiên. Tiêu đề, kênh và thumbnail có nguồn thực; không tự đặt metadata cho video. Đã kiểm tra thêm YouTube oEmbed cho video đầu tiên của cả tám playlist, 8/8 trả metadata hợp lệ. Đây không phải kiểm thử phát âm thanh hoặc cam kết mọi video nhúng được tại mọi quốc gia.

| Playlist | Slug | Nguồn | Mục nguồn | Đã nhập | Không truy xuất | Trùng ID |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Try Hard · Mr. Robot | `tryhard-mr-robot` | [mellophello](https://music.youtube.com/playlist?list=PLgK9PtkIOqeAVW_4e-WT7DJeHajdd9B1B) | 32 | 31 | 1 | 0 |
| Recon · Ambient Focus | `tryhard-ambient` | [Downtempo Vibes](https://music.youtube.com/playlist?list=PLe8L6QnLLKDZst5MuV5Qg1GChg-eVluin) | 11 | 11 | 0 | 0 |
| Night Shift · HOME | `tryhard-home` | [Doomed](https://music.youtube.com/playlist?list=PLKpH9TsJs6VLqp2I259RtVAi803qk8pCU) | 12 | 12 | 0 | 0 |
| Synthwave · Lofi Girl | `tryhard-lofi-synthwave` | [Lofi Girl - Synthwave](https://music.youtube.com/playlist?list=PLUNz3rL3KK9W21UspvmRt3bwsKZFX73DE) | 29 | 29 | 0 | 0 |
| Cyberpunk · Coding Sessions | `tryhard-cyberpunk` | [Hack Certify](https://music.youtube.com/playlist?list=PLo_jEktp4IqyElhGKD83_7sSO3ZnAUsj4) | 95 | 95 | 0 | 0 |
| Darksynth · Perturbator | `tryhard-perturbator` | [NeonAether](https://music.youtube.com/playlist?list=PLT3ccL9Gu5yo1ERUCR8J2VNM85m-C4nQX) | 13 | 13 | 0 | 0 |
| Adrenaline · Carpenter Brut | `tryhard-carpenter-brut` | [NeonAether](https://music.youtube.com/playlist?list=PLT3ccL9Gu5ypx2v25i-dEdrbJZZLqLz3I) | 20 | 19 | 1 | 0 |
| Flow State · Liquid DnB | `tryhard-liquid-dnb` | [dtrywets](https://music.youtube.com/playlist?list=PLXvmzH9jr9M7Ag9HtEGcchGi4lKjsZKA_) | 46 | 33 | 12 | 1 |

Tổng cộng **243 video ID mới**, **14 mục không truy xuất được**, **1 mục trùng** trong nguồn Liquid DnB. Tất cả nguồn đã hết trang tiếp theo. Một số video là album/mix dài; không tách thành các track giả. Số mục YouTube Music hiển thị có thể khác số video công khai trả về trên YouTube (đặc biệt Carpenter Brut và Liquid DnB); chỉ nhập video có ID, tiêu đề và kênh trong danh sách công khai, không bổ sung từ gợi ý. Số mục nhìn thấy trên YouTube Music được lưu riêng ở `musicVisibleItemCount`.

Snapshot ở `lib/imported-playlists.json` giữ ID nguồn, tên nguyên bản, người tạo, thời điểm và số lượng. Bộ lọc **Try Hard** ở thư viện và trang quản trị chỉ lọc danh sách playlist; không thay đổi hàng đang phát hoặc khởi tạo lại player. Mọi playlist mới được liệt kê công khai và nằm trong **Tất cả bài hát**, gộp trùng ổn định theo video ID.

Sau bổ sung, bộ seed có **33 playlist**, **1.318 vị trí**, **1.187 video ID khác nhau**. Dữ liệu thực tế tùy chỉnh sửa trong D1. Các định nghĩa cũ được giữ nguyên. Marker riêng `imported:<sourcePlaylistId>:v1` giúp việc triển khai lại không thêm trùng, không ghi đè tên/thứ tự/bài đã sửa và không khôi phục playlist đã xóa. Quyền nghe công khai và quyền quản lý bằng tài khoản quản trị được giữ nguyên. Đây là bản nhập tại thời điểm trên, không tự đồng bộ theo nguồn.

Kiểm tra: 102 test tự động đạt, TypeScript đạt. Test bao phủ nguồn/count/order/metadata, danh mục công khai, gộp vào thư viện, quyền sửa/xóa, bổ sung trên DB đã có chỉnh sửa, seed lặp, bộ lọc quản trị và bộ lọc người nghe khi player đang phát tại giây 83. Không có công cụ control-browser trong môi trường; chưa kiểm tra bố cục bằng trình duyệt, WebGL hoặc phát âm thanh trên thiết bị thật trong lần cập nhật này.
