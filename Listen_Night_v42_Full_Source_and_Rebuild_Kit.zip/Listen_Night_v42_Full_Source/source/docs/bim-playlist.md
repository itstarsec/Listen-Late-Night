# bim · Nhạc Việt

Ngày 01/11/2026, bổ sung toàn bộ 25 bài trong danh sách người dùng dán trực tiếp.
Danh sách cá nhân được xác định từ tên bài, kênh và thời lượng người dùng cung cấp;
không suy ra mã Mix `RD...` hoặc truy cập tài khoản YouTube của người dùng.

Giữ session và tên hiển thị `bim`, category `viet` (**Nhạc Việt**).
Mở bằng `/?s=bim`; trang quản trị `/bim` là một route riêng.

## Bổ sung và lưu trữ

- Bản đang chạy trước cập nhật có Em Không Khóc (`w8r5zDA4awM`).
- Giữ marker gốc `imported-video:bim:w8r5zDA4awM:v1`.
- 24 bài mới được thêm theo thứ tự qua `additionalTracks`, revision `bim-mix-25-2026-11-v1`.
- Migration chỉ nối các ID chưa có, giữ tên, thứ tự và các bài quản trị đã bổ sung.
- Migration có CAS và receipt một lần trong D1; đọc lại không thêm trùng, không khôi phục playlist hoặc bài đã bị quản trị xoá sau khi áp dụng.
- Các trigger `video_blocks` tiếp tục chặn video bị bảo trì gỡ. Không thay đổi auth, audience hoặc lịch bảo trì.
- `sourceKind=curated`, `sourcePlaylistId=null`; liên kết nguồn là video đầu, không giả định có URL gốc của Mix cá nhân.

## Đối chiếu nguồn

Cả 25 ID được YouTube oEmbed xác nhận tiêu đề và kênh; trang watch xác nhận ID và thời lượng.
Thời lượng khớp danh sách (chênh tối đa một giây do hiển thị làm tròn).
Cả 25 trang embed trả preview `OK`, `playableInEmbed=true` tại thời điểm kiểm tra.
Đây là kiểm tra metadata/preview nhúng, không phải xác nhận phát âm thanh đầy đủ trên mọi trình duyệt hoặc khu vực.
Chi tiết máy đọc được nằm trong `docs/bim-mix-audit.json`.

| # | Video ID | Tiêu đề YouTube | Kênh | Thời lượng người dùng |
| --- | --- | --- | --- | --- |
| 1 | `w8r5zDA4awM` | Em Không Khóc / buitruonglinh ft vuphungtien | buitruonglinh | 4:30 |
| 2 | `ZlvAZsA3Nuc` | Táo – KỊCH BẢN / Official Music Video (feat. Hoàng Yến Chibi) | Táo | 4:48 |
| 3 | `8STFDAO7UEQ` | Young H x Táo x Sol'Bass - 2 5 (Official Lyrics Video) | Young H | 5:03 |
| 4 | `IJML-4ZYejA` | Lựa Chọn Của Em / buitruonglinh ft. vuphungtien, dautatdat | buitruonglinh | 4:29 |
| 5 | `f-VsoLm4i5c` | Từng Ngày Yêu Em / buitruonglinh | buitruonglinh | 3:42 |
| 6 | `nJiC65S5TZw` | Anh muốn mình như con thuyền kia - Ngắn ft Mhee (M/V) | BẠN CÓ TÀI MÀ | 3:26 |
| 7 | `QTULiXpMgLk` | SIVAN - Tìm Thấy Nhau / WEMORIES (EP) | SIVAN | 3:46 |
| 8 | `gJAbDSse5WM` | Hngle - Tìm em ft. Bảo Anh / Official Music Video | HNGLE / hưng lê | 4:33 |
| 9 | `YfMRfJW0kM0` | Táo - Blue Tequile //Official Audio | Táo | 3:23 |
| 10 | `vjTx0TWNfnI` | Dab, Chilythoi - overtired | Dab | 2:55 |
| 11 | `K01LvulhFRg` | Khổng Minh x Châu Nhuận Phát - ''E LÀ ĐÔN CHỀ''  Prod.@tiengaz | Dagoats House | 3:11 |
| 12 | `eTXDB5i2z6A` | LAM / Huỳnh Công Hiếu x Lãng / "Đà Lạt Ep2" | BẠN CÓ TÀI MÀ | 4:28 |
| 13 | `3J1hqqcAxrM` | CƠN MƯA THÁNG 5 - BỨC TƯỜNG - Lyric | Trí Thông Ngô | 4:04 |
| 14 | `bjEbdWv2k6I` | LOPE DOPE - FUU VÀ BIỂN (OFFICIAL MV LYRICS) | Lope Dope | 5:19 |
| 15 | `y8W0jp0AU2s` | Nơi Pháo Hoa Rực Rỡ (Đi Để Trở Về 8 ) - Hoàng Hải Trở lại Thanh Xuân | Hoàng Hải Official | 4:14 |
| 16 | `2-zSSzg8i3Y` | PC - 10 Ngàn Năm ( Prod. Duckie ) [Official Audio] | PC FeelingSoundz | 4:00 |
| 17 | `OA8s2Gr3KEE` | W/n - Text 07 (ft. 267) | W/n | 4:19 |
| 18 | `ovExasFv7Nw` | Sáo - Ngồi Nhìn Em Khóc (prod. Heki) I Lyrics Video | Sáo | 4:34 |
| 19 | `69ZDBWoj5YM` | Giờ Thì (Official MV) / buitruonglinh | buitruonglinh | 3:58 |
| 20 | `ZRhNBbcV6AE` | [XHTDRLX3] This Love (OST Hậu Duệ Mặt Trời) - Lâm Bảo Ngọc hát tiếng Hàn khiến Dongwoon ngỡ ngàng | FOREST STUDIO | 4:20 |
| 21 | `9UcQ7ddVjoc` | Hngle - KHÔNG BUÔNG ft. Ari / Official Music Video | HNGLE / hưng lê | 3:25 |
| 22 | `wdQoVMlVMGY` | Ngủ sớm đi em - DucMinh ( Prod. by GC ) | DucMinh | 3:56 |
| 23 | `f9P7_qWrf38` | bình yên / Vũ. ft. Binz (Official MV) từ Album "Bảo Tàng Của Nuối Tiếc" | Vũ Official | 3:23 |
| 24 | `LZZexCVBHfM` | SAO EM LẠI TẮT MÁY / Phạm Nguyên Ngọc ft. VAnh (Original) | Phạm Nguyên Ngọc | 3:25 |
| 25 | `X9N4QJpK7TA` | LIVE OUTDOOR / Phạm Kỳ live " Anh Chẳng Thể " | PHẠM KỲ OFFICIAL | 3:59 |
