# Bé ngủ ngoan · 0–12 tháng

> Tài liệu lịch sử v31–v32. Theo yêu cầu tiếp theo, toàn bộ 23 video đã được thay bằng tuyển chọn [Baby Sleep Instantly](baby-sleep-instantly.md), giữ nguyên slug `be-ngu-ngoan`.

Playlist hiện được bổ sung năm video dài hơn một giờ, giữ 18 video gốc bên dưới đúng thứ tự nguồn. Chi tiết nguồn bổ sung, nút **Nghe bản dài** và giới hạn quảng cáo ở [baby-longform.md](baby-longform.md). Các số liệu 18 mục của nguồn bên dưới mô tả playlist YouTube gốc, không phải tổng 23 video trong website sau bổ sung.

- Slug: `be-ngu-ngoan`.
- Nguồn chính thức: [Super Simple Lullabies for kids!](https://music.youtube.com/playlist?list=PLdkj6XH8GYPTOoIkfvhzIoaYccAhxB-Lf), do **Super Simple Songs - Kids Songs** tuyển chọn.
- Ngày kiểm tra nguồn: 30/10/2026. Playlist công khai có 18 video, một trang dữ liệu, không có video trùng ID hay mục không truy xuất được. YouTube Music cũng hiển thị 18 mục.
- Giữ nguyên thứ tự của nguồn. Có bài ru ngắn và video tuyển tập dài; không cần phát hết playlist trong một lần nghe.
- Đã xác minh toàn bộ 18 video qua YouTube oEmbed, giới hạn ba request đồng thời. Tiêu đề, tên kênh và thumbnail dùng dữ liệu thật, không bịa metadata. Việc nhúng/phát tiếp tục phụ thuộc YouTube, vùng và trình duyệt; không bảo đảm không có quảng cáo.

Một số bài: **Hush Little Baby**, **Twinkle Twinkle Little Star**, **Sweet Dreams (Goodnight Song)**, **Rock-A-Bye Little One**, **Good Night Sleep Tight**. Đây là lựa chọn theo sắc thái ru ngủ để ba mẹ thử cùng bé; không khẳng định mọi bé đều thích hoặc bảo đảm hiệu quả gây ngủ, không gán tác dụng phát triển trí não/chữa bệnh.

Mô tả playlist gợi ý mở loa nhỏ, đặt xa bé và nghe trong thời gian ngắn. Cơ sở: [American Academy of Pediatrics · How Noise Affects Children](https://www.healthychildren.org/English/safety-prevention/all-around/Pages/how-noise-affects-your-child.aspx), phần giảm âm lượng thiết bị và giới hạn âm thanh ở nơi bé ngủ. Không đặt phần trăm âm lượng hay số dB cố định vì website không đo được mức âm thực tại tai bé.

## Lưu trữ và quyền

Playlist được thêm vào `lib/imported-playlists.json` và khởi tạo bền vững trong D1 bằng marker nguồn riêng. Nằm trong thư viện tuyển chọn; cả hai tài khoản quản trị hiện có quản lý được như các playlist mẫu. Nghe qua liên kết không cần đăng nhập. Lần khởi tạo/lặp lại không thêm trùng, không ghi đè các chỉnh sửa và không khôi phục playlist đã xóa. Tất cả bài hát tổng hợp theo video ID như cũ; điện thoại giữ cách mở một playlist ngẫu nhiên, không tự tải thư viện tổng hợp.

## Kiểm chứng

Bổ sung test API cho link trực tiếp trước khi catalogue khởi tạo, 18 ID/thứ tự/metadata, quyền nghe/sửa, xuất hiện trong console quản trị và thư viện tổng hợp; thử tải lại, sửa, xóa bài và xóa playlist không bị seed lại. Bộ kiểm thử hiện có tiếp tục bao phủ một player, không tự phát, liên kết cụ thể trên điện thoại và khởi đầu ngẫu nhiên gọn.

Bản đầu v31: 126/126 kiểm thử đạt; TypeScript và `git diff --check` đạt. Preview Chrome mở đúng tên playlist, 18 hàng bài hát với metadata thật, một YouTube iframe, không tự phát. Player đã kết nối và hiển thị thời lượng bài đầu 2:35, chờ thao tác người nghe. Ảnh browser bản đầu: [be-ngu-ngoan.jpg](previews/be-ngu-ngoan.jpg). Môi trường preview không có WebGL và không tải được một số thumbnail; ứng dụng dùng fallback hiện có.

Chưa kiểm thử âm thanh hoặc mức âm lượng trên iPhone/Android thật. Không kết luận hiệu quả giấc ngủ từ kiểm thử phần mềm.
