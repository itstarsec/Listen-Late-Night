# imagine you are in Paris at night (jazz playlist)

- Session: `paris-at-night-jazz`.
- Nguồn: https://www.youtube.com/watch?v=EQfKnvCFs1Y.
- Kênh: **elisad**, https://www.youtube.com/@elisad6.
- Thời lượng thực: **18:37** (1.117 giây).
- Kiểm tra ngày 31/10/2026: oEmbed trả tiêu đề/kênh thật; metadata công khai của trang video có trạng thái `OK`, `playableInEmbed=true`, không phải livestream.

Nguồn trùng tên yêu cầu là **một video mix**, không phải URL playlist YouTube nhiều video. Playlist trong Listen Night chứa nguyên bản đó thành một mục, không chia giả thành các video/bài hát riêng, không lấy tracklist từ nguồn thứ ba hoặc suy đoán từ tên. Tên và nguồn được hiển thị chính xác; “Xem video nguồn” mở video gốc. Giữ nội dung liên tục và thứ tự của bản mix.

Lưu tên, video ID và thứ tự trong D1 bằng marker `imported-video:EQfKnvCFs1Y:v1`. Lặp lại không thêm trùng, không ghi đè tên/thứ tự đã sửa hoặc khôi phục playlist đã xóa. Nằm trong thư viện tuyển chọn, giao diện iPad tương thích và phần quản trị; thêm một ID vào tổng hợp tất cả bài hát. Không yêu cầu đăng nhập để nghe. Các playlist khác không thay đổi.

Kiểm thử API và component bao phủ link trực tiếp, metadata, loại nguồn video, quyền đọc/sửa, một player, không tự phát, phát tất cả, không tải aggregate trên điện thoại và không khởi tạo lại sau xóa. Khả năng phát/quảng cáo và phát nền vẫn phụ thuộc YouTube/trình duyệt; không kết luận đã nghe trọn bản mix từ kiểm thử fixture.

147/147 kiểm thử đạt; TypeScript và `git diff --check` đạt, bao gồm các kiểm thử tương thích iOS 12 hiện có.
