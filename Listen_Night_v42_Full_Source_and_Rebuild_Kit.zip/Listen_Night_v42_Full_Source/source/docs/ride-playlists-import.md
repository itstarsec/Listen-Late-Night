# Ride · Mô tô — bản nhập ngày 23/10/2026

Tám playlist được chọn cho người yêu mô tô: classic rock/cruiser, southern rock/touring, country, blues/garage/café racer, synthwave/retrowave, phonk và nhạc Việt về những chuyến đi. Đây là tuyển chọn biên tập theo phong cách, không phải bảng xếp hạng thói quen nghe của người lái xe phân khối lớn.

Hướng tuyển chọn tham khảo [hướng dẫn road trip của Las Vegas Harley-Davidson](https://news.lasvegasharleydavidson.com/blog/ultimate-motorcycle-road-trip?hs_amp=true), trong đó có classic rock, Americana, outlaw country và modern blues; tham khảo thêm [chia sẻ night ride của cộng đồng](https://www.reddit.com/r/motorcycles/comments/1mo0g75/give_me_your_city_riding_at_night_music/) về electronic/synthwave. Những nguồn này giúp chọn phong cách; không dùng số liệu lượt nghe giả hoặc gán mọi playlist cộng đồng thành playlist chính thức của hãng xe.

## Nguồn và phạm vi

Đã đọc frontend công khai trên YouTube Music và danh sách YouTube cùng ID của từng nguồn. Chỉ nhập mục thuộc playlist; giữ thứ tự và đọc hết một trang cho cả tám nguồn. Không nhập video gợi ý. Có **284 mục nguồn**, **260 video công khai truy xuất được**, **24 mục không khả dụng**, **0 ID lặp trong nguồn**. Tám playlist mới không lặp ID với nhau. Có **12 ID đã thuộc thư viện cũ**, nên thêm **248 ID mới** vào bộ seed tổng hợp.

| Playlist | Slug | Người tạo nguồn | Mục nguồn | Đã nhập | Không khả dụng |
| --- | --- | --- | ---: | ---: | ---: |
| Cruiser · Harley Road Songs | `ride-cruiser` | [tommykiddd](https://music.youtube.com/playlist?list=PLfDdnqJzu919YyQ93e8q5Up6EylW0ExZY) | 30 | 30 | 0 |
| Touring · Southern Rock | `ride-southern-rock` | [MARK NEWMAN](https://music.youtube.com/playlist?list=PL4DOVH_fJydgihwDu7ge3u7lFLM6eZZw0) | 18 | 17 | 1 |
| Open Road · Country | `ride-country` | [PlaylisterCrazy](https://music.youtube.com/playlist?list=PLL1NQSkQU5Ld7LSD55wkX4aNz2KVti8HL) | 29 | 24 | 5 |
| Café Racer · Blues & Garage | `ride-cafe-racer` | [Robert Helmuth](https://music.youtube.com/playlist?list=PLyhKs8nOF5KP1IFvz0BddEk3Pp_u30jVi) | 49 | 44 | 5 |
| Night Ride · The Midnight | `ride-the-midnight` | [Topic Albums Playlists Only](https://music.youtube.com/playlist?list=PLMynaxX_I0z-7AMkboScWDZCTa8Xzb3V-) | 14 | 14 | 0 |
| Neon Ride · FM-84 | `ride-fm84` | [Topic Albums Playlists Only](https://music.youtube.com/playlist?list=PLMynaxX_I0z_wrTK8gOuMuKL6ee0HK-A8) | 22 | 11 | 11 |
| Sportbike · Phonk | `ride-sportbike` | [Zombr3x (Phonk)](https://music.youtube.com/playlist?list=PLGBKsNyGY-ach-E0fkiLSDgzVbs_wO3F_) | 100 | 99 | 1 |
| Đi để trở về · Nhạc Việt | `ride-viet-roadtrip` | [Mavis Vi Vu Ký](https://music.youtube.com/playlist?list=PLYIPTnT7JwmPomvB-Y0dA3p1VQlQ87UdX) | 22 | 21 | 1 |

- Tất cả nguồn là playlist cộng đồng. Các playlist có tên Harley Davidson không phải do thương hiệu Harley-Davidson phát hành.
- Southern Rock và Blues & Garage dùng nhiều video trên kênh nghệ sĩ/Topic. Hai lựa chọn synthwave dùng video của The Midnight và FM-84 - Topic, theo playlist do Topic Albums Playlists Only tổng hợp.
- Night Ride có 12 bài Endless Summer và hai bonus track Comet, Bend. Neon Ride lưu 11 mục công khai từ nguồn 22 mục; không tự tạo bản thay thế cho 11 mục không truy xuất.
- Sportbike giữ 99 mục công khai theo nguồn Zombr3x (Phonk); có nhiều video là remix hoặc bản phonk house. Không diễn giải những tên bài hoặc hình ảnh thành khuyến nghị tốc độ hay cách điều khiển xe.
- Đi để trở về là tên hiển thị được biên tập cho Playlist Du Lịch của Mavis Vi Vu Ký, không phải tên nguyên bản nguồn. Các bài tiêu biểu: Đưa Nhau Đi Trốn, Cho Tôi Lang Thang, Đi Theo Bóng Mặt Trời.
- Loại khỏi lựa chọn các playlist trộn motovlog/promo hoặc có số mục vượt giới hạn session. Các nguồn được chọn đều có điểm kết thúc rõ ràng, không chứa livestream vô hạn.

Video ID, tiêu đề, kênh và thumbnail được lấy từ dữ liệu công khai thực. YouTube oEmbed của video đầu tiên trong cả tám nguồn trả metadata hợp lệ (8/8). Không khẳng định mọi video nhúng được ở mọi vùng hoặc thiết bị. Snapshot ở `lib/imported-playlists.json` lưu nguồn, thời gian, số mục và số trang; không tự đồng bộ thay đổi sau này của YouTube.

## Tích hợp

- Danh mục **Ride · Mô tô** có biểu tượng mô tô, số playlist và bộ lọc ở thư viện công khai; trang quản trị có cùng bộ lọc.
- Nút danh mục tiếp tục dùng hàng riêng cao tối thiểu 48px, có tên truy cập và trạng thái chọn. Chọn bộ lọc hoặc mở playlist không đổi hàng đang phát.
- Các bài mới được tổng hợp vào trang mặc định **Tất cả bài hát**, gộp trùng theo video ID, giữ thứ tự thư viện cũ trước các nguồn Ride. 12 video đã có giữ vị trí cũ và thêm thông tin playlist nguồn.
- D1 dùng marker `imported:<sourcePlaylistId>:v1`, chỉ nhập một lần; triển khai lại không ghi đè chỉnh sửa hoặc khôi phục dữ liệu đã xóa. Quyền nghe công khai và quyền quản lý giữ cơ chế hiện có.
- Bộ seed sau bổ sung có **51 playlist, 1.798 vị trí, 1.655 ID khác nhau**. Baseline production trước triển khai có 43 playlist, 1.536 vị trí, 1.405 ID; số thực tế phản ánh sửa/xóa của quản trị viên.
- Tăng lô nhập metadata từ 100 lên 250 bản ghi qua một tham số JSON, để lần khởi tạo DB trống vẫn nằm trong kiểm thử giới hạn 50 truy vấn D1. Giữ nguyên giới hạn kiểm thử, schema và cấu hình xác thực.

## Kiểm chứng

106/106 test tự động và TypeScript đạt. Bao phủ count/order/nguồn/metadata, danh mục người nghe và quản trị, chia sẻ 12 ID cũ, gộp trùng, quyền chỉnh sửa, seed vào DB đã có dữ liệu sửa, retry và không tạo lại bài/playlist bị xóa. Kiểm thử giao diện xác nhận lọc Ride giữ một player đang phát ở giây 83 và không load lại video.

Preview Chrome desktop: thấy Ride 8, đủ tám playlist và số bài; mở Café Racer có 44 bài cùng kênh nghệ sĩ thực, nguồn Robert Helmuth và thông báo năm mục thiếu. Tìm “Rival Sons” trả hai kết quả. Mở playlist giữ video/hàng tổng hợp cũ. Ảnh chụp browser thật: `docs/previews/ride-desktop.jpg`.

WebGL không khả dụng trong trình duyệt kiểm tra, fallback SVG hoạt động; ảnh thumbnail YouTube không tải đầy đủ ở browser này. Lần cập nhật này kiểm tra thêm nội dung/bộ lọc, không xác nhận lại phát âm thanh hoặc kiểm thử vật lý iPhone/Android.
