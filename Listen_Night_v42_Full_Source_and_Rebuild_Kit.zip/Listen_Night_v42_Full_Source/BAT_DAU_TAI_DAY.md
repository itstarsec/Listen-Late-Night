# Listen Night · Gói source và kế thừa v42

Đây là **toàn bộ 209 file source tracked của bản v42**, kèm snapshot dữ liệu đang lưu, công cụ phục hồi một lần và prompt dựng Site mới. Commit gốc: `ed82cca0f6055c8de85adb401048bbffd0f89537`.

## Cách dùng với cuộc trò chuyện mới

1. Đính kèm `Listen_Night_v42_Full_Source_and_Rebuild_Kit.zip`.
2. Dán toàn bộ nội dung `PROMPT_DUNG_LAI_LISTEN_NIGHT_v42.md` trong gói hoặc file prompt được bàn giao riêng.
3. Cung cấp mật khẩu muốn dùng cho các tài khoản quản trị khi được hỏi. Mã có sẵn công cụ tạo salted hash; secret thật không nằm trong gói.
4. Yêu cầu ChatGPT đọc `RESTORE_AND_DEPLOY.md` và chạy công cụ chuẩn bị trước khi tạo Site mới. Không để nó tạo UI mới chỉ dựa trên mô tả.

## Có gì trong gói

| Đường dẫn | Nội dung |
| --- | --- |
| `source/` | React/Vinext, Three.js, SVG, ES5 Lite, admin, trò ném file, API/auth/maintenance, migrations, assets, tests, lockfile và scripts build nguyên bản |
| `data/runtime-snapshot.json` | 9 bảng nghiệp vụ đọc từ D1, gồm playlist thật và thứ tự hiện tại |
| `data/catalogue.json` | Thông tin 73 playlist công khai, category và nguồn |
| `data/inventory.json` | Số lượng, provenance và giới hạn snapshot |
| `tools/prepare-new-site.mjs` | Tạo checkout độc lập, bỏ ID Site cũ, thêm bộ phục hồi dữ liệu một lần |
| `tools/test-restore.mjs` | Kiểm tra toàn bộ dữ liệu phục hồi, auth fixture, import, idempotency và rollback bằng SQLite |
| `tools/verify-live.mjs` | Đọc lại dữ liệu sau khi Site mới chạy |
| `tools/verify-bundle.py`, `INTEGRITY.json` | Kiểm tra SHA-256 từng file và source nguyên bản |
| `config/` | Cấu hình runtime mẫu và định nghĩa lịch bảo trì để tạo lại trên Site mới |

## Dữ liệu được giữ

- **75 session**: 73 công khai, 2 chỉ mở bằng liên kết.
- Toàn bộ session: **2.495 vị trí bài**, **2.324 video ID duy nhất**.
- Thư viện công khai: **2.476 vị trí**, gộp còn **2.305 video**.
- **bim** thuộc Nhạc Việt, đủ **25 bài** theo danh sách mới nhất.
- Baby Sleep Instantly chỉ có `377o0R09Y0U`; Paris at night jazz chỉ có `EQfKnvCFs1Y`; Nhạc AI có đủ ba playlist.
- 2.355 dòng metadata, seed markers, import receipts và trạng thái/nhật ký bảo trì. Hiện snapshot không có video bị chặn hoặc bản sao gỡ video.

## Những phần cần thiết lập trên Site mới

Mật khẩu/hash thật, secret bảo trì, cookie/phiên đăng nhập, domain mới, quyền MCP và lịch cloud không phải sourcecode. Gói có cấu hình và hướng dẫn để tạo lại chúng; không có token hay secret cũ. Vị trí nghe/localStorage của từng thiết bị cũng không phải dữ liệu chia sẻ.

Giữ nguyên mã cho phép bảo toàn giao diện và chức năng ứng dụng. Không thể cam kết YouTube luôn cho nhúng, không quảng cáo, phát nền hoặc cho kết quả giống nhau trên mọi thiết bị. Snapshot là bản đọc nhiều trang, không phải bản chụp transaction toàn database; các mảng bài dài đã được đối chiếu lại bằng version/name/updatedAt.

**Website gốc không bị thay đổi hay publish lại trong quá trình xuất này.**
