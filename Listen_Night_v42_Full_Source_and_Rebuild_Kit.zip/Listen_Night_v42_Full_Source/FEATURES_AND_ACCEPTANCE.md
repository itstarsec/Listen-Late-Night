# Checklist chức năng v42 và nghiệm thu bản sao

Mỗi ô chỉ đánh dấu khi đã thực hiện ở môi trường được nêu. Mock/SQLite, browser cloud và thiết bị vật lý là ba phạm vi kiểm tra khác nhau.

## Dữ liệu và thư viện

- [ ] 73 playlist trong catalogue; 75 session trong không gian quản trị. Hai session link-only không tự xuất hiện trong catalogue hoặc tổng hợp công khai.
- [ ] Công khai 2.476 vị trí /2.305 ID duy nhất; toàn không gian 2.495 vị trí /2.324 ID.
- [ ] Các category: tất cả, Nhạc Việt, Nhạc AI, Try Hard, Ride · Mô tô, Active · Thể thao, Dopamine, Gaming; giữ source/curator/mood/accent.
- [ ] bim25 đúng thứ tự; baby1 `377o0R09Y0U`; Paris1 `EQfKnvCFs1Y`; ba playlist AI, Shelby và tất cả playlist cũ còn nguyên.
- [ ] Reload/redeploy không thêm trùng hoặc trả lại bài/playlist đã xoá; đổi tên không đổi slug. Các seed markers và receipt phục hồi được giữ.
- [ ] Desktop mặc định Tất cả bài hát; mobile <=900px mặc định một playlist random; `?s=` và `?view=all` đúng ý nghĩa.

## Nghe và mô hình

- [ ] Một player chính thức; video/điều khiển YouTube hiển thị; phát sau thao tác, inline và tap-to-play khi cần.
- [ ] Play/pause, trước/tiếp, seek/time, shuffle, repeat off/one/all, ended, video lỗi và giới hạn skip.
- [ ] Duyệt playlist, hàng đợi, metadata, đổi chế độ hoặc sửa bài khác giữ player và vị trí. Xoá current chọn successor đúng.
- [ ] Bàn đĩa 3D thật, kim liền, nhãn/title đúng, đĩa tăng/giảm tốc từ trạng thái player, buffering/đèn/kim phản ánh thật.
- [ ] Camera có giới hạn, damping, reset, auto rotate mặc định tắt; click khác drag, touch tương tác chủ động; mọi nút mô hình có HTML tương ứng.
- [ ] 3D tải động, DPR giới hạn, paused render khi ngoài viewport/tab ẩn; reduced motion, context-loss/SVG fallback và cleanup.
- [ ] Chế độ nhẹ không dư đối tượng trên đĩa. ES5 `/lite` cùng backend, 20 bài/trang và đủ hàng phát; iOS cũ được route đúng.

## Quản trị và nhập

- [ ] Trang nghe không có nút login; `/bim` là console riêng không khởi tạo audio/3D. Hai tài khoản quản trị độc lập, logout một người không xoá playlist.
- [ ] Tạo, sửa tên, xoá có xác nhận; add URL/ID một hoặc nhiều dòng, normalize, dedup, báo số thành công/lỗi, refresh metadata.
- [ ] Tìm/lọc/sort/phân trang, kéo thả và nút lên/xuống; chọn/xoá nhiều bài, xuất URL, modal căn giữa.
- [ ] File TXT/CSV/TSV/M3U/M3U8 chứa URL được xem trước; tên playlist hợp lệ và chống trùng.
- [ ] Trò ném file: thẻ bám chuột tại điểm bấm, kéo nhiều góc/lấy lực, radar chấm đỏ, spin và collision vành, vào/rớt ra theo vật lý; chỉ lưu sau khi xuyên qua lưới; thao tác HTML thay thế dùng được.
- [ ] Backend từ chối anonymous/khác quyền, Origin sai, stale version; retry không nhân đôi. Dữ liệu là text, không HTML thực thi; giới hạn input/file/session/rate hoạt động.

## Bảo trì và vận hành

- [ ] Writer MCP đã cấp quyền đúng Site mới, status trước/sau lưu bền vững; lịch mới 03:30 Asia/Bangkok, không đụng bản gốc.
- [ ] 360 ID/ngày, 20/lô, tối đa18; ưu tiên lỗi; hai clear failures cùng lý do >=6h mới remove/archive/block.
- [ ] Network/login/bot/region/5/153 là unknown; dừng hai lô toàn unknown, daily_limit/complete/busy, lỗi quyền/lưu.
- [ ] Restore trên D1 trống nguyên tử, retry được; DB có dữ liệu bị từ chối, không có reset DB hoặc auth bypass.
- [ ] 320px không tràn ngang, input16px, focus/labels/keyboard, vùng chạm44px+, safe area, lazy ảnh, trạng thái loading/error/retry và long title.

Không có chức năng bỏ quảng cáo, tải audio, vượt khoá vùng, đảm bảo phát nền, tạo account/RBAC qua UI hoặc tự đồng bộ mọi playlist nguồn. Đây không phải những tính năng đã tồn tại trong v42.
